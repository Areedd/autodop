"""Render checkpoint-lineage evidence and offline original-teacher accuracy."""
import json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]/'runs/report90_20260912';O=R/'original_teacher_audit';a=json.loads((O/'RESULT.json').read_text());line=json.loads((O/'LINEAGE.json').read_text());d=json.loads((O/'DATA_PROVENANCE.json').read_text())
old=json.loads((R.parent/'multi_structure_feedback_cost05_20260910/PAIR_RANKING_AUDIT.json').read_text());assert next(h for p,h in old['source_sha256'].items() if p.endswith('multi_structure_feedback_cost05_20260910/model/cost.pt'))==a['sha256'];v=old['cohorts']['valid14'];assert a['evaluations']['curated_valid_pairs']['original_multistage_transformer']['rank_accuracy']==(v['pairs']-v['after_reversed_or_tied'])/v['pairs']
prior=json.loads((R/'model_comparison_audit/DIAGNOSTICS.json').read_text())
for k,n in [('transformer_rank_s17','retrained30_transformer'),('xgb_rank_s17','xgboost_rank')]:assert a['evaluations']['fixed90_uniform'][n]['rank_accuracy']==prior['uniform_test_ranking'][k]['accuracy']
lines=['# 原多阶段 Transformer：训练追溯与排序准确率', '', '本次直接加载原成本模型，保持其 checkpoint 自带词表、归一化和图结构配置，仅进行离线前向推理；不重训，不执行新 SQL。', '',f"模型：`{a['model']}`；SHA256：`{a['sha256']}`。", '', '## 训练过程', '',
'最后 10 个阶段可依据 checkpoint 内 initial_sha256 与前驱文件哈希连续匹配，每阶段的协议或 checkpoint 契约均记录最终第20轮。因此，这一可核实连续阶段包含200轮微调；不是模型全生命周期总轮数。', '',
'基本目标为动态间隔排序损失：让实测快配置的分数高于慢配置。全参数微调阶段增加旧评分保持项（权重10，每步16个旧配置），将新模型在旧训练配置上的评分约束在上一阶段模型附近；旧模型冻结、验证集不用于梯度。后期将修复计划组与其余训练计划组赋予相同总权重，组内再按计划均衡，避免排序对多的计划支配训练。', '',
'| 按继承顺序 | 训练计划/验证计划 | 轮数 | 主要目的与数据 |','|---|---:|---:|---|']
notes={
'multi_low_cost_repair03_20260909':'多低DOP偏好分支的误排序修复；保留原58计划评分约束。',
'legacy_cost_repair01_20260909':'加入4个legacy分支计划；旧66计划配置作为评分保持样本。',
'legacy_cost_repair02_20260909':'加入搜索暴露的反例配置；保持原70计划的旧评分。',
'legacy_cost_repair03_20260909':'继续修复反例；4978个训练排序对，保持971个旧配置评分。',
'range_coverage_cost01_20260910':'新增4个范围覆盖结构计划、28个配置和76个排序对。',
'range_coverage_cost02_20260910':'为同4个计划追加4个配置、102个同批次反馈排序对。',
'multi_low_coverage_cost02_20260910':'新增4个多低DOP分支结构计划；新4计划与旧74计划各占一半排序权重，5324训练对。未继承失败的cost01。',
'multi_low_coverage_cost03_20260910':'追加4个搜索配置和121个同批次排序对；5445训练对。',
'multi_low_retention_cost04_20260910':'追加8个配置、80个排序对；5525训练对，对4个修复计划与其余74计划分组均衡。',
'multi_structure_feedback_cost05_20260910':'联合修复multi_low/range/legacy共12计划；追加20个配置、262个排序对，最终5787训练对；其余66计划902旧配置保持评分。'}
for x in reversed(line):
 name=Path(x['directory']).name;lines.append(f"| {name} | {x['train_plans']}/{x['valid_plans']} | 20 | {notes[name]} |")
lines+=['', '后6个阶段的学习率为1e-4，固定20轮；训练结构、词表及归一化保持前驱设置。更早阶段缺少部分协议，未据后期设置补写其学习率。', '',
'更早的保留记录还包括：supplier_network_balanced_cost 的58训练/14验证计划基座（4531训练对，按计划均衡）；其哈希与 range_embedding_repair03 的来源哈希一致，后者增加4个范围分支计划、两种算子签名，只训练16个新增嵌入参数，并记录980个旧配置评分一致。', '',
'审计缺口：当前连续链在 multi_low_cost_repair02 的 d9f38f… checkpoint 处中断；该文件已缺失，其名称只能由保留搜索诊断中的模型哈希确认。因此，不能完全证明更早各候选如何接入最终链，也无法恢复精确的初训轮数。另有 multi_low_cost_repair01 的100轮受限训练失败记录；不能因名称相邻就把它计入当前模型的训练继承链。', '',
'## 训练数据', '',
'- 最终数据共92个计划、1225个“计划+DOP配置”耗时样本、6323个保留排序对。',
'- 训练：78计划、1077配置样本、5787排序对；验证：14计划、148配置样本、536排序对。',
'- TPC-DS SF100 数据库上的生成查询：88计划、1145配置样本；TPC-H SF10 数据库上的供应关系等生成查询：4计划、80配置样本。这里是底层数据来源，不表示使用标准benchmark全套查询。',
'- 结构包括扫描控制、窗口/排名、顾客与产品后续活动、群体留存、范围分支组合、多低DOP分支、legacy分支和供应关系连接等。',
'- 最终追加的三组反馈分别包含32/28/28个被测配置，执行96/84/84次。与旧数据重合的配置保留旧标签，净新增20个配置；新增262个同批次排序对。',
'- 当前90查询与该数据集的SQL SHA交集为0；它们仍共享底层数据和构造思想，不等于结构家族完全独立。', '',
'## 本次重新测得的准确率', '', '| 评估集合 | 排序对数 | 原多阶段Transformer | 30轮重训Transformer | XGBoost排序 |', '|---|---:|---:|---:|---:|']
labels={'curated_train_pairs':'原数据保留训练对（仅拟合指标）','curated_valid_pairs':'原数据保留验证对','validation':'验证配置重新枚举，过滤差距<3%','fixed90_uniform':'固定90的5档统一DOP','fixed90_observed_pool':'固定90的已测候选子集（含异构）'}
for key,label in labels.items():
 vals=a['evaluations'][key];n=vals['original_multistage_transformer']['ranking_pairs'];acc=[f"{100*vals[k]['rank_accuracy']:.2f}%" for k in ['original_multistage_transformer','retrained30_transformer','xgboost_rank']];lines.append(f"| {label} | {n} | {' | '.join(acc)} |")
lines+=['', '原数据保留对使用 pairs.jsonl 的 fast/slow 标签，不重新选对；重新枚举口径则比较同一计划配置样本的耗时，过滤差距低于3%的对。两种口径的集合不同，因此90.86%与86.41%不是矛盾结果。评分相等均计为错误。原数据536个验证对的结果还与已有 PAIR_RANKING_AUDIT.json 的487对正确/49对反转或打平完全一致。', '',
'原验证集在多阶段训练中反复被评估，并用于旧模型退化验收门槛；它没有用于梯度，却不等于全程未查看的最终测试集。', '',
'固定90的候选子集包含5个统一DOP和10种回放模式实际测过的配置；相同配置合并各模式三次均值。排除原生模式、在线策略的置信度回退及在线开销差异。它不是原搜索全部候选池，也不是穷举空间；仅作为本次固定筛选集的事后诊断，不用于训练或挑选模型。', '',
'| 配置选择损失（越低越好） | 原多阶段Transformer | 30轮重训Transformer | XGBoost排序 |', '|---|---:|---:|---:|']
for key in ['validation','fixed90_observed_pool']:
 vals=a['evaluations'][key];lines.append('| '+labels[key]+' | '+' | '.join(f"{100*vals[k]['mean_regret']:.2f}%" for k in ['original_multistage_transformer','retrained30_transformer','xgboost_rank'])+' |')
lines+=['','选择损失按计划平均：所选配置耗时/已测最快配置耗时−1。此离线选择结果复用原始耗时，没有重新执行原模型新选择的配置，不能直接替代新一轮在线性能实验。', '',
'结论：多阶段模型确实比30轮重训模型更强，在原保留验证对上领先14.37个百分点，也领先XGBoost约5.04个百分点；但在当前90查询已测候选子集上，XGBoost仍领先约6.80个百分点。结果指向评估分布与候选集合差异，不能仅用“原模型没参与”解释之前全部差距。', '',
'证据：RESULT.json、POOL_SCORES.json、LINEAGE.json、DATA_PROVENANCE.json。复现脚本：tools/autodop/scripts/report90_measure_original_teacher.py。']
(O/'REPORT.md').write_text('\n'.join(lines)+'\n')
(O/'CHECKS.json').write_text(json.dumps({'original_curated_validation_matches_previous_audit':True,'baseline_uniform_accuracies_match_previous_audit':True,'model_sha256':a['sha256'],'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path(__file__).with_name('report90_measure_original_teacher.py')]}},indent=2)+'\n')
