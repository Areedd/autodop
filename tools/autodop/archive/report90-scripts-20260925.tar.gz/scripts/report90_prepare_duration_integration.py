"""Prepare and compile opt-in single-FE experiment sources; never deploy."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parents[3]
RUN = ROOT / 'tools/autodop/runs/report90_20260912'
JAVA = ROOT / 'fe/fe-core/src/main/java'


def main():
    out = RUN / ('duration_integration_' + str(time.time_ns()))
    out.mkdir()
    src = out / 'src'
    sources = {}
    slot = 'com/starrocks/qe/scheduler/slot/'
    for name in ['PredictedDurationQueue', 'PredictedDurationRegistry']:
        path = RUN / 'duration_queue_validation/src' / slot / (name + '.java')
        sources[slot + name + '.java'] = path.read_text()
    sources[slot + 'ReportDurationBridge.java'] = '''package com.starrocks.qe.scheduler.slot;
public final class ReportDurationBridge {
    public static final boolean ENABLED = Boolean.getBoolean("autodop.report.durationQueue");
    public static final PredictedDurationRegistry REGISTRY =
            new PredictedDurationRegistry(4096, 600_000_000_000L, System::nanoTime);
    private ReportDurationBridge() {}
}
'''
    predictor = 'com/starrocks/sql/optimizer/cost/feature/CostPredictor.java'
    value = (JAVA / predictor).read_text()
    value = value.replace('import com.starrocks.common.Config;', '''import com.starrocks.common.Config;
import com.starrocks.qe.ConnectContext;
import com.starrocks.qe.scheduler.slot.ReportDurationBridge;
import com.starrocks.thrift.TUniqueId;''')
    anchor = '            try {\n                // Use Apache HttpClient'
    assert value.count(anchor) == 1
    value = value.replace(anchor, '''            ConnectContext durationContext = ReportDurationBridge.ENABLED ? ConnectContext.get() : null;
            TUniqueId durationId = durationContext == null || durationContext.getExecutionId() == null
                    ? null : durationContext.getExecutionId().deepCopy();
            long durationToken = durationId == null ? 0 : ReportDurationBridge.REGISTRY.begin(durationId);
            boolean durationInstalled = false;
            try {
                // Use Apache HttpClient''')
    anchor = '                httpPost.setEntity(entity);'
    assert value.count(anchor) == 1
    value = value.replace(anchor, anchor + '''
                if (durationToken != 0) {
                    httpPost.setHeader("X-AutoDOP-Execution-Id",
                            com.starrocks.common.util.UUIDUtil.fromTUniqueid(durationId).toString());
                }''')
    anchor = '                        return (long) Double.parseDouble(responseBody);'
    assert value.count(anchor) == 1
    value = value.replace(anchor, '''                        long memory = (long) Double.parseDouble(responseBody);
                        if (durationToken != 0) {
                            org.apache.http.Header duration = response.getFirstHeader("X-AutoDOP-Duration-Ms");
                            if (duration != null) {
                                try {
                                    durationInstalled = ReportDurationBridge.REGISTRY.complete(durationId, durationToken,
                                            Double.parseDouble(duration.getValue()));
                                } catch (NumberFormatException ignored) { /* Unknown prediction uses FIFO fallback. */ }
                            }
                        }
                        return memory;''')
    anchor = '                throw new RuntimeException("Failed to predict memory bytes", e);\n            }'
    assert value.count(anchor) == 1
    value = value.replace(anchor, '''                throw new RuntimeException("Failed to predict memory bytes", e);
            } finally {
                if (durationToken != 0 && !durationInstalled) { ReportDurationBridge.REGISTRY.cancel(durationId, durationToken); }
            }''')
    sources[predictor] = value
    strategy = slot + 'SlotSelectionStrategyV2.java'
    value = (JAVA / strategy).read_text()
    anchor = '            if (opts.getPolicy().equals(QueryQueueOptions.SchedulePolicy.SWRR)) {'
    assert value.count(anchor) == 1
    value = value.replace(anchor, '''            if (ReportDurationBridge.ENABLED) {
                newQueue = new PredictedDurationQueue(s -> ReportDurationBridge.REGISTRY.peek(s.getSlotId()), System::nanoTime,
                        Integer.getInteger("autodop.report.maxDurationBypasses", Integer.MAX_VALUE));
            } else if (opts.getPolicy().equals(QueryQueueOptions.SchedulePolicy.SWRR)) {''')
    # This experiment uses the timeline base jar, which predates the separate FIFO enum experiment.
    fifo = '''            } else if (opts.getPolicy().equals(QueryQueueOptions.SchedulePolicy.FIFO)) {
                newQueue = new FifoSlotQueue();'''
    assert value.count(fifo) == 1
    value = value.replace(fifo, '')
    anchor = '            if (requiringQueue != null) {'
    assert value.count(anchor) == 1
    value = value.replace(anchor, '''            if (requiringQueue instanceof PredictedDurationQueue && newQueue instanceof PredictedDurationQueue) {
                ((PredictedDurationQueue) requiringQueue).transferTo((PredictedDurationQueue) newQueue);
            } else if (requiringQueue != null) {''')
    anchor = '    public void onReleaseSlot(LogicalSlot slot) {'
    assert value.count(anchor) == 1
    value = value.replace(anchor, anchor + '\n        if (ReportDurationBridge.ENABLED) { ReportDurationBridge.REGISTRY.cancel(slot.getSlotId()); }')
    anchor = '        requiringQueue.add(slotContext);'
    assert value.count(anchor) == 1
    value = value.replace(anchor, anchor + '''
        if (ReportDurationBridge.ENABLED) {
            LOG.info("AUTODOP_DURATION_REQUIRE query={} durationMs={} slots={}",
                    com.starrocks.common.util.UUIDUtil.fromTUniqueid(slot.getSlotId()),
                    ReportDurationBridge.REGISTRY.peek(slot.getSlotId()), slot.getNumPhysicalSlots());
        }''')
    sources[strategy] = value
    for name, value in sources.items():
        path = src / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value)
    prior = json.loads((RUN / 'duration_queue_validation/COMPILE_COMMAND.json').read_text())
    cmd = ['javac', '--release', '17', '-proc:none', '-cp', prior[prior.index('-cp') + 1],
           '-d', str(out / 'classes'), *[str(src / name) for name in sources]]
    (out / 'COMPILE_COMMAND.json').write_text(json.dumps(cmd, indent=2) + '\n')
    with (out / 'COMPILE.log').open('w') as log:
        process = subprocess.run(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=120)
    result = dict(status='compiled_not_tested_or_deployed' if process.returncode == 0 else 'compile_failed',
                  returncode=process.returncode, source_sha256={name: hashlib.sha256((src/name).read_bytes()).hexdigest() for name in sources},
                  scope='Single-FE experimental source copies. Actual HTTP binding, cancellation and admission integration remain untested.')
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(output=str(out), **result), indent=2))
    raise SystemExit(process.returncode)


if __name__ == '__main__':
    main()
