"""Cost-model baselines with train-only features and validation-only selection."""
import argparse,copy,json,random,resource,sys,time,math
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,'/tmp/autodop-report-deps')
import numpy as np
import torch
from torch import nn
from autodop.data import load_dataset,build_metadata
from autodop.graph import build_graph
from autodop.model import CostModel,LatencyRegressionModel,dynamic_margin_ranking_loss,save_checkpoint
from autodop.training import make_training_contract,select_partition,file_sha256
from measure_ablation_cost import save,stats
RUN=ROOT/'runs/report90_20260912';DATA=ROOT/'runs/multi_structure_feedback_cost05_20260910/dataset'
KINDS=['transformer_rank','transformer_regression','mlp_rank','xgb_regression','xgb_rank']

def flat_features(g,metadata):
 # Pool explicit per-fragment features and their DOP interactions; no latency or query IDs.
 cats=torch.cat([torch.nn.functional.one_hot(g['categorical'][:,i],len(metadata['category_vocab'][name])).float() for i,name in enumerate(metadata['category_features'])],dim=1)
 dops=torch.tensor([0]+metadata['dop_classes'],dtype=torch.float32)[g['dop_ids']];d=torch.log1p(dops)[:,None]
 extra=torch.stack([g['dependency'].sum(0),g['dependency'].sum(1),g['competition'].sum(0),g['competition'].sum(1)],dim=1)
 node=torch.cat([g['numerical'],cats,d,d*g['numerical'],d*cats,extra],dim=1)
 pooled=torch.cat([node.mean(0),node.sum(0),node.max(0).values,node.std(0,unbiased=False)])
 edge=torch.tensor([len(dops),g['dependency'].sum().item(),g['competition'].sum().item(),g['competition'].max().item()])
 return torch.cat([pooled,edge]).numpy()

class MLP(nn.Module):
 def __init__(self,width):
  super().__init__();self.net=nn.Sequential(nn.Linear(width,64),nn.GELU(),nn.Linear(64,64),nn.GELU(),nn.Linear(64,1))
 def forward(self,x):return self.net(x).squeeze(-1)

def metrics(samples,scores):
 groups=defaultdict(list)
 for s,p in zip(samples,scores):groups[s['plan_key']].append((s,float(p)))
 regrets=[];correct=total=0;choices={}
 for key,rows in groups.items():
  best=min(rows,key=lambda x:(-x[1],x[0]['config_key']))[0];fast=min(x[0]['latency_ms'] for x in rows);regrets.append(best['latency_ms']/fast-1);choices[key]=best['config_key']
  for i,(a,sa) in enumerate(rows):
   for b,sb in rows[i+1:]:
    if abs(a['latency_ms']-b['latency_ms'])/min(a['latency_ms'],b['latency_ms'])<.03:continue
    total+=1;correct+=int((sa-sb)*(b['latency_ms']-a['latency_ms'])>0)
 return dict(plans=len(groups),mean_regret=float(np.mean(regrets)),rank_accuracy=correct/total if total else None,ranking_pairs=total,choices=choices)

def prepare_data():
 samples,pairs,_=load_dataset(DATA);contract=make_training_contract(samples,pairs,.2,20260912,DATA/'model_split.json');train,tp=select_partition(samples,pairs,contract,'train');valid,_=select_partition(samples,pairs,contract,'valid');meta=build_metadata(train)
 return samples,train,valid,tp,meta,contract

def train(stage):
 import xgboost as xgb
 torch.set_num_threads(1);out=RUN/('models_'+stage);out.mkdir(exist_ok=False)
 samples,tr,va,pairs,meta,contract=prepare_data();seeds=[17] if stage=='pilot' else [17,29,43];epochs=2 if stage=='pilot' else 30;settings=[0] if stage=='pilot' else [0,1]
 save(out/'CONTRACT.json',contract);save(out/'METADATA.json',meta)
 started=time.perf_counter();graphs={ (s['plan_key'],s['config_key']):build_graph(s,meta) for s in samples};raw={k:flat_features(g,meta) for k,g in graphs.items()};keys=lambda s:(s['plan_key'],s['config_key']);X=np.stack([raw[keys(s)] for s in tr]);mean=X.mean(0);std=X.std(0);std[std<1e-6]=1
 flat={k:torch.tensor((x-mean)/std,dtype=torch.float32) for k,x in raw.items()};np.savez(out/'FEATURE_NORMALIZATION.npz',mean=mean,std=std);save(out/'PREPARATION.json',dict(seconds=time.perf_counter()-started,train_samples=len(tr),valid_samples=len(va),flat_features=len(mean),training_only_normalization=True))
 by=defaultdict(list);pair_by=defaultdict(list)
 for s in tr:by[s['plan_key']].append(s)
 for pair in pairs:pair_by[pair['plan_key']].append(pair)
 summary=[];selected={}
 for seed in seeds:
  for kind in KINDS:
   candidates=[]
   for setting in settings:
    torch.manual_seed(seed);rng=random.Random(seed);start=time.perf_counter();name=f'{kind}_s{seed}_h{setting}';target=out/name;target.mkdir();history=[]
    if kind.startswith('xgb'):
     train_rows=sorted(tr,key=lambda s:(s['plan_key'],s['config_key']));xx=np.stack([flat[keys(s)].numpy() for s in train_rows]);yy=np.array([math.log1p(s['latency_ms']) for s in train_rows]);params=dict(n_estimators=5 if stage=='pilot' else 200,max_depth=3 if setting==0 else 6,learning_rate=.05,n_jobs=1,random_state=seed,tree_method='hist',subsample=1.,colsample_bytree=1.)
     if kind=='xgb_regression':model=xgb.XGBRegressor(objective='reg:squarederror',**params);model.fit(xx,yy)
     else:
      groups=[];labels=[]
      for plan in sorted(by):
       group=[s for s in train_rows if s['plan_key']==plan];unique_lat=sorted({s['latency_ms'] for s in group},reverse=True);labels.extend([unique_lat.index(s['latency_ms']) for s in group]);groups.append(len(group))
      model=xgb.XGBRanker(objective='rank:pairwise',**params);model.fit(xx,np.array(labels),group=groups)
     vs=model.predict(np.stack([flat[keys(s)].numpy() for s in va]));vs=-vs if kind.endswith('regression') else vs;model.save_model(target/'model.ubj');parameters=None
    else:
     model=CostModel(meta) if kind=='transformer_rank' else LatencyRegressionModel(meta) if kind=='transformer_regression' else MLP(len(mean));optimizer=torch.optim.Adam(model.parameters(),lr=3e-4 if setting==0 else 1e-3);parameters=sum(p.numel() for p in model.parameters())
     def input_for(k):return flat[k] if kind=='mlp_rank' else graphs[k]
     for epoch in range(epochs):
      model.train();jobs=[]
      for plan in sorted(by):
       for _ in range(4):jobs.append(('reg',rng.choice(by[plan])) if kind.endswith('regression') else ('rank',rng.choice(pair_by[plan])))
      rng.shuffle(jobs);losses=[]
      for offset in range(0,len(jobs),16):
       optimizer.zero_grad();batch=[]
       for typ,item in jobs[offset:offset+16]:
        if typ=='reg':loss=(model(input_for(keys(item)))-math.log1p(item['latency_ms'])).square()
        else:
         k=item['plan_key'];fa=model(input_for((k,item['fast_config_key'])));sl=model(input_for((k,item['slow_config_key'])));loss=dynamic_margin_ranking_loss(fa,sl,item['fast_latency_ms'],item['slow_latency_ms'])
        batch.append(loss)
       loss=torch.stack(batch).mean();assert torch.isfinite(loss);loss.backward();optimizer.step();losses.append(float(loss.detach()))
      history.append(dict(epoch=epoch+1,loss=float(np.mean(losses))));save(target/'PROGRESS.json',dict(status='training',history=history));print(name,epoch+1,flush=True)
     model.eval()
     with torch.no_grad():vs=np.array([float(model(input_for(keys(s)))) for s in va]);vs=-vs if kind.endswith('regression') else vs
     if kind=='mlp_rank':torch.save(dict(state=model.state_dict(),width=len(mean)),target/'model.pt')
     else:save_checkpoint(target/'model.pt','cost' if kind.endswith('rank') else 'regression',model,meta,contract)
    elapsed=time.perf_counter()-start;quality=metrics(va,vs);record=dict(name=name,kind=kind,seed=seed,setting=setting,seconds=elapsed,parameters=parameters,validation=quality,history=history);save(target/'RESULT.json',record);candidates.append(record);summary.append(record);save(out/'PROGRESS.json',dict(status='training',completed=summary))
   winner=min(candidates,key=lambda c:(c['validation']['mean_regret'],-(c['validation']['rank_accuracy'] or 0),c['setting']));selected[f'{kind}_s{seed}']=winner['name'];save(out/'SELECTED.json',selected)
 save(out/'RESULT.json',dict(status='complete',candidates=summary,selected=selected,peak_RSS_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,xgboost_version=xgb.__version__,selection='minimum validation mean observed-candidate regret, ranking tie break; no 90-query labels or timings accessed'))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--stage',choices=['pilot','full'],required=True);a=p.parse_args();train(a.stage)
