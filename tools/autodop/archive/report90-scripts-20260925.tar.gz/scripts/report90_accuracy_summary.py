"""Aggregate all fixed seeds without selecting a favorable model or metric."""
import hashlib
import json
from pathlib import Path
from statistics import mean

BASE = Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    seeds = [17,29,43]
    records = {}
    sources = [Path(__file__)]
    pool_hash = None
    for seed in seeds:
        folder = BASE/f'accuracy_pair_audit_seed{seed}'
        path = folder/'RESULT.json'
        record = json.loads(path.read_text())
        assert record['status'] == 'verified_independent_pair_replay' and record['seed'] == seed
        for source,expected in record['source_sha256'].items():
            assert sha(source) == expected
        current = sha(folder/'PAIR_POOL.json')
        if pool_hash is None: pool_hash = current
        else: assert pool_hash == current
        records[str(seed)] = record['models']
        sources.append(path)
    kinds = list(records['17'])
    assert all(set(r) == set(kinds) for r in records.values())
    aggregate = {}
    for kind in kinds:
        aggregate[kind] = {}
        for metric in ['macro_accuracy','pooled_accuracy']:
            values = [records[str(seed)][kind][metric] for seed in seeds]
            aggregate[kind][metric] = dict(mean=mean(values),minimum=min(values),maximum=max(values))
    scope = ('Same 920 development pairs replayed for all models and all three seeds, not 2760 independent pairs. '
             'Latency gaps below3% excluded uniformly; predicted ties count as errors. '
             'Checkpoints selected by historical/complex equal-cohort macro accuracy, regret tie breaker. '
             'Pooled accuracy weights cohorts by their699/221 pair counts. Both metrics retained; reused validation, not final-test evidence.')
    out = BASE/'accuracy_comparison'
    out.mkdir(exist_ok=False)
    result = dict(status='verified_three_seed_accuracy_summary',seeds=seeds,pair_pool_sha256=pool_hash,
                  unique_pairs=920,cohort_pairs=dict(historical=699,complex_new=221),aggregate=aggregate,
                  seed_metrics={seed:{kind:{k:v for k,v in row.items() if k!='scores'} for kind,row in model.items()}
                                for seed,model in records.items()},scope=scope,
                  source_sha256={str(p):sha(p) for p in sources})
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines = ['# 按排序准确率选模的三种子比较', '', scope, '',
             '| 模型 | 合并候选对准确率均值 | 种子范围 | 两类等权准确率均值 | 种子范围 |',
             '|---|---:|---:|---:|---:|']
    for kind in kinds:
        pooled,macro = aggregate[kind]['pooled_accuracy'],aggregate[kind]['macro_accuracy']
        lines.append(f"| {kind} | {100*pooled['mean']:.3f}% | {100*pooled['minimum']:.3f}–{100*pooled['maximum']:.3f}% | "
                     f"{100*macro['mean']:.3f}% | {100*macro['minimum']:.3f}–{100*macro['maximum']:.3f}% |")
    lines += ['', '逐种子、逐类正确数、平分数及模型分数保留在各自的独立重放目录中。'
              '指标差异来自候选对权重，不能因为某一口径更有利就替换预先固定的开发选模指标。'
              '本表比较各自的完整模型与输入表示，未将竞争边从Transformer中单独拆出。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines))


if __name__ == '__main__':main()
