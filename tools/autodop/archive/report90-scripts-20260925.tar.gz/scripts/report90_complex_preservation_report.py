"""Wait for completed preservation ablation and replay all selected checkpoints."""
import json
import os
from pathlib import Path
import time
import torch
from report90_execute import RUN
from report90_complex_retrain import validation
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from autodop.training import select_partition,file_sha256

BASE=RUN/'complex_development24';OUT=BASE/'preservation_ablation';JOB=BASE/'preservation_report'

def read(p):return json.loads(p.read_text())
def save(v):
    p=JOB/'STATUS.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(v,indent=2)+'\n');t.replace(p)

def main():
    JOB.mkdir(exist_ok=False);save({'status':'running','stage':'waiting_ablation','pid':os.getpid()})
    while True:
        state=read(OUT/'STATUS.json')
        if state['status']=='complete':break
        assert state['status']=='running',state
        pid=state['pid'];os.kill(pid,0)
        assert b'report90_complex_preservation_ablation.py' in Path(f'/proc/{pid}/cmdline').read_bytes()
        time.sleep(15)
    save({'status':'running','stage':'independent_score_replay','pid':os.getpid()})
    os.sched_setaffinity(0,{35});torch.set_num_threads(1)
    for p,expected in read(BASE/'PRESERVATION_ABLATION_PROTOCOL.json')['source_sha256'].items():assert file_sha256(p)==expected
    for p,expected in read(OUT/'EXECUTION_SOURCE_SHA256.json').items():assert file_sha256(p)==expected
    samples,pairs,metadata=load_dataset(BASE/'merged_dataset');contract=read(OUT/'CONTRACT.json')
    valid,_=select_partition(samples,pairs,contract,'valid');assert len(valid)==212
    graphs=[build_graph(s,metadata) for s in valid];result=read(OUT/'RESULT.json');verified=[]
    for candidate in sorted(result['candidates'],key=lambda c:c['preservation_weight']):
        p=Path(candidate['model']);assert file_sha256(p)==candidate['model_sha256']
        model,ck=load_cost_model(p);model.eval();assert ck['metadata']==metadata
        with torch.no_grad():scores=[float(model(g)) for g in graphs]
        quality=validation(valid,scores);assert quality==candidate['selected']['validation']
        verified.append({'weight':candidate['preservation_weight'],'epoch':candidate['selected']['epoch'],
            'seconds':candidate['seconds'],'quality':quality,'model_sha256':file_sha256(p)})
    audit={'status':'verified','candidates':verified,'development_gate_passed':result['development_gate_passed'],
        'scope':'Development-only training-stage ablation, same initialization/data/seed/lr1e-4/100epochs. Validation has been used for prior development. No independent-test claim.',
        'source_sha256':{str(p):file_sha256(p) for p in [Path(__file__),OUT/'RESULT.json',OUT/'EXECUTION_SOURCE_SHA256.json']}}
    (OUT/'SCORE_REPLAY.json').write_text(json.dumps(audit,indent=2)+'\n')
    lines=['# 历史教师分数保留约束的训练消融','','固定接续起点、训练数据、种子17、学习率1e-4、100轮及选模规则。权重10复用此前同设置的完整训练；权重0和1为新训练。权重0仍保留历史排序样本，只关闭历史教师分数的MSE约束。', '',
        '| 保留权重 | 选中轮次 | 历史验证选择损失 | 复杂验证选择损失 | 等权选择损失 | 历史/复杂排序准确率 | 候选耗时（秒） |',
        '|---:|---:|---:|---:|---:|---:|---:|']
    for row in verified:
        q=row['quality'];h=q['cohorts']['historical'];n=q['cohorts']['complex_new']
        lines.append(f"| {row['weight']:g} | {row['epoch']} | {100*h['mean_regret']:.2f}% | {100*n['mean_regret']:.2f}% | {100*q['weighted_regret']:.2f}% | {100*h['rank_accuracy']:.2f}% / {100*n['rank_accuracy']:.2f}% | {row['seconds']:.2f} |")
    lines += ['',f"相对两种冻结XGBoost对照的开发门槛：{'通过' if result['development_gate_passed'] else '未通过'}。门槛同时要求等权选择损失和复杂验证选择损失均不更差。",'',
        '所有选定模型均重新加载，复算指标与原记录完全一致。对照XGBoost与完整接续训练结果见 [前次训练报告](../retrained/REPORT.md)。', '',
        '这是在观察前次开发结果后提出的有限训练消融，验证集已经参与此前开发与本次选模；不将本结果称为独立最终测试。保留所有权重和两组验证结果，不根据表现删除查询。', '',
        '耗时口径沿用前次训练报告，包含候选训练、定期验证和记录写入。复用的权重10耗时来自原次执行，不冒充本轮重跑；不包含历史预训练及SQL采集。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
    report=BASE/'REPORT.md';old=report.read_text();(JOB/'REPORT.before.md').write_text(old)
    assert '## 历史分数保留约束消融' not in old
    report.write_text(old+'\n\n## 历史分数保留约束消融\n\n固定数据、初始化、种子、学习率和训练轮数，比较保留权重0、1、10的训练阶段消融及独立分数回放，见 [保留约束消融](preservation_ablation/REPORT.md)。该开发结果不自动构成SQL执行收益。\n')
    save({'status':'complete','development_gate_passed':result['development_gate_passed']})
    print(json.dumps({'status':'verified','development_gate_passed':result['development_gate_passed']}))

if __name__=='__main__':
    if JOB.exists():raise SystemExit('Preserve existing report job')
    try:main()
    except BaseException as e:
        if JOB.exists():save({'status':'failed','error':repr(e),'pid':os.getpid()})
        raise
