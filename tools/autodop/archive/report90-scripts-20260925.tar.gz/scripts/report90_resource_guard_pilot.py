"""Small predeclared admission-profile comparison; keep the main curve frozen."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import report90_sustained_streams as collector


BASE=collector.RUN/'distillation_concurrency_extension'
PROFILES={'cap4':dict(cap=4,memory_limit_pct=0),
          'memory_cap5':dict(cap=5,memory_limit_pct=75)}


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--profile',choices=PROFILES,required=True)
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    out=args.output.resolve();assert not out.exists()
    profile=PROFILES[args.profile];manifest=BASE/'STREAM_PILOT_MANIFEST.json'
    command=[str(Path(collector.__file__)), '--output',str(out),'--manifest',str(manifest),
        '--streams','16,20','--modes','policy_load','--queue-cap',str(profile['cap']),
        '--duration','60','--settle','15']
    spec=out.with_suffix('.PROFILE.json');spec.parent.mkdir(parents=True,exist_ok=True)
    value=dict(status='frozen_before_sql',profile=args.profile,settings=profile,command=command,
        scope='Four fixed root structures at16/20streams; same deployed policy and SQL cycle. Candidate increases hard cap4to5 and adds75percent native memory admission gate. CPU admission gate stays0; policy CPU correction unchanged. No throughput acceptance or full expansion implied.',
        rationale='Primary90 curve:20streams lost2completions/240s, CPU7.16to6.90cores/BE while policy service17.8to17.1ms. Test modest additional execution concurrency with a memory guard; do not attribute a noisy2query difference to inference overhead.',
        source_sha256={str(p.resolve()):sha(p) for p in [Path(__file__),Path(collector.__file__),manifest,BASE/'streams_report90/AUDIT.json',BASE/'streams_report90/ONLINE_AUDIT.json',BASE/'RESOURCE_AUDIT.json']})
    with spec.open('x') as handle:json.dump(value,handle,indent=2)
    collector.SETTINGS['query_queue_mem_used_pct_limit']=str(profile['memory_limit_pct'])
    collector.SETTINGS['query_queue_cpu_used_permille_limit']='0'
    sys.argv=command;collector.main()
    queue=json.loads((out/'QUEUE_SETTINGS.json').read_text());assert queue['restored']
    assert queue['requested']['query_queue_mem_used_pct_limit']==str(profile['memory_limit_pct'])
    assert queue['requested']['query_queue_concurrency_limit']==str(profile['cap'])
    subprocess.run([sys.executable,str(collector.ROOT/'scripts/report90_sustained_audit.py'),str(out)],check=True)
    for p,d in value['source_sha256'].items():assert sha(Path(p))==d,p
    result=dict(status='verified_profile_pilot',profile=args.profile,
        source_sha256={str(p):sha(p) for p in [spec,out/'AUDIT.json',out/'QUEUE_SETTINGS.json']})
    (out/'PROFILE_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':main()
