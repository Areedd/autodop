"""Summarize actual admission waits; preserve every mode and both phases."""
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean
from report90_execute import RUN


def analyze(out):
    audit=json.loads((out/'ALLOCATION_AUDIT.json').read_text())
    assert audit['status']=='verified'
    events={e['query_id']:e for e in map(json.loads,(out/'scored/events.jsonl').read_text().splitlines())}
    groups=defaultdict(list)
    for row in audit['rows']:
        event=events[row['query_id']]
        pending=int(re.search(r'\|PendingTimeMs=(\d+)\|',row['audit_line'])[1])
        groups[row['phase']+'/'+row['mode']].append(dict(query_id=row['query_id'],pending_ms=pending,
            slots=row['slots'],client_ms=event['client_latency_ms']))
    summaries={key:dict(count=len(rows),mean_pending_ms=mean(r['pending_ms'] for r in rows),
        max_pending_ms=max(r['pending_ms'] for r in rows),waiting_over_10ms=sum(r['pending_ms']>10 for r in rows),
        slots_histogram=dict(Counter(r['slots'] for r in rows)),
        aggregate_pending_fraction=sum(r['pending_ms'] for r in rows)/sum(r['client_ms'] for r in rows))
        for key,rows in groups.items()}
    result=dict(status='verified',summaries=summaries,rows=dict(groups),
        scope='FE PendingTimeMs is observed global admission waiting. Aggregate ratio uses matched client durations; no inferred execution-only latency or causal attribution of remaining time.')
    (out/'WAIT_ANALYSIS.json').write_text(json.dumps(result,indent=2)+'\n')
    return summaries

if __name__=='__main__':
    for name in ['native_budget_fixed32','native_budget_fixed128','native_budget_fixed17']:
        out=RUN/name
        if (out/'ALLOCATION_AUDIT.json').exists():print(name,json.dumps(analyze(out)))
