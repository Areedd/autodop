"""Matched hard-pair EMA pilot with fixed sharper ranking temperature."""
import os
from pathlib import Path
import subprocess
import sys
import torch
from autodop.model import load_cost_model
import report90_coverage_stability as common
from report90_neighborhood_prepare import RUN, sha

BASE = RUN / 'structure_coverage20'
OUT = BASE / 'ranking_temperature_pilot'
REFERENCE = BASE / 'hard_pair_ema_pilot/pilot'
SOURCE = BASE / 'hard_pair_ema_pilot/pilot_trainer.py'


def main():
    os.sched_setaffinity(0, {34})
    torch.set_num_threads(1)
    assert not OUT.exists()
    assert common.read(REFERENCE / 'SCORE_REPLAY.json')['status'] == 'verified'
    for p, digest in common.read(REFERENCE / 'EXECUTION_SOURCE_SHA256.json').items():
        assert sha(Path(p)) == digest
    OUT.mkdir()
    common.save(OUT / 'PROTOCOL.json', {
        'seed': 17, 'smoke_epochs': 2, 'pilot_epochs': 30,
        'hypothesis': 'Fixedtemperature0.1 makes softplus more concentrated on margin violations while retaining differentiability and calibrated gap penalty. Training-only derivative audit motivates testing; it does not prove an accuracy benefit.',
        'design': 'Only change calibrated softplus term fromsoftplus(target-gap) to0.1*softplus((target-gap)/0.1). The0.1smooth-L1 gap term remains unchanged. Original multistage+competition, hard-pair50% sampling refreshed every10epochs,EMA0.99,1365train/212valid,624pairs/epoch,batch16,Adam1e-4,cosine100 unchanged. Temperature is fixed before validation, no sweep or report90 fitting.',
        'selection': 'Equal-cohort validation pair accuracy, regret, earlier epoch. Reused development validation; no report90 data, no SQL, no deployment.',
        'gate': 'Exceed matched Transformer reference and both unchanged XGBoost controls before any expansion. Additional MLP controls and three fixed seeds remain required for overall acceptance.',
        'source_sha256': {str(p): sha(p) for p in [Path(__file__), SOURCE, Path(common.__file__), REFERENCE / 'SCORE_REPLAY.json', BASE / 'pair_gradient_audit/RESULT.json']}})
    for stage in ['smoke', 'pilot']:
        folder = OUT / stage
        changes = {
            repr(str(REFERENCE)): repr(str(folder)),
            repr(str(BASE / 'hard_pair_ema_pilot/PROTOCOL.json')): repr(str(OUT / 'PROTOCOL.json')),
            'ranking.append(torch.nn.functional.softplus(target-a+b) + 0.1*torch.nn.functional.smooth_l1_loss(a-b,target))':
                'ranking.append(0.1*torch.nn.functional.softplus((target-a+b)/0.1) + 0.1*torch.nn.functional.smooth_l1_loss(a-b,target))',
        }
        if stage == 'smoke':
            changes.update({'range(1,31)': 'range(1,3)', 'epoch%10==0': 'epoch%1==0', 'n_estimators=200': 'n_estimators=5'})
        text = SOURCE.read_text()
        applied = {}
        for old, new in changes.items():
            count = text.count(old)
            assert count == (2 if old in [repr(str(BASE / 'hard_pair_ema_pilot/PROTOCOL.json')), 'epoch%10==0'] else 1), (old, count)
            text = text.replace(old, new)
            applied[old] = {'replacement': new, 'occurrences': count}
        script = OUT / f'{stage}_trainer.py'
        compile(text, str(script), 'exec')
        script.write_text(text)
        common.save(OUT / f'{stage}_TRANSFORM.json', {'original_sha256': sha(SOURCE), 'generated_sha256': sha(script), 'changes': applied})
        common.save(OUT / 'STATUS.json', {'status': 'running', 'stage': stage, 'pid': os.getpid()})
        with (OUT / f'{stage}.log').open('w') as stream:
            subprocess.run([sys.executable, str(script)], stdout=stream, stderr=subprocess.STDOUT, check=True)
        common.load_cost_model = load_cost_model
        replay = common.replay(folder)
        print(stage, {k: v['weighted_rank_accuracy'] for k, v in replay.items()}, flush=True)
    score = replay['transformer']['weighted_rank_accuracy']
    reference = common.read(REFERENCE / 'SCORE_REPLAY.json')['models']['transformer']['weighted_rank_accuracy']
    gate = score > reference and all(score > v['weighted_rank_accuracy'] for k, v in replay.items() if k != 'transformer')
    common.save(OUT / 'RESULT.json', {'status': 'verified', 'models': replay, 'reference_macro_accuracy': reference, 'expansion_gate_passed': gate, 'protocol_sha256': sha(OUT / 'PROTOCOL.json')})
    common.save(OUT / 'STATUS.json', {'status': 'complete', 'expansion_gate_passed': gate})


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        if OUT.exists():
            common.save(OUT / 'STATUS.json', {'status': 'failed', 'error': repr(error)})
        raise
