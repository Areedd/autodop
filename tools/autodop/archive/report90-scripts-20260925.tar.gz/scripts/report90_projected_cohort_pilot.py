"""Matched pilot: project conflicting cohort gradients symmetrically."""
import os
from pathlib import Path
import subprocess
import sys
import torch
from autodop.model import load_cost_model
import report90_coverage_stability as common
from report90_neighborhood_prepare import RUN, sha

BASE = RUN / 'structure_coverage20'
OUT = BASE / 'projected_cohort_pilot'
REFERENCE = BASE / 'hard_pair_ema_pilot/pilot'
SOURCE = BASE / 'hard_pair_ema_pilot/pilot_trainer.py'


def main():
    os.sched_setaffinity(0, {34})
    torch.set_num_threads(1)
    assert not OUT.exists()
    assert common.read(REFERENCE / 'SCORE_REPLAY.json')['status'] == 'verified'
    for p, digest in common.read(REFERENCE / 'EXECUTION_SOURCE_SHA256.json').items():
        assert sha(Path(p)) == digest
    OUT.mkdir()
    common.save(OUT / 'PROTOCOL.json', {
        'seed': 17, 'smoke_epochs': 2, 'pilot_epochs': 30,
        'hypothesis': 'Training-only diagnostic observed opposing historical/complex gradients in4of4warm minibatches and1of4final minibatches. Test symmetric projection only when cohort gradient dot product is negative; no assertion of causal generalization benefit.',
        'design': 'Same calibrated pair loss, hard-pair50% sampler refreshed every10epochs,EMA0.99,multistage+competition,1365train/212valid,624pairs/epoch,batch16,Adam1e-4,cosine100. For each batch, each cohort loss is divided by full batch size; positive-dot gradients sum normally, negative-dot gradients projected on the other gradient orthogonal complement using original vectors before summing. No task resampling or normalization change. Two backward traversals and float64 projection add training work; inference unchanged.',
        'selection': 'Equal-cohort validation pair accuracy, regret, earlier epoch. Reused development validation; no report90 data, no SQL, no deployment.',
        'gate': 'Exceed matched Transformer reference and both unchanged XGBoost controls before any expansion. Additional MLP controls and three fixed seeds remain required for overall acceptance.',
        'source_sha256': {str(p): sha(p) for p in [Path(__file__), SOURCE, Path(common.__file__), REFERENCE / 'SCORE_REPLAY.json', BASE / 'cohort_gradient_conflict/RESULT.json', Path(__file__).with_name('report90_projected_cohort_gradients.py')]}})
    for stage in ['smoke', 'pilot']:
        folder = OUT / stage
        changes = {
            repr(str(REFERENCE)): repr(str(folder)),
            repr(str(BASE / 'hard_pair_ema_pilot/PROTOCOL.json')): repr(str(OUT / 'PROTOCOL.json')),
            'def order(q):':'from report90_projected_cohort_gradients import assign_gradients\n\ndef order(q):',
            'by=pair_index(train,tp);historical=':'cohort_by_plan={s["plan_key"]:s["source_cohort"] for s in train};by=pair_index(train,tp);historical=',
            'model.train();jobs=epoch_pairs(by,rng,hard);losses=[]':'model.train();jobs=epoch_pairs(by,rng,hard);losses=[];projected_steps=0',
            'optimizer.zero_grad();ranking=[]':'optimizer.zero_grad();ranking=[];task_losses={c:[] for c in COHORTS}',
            'ranking.append(torch.nn.functional.softplus(target-a+b) + 0.1*torch.nn.functional.smooth_l1_loss(a-b,target))':
                'ranking.append(torch.nn.functional.softplus(target-a+b) + 0.1*torch.nn.functional.smooth_l1_loss(a-b,target));task_losses[cohort_by_plan[plan]].append(ranking[-1])',
            'loss.backward();optimizer.step()':'projection=assign_gradients(task_losses,model.parameters());projected_steps+=projection["projected"];optimizer.step()',
            "entry={'epoch':epoch,'loss'":"entry={'epoch':epoch,'projected_steps':projected_steps,'optimizer_steps':len(range(0,len(jobs),16)),'loss'",

        }
        if stage == 'smoke':
            changes.update({'range(1,31)': 'range(1,3)', 'epoch%10==0': 'epoch%1==0', 'n_estimators=200': 'n_estimators=5'})
        text = SOURCE.read_text()
        applied = {}
        for old, new in changes.items():
            count = text.count(old)
            assert count == (2 if old in [repr(str(BASE / 'hard_pair_ema_pilot/PROTOCOL.json')), 'epoch%10==0'] else 1), (old, count)
            text = text.replace(old, new)
            applied[old] = {'replacement': new, 'occurrences': count}
        script = OUT / f'{stage}_trainer.py'
        compile(text, str(script), 'exec')
        script.write_text(text)
        common.save(OUT / f'{stage}_TRANSFORM.json', {'original_sha256': sha(SOURCE), 'generated_sha256': sha(script), 'changes': applied})
        common.save(OUT / 'STATUS.json', {'status': 'running', 'stage': stage, 'pid': os.getpid()})
        with (OUT / f'{stage}.log').open('w') as stream:
            subprocess.run([sys.executable, str(script)], stdout=stream, stderr=subprocess.STDOUT, check=True)
        common.load_cost_model = load_cost_model
        replay = common.replay(folder)
        print(stage, {k: v['weighted_rank_accuracy'] for k, v in replay.items()}, flush=True)
    score = replay['transformer']['weighted_rank_accuracy']
    reference = common.read(REFERENCE / 'SCORE_REPLAY.json')['models']['transformer']['weighted_rank_accuracy']
    gate = score > reference and all(score > v['weighted_rank_accuracy'] for k, v in replay.items() if k != 'transformer')
    common.save(OUT / 'RESULT.json', {'status': 'verified', 'models': replay, 'reference_macro_accuracy': reference, 'expansion_gate_passed': gate, 'protocol_sha256': sha(OUT / 'PROTOCOL.json')})
    common.save(OUT / 'STATUS.json', {'status': 'complete', 'expansion_gate_passed': gate})


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        if OUT.exists():
            common.save(OUT / 'STATUS.json', {'status': 'failed', 'error': repr(error)})
        raise
