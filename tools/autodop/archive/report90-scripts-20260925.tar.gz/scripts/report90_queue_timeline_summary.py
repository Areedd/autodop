"""Describe complete queue timelines without attributing causality."""
from collections import defaultdict
from pathlib import Path
import hashlib,json,statistics

RUN=Path(__file__).resolve().parents[1]/'runs/report90_20260912'

def main():
    source=RUN/'report90_native_budget_timeline_power2/TIMELINE_AUDIT.json'
    proof=json.loads(source.read_text());assert proof['status']=='verified_diagnostic' and proof['queries']==128
    for name,digest in proof['source_sha256'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
    selection=RUN/'native_mixed_budget_pilot_support/SELECTION.json'
    classes={r['id']:r['native_slots'] for r in json.loads(selection.read_text())['queries']}
    groups=defaultdict(list)
    for r in proof['rows']:groups[r['phase'],r['mode']].append(r)
    summaries=[]
    for (phase,mode),rows in sorted(groups.items()):
        assert len(rows)==16
        require=sorted(rows,key=lambda r:r['require_sequence'])
        allocate=sorted(rows,key=lambda r:r['allocate_sequence'])
        inversions=sum(a['allocate_sequence']>b['allocate_sequence'] for i,a in enumerate(require) for b in require[i+1:])
        same=sum(a['allocate_sequence']>b['allocate_sequence'] and a['slots']==b['slots'] for i,a in enumerate(require) for b in require[i+1:])
        span=(max(r['release_ns'] for r in rows)-min(r['require_ns'] for r in rows))/1e6
        summaries.append(dict(phase=phase,mode=mode,require_spread_ms=(require[-1]['require_ns']-require[0]['require_ns'])/1e6,
                              first_four_admitted_classes=[classes[r['id']] for r in allocate[:4]],
                              arrival_classes=[classes[r['id']] for r in require],allocation_classes=[classes[r['id']] for r in allocate],
                              order_inversions=inversions,same_slot_inversions=same,
                              workload_reservation_fraction=sum(r['held_ms']*r['slots'] for r in rows)/(96*span),
                              by_query={q:dict(count=sum(r['id']==q for r in rows),mean_queue_ms=statistics.mean(r['queue_ms'] for r in rows if r['id']==q),mean_held_ms=statistics.mean(r['held_ms'] for r in rows if r['id']==q)) for q in sorted(classes)}))
    result=dict(status='descriptive_diagnostic',queries=128,batches=summaries,
                scope='One instrumented run. Frozen classes 24/48 identify queries; fixed-budget modes actually give both queries 24 slots. Inversions compare tracker require and allocate order, not client order. Reservation fraction covers only the 16 workload queries during their tracker span; it is neither CPU utilization nor memory utilization and omits helper SQL. Slot held time includes non-BE costs. No causal or significance claim.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),source,selection]})
    out=RUN/'native_queue_timeline_summary';out.mkdir(exist_ok=True)
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 实际队列时序诊断','',result['scope'],'',
           '| 阶段/模式 | 入队跨度 ms | 首4条获准的查询类别 | 顺序逆序对 | 同槽位逆序对 | 工作负载槽位预留比例 |',
           '|---|---:|---|---:|---:|---:|']
    for r in summaries:lines.append(f"| {r['phase']}/{r['mode']} | {r['require_spread_ms']:.2f} | {r['first_four_admitted_classes']} | {r['order_inversions']} | {r['same_slot_inversions']} | {100*r['workload_reservation_fraction']:.2f}% |")
    lines+=['','| 阶段/模式 | 查询 | 平均队列等待 ms | 平均槽位持有 ms |','|---|---|---:|---:|']
    for r in summaries:
        for q,v in r['by_query'].items():lines.append(f"| {r['phase']}/{r['mode']} | {q} | {v['mean_queue_ms']:.2f} | {v['mean_held_ms']:.2f} |")
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))

if __name__=='__main__':main()
