"""Two additional formal observations of the same pilot configs to diagnose noise."""
import json
from pathlib import Path
import subprocess
import sys

from report90_neighborhood_prepare import OUT as BASE, sha


def main():
    prior = json.loads((BASE / 'collection/RESULT.json').read_text())
    summary = json.loads((BASE / 'SUMMARY.json').read_text())
    assert prior['status'] == 'verified' and summary['status'] == 'verified_descriptive_summary'
    for path, digest in {**prior['source_sha256'], **summary['source_sha256']}.items():
        assert sha(Path(path)) == digest
    assert not (BASE / 'repeat').exists()
    protocol_path = BASE / 'REPEAT_PROTOCOL.json'
    assert not protocol_path.exists()
    original = Path(__file__).with_name('report90_neighborhood_collect.py')
    generated = BASE / 'repeat_collector_staged.py'
    text = original.read_text()
    changes = {
        "OUT = BASE / 'collection'": "OUT = BASE / 'repeat'",
        "'expected': 64": "'expected': 96",
        "'--repetitions', '1', '--seed', '2026091401'": "'--repetitions', '2', '--seed', '2026091402'",
        "proof['expected_slots'] == 64": "proof['expected_slots'] == 96",
        'assert len(events) == 64': 'assert len(events) == 96',
        'assert len(samples) == 32': 'assert len(samples) == 64',
        "'executions': 64, 'newly_measured_configs': 32": "'executions': 96, 'newly_measured_configs': 32, 'formal_observations': 64",
        'one formal observation per configuration.': 'two formal observations per configuration; same32 configs as the pilot.',
        "print('64 executions independently verified;32 training configurations retained', flush=True)":
            "print('96 executions independently verified;64 formal observations retained', flush=True)",
        "    save('SOURCES.json', {str(p): sha(p) for p in sources})":
            "    sources += [Path(" + repr(str(protocol_path)) + "), Path(" + repr(str(original)) + ")]\n    save('SOURCES.json', {str(p): sha(p) for p in sources})",
    }
    for old, new in changes.items():
        assert text.count(old) == 1, old
        text = text.replace(old, new)
    compile(text, str(generated), 'exec')
    generated.write_text(text)
    protocol_path.write_text(json.dumps({'scope': 'Same4 training queries and32 frozen configs. One warmup plus2 additional formal rounds; total96 executions. Combined with pilot there will be3 formal observations per config. No new queries, no label filtering, no automatic training.',
        'reason': 'Pilot yielded48 near-best pairs but only21/31 warm/formal stable pairs agreed in order. Diagnose measurement consistency before expanding or using labels.',
        'changes': changes, 'source_sha256': {str(p): sha(p) for p in [Path(__file__), original, generated, BASE / 'collection/RESULT.json', BASE / 'SUMMARY.json', BASE / 'PROTOCOL.json']}}, indent=2) + '\n')
    subprocess.run([sys.executable, str(generated)], check=True)


if __name__ == '__main__':
    main()
