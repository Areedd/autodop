"""Prepare verified augmented labels and function-preserving training vocabulary."""
import copy
import json
from pathlib import Path
import torch
from report90_execute import RUN
from autodop.data import load_dataset,write_jsonl
from autodop.graph import build_graph
from autodop.model import CostModel,load_cost_model,save_checkpoint
from autodop.training import file_sha256,make_training_contract,select_partition

BASE=RUN/'structure_coverage20';OUT=BASE/'prepared';DATA=BASE/'merged_dataset'

def read(p):return json.loads(p.read_text())
def save(name,v):(OUT/name).write_text(json.dumps(v,indent=2)+'\n')

def main():
    assert not OUT.exists() and not DATA.exists(),'Preserve prior preparation'
    checked=read(BASE/'labels_recovery/RESULT.json');assert checked['status']=='complete' and checked['samples']==160
    assert checked['protected_validation_raw_graph_overlap']==0
    for p,sha in checked['source_sha256'].items():assert file_sha256(p)==sha
    protocol=read(BASE/'RETRAIN_PROTOCOL.json')
    for p,sha in protocol['source_sha256'].items():assert file_sha256(p)==sha
    old,old_pairs,_=load_dataset(RUN/'complex_development24/merged_dataset')
    new=[json.loads(l) for l in (BASE/'labels_recovery/dataset/all/samples.jsonl').open()]
    new_pairs=[json.loads(l) for l in (BASE/'labels_recovery/dataset/all/pairs.jsonl').open()]
    assert len(old)==1417 and len(new)==160 and all(s['split']=='train' for s in new)
    assert {s['sql_sha256'] for s in old}.isdisjoint(s['sql_sha256'] for s in new)
    report_hashes={q['sql_sha256'] for q in read(RUN/'manifest.json')['queries']}
    assert report_hashes.isdisjoint(s['sql_sha256'] for s in new)
    assert {s['plan_key'] for s in old}.isdisjoint(s['plan_key'] for s in new)
    samples=old+[{**s,'source_cohort':'complex_new'} for s in new];pairs=old_pairs+new_pairs
    assert len({(s['plan_key'],s['config_key']) for s in samples})==1577
    splits={split:sorted({s['plan_key'] for s in samples if s['split']==split}) for split in ['train','valid','test']}
    assert len(splits['train'])==114 and len(splits['valid'])==22 and not splits['test']
    lookup={(s['plan_key'],s['config_key']):s for s in new};seen=set()
    for pair in new_pairs:
        identity=(pair['plan_key'],pair['fast_config_key'],pair['slow_config_key']);assert identity not in seen;seen.add(identity)
        fast=lookup[(pair['plan_key'],pair['fast_config_key'])];slow=lookup[(pair['plan_key'],pair['slow_config_key'])]
        assert 0<fast['latency_ms']==pair['fast_latency_ms']<slow['latency_ms']==pair['slow_latency_ms']
    OUT.mkdir();torch.set_num_threads(1)
    teacher=Path(protocol['transformer']['initialization']);model,ck=load_cost_model(teacher);model.eval()
    metadata=copy.deepcopy(ck['metadata']);added={}
    for feature in metadata['category_features']:
        vocab=metadata['category_vocab'][feature];assert set(vocab.values())==set(range(len(vocab)))
        values=sorted({str(f.get(feature,'')) for s in new for f in s['fragments']}-set(vocab))
        added[feature]=values
        for value in values:vocab[value]=len(vocab)
    promoted=CostModel(metadata,ck['model_config']);state=promoted.state_dict();previous=model.state_dict()
    for key,value in state.items():
        if key.startswith('encoder.category_embeddings.'):
            index=int(key.split('.')[2]);feature=metadata['category_features'][index]
            value[:previous[key].shape[0]].copy_(previous[key])
            if len(value)>len(previous[key]):value[len(previous[key]):].copy_(previous[key][ck['metadata']['category_vocab'][feature]['<UNK>']])
        else:assert value.shape==previous[key].shape;value.copy_(previous[key])
    promoted.load_state_dict(state);promoted.eval()
    maximum=0.
    with torch.no_grad():
        for s in samples:
            a=model(build_graph(s,ck['metadata']));b=promoted(build_graph(s,metadata));maximum=max(maximum,abs(float(a)-float(b)))
            assert torch.equal(a,b),'Vocabulary extension changed an initial prediction'
    save_checkpoint(OUT/'cost.pt','cost',promoted,metadata,{'stage':'vocabulary_extension_no_training','parent_sha256':file_sha256(teacher),'exact_parity_samples':1577})
    save('METADATA.json',metadata)
    DATA.mkdir();write_jsonl(DATA/'samples.jsonl',samples);write_jsonl(DATA/'pairs.jsonl',pairs)
    (DATA/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n');(DATA/'model_split.json').write_text(json.dumps(splits,indent=2)+'\n')
    contract=make_training_contract(samples,pairs,.2,2026091320,DATA/'model_split.json')
    train,tp=select_partition(samples,pairs,contract,'train');valid,vp=select_partition(samples,pairs,contract,'valid')
    assert len(train)==1365 and len(valid)==212
    assert [s for s in old if s['split']=='valid']==valid
    (DATA/'CONTRACT.json').write_text(json.dumps(contract,indent=2)+'\n')
    result={'status':'complete','samples':1577,'train_samples':1365,'valid_samples':212,'train_plans':114,'valid_plans':22,
        'train_pairs':len(tp),'valid_pairs':len(vp),'added_categories':added,'exact_score_parity_samples':1577,'max_absolute_score_difference':maximum,
        'model_sha256':file_sha256(OUT/'cost.pt'),'source_sha256':{str(p):file_sha256(p) for p in [Path(__file__),BASE/'RETRAIN_PROTOCOL.json',BASE/'labels_recovery/RESULT.json',teacher,DATA/'samples.jsonl',DATA/'pairs.jsonl',DATA/'metadata.json',DATA/'CONTRACT.json']}}
    save('RESULT.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ['source_sha256','added_categories']}))

if __name__=='__main__':main()
