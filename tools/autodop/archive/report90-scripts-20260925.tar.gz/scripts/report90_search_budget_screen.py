"""Screen search budget/quality tradeoffs without executing or selecting by SQL."""
import json
import os
from pathlib import Path
import random
import time
from unittest.mock import patch
import torch
from autodop import graph
from autodop.model import load_cost_model
from report90_search_refinement import search
from report90_batched_cost import score_batch
from report90_neighborhood_prepare import RUN,sha


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1)
    out=RUN/'search_budget_screen';out.mkdir(exist_ok=False)
    old=RUN/'search_refinement_development'
    prior=json.loads((old/'PROTOCOL.json').read_text())
    vectors=json.loads((old/'vectors.json').read_text())
    model,ck=load_cost_model(prior['model']);model.eval();metadata=ck['metadata']
    code=RUN/'graph_construction_pilot/competition_staged.py'
    namespace=dict(vars(graph));exec(compile(code.read_text(),str(code),'exec'),namespace)
    original=graph._competition
    protocol=dict(queries=prior['queries'],seeds=[17,29,43],budgets=[16,32,64],
                  methods=['refined','random_batch'],batch_size=16,
                  scope='Development search screening only. Same optimized graph construction for both methods; all budgets shown. One timing per cell, descriptive only. Model score and configuration retention do not establish SQL latency quality.',
                  source_sha256={str(p):sha(p) for p in [Path(__file__),old/'PROTOCOL.json',old/'vectors.json',Path(prior['model']),code,Path(graph.__file__),Path(__file__).with_name('report90_search_refinement.py'),Path(__file__).with_name('report90_batched_cost.py')]})
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    rows=[]
    with patch.object(graph,'_competition',namespace['_competition']),torch.inference_mode():
        for query in prior['queries']:
            sample=graph.sample_from_request(vectors['refined_full'][query]['request'])
            sample['dop_config']=[1 if f.get('is_gather_root') else 4 for f in sample['fragments']]
            for seed in protocol['seeds']:
                for method in protocol['methods']:
                    for budget in protocol['budgets']:
                        start=time.perf_counter_ns()
                        if method=='refined':
                            r=search(sample,model,metadata,budget=budget,seed=seed)
                            configs=[v['config'] for v in r['records']];scores=[v['score'] for v in r['records']]
                            chosen=r['config'];score=r['score']
                        else:
                            domains=[graph.supported_dops(f,metadata['dop_classes']) for f in sample['fragments']]
                            rng=random.Random(seed);configs=[[rng.choice(d) for d in domains] for _ in range(budget)]
                            scores=[]
                            for i in range(0,budget,16):
                                gs=[graph.build_graph({**sample,'dop_config':cfg},metadata) for cfg in configs[i:i+16]]
                                scores.extend(score_batch(model,gs).tolist())
                            best=max(range(budget),key=lambda i:scores[i]);chosen=configs[best];score=scores[best]
                        elapsed=(time.perf_counter_ns()-start)/1e6
                        assert len(configs)==len(scores)==budget
                        rows.append(dict(query=query,seed=seed,method=method,budget=budget,
                                         config=chosen,score=score,configs=configs,scores=scores,total_ms=elapsed))
            print(query,flush=True)
    assert graph._competition is original
    comparisons=[]
    for query in prior['queries']:
        for seed in protocol['seeds']:
            for method in protocol['methods']:
                matched={r['budget']:r for r in rows if (r['query'],r['seed'],r['method'])==(query,seed,method)}
                for budget in [16,32]:
                    low,high=matched[budget],matched[64]
                    assert low['configs']==high['configs'][:budget] and low['scores']==high['scores'][:budget]
                    comparisons.append(dict(query=query,seed=seed,method=method,budget=budget,
                                            same_winner_as64=low['config']==high['config'],model_score_loss=high['score']-low['score']))
    for p,d in protocol['source_sha256'].items():assert sha(Path(p))==d
    result=dict(status='verified_prefix_screen',rows=rows,comparisons=comparisons,scope=protocol['scope'])
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    summary={f'{method}_{budget}':sum(r['same_winner_as64'] for r in comparisons if r['method']==method and r['budget']==budget) for method in protocol['methods'] for budget in [16,32]}
    (out/'SUMMARY.json').write_text(json.dumps(dict(same_config_as64_out_of12=summary,sql_executions=0),indent=2)+'\n')
    (out/'REPORT.md').write_text('# 搜索候选预算筛查\n\n4条开发查询、3种子、16/32/64候选；两种方法均使用同一构图优化。全部72次搜索完成，较小预算的候选和分数均与64预算前缀完全一致。\n\n与64预算首选相同的次数（每组12次）：\n\n'+ '\n'.join(f'- {k}: {v}/12' for k,v in summary.items())+'\n\n这只说明配置保留情况；模型分数不是实测SQL延迟。不同候选预算必须明确标注，不能称为同评分预算比较。每个组合仅一次计时，不作为稳定成本结论。\n\n[全部轨迹](RESULT.json)、[固定协议](PROTOCOL.json)。\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
