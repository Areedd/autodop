"""Serial SQL budget pilot with an idle gate and independent execution proof."""
import argparse
import json
from pathlib import Path
import statistics
import subprocess
import sys
from report90_execute import check,ROOT,RUN
from autodop.training import file_sha256


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--scope',choices=['development','report90'],required=True);parser.add_argument('--attempt',type=int,default=0);args=parser.parse_args()
    base=RUN/'distillation_concurrency_extension'/('distillation_'+args.scope);out=base/('collection' if args.attempt==0 else 'collection_attempt'+str(args.attempt));out.mkdir(exist_ok=False)
    def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
    protocol=json.loads((base/'PROTOCOL.json').read_text())
    expected_count=protocol['expected_executions']
    for path,digest in protocol['source_sha256'].items():assert file_sha256(path)==digest
    command=[sys.executable,str(ROOT/'collect_paper_evaluations.py'),'--manifest',str(base/'manifest.json'),
             '--trusted-collection',str(RUN/'complex_development24/TRUSTED_NATIVE.json' if args.scope=='development' else ROOT/'runs/preference_random200_20260911/random200/trusted_merged.json'),'--output-dir',str(out/'scored'),
             '--modes',','.join(protocol['modes']),'--scenario','serial','--query-timeout-s','180',
             '--auto-dop-max-dop','16','--torch-threads','1','--decision-timeout-ms','1000',
             '--warmup','1','--repetitions','1','--seed','2026091451','--decision-vectors',str(base/'vectors.json')]
    save('COMMAND.json',command)
    sources=[Path(__file__),base/'PROTOCOL.json',base/'manifest.json',base/'vectors.json',ROOT/'collect_paper_evaluations.py',ROOT/'scripts/verify_paper_evaluations.py']
    save('SOURCES.json',{str(p):file_sha256(p) for p in sources})
    save('STATUS.json',dict(status='checking_idle',expected=expected_count))
    try:
        check(out/'IDLE.json')
        save('STATUS.json',dict(status='executing',expected=expected_count))
        subprocess.run(command,check=True)
        proof=out/'scored/independent_verification.json'
        subprocess.run([sys.executable,str(ROOT/'scripts/verify_paper_evaluations.py'),'--collection-dir',str(out/'scored'),'--output',str(proof)],check=True)
        p=json.loads(proof.read_text());assert p['all_expected_executions_verified'] and p['expected_slots']==expected_count
        assert json.loads((out/'scored/frontend_settings.json').read_text())['restored']
        events=[json.loads(line) for line in (out/'scored/events.jsonl').read_text().splitlines()]
        assert len(events)==expected_count and all(e['status']=='verified' and e['dop_validation']['applied'] for e in events)
        expected={(m,q,phase) for m in protocol['modes'] for q in protocol['queries'] for phase in ['warmup','measured']}
        assert {(e['mode'],e['id'],e['phase']) for e in events}==expected
        values={mode:{e['id']:e['client_latency_ms'] for e in events if e['mode']==mode and e['phase']=='measured'} for mode in protocol['modes']}
        means={mode:statistics.mean(v.values()) for mode,v in values.items()}
        for path,digest in json.loads((out/'SOURCES.json').read_text()).items():assert file_sha256(path)==digest
        result=dict(status='verified',executions=expected_count,restored=True,per_query_ms=values,mean_ms=means,
                    scope=protocol['scope'],source_sha256={str(p):file_sha256(p) for p in [proof,out/'SOURCES.json',out/'scored/events.jsonl']})
        save('RESULT.json',result)
        lines=['# 匹配教师与学生的实际SQL对照','',protocol['scope'],'',
               '| 配置来源 | 平均查询毫秒 |','|---|---:|']
        for mode,value in means.items():lines.append(f'| {mode} | {value:.3f} |')
        lines+=['', '全部执行和DOP安装通过独立核验，FE设置已恢复。固定配置回放不含离线选择时间，各组使用同样服务路径。学生原始向量在回放时直接安装，置信度不参与回放拒绝；不代表新学生线上默认回退后的性能。每配置仅一次正式测量。', '',
                '全部逐查询耗时及来源：[RESULT.json](RESULT.json)。']
        (out/'REPORT.md').write_text('\n'.join(lines)+'\n');save('STATUS.json',dict(status='verified',restored=True))
        print(json.dumps(means,indent=2))
    except BaseException as error:
        save('STATUS.json',dict(status='failed',error=repr(error)));raise


if __name__=='__main__':main()
