"""Adversarial partition/weight checks; no real model fitting or SQL benchmark."""
import collections
import hashlib
import json
from pathlib import Path
import random
import numpy as np
import xgboost as xgb
from report90_complex_retrain import BASE,pair_index,epoch_pairs,xgb_rows

samples=[];pairs=[];flat={}
for cohort in ['historical','complex_new']:
    for n in range(2):
        plan=cohort+str(n)
        for config,lat in [('fast',10),('slow',20)]:
            samples.append(dict(plan_key=plan,config_key=config,split='train',source_cohort=cohort,latency_ms=lat))
            flat[(plan,config)]=np.array([n,lat],dtype=np.float32)
        pairs.append(dict(plan_key=plan,fast_config_key='fast',slow_config_key='slow',fast_latency_ms=10,slow_latency_ms=20))
by=pair_index(samples,pairs);jobs=epoch_pairs(by,random.Random(17))
assert len(jobs)==624
assert collections.Counter('historical' if p['plan_key'].startswith('historical') else 'complex_new' for p in jobs)=={'historical':312,'complex_new':312}
for paired in [False,True]:
    X,y,g,w=xgb_rows(samples,pairs,flat,paired)
    assert len(w)==len(g)==4 and np.isclose(w[:2].sum(),.5) and np.isclose(w[2:].sum(),.5)
    model=xgb.XGBRanker(objective='rank:pairwise',n_estimators=1,n_jobs=1,tree_method='hist',random_state=17)
    model.fit(X,y,group=g,sample_weight=w)
    assert np.isfinite(model.predict(X)).all()
    try:xgb_rows([*samples,{**samples[0],'split':'valid'}],pairs,flat,paired)
    except AssertionError:pass
    else:raise AssertionError('Validation row must be rejected')
try:pair_index(samples,[*pairs,dict(pairs[0],plan_key='validation_only')])
except KeyError:pass
else:raise AssertionError('Non-training pair must be rejected')
script=Path(__file__).with_name('report90_complex_retrain.py')
result={'status':'passed','scope':'Synthetic mechanics checks only, not real model quality or runtime performance.',
        'checks':['exact312 draws per cohort','each cohort group weights sum0.5','XGBoost group-weight fitting works for both organizations','validation rows/non-training pairs rejected'],
        'xgboost_version':xgb.__version__,'source_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
        'test_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(BASE/'TRAINING_PIPELINE_SELFTEST.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
