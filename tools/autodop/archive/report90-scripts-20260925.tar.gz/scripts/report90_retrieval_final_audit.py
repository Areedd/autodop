"""Independent plain-Python replay of full retrieval targets, hits and identity."""
import hashlib
import json
import math
from pathlib import Path

RUN=Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    base=RUN/'retrieval_independent_report90'
    inputs=[base/n for n in ['PROTOCOL.json','RESULT.json','SUMMARY.json','REFERENCE.json']]
    protocol,result,summary,reference=[json.loads(p.read_text()) for p in inputs]
    assert result['status']=='verified_timed_traces' and summary['status']=='verified_first_hit_summary'
    assert result['protocol_sha256']==sha(inputs[0])
    for p,d in protocol['source_sha256'].items():
        assert sha(Path(p))==d,p
    wanted={(q,m,s) for q in protocol['queries'] for m in protocol['modes'] for s in protocol['seeds']}
    actual={(r['query'],r['method'],r['seed']) for r in result['rows']}
    assert wanted==actual and len(result['rows'])==len(wanted)==1620
    assert len(reference)==90
    for r in reference:
        assert len(r['configs'])==len(r['scores'])==256
        assert all(math.isfinite(v) for v in r['scores'])
        unique={}
        for c,v in zip(r['configs'],r['scores']):
            k=tuple(c)
            assert k not in unique or unique[k]==v
            unique[k]=v
        values=sorted(unique.values())
        assert values==protocol['reference_score_pools'][r['query']]
        for t,value in protocol['targets'][r['query']].items():
            assert values[math.ceil(float(t)*(len(values)-1))]==value
    rows={(r['query'],r['method'],r['seed']):r for r in result['rows']}
    for q in protocol['queries']:
        for seed in protocol['seeds']:
            scalar=rows[(q,'random_scalar',seed)]['trace']
            batched=rows[(q,'random_batch',seed)]['trace']
            assert [t['config'] for t in scalar]==[t['config'] for t in batched]
            for target in protocol['targets'][q].values():
                assert [t['score']>=target for t in scalar]==[t['score']>=target for t in batched]
    hits=0
    for trial in summary['trials']:
        r=rows[(trial['query'],trial['method'],trial['seed'])]
        assert len(r['trace'])==64
        assert r['total_ms']>0
        assert all(math.isfinite(t['score']) and 0<t['available_ms']<=r['total_ms'] for t in r['trace'])
        assert all(a['available_ms']<=b['available_ms'] for a,b in zip(r['trace'],r['trace'][1:]))
        assert r['score']==max(t['score'] for t in r['trace'])
        target=protocol['targets'][trial['query']][trial['target']]
        first=next((t for t in r['trace'] if t['score']>=target),None)
        assert trial['hit']==(first is not None)
        assert trial['median_hit_ms']==(first['available_ms'] if first else None)
        assert trial['evaluations']==(first['evaluations'] if first else None)
        if r['method']=='random_batch':
            assert all(t['evaluations']==16*(i//16+1) for i,t in enumerate(r['trace']))
            assert all(len({t['available_ms'] for t in r['trace'][i:i+16]})==1 for i in range(0,64,16))
        hits+=1
    assert hits==4860
    for item in summary['summary']:
        cells=[t for t in summary['trials'] if (t['method'],t['target'])==(item['method'],item['target'])]
        assert len(cells)==item['trials']==270
        assert sum(t['hit'] for t in cells)==item['hits']
        for b,count in item['hit_by_evaluations'].items():
            assert sum(t['hit'] and t['evaluations']<=int(b) for t in cells)==count
        for duration,count in item['hit_by_median_time_ms'].items():
            assert sum(t['hit'] and t['median_hit_ms']<=int(duration) for t in cells)==count
    oldpath=RUN/'search_refinement_report90/CHOICES.json'
    old=json.loads(oldpath.read_text())
    old={(r['id'],r['mode'],r['seed']):r for r in old}
    mapping=dict(original_mcts='original_mcts',refined='refined_full',no_attention='refined_no_attention',no_equivalence='refined_no_equivalence')
    checks=0
    for q in protocol['queries']:
        for a,b in mapping.items():
            row=rows[(q,a,17)];previous=old[(q,b,17)]
            assert row['config']==previous['config'],(q,a)
            assert math.isclose(row['score'],previous['score'],rel_tol=1e-6,abs_tol=1e-6)
            checks+=1
    assert checks==360
    report=dict(status='verified_independent_full_retrieval_audit',queries=90,
        timed_searches=1620,reference_candidate_scores=23040,first_hit_replays=4860,
        archived_mcts_choices=360,complete_query_method_seed_coverage=True,
        batch_completion_charged_in_full=True,
        scope='Independent recomputation of target order statistics, hits, time accounting and archived selections. No new SQL or claim of model-score correctness versus SQL latency.',
        source_sha256={str(p):sha(p) for p in inputs+[oldpath,Path(__file__)]})
    (base/'FINAL_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'},indent=2))


if __name__=='__main__':main()
