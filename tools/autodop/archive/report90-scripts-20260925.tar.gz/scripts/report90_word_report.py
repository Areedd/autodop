"""Build a self-contained, editable DOCX from frozen experimental evidence."""
import hashlib
import json
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'runs/report90_20260912'
OUT = RUN / 'word_report'
PRE = ROOT / 'runs/preference_random200_20260911/random200'
sources = {}


def read(p):
    sources[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
    return p.read_text()


def sections(text):
    parts = re.split(r'^## (.+)\n', text, flags=re.M)
    return {parts[i]: parts[i+1].strip() for i in range(1, len(parts), 2)}


def main():
    OUT.mkdir(exist_ok=True)
    base = sections(read(RUN / 'FINAL_REPORT.md'))
    ext = sections(read(RUN / 'distillation_concurrency_extension/REPORT.md'))
    def b(prefix):
        return next(v for k, v in base.items() if k.startswith(prefix))
    def e(title):
        s = ext[title]
        return re.sub(r'\]\((?!https?:|/)([^)]+)\)',
                      r'](distillation_concurrency_extension/\1)', s)
    structural = '''## 3. 实验数据与查询构造

本实验使用同一套事实表及日期维表构造查询。事实表包含重复实体键、日期键和数值列；查询按日期过滤三个月数据。不同窗口长度相同，但过滤后行数、不同键数量及键内日期密度可能不同，不能将窗口长度视为工作量。当前未提供完整逐窗口行数、NDV和偏斜分布的配对因果实验。

分支按算子结构定义，而非按业务名称定义：①按键和日期预聚合后，进行等值键与七日范围条件联合自连接，随后去重计数和聚合；②多层聚合后与三行阈值集合连接并条件汇总；③多层聚合后求键的起止月份，再与少量月份作范围连接；④多层聚合、分区MIN窗口及月份展开；⑤按键和日期预聚合后执行分区排序LAG窗口，再汇总。范围自连接可扩大中间结果；LAG通常不增加输入行数，两者不能仅因同属高DOP偏好而视为等量工作。

先对五类分支在三个窗口分别测量统一DOP1/2/4/8/16，每配置预热一次、正式三次。高组为8/16，低组为1/2/4；两组最快均值差至少10%，且三轮最优DOP同属一组才分类。随后在每条查询中选择2～4种不同分支，要求同时包含高低偏好，以INNER、LEFT、FULL OUTER JOIN和UNION ALL组成有序二叉树。JOIN通过月份键连接，指标列保留独立命名空间，UNION ALL保留重复行。不重复叶分支，不通过相同子查询填充数量。

固定生成种子20270923，抽取双分支24条、三分支76条、四分支100条；三个起始月份为1183、1189、1195。200条SQL和具体分支树签名均唯一，语法唯一不代表物理计划或语义均不等价。生成阶段不读取组合查询时延。

200条实测完成后，以AutoDOP三轮平均延迟优于逐查询最佳候选统一DOP为条件事后筛选90条。原筛选中78条三轮均正收益、50条平均优势至少20%。后续报告冻结全部90条，不再次按新测量筛选。该集合用于分析已观察到异构收益的负载，不能代替全200条或独立泛化评估。

| 结构特征 | 入选90条 | 未入选110条 |
|---|---:|---:|
| 包含预聚合后等值＋范围自连接 | 82（91.1%） | 72（65.5%） |
| 包含预聚合后LAG窗口 | 56（62.2%） | 79（71.8%） |
| 双／三／四分支数 | 9／31／50 | 15／45／50 |
| 四分支中平衡二叉树 | 17/50 | 7/50 |
| 预检查Fragment均值（含汇聚根） | 33.47 | 32.05 |
| 预检查Fragment中位数 | 34 | 33 |
| 四分支Fragment均值 | 39.22 | 39.44 |

平衡四分支结构为OP(OP(A,B),OP(C,D))，其入选率17/24；非平衡四分支为33/76。上述为事后关联，未控制分支组合和窗口，不证明树形具有独立因果收益。两组Fragment规模接近，支持进一步关注分支工作量和DOP敏感性，而非仅增加Fragment数量。Fragment来自原200条统一DOP4预检查，后续计划版本应以各阶段记录为准。

例如random200_012_m1189为INNER(FULL(B3,B2),INNER(B1,B0))，其中B0为范围自连接，其余为多阶段压缩/展开分支，原筛选相对最佳统一DOP平均降低43.62%。同时也存在包含B0却明显退化的查询，说明该结构不是收益保证。

来源：preference_random200_20260911下的BRANCH_PREFERENCES.json、prepare_random200.py、random200/manifest.json、trusted_merged.json和positive90/RESULT.json。
'''
    md = '# AutoDOP异构Fragment并行度调优实验报告\n\n版本：2026年9月19日整理版｜实验数据以各阶段协议为准\n\n'
    md += '## 摘要\n\n本报告整理冻结90条结构化查询的端到端性能、成本模型、搜索、策略消融、蒸馏、调优开销和并发结果。主串行实验相对原生、固定DOP4、逐查询最佳候选统一DOP的平均延迟分别降低36.71%、36.57%、23.83%。搜索在固定候选预算内的目标命中率提高；匹配蒸馏学生本地决策加速30.06倍。持续并发的AutoDOP观测峰值比同准入上限原生高9.23%，20 streams保持峰值98.59%，严格逐档吞吐不下降尚未达到。结论限定于历史优势子集，各实验的模型身份、计时范围和环境分别说明。\n\n'
    objectives = '''本实验旨在验证AutoDOP作为一种Fragment级DOP调优方法，能否根据同一SQL内不同Fragment的计算特征和并行度需求分配不同DOP，从而降低异构查询的端到端执行延迟，并在并发请求增加、系统资源趋于饱和时维持稳定的吞吐与运行状态。实验以完整查询的实际执行表现为主要依据，模型预测和搜索结果用于解释调优机制。

### 1.1 目标一：降低异构查询的端到端执行延迟

以相同SQL、相同数据、相同资源和共同执行设置进行对照，验证Fragment级异构DOP是否优于查询级统一DOP。主要基线包括关闭AutoDOP的受控原生StarRocks、固定统一DOP4，以及在候选DOP1/2/4/8/16中按每条查询实测均值选择的最佳统一DOP。最后一项用于检验收益是否超出了仅为整条查询选择合适统一DOP的效果，不称为所有可能配置中的全局最优。

主要指标为客户端从提交执行到完整取回结果的端到端延迟，包含查询路径上实际发生的在线AutoDOP调用、执行与结果传输；并发实验中还包含排队等待。会话准备和结果摘要计算不计入该计时。离线搜索生成配置后再直接安装的SQL回放不包含离线选配置成本，须独立列示，不能替代完整在线端到端结果。

| 评价维度 | 指标及统计方法 | 对应问题 |
|---|---|---|
| 整体延迟收益 | 对每条查询的正式重复取均值，再对固定查询集求平均；降幅为1－AutoDOP均值/基线均值 | 整体查询耗时是否降低 |
| 延迟分布 | 固定查询集逐查询均值的p50、p90、p99及其相对降幅 | 收益是否覆盖典型查询与较慢查询 |
| 收益覆盖 | 更快查询数/总查询数、逐查询相对降幅分布、退化查询及幅度 | 收益是否普遍，是否存在严重退化 |
| 测量一致性 | 保留全部正式轮次，比较各轮收益；报告重复次数 | 观察到的收益是否跨测量轮次保持 |
| 执行正确性 | 相同SQL结果摘要一致、实际DOP安装与请求关联核验、回退计数 | 加速是否来自有效且正确的执行 |

上述p90/p99描述查询集内不同查询平均延迟的分布，不等于单条查询经大量重复测得的尾延迟。不同实验重复次数不同，按各阶段协议说明，不将少量重复表述为统计显著性证明。正式评估保留冻结查询集中的全部查询、回退和退化结果，不依据本轮收益再次筛选。

### 1.2 目标二：在高并发下保持吞吐与运行稳定

逐步提高客户端streams，观察系统从资源尚有余量到接近饱和的变化。预期行为是资源未充分利用时吞吐随负载提高；达到饱和后，额外请求通过准入和排队得到处理，吞吐维持在稳定水平，且不因过量并行引发持续吞吐下降、内存耗尽或大量查询失败。该目标需要由实际测量检验，不预先将曲线平滑或波动视为通过。

| 评价维度 | 指标及统计方法 | 对应问题 |
|---|---|---|
| 吞吐扩展性 | 固定测量窗口内成功且结果核验通过的完成数/窗口秒数；绘制QPS－streams曲线 | 增加并发能否提高吞吐，何时进入饱和 |
| 饱和后吞吐保持 | 各档QPS、观测峰值、最高档QPS/峰值、饱和后各档相对峰值降幅 | 高并发是否出现吞吐回落或断崖式下降 |
| 相对基线表现 | 相同资源、相同查询序列、相同准入设置下的同档吞吐比及峰值吞吐比 | 异构调优是否在公平资源条件下保持优势 |
| 请求服务质量 | 包含排队的请求平均、p50、p90、p99延迟及等待队列、实际运行查询数 | 吞吐保持是否伴随过大的排队与尾延迟代价 |
| 运行可靠性 | 全部请求的成功、失败、超时、OOM及未完成数量；区分置信度回退与执行失败 | 高负载下能否持续正确处理请求 |
| 资源与时间稳定性 | CPU、内存、分段吞吐及采样覆盖，结合独立重复窗口（如有） | 吞吐变化是否与资源饱和和时间波动一致 |

持续窗口吞吐为主要并发证据。预热/稳定期和结束后的排空阶段单独记录，不混入窗口吞吐；有限批次完成时间作为补充。窗口内成功完成数用于计算有效吞吐，同时完整披露失败和超时，不能只用成功请求延迟掩盖失败。原生基线若启用相同准入控制，必须明确为受控原生对照，不能描述为关闭准入的产品默认行为。

吞吐稳定性与请求延迟稳定性分别判断：饱和后QPS保持并不意味着排队延迟不增长。“各档观测吞吐严格不下降”按原始曲线逐档核验；若存在下降，应报告幅度。若采用统计容差或非劣性标准，需要在验证前明确阈值、重复设计和判断方法，不能在看到下降后补设通过标准。当前仅有一次持续窗口的档位，可描述本轮观测，不足以证明长期稳定性。

### 1.3 辅助评价：解释收益来源及调优成本

成本模型成对排序准确率、固定评分预算下的搜索命中率、达到质量目标的评分次数和耗时、蒸馏决策成本及策略阶段消融，用于说明AutoDOP如何产生有效DOP配置，以及各步骤的作用。Transformer与竞争边作为整体建模方案，不单独设置删除竞争边对照。局部预测准确率或教师评分提高，不直接等同于端到端延迟降低。

同时报告在线决策与FE调用开销、离线标签生成和模型训练成本，明确计时范围及是否计入在线查询。最后训练阶段消融与匹配蒸馏对照分别解释，不将局部阶段消融写成完整训练链消融。完整系统收益、组件贡献及部署可用性分别给出结论。

本报告使用脚本构造并依据前期性能筛选、冻结的90条异构查询。实验目标和结论限定于该查询集及已记录的环境；该范围不替代标准TPC-H吞吐或TP/AP完整优化器开销验收，也不直接证明对任意异构查询均有相同收益。
'''
    chapters = [
        ('1. 实验目标与评价指标', objectives),
        ('2. 实验环境、模型与测量配置', b('2.')),
    ]
    for title, body in chapters: md += f'## {title}\n\n{body}\n\n'
    md += structural + '\n'
    chapters = [
        ('4. 异构查询端到端性能', b('3.')),
        ('5. 成本模型对比与消融', b('4.')),
        ('6. 搜索效率与结构消融', b('5.')),
        ('7. 策略蒸馏与训练阶段消融', '### 7.1 最后训练阶段消融\n\n'+b('6.')+'\n\n### 7.2 匹配教师与学生\n\n'+e('匹配教师与学生')+'\n\n![匹配蒸馏的决策与SQL延迟分布](distillation_concurrency_extension/figures/matched_distillation.png)'),
        ('8. 调优开销与资源成本', b('8.')+'\n\n### 8.1 持续并发中的在线服务成本\n\n'+e('在线负载修正与服务成本')+'\n\n### 8.2 在线缓存候选与适用边界\n\n'+e('在线改动与边界')),
        ('9. 并发性能与在线资源调节', '### 9.1 早期有限批次对照\n\n'+b('7.')+'\n\n### 9.2 最新持续窗口对照\n\n'+e('持续并发')+'\n\n![固定窗口吞吐与排队](distillation_concurrency_extension/figures/sustained_streams.png)\n\n### 9.3 资源与实际部署\n\n'+e('资源占用证据')+'\n\n### 9.4 准入参数小测\n\n'+e('后续准入参数小测')),
        ('10. 结论、正确性与适用范围', b('9.').replace('未新增生产代码或替换线上模型', '原主实验未新增生产代码或替换线上模型；后续补充增加默认关闭的可选策略缓存，仍未替换线上模型')+'\n\n本报告支持当前异构优势子集的性能改善以及规定对照下的组件贡献。Transformer排序准确率低于保留显式交互项的增强XGBoost；搜索较高教师分数不保证较低SQL延迟；最后阶段消融并非完整历史训练消融。新学生90/90条低于默认置信度门限，直接配置回放不能证明默认线上可部署。持续吞吐末档回落1.41%，不能认定严格单调或重复实验显著稳定。标准TPC-H SF100 throughput streams7–20、TP基准和完整TP/AP EXPLAIN开销仍不在完成范围内。'),
    ]
    for title, body in chapters: md += f'## {title}\n\n{body}\n\n'
    # Keep provenance for the structural statistics in the main text.
    read(PRE/'manifest.json')
    read(PRE/'positive90/RESULT.json')
    read(PRE/'trusted_merged.json')
    read(PRE.parent/'BRANCH_PREFERENCES.json')
    # Old report section references no longer match the reorganized chapter numbers.
    md = md.replace('最新全90搜索成本见第5节','最新全90搜索成本见第6节')
    # Omit the candidate-pool size, while retaining the performance-based selection method.
    md = md.replace('90条查询在本轮前由历史200条按优势筛选并冻结，本轮没有再次筛选。',
                    '本报告使用脚本构造并依据前期性能筛选、冻结的90条结构化查询，本轮没有再次筛选。')
    md = md.replace('固定生成种子20270923，抽取双分支24条、三分支76条、四分支100条；三个起始月份为1183、1189、1195。200条SQL和具体分支树签名均唯一，语法唯一不代表物理计划或语义均不等价。生成阶段不读取组合查询时延。',
                    '脚本使用固定生成种子20270923，覆盖起始月份1183、1189、1195。最终冻结的90条包含双分支9条、三分支31条、四分支50条，SQL及具体分支树签名均唯一。语法唯一不代表物理计划或语义均不等价。生成阶段不读取组合查询时延，后续按前期性能确定报告查询集。')
    md = md.replace('200条实测完成后，以AutoDOP三轮平均延迟优于逐查询最佳候选统一DOP为条件事后筛选90条。原筛选中78条三轮均正收益、50条平均优势至少20%。后续报告冻结全部90条，不再次按新测量筛选。该集合用于分析已观察到异构收益的负载，不能代替全200条或独立泛化评估。',
                    '本报告的90条查询由脚本构造，并以前期实测中AutoDOP三轮平均延迟优于逐查询最佳候选统一DOP为条件筛选、冻结。前期测量中78条三轮均正收益、50条平均优势至少20%。后续报告保留全部90条，不再次按新测量筛选。该集合用于分析已观察到异构收益的负载，不作为未经性能筛选的独立泛化评估。')
    table_start = md.index('| 结构特征 | 入选90条 | 未入选110条 |')
    table_end = md.index('\n\n例如random200_012', table_start)
    md = md[:table_start] + '''| 结构特征 | 冻结90条 |
|---|---:|
| 包含预聚合后等值＋范围自连接 | 82（91.1%） |
| 包含预聚合后LAG窗口 | 56（62.2%） |
| 双／三／四分支数 | 9／31／50 |
| 四分支中平衡二叉树 | 17/50 |
| 预检查Fragment均值（含汇聚根） | 33.47 |
| 预检查Fragment中位数 | 34 |
| 四分支Fragment均值 | 39.22 |

平衡四分支结构为OP(OP(A,B),OP(C,D))。上述为冻结查询集的描述性统计，不证明树形具有独立因果收益；应结合分支工作量和DOP敏感性分析，不能仅以Fragment数量解释优势。Fragment来自前期统一DOP4预检查，后续计划版本应以各阶段记录为准。''' + md[table_end:]
    md = md.replace('来源：preference_random200_20260911下的BRANCH_PREFERENCES.json、prepare_random200.py、random200/manifest.json、trusted_merged.json和positive90/RESULT.json。',
                    '构造、分支偏好、预检查和筛选证据保存在原实验目录，具体来源及摘要见本报告配套DOCX_AUDIT.json。配套实验数据保留原始查询ID，以便追溯SQL和测量结果。')
    from report90_absolute_latency import convert
    sources[str(Path(__file__).with_name('report90_absolute_latency.py'))] = hashlib.sha256(Path(__file__).with_name('report90_absolute_latency.py').read_bytes()).hexdigest()
    md = convert(md, RUN, OUT, read)
    unified = RUN/'six_model_control_20260919/full/UNIFIED_REPORT.md'
    unified_audit = unified.with_name('FINAL_AUDIT.json')
    if unified.exists() and unified_audit.exists():
        audit = json.loads(read(unified_audit))
        assert audit['status'] == 'verified_independent_replay'
        assert hashlib.sha256(unified.read_bytes()).hexdigest() == audit['report_sha256']
        read(unified.with_name('RESULT.json'))
        content = read(unified).split('\n', 1)[1].strip()
        basic = RUN/'basic_four_control_20260920/full/UNIFIED_REPORT.md'
        basic_audit = basic.with_name('FINAL_AUDIT.json')
        if basic.exists() and basic_audit.exists():
            md = md.replace('版本：2026年9月19日整理版','版本：2026年9月20日整理版')
            ba = json.loads(read(basic_audit))
            assert ba['status'] == 'verified_product_removal_and_replay'
            assert hashlib.sha256(basic.read_bytes()).hexdigest() == ba['report_sha256']
            read(basic.with_name('RESULT.json'))
            read(basic.with_name('MASK.json'))
            basic_content = read(basic).split('\n', 1)[1].strip().replace('## 完整特征版保留对照','### 显式乘积项的影响')
            content = basic_content + '\n\n### 5.2 完整显式乘积特征版补充对照\n\n以下为上一轮完整特征版，MLP和XGBoost输入与本报告基础特征主对照不同，单独保留。\n\n' + content
        md = md.replace('## 5. 成本模型对比与消融',
                        '## 5. 成本模型对比与消融\n\n### 5.1 六组模型统一条件主对照\n\n' + content +
                        '\n\n### '+('5.3' if basic.exists() and basic_audit.exists() else '5.2')+' 历史开发配置与特征消融\n\n以下为历史开发结果，其初始化、训练数据口径或训练过程与5.1不同，单独保留，不混入统一条件主对照。')
    (OUT/'实验报告正文.md').write_text(md)
    build_docx(md)


def build_docx(md):
    W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
    R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
    rels=[]; media={}; body=[]; figures=0; tables=0
    def rel(kind,target,external=False):
        rid=f'rId{len(rels)+1}';rels.append((rid,kind,target,external));return rid
    def run(text,bold=False):
        prop='<w:rPr><w:b/><w:bCs/><w:color w:val="000000"/></w:rPr>' if bold else ''
        return '<w:r>'+prop+'<w:t xml:space="preserve">'+escape(text)+'</w:t></w:r>'
    def inline(text):
        result='';pos=0
        for m in re.finditer(r'\[([^\]]+)\]\(([^)]+)\)|`([^`]+)`|\*\*([^*]+)\*\*',text):
            result+=run(text[pos:m.start()])
            if m[1]:
                target=m[2];p=RUN/target.split('#')[0]
                if not target.startswith(('http:','https:')):
                    if not p.exists():raise FileNotFoundError(p)
                    target=p.resolve().as_uri()
                rid=rel('hyperlink',target,True)
                result+=f'<w:hyperlink r:id="{rid}">'+run(m[1])+'</w:hyperlink>'
            else:result+=run(m[3] or m[4],bool(m[4]))
            pos=m.end()
        return result+run(text[pos:])
    def para(text,style=None):
        props=f'<w:pPr><w:pStyle w:val="{style}"/></w:pPr>' if style else ''
        return '<w:p>'+props+inline(text)+'</w:p>'
    lines=md.splitlines();i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line:i+=1;continue
        if line.startswith('|') and i+1<len(lines) and re.fullmatch(r'[| :\-]+',lines[i+1]):
            rows=[[x.strip() for x in line.strip('|').split('|')]];i+=2
            while i<len(lines) and lines[i].startswith('|'):
                rows.append([x.strip() for x in lines[i].strip('|').split('|')]);i+=1
            n=len(rows[0]);assert all(len(r)==n for r in rows);tables+=1
            body.append(para(f'表 {tables}', 'Caption'))
            width=10000//n
            table='<w:tbl><w:tblPr><w:tblStyle w:val="DataTable"/><w:tblW w:w="10000" w:type="dxa"/><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid>'+''.join(f'<w:gridCol w:w="{width}"/>' for _ in range(n))+'</w:tblGrid>'
            for j,row in enumerate(rows):
                table+='<w:tr><w:trPr><w:cantSplit/>'+('<w:tblHeader/>' if j==0 else '')+'</w:trPr>'
                for cell in row:
                    shade='<w:shd w:fill="E7EFF7"/>' if j==0 else ''
                    table+=f'<w:tc><w:tcPr><w:tcW w:w="{width}" w:type="dxa"/>{shade}</w:tcPr>'+para(cell,'TableText')+'</w:tc>'
                table+='</w:tr>'
            body.append(table+'</w:tbl>');continue
        image=re.fullmatch(r'!\[([^]]*)\]\(([^)]+)\)',line)
        if image:
            p=RUN/image[2];data=p.read_bytes();sources[str(p)]=hashlib.sha256(data).hexdigest()
            figures+=1;name=f'image{figures}.png';media[name]=data;rid=rel('image','media/'+name)
            with Image.open(p) as im:w,h=im.size
            cx=6200000;cy=int(cx*h/w)
            if cy>7000000:cx=int(cx*7000000/cy);cy=7000000
            body.append(f'<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:drawing><wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"><wp:extent cx="{cx}" cy="{cy}"/><wp:docPr id="{figures}" name="Figure {figures}"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="0" name="{name}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>')
            body.append(para(f'图 {figures}　{image[1]}','Caption'))
        elif line.startswith('# '):body.append(para(line[2:],'Title'))
        elif line.startswith('## '):body.append(para(line[3:],'Heading1'))
        elif line.startswith('### '):body.append(para(line[4:],'Heading2'))
        else:body.append(para(line[2:] if line.startswith('- ') else line))
        i+=1
    styleid=rel('styles','styles.xml');footerid=rel('footer','footer1.xml')
    sect=f'<w:sectPr><w:footerReference w:type="default" r:id="{footerid}"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="900" w:bottom="1134" w:left="900" w:header="500" w:footer="500"/></w:sectPr>'
    document=f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="{W}" xmlns:r="{R}"><w:body>'+''.join(body)+sect+'</w:body></w:document>'
    styles=f'<w:styles xmlns:w="{W}"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="宋体"/><w:sz w:val="22"/><w:lang w:val="en-US" w:eastAsia="zh-CN"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="100" w:line="300" w:lineRule="auto"/><w:widowControl/></w:pPr></w:pPrDefault></w:docDefaults>'
    for sid,size,color in [('Title',38,'16324F'),('Heading1',30,'16324F'),('Heading2',25,'234F70'),('Caption',19,'526577'),('TableText',18,'222222')]:
        heading=sid.startswith('Heading')
        pp=('<w:keepNext/>' if heading or sid=='Title' else '')+('<w:pageBreakBefore/>' if sid=='Heading1' else '')+(f'<w:outlineLvl w:val="{0 if sid=="Heading1" else 1}"/>' if heading else '')
        styles+=f'<w:style w:type="paragraph" w:styleId="{sid}"><w:name w:val="{sid}"/><w:pPr>{pp}<w:spacing w:before="120" w:after="100"/></w:pPr><w:rPr><w:sz w:val="{size}"/><w:color w:val="{color}"/>'+('<w:b/>' if heading or sid=='Title' else '')+'</w:rPr></w:style>'
    styles+='<w:style w:type="table" w:styleId="DataTable"><w:name w:val="DataTable"/><w:tblPr><w:tblBorders>'+''.join(f'<w:{k} w:val="single" w:sz="4" w:color="CAD3DD"/>' for k in ['top','left','bottom','right','insideH','insideV'])+'</w:tblBorders><w:tblCellMar><w:top w:w="75" w:type="dxa"/><w:bottom w:w="75" w:type="dxa"/><w:left w:w="80" w:type="dxa"/><w:right w:w="80" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style></w:styles>'
    footer=f'<w:ftr xmlns:w="{W}"><w:p><w:pPr><w:jc w:val="center"/></w:pPr>'+run('AutoDOP实验报告　|　')+'<w:fldSimple w:instr="PAGE"/></w:p></w:ftr>'
    relxml='<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+''.join(f'<Relationship Id="{rid}" Type="{R}/{kind}" Target="{escape(target, {chr(34): "&quot;"})}"'+(' TargetMode="External"' if external else '')+'/>' for rid,kind,target,external in rels)+'</Relationships>'
    ct='<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/>'+''.join(f'<Override PartName="/word/{name}.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.{typ}+xml"/>' for name,typ in [('document','document.main'),('styles','styles'),('footer1','footer')])+'</Types>'
    package={'[Content_Types].xml':ct,'_rels/.rels':f'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="{R}/officeDocument" Target="word/document.xml"/></Relationships>','word/document.xml':document,'word/styles.xml':styles,'word/footer1.xml':footer,'word/_rels/document.xml.rels':relxml}
    for xml in package.values():ET.fromstring(xml)
    path=OUT/'AutoDOP异构Fragment并行度调优实验报告.docx'
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for name,data in package.items():z.writestr(name,data)
        for name,data in media.items():z.writestr('word/media/'+name,data)
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        for rid,kind,target,external in rels:
            if not external:assert 'word/'+target in z.namelist()
    audit=dict(status='verified_docx_package_and_content',tables=tables,figures=figures,query_appendix_count=0,
               source_sha256=sources,docx_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
               visual_rendering='Not performed: no Word/LibreOffice renderer installed',script=str(Path(__file__).resolve()))
    (OUT/'DOCX_AUDIT.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'path':str(path),'tables':tables,'figures':figures,'bytes':path.stat().st_size},ensure_ascii=False))


if __name__=='__main__':main()
