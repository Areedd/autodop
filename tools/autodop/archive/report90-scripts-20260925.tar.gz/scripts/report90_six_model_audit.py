"""Independent checkpoint replay and report generation for matched six-model data."""
import csv
import hashlib
import json
import os
from pathlib import Path
import statistics
import sys
import time
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'scripts'),'/tmp/autodop-report-deps']
import numpy as np
import torch
import xgboost as xgb
from autodop.data import load_dataset,build_metadata
from autodop.training import select_partition,file_sha256
from autodop.graph import build_graph
from autodop.model import CostModel,LatencyRegressionModel
from report90_models import MLP,flat_features
from report90_six_model_control import DATA,OUT,KINDS,quality,key,state_hash,save


def main():
    run=OUT/'full';result=json.loads((run/'RESULT.json').read_text())
    assert result['status']=='verified' and len(result['candidates'])==36 and len(result['selected'])==18
    assert result['protocol']==json.loads((run/'PROTOCOL.json').read_text())
    for p,h in result['source_sha256'].items():assert file_sha256(p)==h
    cpus=os.sched_getaffinity(0);os.sched_setaffinity(0,{34 if 34 in cpus else min(cpus)});torch.set_num_threads(1)
    samples,pairs,_=load_dataset(DATA);contract=json.loads((run/'CONTRACT.json').read_text())
    tr,tp=select_partition(samples,pairs,contract,'train');va,_=select_partition(samples,pairs,contract,'valid')
    meta=json.loads((run/'METADATA.json').read_text());assert meta==build_metadata(tr)
    assert len({s['plan_key'] for s in tr})==114 and len({s['plan_key'] for s in va})==22
    supervised_keys={(p['plan_key'],p[w+'_config_key']) for p in tp for w in ['fast','slow']}
    assert len(supervised_keys)==1363
    graphs={key(s):build_graph(s,meta) for s in tr+va}
    xx=np.stack([flat_features(graphs[key(s)],meta) for s in tr]);norm=np.load(run/'NORMALIZATION.npz')
    mean=xx.mean(0);std=xx.std(0);std[std<1e-6]=1
    assert np.array_equal(mean,norm['mean']) and np.array_equal(std,norm['std'])
    vx=torch.tensor(np.stack([(flat_features(graphs[key(s)],meta)-mean)/std for s in va]))
    rows=[];pair_set=None
    for r in result['selected']:
        candidates=[x for x in result['candidates'] if (x['kind'],x['seed'])==(r['kind'],r['seed'])]
        expected_winner=min(candidates,key=lambda x:(-x['selected']['quality']['weighted_rank_accuracy'],x['selected']['quality']['weighted_regret'],x['setting']))
        assert r==expected_winner
        kind=r['kind'];reg=kind.endswith('regression');graph=kind.startswith('transformer');tree=kind.startswith('xgb')
        p=Path(r['model']);assert file_sha256(p)==r['model_sha256']
        if tree:
            model=xgb.XGBRegressor() if reg else xgb.XGBRanker();model.load_model(p);model.set_params(n_jobs=1)
            scores=model.predict(vx.numpy()).astype(float)
        else:
            torch.manual_seed(r['seed']);model=(LatencyRegressionModel(meta) if reg else CostModel(meta)) if graph else MLP(vx.shape[1]);assert state_hash(model)==r['initial_state_sha256']
            model.load_state_dict(torch.load(p,weights_only=True));model.eval()
            with torch.no_grad():scores=np.array([float(model(graphs[key(s)])) for s in va]) if graph else model(vx).numpy().astype(float)
        if reg:scores=-scores
        assert np.isfinite(scores).all()
        stored=json.loads((p.parent/'PREDICTIONS.json').read_text());expected=np.array([s['score'] for s in stored])
        assert np.array_equal(scores,expected)
        q,a=quality(va,scores);assert q==r['selected']['quality']
        sig={(x['plan'],x['a'],x['b'],x['cohort']) for x in a}
        assert len(sig)==920
        if pair_set is None:pair_set=sig
        else:assert sig==pair_set
        assert q['cohorts']['historical']['ranking_pairs']==699 and q['cohorts']['complex_new']['ranking_pairs']==221
        rows.append(dict(model=kind,seed=r['seed'],replay_max_abs_difference=float(np.max(np.abs(scores-expected))),pairs=920))
    # Audit all candidate training trajectories and paired initializations, not only winners.
    for seed in [17,29,43]:
        for family in ['transformer','mlp']:
            cc=[r for r in result['candidates'] if r['seed']==seed and r['kind'].startswith(family)]
            assert len({r['initial_state_sha256'] for r in cc})==1
            for r in cc:
                h=json.loads((Path(r['model']).parent/'PROGRESS.json').read_text())['history']
                assert len(h)==30 and [x['epoch'] for x in h if 'quality' in x]==[5,10,15,20,25,30]
                best_epoch=min([x for x in h if 'quality' in x],key=lambda x:(-x['quality']['weighted_rank_accuracy'],x['quality']['weighted_regret'],x['epoch']))
                assert best_epoch['epoch']==r['selected']['epoch'] and best_epoch['quality']==r['selected']['quality']
    names={'transformer_rank':'Transformer＋排序损失','transformer_regression':'Transformer＋回归损失','mlp_rank':'MLP＋排序损失','mlp_regression':'MLP＋回归损失','xgb_rank':'XGBoost＋排序目标','xgb_regression':'XGBoost＋回归目标'}
    agg=result['aggregate']
    def fmt(v,best,scale=1,decimals=3):
        text=f'{v*scale:.{decimals}f}'
        return '**'+text+'**' if best else text
    lines=['# 六组模型统一条件实验结果','',
      '本次比较统一使用114个训练计划的1365条配置和6702条训练对，验证为22个计划、212条配置；有效排序对共920条，其中历史699条、复杂221条。为匹配两种损失的监督来源，六组实际训练标签均取训练对的端点，覆盖1363条配置；另两条无训练对的配置只参与训练侧特征归一化。六组全部从头训练，不使用历史多阶段初始化、EMA或错对强化。验证集已被历史开发反复使用，并用于本轮选模，因此属于统一条件的开发集对照，而非独立盲测。','',
      '三个种子为17/29/43。Transformer和MLP每种目标均训练30轮，学习率为0.0003/0.001两档；每轮624对、每批16对，两个目标使用完全相同的端点和测量标签，初始化也相同。排序使用动态间隔hinge，回归使用训练权重标准化的log1p时延MSE。每5轮验证，以等权排序准确率优先、候选选择损失次之选模。','',
      'XGBoost均为200棵树、深度3/6两档、学习率0.05、全行全列采样，使用与神经网络同来源的全部训练对端点及等价权重。MLP与XGBoost均保留完整1088维特征和显式DOP交互项；Transformer使用完整依赖/竞争图。输入信息来源一致，但图与池化向量表示不同；树数与神经网络轮数不表示相同计算预算。','',
      '| 方案 | 等权排序准确率 % | 种子标准差（百分点） | 微平均准确率 % | 已测候选时延均值 ms | 训练循环 s | 单配置推理 ms |','|---|---:|---:|---:|---:|---:|---:|']
    columns=[('macro_accuracy_mean',True,100,3),('macro_accuracy_sd',None,100,3),('micro_accuracy_mean',True,100,3),('selected_observed_latency_mean_ms',False,1,2),('training_fit_mean_seconds',False,1,2),('inference_mean_ms',False,1,4)]
    for kind in KINDS:
        cells=[]
        for k,higher,scale,dec in columns:
            val=agg[kind][k];best=False if higher is None else val==(max if higher else min)(x[k] for x in agg.values())
            cells.append(fmt(val,best,scale,dec))
        lines.append('| '+names[kind]+' | '+' | '.join(cells)+' |')
    os.environ.setdefault('MPLCONFIGDIR','/tmp/autodop-matplotlib')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(9,4.5))
    values=[100*agg[k]['macro_accuracy_mean'] for k in KINDS]
    deviations=[100*agg[k]['macro_accuracy_sd'] for k in KINDS]
    bars=ax.bar(range(6),values,yerr=deviations,capsize=4,color=['#215c84','#8cb4cc','#2c7d61','#9cc9b6','#936625','#d4b48a'])
    ax.set_xticks(range(6),['Transformer\nRanking','Transformer\nRegression','MLP\nRanking','MLP\nRegression','XGBoost\nRanking','XGBoost\nRegression'])
    ax.set_ylim(0,100);ax.set_ylabel('Equal-cohort pairwise accuracy (%)')
    ax.set_title('Matched from-scratch comparison: mean and SD across 3 seeds')
    for i,(bar,v) in enumerate(zip(bars,values)):
        ax.text(bar.get_x()+bar.get_width()/2,v+deviations[i]+1,f'{v:.3f}',ha='center',fontsize=9,color='black',weight='bold' if v==max(values) else 'normal')
    fig.tight_layout();figure=run/'UNIFIED_ACCURACY.png';fig.savefig(figure,dpi=180);fig.savefig(run/'UNIFIED_ACCURACY.pdf');plt.close(fig)
    lines+=['',f'![六模型排序准确率：三种子均值与标准差]({figure})']
    lines+=['','黑色粗体为本表同列最优观测值，不表示统计显著性。等权准确率先分别计算历史/复杂组准确率，再平均；微平均直接统计920对。预测并列算错，实测时延差小于3%的对不纳入。','',
      '“已测候选时延”是模型从验证候选池选出的配置所对应的历史实测标签，不是本轮重新执行SQL，也不是90条报告查询的端到端性能。训练列为所选超参数设置完整30轮/200棵树的训练循环平均，不是达到所选检查点的最短训练时间；全部调参成本另列。推理列为单CPU、预建输入、单配置模型API耗时，不含特征构建、HTTP、FE或SQL。','',
      '| 方案 | seed | 历史准确率 % | 复杂准确率 % | 等权准确率 % | 所选epoch | 参数档位 |','|---|---:|---:|---:|---:|---:|---:|']
    for r in result['selected']:
        q=r['selected']['quality'];same_seed=[x['selected']['quality'] for x in result['selected'] if x['seed']==r['seed']]
        historical=fmt(q['cohorts']['historical']['rank_accuracy'],q['cohorts']['historical']['rank_accuracy']==max(x['cohorts']['historical']['rank_accuracy'] for x in same_seed),100)
        complex_value=fmt(q['cohorts']['complex_new']['rank_accuracy'],q['cohorts']['complex_new']['rank_accuracy']==max(x['cohorts']['complex_new']['rank_accuracy'] for x in same_seed),100)
        macro=fmt(q['weighted_rank_accuracy'],q['weighted_rank_accuracy']==max(x['weighted_rank_accuracy'] for x in same_seed),100)
        lines.append(f"| {names[r['kind']]} | {r['seed']} | {historical} | {complex_value} | {macro} | {r['selected']['epoch'] or '—'} | {r['setting']} |")
    lines+=['','| 方案 | 三种子两档参数累计训练循环 s |','|---|---:|']
    for kind in KINDS:lines.append(f"| {names[kind]} | {agg[kind]['total_tuning_fit_seconds']:.2f} |")
    lines+=['','XGBoost全行全列采样可能使三个种子模型相同；零种子标准差不代表独立数据重复。旧86.442%等接续训练结果属于不同训练条件，不与本表直接混合归因。所有参数候选、逐配置预测、920对判断和模型检查点均保留。','',
      f'[完整结构化结果]({run}/RESULT.json)；[执行协议]({run}/PROTOCOL.json)；[独立核验]({run}/FINAL_AUDIT.json)。']
    path=run/'UNIFIED_REPORT.md';path.write_text('\n'.join(lines)+'\n')
    audit=dict(status='verified_independent_replay',selected_models=18,candidate_models=36,pairs_per_model=920,
               same_evaluation_pairs=True,supervised_configurations=len(supervised_keys),train_only_normalization_verified=True,paired_initialization_verified=True,
               all_neural_candidates_30_epochs=True,replay=rows,figure_sha256=file_sha256(figure),source_sha256={str(Path(__file__)):file_sha256(__file__),str(run/'RESULT.json'):file_sha256(run/'RESULT.json')},
               report_sha256=file_sha256(path))
    save(run/'FINAL_AUDIT.json',audit)
    print(json.dumps(dict(status=audit['status'],aggregate=agg),ensure_ascii=False,indent=2))


if __name__=='__main__':main()
