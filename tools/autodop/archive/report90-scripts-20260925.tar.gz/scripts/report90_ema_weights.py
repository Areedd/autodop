"""Fixed-decay weight averaging; no data access or gradient updates."""
import copy
import torch

def initialize(model):
    averaged=copy.deepcopy(model).eval()
    averaged.requires_grad_(False)
    return averaged

@torch.no_grad()
def update(averaged,model):
    a=dict(averaged.named_parameters());b=dict(model.named_parameters())
    assert a.keys()==b.keys()
    for name,p in a.items():p.mul_(.99).add_(b[name],alpha=.01)
    a=dict(averaged.named_buffers());b=dict(model.named_buffers())
    assert a.keys()==b.keys()
    for name,p in a.items():p.copy_(b[name])
