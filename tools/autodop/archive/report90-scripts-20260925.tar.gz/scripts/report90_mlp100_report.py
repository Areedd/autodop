"""Render the100epoch MLP comparison from independently verified results."""
import json
from pathlib import Path
from report90_interaction_pair_audit import BASE,sha


def main():
    out=BASE/'mlp_interaction100'
    audit=json.loads((out/'PAIR_AUDIT.json').read_text())
    parity=json.loads((out/'BASELINE_PARITY.json').read_text())
    assert audit['status']=='verified_independent_pair_replay'
    lines=['# MLP显式DOP交互项：100轮同预算对照','',
           '两组均从头训练100轮，seed17，1088输入与64/64隐藏层。使用相同初始化规则、训练样本、采样和学习率候选。无交互组仅屏蔽532个归一化DOP乘积项，其余556列保持一致。', '',
           '| 模型 | 完整特征准确率 | 无交互项准确率 | 完整减无交互（百分点） |','|---|---:|---:|---:|']
    for kind,r in audit['models'].items():
        a,b=r['full']['macro_accuracy'],r['no_explicit_interaction']['macro_accuracy']
        lines.append(f'| {kind} | {100*a:.4f}% | {100*b:.4f}% | {100*(a-b):+.4f} |')
    lines += ['',f"完整特征组的6个候选与此前100轮基线参数逐张量相同：{parity['all_exact']}。", '',
              '两组先完成2轮冒烟检查及30轮小测，再分别进行本轮100轮训练。学习率3e-4/1e-3，每10轮按开发集两类等权排序准确率选模；920有效对已独立重算。', '',
              '单种子且复用开发集；该结果说明本轮特征干预的影响，不构成三种子稳定性、纯架构对照或报告90查询的盲测结论。', '',
              '证据：[独立核验](PAIR_AUDIT.json)、[完整基线重现](BASELINE_PARITY.json)、[协议](PROTOCOL.json)。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    sources=[Path(__file__),out/'PAIR_AUDIT.json',out/'BASELINE_PARITY.json',out/'PROTOCOL.json']
    (out/'REPORT.sources.json').write_text(json.dumps(dict(source_sha256={str(p):sha(p) for p in sources},output_sha256=sha(out/'REPORT.md')),indent=2)+'\n')


if __name__=='__main__':main()
