"""Query-cluster feature diagnostic on reused development validation data."""
import hashlib
import json
from pathlib import Path
import numpy as np

BASE = Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20'
OUT = BASE/'xgb_feature_ablation_pilot'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    result = json.loads((OUT/'RESULT.json').read_text())
    samples = json.loads((OUT/'VALIDATION_ROWS.json').read_text())
    selected = result['selected']
    parity = []
    for depth,index in [(3,0),(6,1)]:
        new = OUT/f'full_d{depth}.ubj'
        old = BASE/f'retrained/xgboost_pairs_h{index}/model.ubj'
        assert sha(new)==sha(old)
        parity.append(dict(depth=depth,original=str(old),retrained=str(new),sha256=sha(new)))
    rows = []
    for plan in sorted({s['plan_key'] for s in samples}):
        indices = [i for i,s in enumerate(samples) if s['plan_key']==plan]
        pairs = [(i,j) for pos,i in enumerate(indices) for j in indices[pos+1:]
                 if abs(samples[i]['latency_ms']-samples[j]['latency_ms'])/min(samples[i]['latency_ms'],samples[j]['latency_ms'])>=.03]
        assert pairs
        counts = {}
        correctness = {}
        for arm,record in selected.items():
            scores = record['scores']
            correctness[arm] = [int((scores[i]-scores[j])*(samples[j]['latency_ms']-samples[i]['latency_ms'])>0) for i,j in pairs]
            counts[arm] = sum(correctness[arm])
        discordance = {}
        for arm in selected:
            if arm=='full':continue
            discordance[arm] = dict(full_only=sum(a and not b for a,b in zip(correctness['full'],correctness[arm])),
                                   ablated_only=sum(b and not a for a,b in zip(correctness['full'],correctness[arm])))
        rows.append(dict(plan_key=plan,cohort=samples[indices[0]]['source_cohort'],pairs=len(pairs),correct=counts,discordance=discordance))
    assert len(rows)==22 and sum(r['pairs'] for r in rows)==920
    cohorts = sorted({r['cohort'] for r in rows})
    def accuracy(chosen,arm):
        return sum(sum(r['correct'][arm] for r in chosen if r['cohort']==c)/sum(r['pairs'] for r in chosen if r['cohort']==c) for c in cohorts)/len(cohorts)
    for arm in selected:
        assert abs(accuracy(rows,arm)-selected[arm]['quality']['weighted_rank_accuracy'])<1e-12
    rng = np.random.default_rng(20260914)
    draws = []
    for _ in range(10000):
        picked = []
        for cohort in cohorts:
            group = [r for r in rows if r['cohort']==cohort]
            picked.extend(group[i] for i in rng.integers(0,len(group),len(group)))
        draws.append(picked)
    comparisons = {}
    for arm in selected:
        if arm=='full':continue
        delta = np.array([100*(accuracy(p,'full')-accuracy(p,arm)) for p in draws])
        comparisons[arm] = dict(full_minus_ablated_pp=100*(accuracy(rows,'full')-accuracy(rows,arm)),
                                descriptive_cluster_interval_95_pp=np.quantile(delta,[.025,.975]).tolist(),
                                queries_full_better=sum(r['correct']['full']>r['correct'][arm] for r in rows),
                                queries_full_worse=sum(r['correct']['full']<r['correct'][arm] for r in rows),
                                queries_tied=sum(r['correct']['full']==r['correct'][arm] for r in rows),
                                full_only_pairs=sum(r['discordance'][arm]['full_only'] for r in rows),
                                ablated_only_pairs=sum(r['discordance'][arm]['ablated_only'] for r in rows))
    output = dict(status='verified',baseline_checkpoints_byte_identical=parity,comparisons=comparisons,queries=rows,
                  bootstrap=dict(seed=20260914,draws=10000,unit='query clusters within cohort; same resampled queries for all arms'),
                  limitation='Post-selection descriptive intervals on reused development data, conditional on one seed and fitted models. Not blind-test significance or uncertainty over training runs.',
                  source_sha256={str(p):sha(p) for p in [Path(__file__),OUT/'RESULT.json',OUT/'VALIDATION_ROWS.json',OUT/'PROTOCOL.json']})
    (OUT/'QUERY_DIAGNOSTIC.json').write_text(json.dumps(output,indent=2)+'\n')
    lines = ['# 特征消融的逐查询诊断','',
             '完整特征的深度3、6模型与原对照检查点字节完全相同，基线重现。', '',
             '| 移除项 | 完整组领先百分点 | 查询胜/负/平 | 描述性95%区间（百分点） |', '|---|---:|---|---|']
    for arm,r in comparisons.items():
        lo,hi=r['descriptive_cluster_interval_95_pp']
        lines.append(f"| {arm} | {r['full_minus_ablated_pp']:.3f} | {r['queries_full_better']}/{r['queries_full_worse']}/{r['queries_tied']} | [{lo:.3f}, {hi:.3f}] |")
    lines += ['', '按历史/复杂查询分层、以整条查询为单位配对重采样10000次，避免把同一查询的候选对当成独立样本。', '',
              '区间仅描述已拟合模型在复用开发集上的变化；各组深度已使用此验证集选择，不能称为盲测显著性，也未覆盖训练随机性。', '',
              '现有Transformer已做过显式DOP交互输入及平坦统计残差分支训练，均未稳定领先完整XGBoost；本诊断不证明简单加入交互特征就能解决Transformer差距。', '',
              '逐查询完整计数、差异对数与检查点哈希：[QUERY_DIAGNOSTIC.json](QUERY_DIAGNOSTIC.json)。']
    (OUT/'QUERY_DIAGNOSTIC.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(comparisons,indent=2))


if __name__=='__main__':main()
