"""Run unchanged search variants on the remaining four development queries."""
import argparse
import hashlib
import json
from pathlib import Path

import report90_search_refinement_prepare as prepare
import report90_search_refinement_execute as execute


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['prepare', 'execute'], required=True)
    args = parser.parse_args()
    base = prepare.RUN/'search_refinement_complement'
    assert json.loads((base/'PROTOCOL.json').read_text())['status'] == 'frozen_before_complement_search'
    sources = [Path(__file__), Path(prepare.__file__), Path(execute.__file__)]
    hashes = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
    provenance = base/'WRAPPER_SOURCES.json'
    if args.stage == 'prepare':
        with provenance.open('x') as stream:
            json.dump(hashes, stream, indent=2)
        prepare.OUT = base
        prepare.main()
    else:
        assert json.loads(provenance.read_text()) == hashes
        execute.BASE = base
        execute.OUT = base/'pilot'
        execute.main()


if __name__ == '__main__':
    main()
