"""Freeze training-only local DOP neighborhoods around observed development incumbents."""
import hashlib
import json
from pathlib import Path
import random

from autodop.data import sample_from_trace
from autodop.graph import sample_from_request
from autodop.mcts import equivalence_groups
from collect_paper_evaluations import VectorEngine
from build_trusted_dataset import digest

RUN = Path(__file__).resolve().parents[1] / 'runs/report90_20260912'
OUT = RUN / 'training_neighborhood_pilot'
COM = RUN / 'complex_development24'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def main():
    assert not OUT.exists()
    manifest = json.loads((COM / 'manifest.json').read_text())
    eligible = [q for q in manifest['queries'] if q['split'] == 'train' and '_b4_' in q['id']]
    selected = [min((q for q in eligible if q['tree']['op'] == root), key=lambda q: q['id']) for root in ['inner', 'left', 'full', 'union']]
    ids = {q['id'] for q in selected}
    samples_path = RUN / 'structure_coverage20/merged_dataset/samples.jsonl'
    samples = [json.loads(line) for line in samples_path.open()]
    best = {q: min((s for s in samples if s['template_id'] == q and s['split'] == 'train'), key=lambda s: (s['latency_ms'], s['config_key'])) for q in ids}
    evidence_path = COM / 'verified_labels/sample_evidence.jsonl'
    evidence = [json.loads(line) for line in evidence_path.open()]
    wanted = {query_id: e['template_id'] for e in evidence if e['template_id'] in ids and e['plan_key'] == best[e['template_id']]['plan_key'] for query_id in e['query_ids']}
    trace_path = COM / 'labels/collection/measured/accepted.jsonl'
    requests = {}
    for line in trace_path.open():
        trace = json.loads(line)
        if trace['query_id'] not in wanted:
            continue
        q = wanted[trace['query_id']]
        sample = sample_from_trace(trace)
        assert digest({'sql_sha256': best[q]['sql_sha256'], 'plan': sample['plan_key']}) == best[q]['plan_key']
        requests.setdefault(q, trace['request'])
    assert set(requests) == ids, ids - set(requests)
    protected = {s['sql_sha256'] for s in samples if s['split'] == 'valid'}
    report = json.loads((RUN / 'manifest.json').read_text())
    report_hashes = {q['sql_sha256'] for q in report['queries']}
    assert not ({q['sql_sha256'] for q in selected} & (protected | report_hashes))
    vectors = {f'neighbor{i}': {} for i in range(8)}
    descriptions = {}
    for q in sorted(ids):
        request = requests[q]
        sample = sample_from_request(request)
        base = best[q]['dop_config']
        assert len(base) == len(sample['fragments'])
        domains = [f['candidate_dops'] for f in best[q]['fragments']]
        groups = equivalence_groups(sample, domains)
        previous = {tuple(s['dop_config']) for s in samples if s['template_id'] == q}
        proposals = {}
        for group in groups:
            actions = sorted(set.intersection(*(set(domains[i]) for i in group)))
            current = base[group[0]]
            neighbors = [max((d for d in actions if d < current), default=None), min((d for d in actions if d > current), default=None)]
            for action in neighbors:
                if action is None:
                    continue
                config = list(base)
                for i in group:
                    config[i] = action
                if tuple(config) not in previous:
                    proposals.setdefault(tuple(config), {'group': list(group), 'action': action})
        candidates = sorted(proposals)
        random.Random(17).shuffle(candidates)
        assert len(candidates) >= 7, (q, len(candidates))
        chosen = [tuple(base)] + candidates[:7]
        descriptions[q] = {'training_plan_key': best[q]['plan_key'], 'old_anchor_latency_ms': best[q]['latency_ms'],
                           'candidate_neighbors': len(candidates), 'configs': []}
        for i, config in enumerate(chosen):
            assert all(d in domain for d, domain in zip(config, domains))
            mode = f'neighbor{i}'
            vector = {'request': request, 'fragment_dops': dict(zip(sample['fragment_ids'], config))}
            vectors[mode][q] = vector
            VectorEngine({q: vector}).decide(request)
            descriptions[q]['configs'].append({'mode': mode, 'dop_config': list(config), 'change': proposals.get(config, 'remeasured_anchor')})
    OUT.mkdir()
    manifest['queries'] = selected
    manifest['query_count'] = len(selected)
    save('manifest.json', manifest)
    save('vectors.json', vectors)
    save('PROPOSALS.json', descriptions)
    sources = [Path(__file__), samples_path, evidence_path, trace_path, COM / 'manifest.json', COM / 'TRUSTED_NATIVE.json', RUN / 'manifest.json']
    save('PROTOCOL.json', {'status': 'frozen_before_measurement', 'queries': sorted(ids), 'modes': list(vectors), 'warmup': 1, 'repetitions': 1, 'expected_executions': 64,
        'design': 'First lexicographic training4-branch query per root inner/left/full/union. Remeasure observed training incumbent and seven unseen one-group adjacent-DOP neighbors chosen with seed17. Local configurations need not be fast; measure every proposal.',
        'scope': 'Training-only acquisition pilot. No report90 or validation queries, no policy deployment or edits to active training data. All proposals and failures retained. No automatic expansion or fitting.',
        'source_sha256': {str(p): sha(p) for p in sources}})
    save('STATUS.json', {'status': 'prepared', 'queries': 4, 'configs': 32})
    print(json.dumps({q: {'neighbors': d['candidate_neighbors'], 'old_anchor_latency_ms': d['old_anchor_latency_ms']} for q, d in descriptions.items()}, indent=2))


if __name__ == '__main__':
    main()
