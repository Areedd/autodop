"""Replay recorded development decisions to measure actual DOP quantization."""
import collections
import json
import os
from pathlib import Path
import torch
from autodop.engine import PolicyEngine
from autodop.load_correction import apply_to_decision, fragment_factor, worker_factor
from autodop.training import file_sha256
from report90_execute import ROOT, RUN

OUT = RUN / 'load_quantization_audit'


def read(path): return json.loads(path.read_text())


def main():
    assert not OUT.exists(), 'Preserve existing audit'
    os.sched_setaffinity(0, {34}); torch.set_num_threads(1)
    protocol = read(RUN / 'PROTOCOL.json'); model_path = Path(protocol['model'])
    assert file_sha256(model_path) == protocol['model_sha256']
    engine = PolicyEngine(model_path)
    sources = [Path(__file__), model_path, ROOT / 'autodop/engine.py', ROOT / 'autodop/load_correction.py']
    all_rows = []; summaries = {}
    for name in ['development17_pressure', 'development17_cpu_threshold']:
        folder = RUN / name / 'scored'; events_path = folder / 'events.jsonl'; decisions_path = folder / 'decisions.jsonl'
        proof_path = folder / 'independent_verification.json'; proof = read(proof_path)
        assert proof['evidence_valid'] and not proof['missing_slots']
        sources += [events_path, decisions_path, proof_path]
        events = [json.loads(l) for l in events_path.open()]
        by_qid = {e['query_id']: e for e in events if e.get('query_id')}
        assert len(by_qid) == sum(bool(e.get('query_id')) for e in events)
        transitions = collections.defaultdict(collections.Counter)
        counts = collections.defaultdict(collections.Counter)
        for line in decisions_path.open():
            record = json.loads(line); mode = record['mode']; request = record['request']
            base = engine.decide(request)
            parameters = ({'cpu_threshold': .999, 'mem_threshold': .65, 'floor': .1}
                          if mode == 'policy_cpu_deferred' else {'cpu_threshold': .4, 'mem_threshold': .65, 'floor': .1})
            fragments = {str(f['fragment_id']): f for f in request['fragments']}
            expected = base if mode == 'policy_static' else {**base, 'decisions': [
                apply_to_decision(d, fragments[d['fragment_id']], request.get('worker_loads', {}), **parameters)
                for d in base['decisions']]}
            assert expected['decisions'] == record['response']['decisions'], (name, mode, record['query_id'])
            assert abs(expected['confidence'] - record['response']['confidence']) < 1e-7
            event = by_qid.get(record['query_id'])
            counts[mode]['replayed_decisions'] += 1
            counts[mode]['linked_decisions'] += int(event is not None)
            fresh = [v for v in request.get('worker_loads', {}).values() if v.get('fresh')]
            changes = []
            for before, after in zip(base['decisions'], expected['decisions']):
                if before['dop'] != after['dop']:
                    factor = fragment_factor(fragments[before['fragment_id']], request.get('worker_loads', {}), **parameters)
                    changes.append({'fragment_id': before['fragment_id'], 'base_dop': before['dop'], 'corrected_dop': after['dop'],
                                    'linear_factor': factor, 'effective_dop_ratio': after['dop'] / before['dop']})
            if event and event['phase'] == 'measured':
                counts[mode]['formal_linked'] += 1
                counts[mode]['formal_linked_failed'] += int(event['status'] != 'verified')
                counts[mode]['formal_changed_requests'] += int(bool(changes))
                counts[mode]['formal_installed_changed_requests'] += int(bool(changes) and bool(event.get('dop_validation', {}).get('applied')))
                for change in changes:
                    transitions[mode][f"{change['base_dop']}->{change['corrected_dop']}"] += 1
            all_rows.append({'experiment': name, 'mode': mode, 'query_id': record['query_id'],
                'event_id': event['id'] if event else None, 'phase': event['phase'] if event else None,
                'status': event['status'] if event else None, 'fresh_workers': len(fresh),
                'max_fresh_cpu': max([x['cpu_used'] for x in fresh], default=None),
                'max_fresh_memory': max([x['mem_used_pct'] for x in fresh], default=None), 'changes': changes})
        summaries[name] = {m: {'counts': dict(v), 'formal_transitions': dict(transitions[m]),
            'failed_events_without_query_id': sum(e['mode'] == m and e['status'] != 'verified' and not e.get('query_id') for e in events)} for m, v in counts.items()}
    factor = worker_factor({'fresh': True, 'cpu_used': .98, 'mem_used_pct': .3})
    from autodop.load_correction import corrected_dop
    example = {str(d): corrected_dop(d, factor, [1, 2, 4, 8, 16]) for d in [1, 2, 4, 8, 16]}
    result = {'status': 'verified_replay', 'experiments': summaries, 'rows': all_rows,
              'cpu98_memory30_example': {'factor': factor, 'base_to_corrected': example},
              'scope': 'Recorded request-time load and exact policy/correction replay. Changes are requested DOP, with installed counts only when event proof says applied. Missing query IDs remain unlinked. Does not prove memory peaks, failure causation, or counterfactual throughput.',
              'source_sha256': {str(p): file_sha256(p) for p in sources}}
    OUT.mkdir(); (OUT / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    lines = ['# 开发并发请求的负载修正量化审计', '', result['scope'], '',
             f"CPU=98%、内存=30%且负载新鲜时，默认线性因子为{factor:.4f}，DOP映射为{example}。离散候选取整会使实际DOP比例不同于线性因子。", '',
             '| 开发实验 | 模式 | 精确复算请求数 | 正式有改动请求 | 正式确认安装改动请求 | 正式DOP转换次数 |', '|---|---|---:|---:|---:|---|']
    for name, modes in summaries.items():
        for mode, s in modes.items():
            c = s['counts']
            lines.append(f"| {name} | {mode} | {c.get('replayed_decisions', 0)} | {c.get('formal_changed_requests', 0)} | {c.get('formal_installed_changed_requests', 0)} | {s['formal_transitions']} |")
    lines += ['', '此审计不修改策略或参数，不重新执行SQL。离散修正幅度及失败请求的负载关联提供机制排查依据，但不足以单独确定吞吐下降或OOM的原因。']
    (OUT / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({'status': result['status'], 'requests': len(all_rows), 'example': example}))


if __name__ == '__main__': main()
