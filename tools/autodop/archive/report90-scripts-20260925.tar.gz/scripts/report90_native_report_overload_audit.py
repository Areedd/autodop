"""Audit all attempted report-pilot queries, retaining observed OOM outcomes."""
import json,re,csv,io,hashlib
from collections import defaultdict,Counter
from datetime import datetime
from pathlib import Path
from report90_execute import ROOT,RUN
from report90_native_report_pilot import OUT,SUPPORT,MODES
from report90_native_predictor import NativePredictor

def main():
 read=lambda p:json.loads(p.read_text())
 events=list(map(json.loads,(OUT/'scored/events.jsonl').read_text().splitlines()));assert len(events)==128
 verification=read(OUT/'scored/independent_verification.json')
 assert verification['evidence_valid'] and not verification['missing_slots']
 assert read(RUN/'report90_native_budget_pilot_restart/RESTORATION.json')['restored']
 manifest={q['id']:q for q in read(SUPPORT/'manifest.json')['queries']}
 norm=lambda x:' '.join(x.split()).rstrip(';').rstrip()
 sqls={key:norm(Path(q['sql_file']).read_text()) for key,q in manifest.items()}
 groups=defaultdict(list)
 for e in events:
  assert e['status'] in ['verified','failed']
  if e['status']=='failed':assert 'Memory of process exceed limit' in e['error']
  groups[e['phase'],e['mode']].append(e)
 candidates=[]
 field=lambda line,key:re.search(r'\|'+key+r'=([^|]*)\|',line)[1]
 for line in (ROOT.parents[1]/'output/fe/log/fe.audit.log').open():
  if ' [query] ' not in line or '|Stmt=' not in line:continue
  sql=norm(line.split('|Stmt=',1)[1].split('|Digest=',1)[0])
  if sql not in sqls.values():continue
  candidates.append((int(field(line,'Timestamp')),sql,line.rstrip('\n')))
 history={h['query_id'].replace('-',''):h for h in read(OUT/'SLOT_HISTORY.json')['rows']}
 predictor=NativePredictor.load(RUN/'native_predictor_service17/MODEL.json')
 tables=lambda body:tuple(list(csv.reader(io.StringIO(body)))[1][:3])
 features={(r['id'],r['pipeline_dop']):r for r in read(RUN/'native_memory_features90_full/RESULT.json')['records']}
 responses=read(OUT/'PREDICTOR_REQUESTS.json');assert not responses['errors']
 for p in responses['records']:assert predictor.predict_csv(p['csv'],MODES.get(p['mode'],'fixed8'))==p['prediction']
 calls=[p for p in responses['records'] if p['mode']!='bootstrap']
 data_calls=[p for p in calls if tables(p['csv'])!=('0','0','0')]
 assert len(data_calls)==128
 assert len(calls)-len(data_calls)==sum(e['status']=='verified' for e in events)
 expected=Counter((p['mode'],tables(p['csv']),p['prediction']['encoded_cost_bytes']) for p in data_calls)
 actual=Counter();used=set();records=[];summary={}
 for (phase,mode),es in groups.items():
  assert len(es)==16
  starts=[datetime.fromisoformat(e['started_at']).timestamp()*1000 for e in es]
  matched=[(sql,line) for ts,sql,line in candidates if min(starts)-1000<=ts<=max(starts)+1000]
  assert len(matched)==16,(phase,mode,len(matched))
  success={e['query_id']:e for e in es if e['status']=='verified'}
  failed=Counter(e['id'] for e in es if e['status']=='failed');observed_failures=Counter()
  for sql,line in matched:
   qid=field(line,'QueryId');assert qid not in used;used.add(qid)
   key=next(k for k,v in sqls.items() if v==sql)
   assert field(line,'Db')==manifest[key]['database']
   state=field(line,'State')
   if qid in success:assert state=='EOF' and success[qid]['id']==key and field(line,'ErrorCode')==''
   else:
    assert state=='ERR' and field(line,'ErrorCode')!='';observed_failures[key]+=1
   encoded=int(field(line,'PredictMemBytes'));slots=int(field(line,'Slots'))
   assert int(field(line,'PendingTimeMs'))>=0
   assert encoded>0 and encoded%predictor.slot_bytes==0
   per_worker=encoded//predictor.slot_bytes
   assert per_worker<=32 and per_worker & (per_worker-1)==0 and slots==per_worker*3
   h=history[qid.replace('-','')];assert h['state']=='RELEASED'
   assert int(h['allocate_slots'])==int(h['est_costs_slots'])==slots
   actual[mode,tables(features[key,4 if mode.startswith('policy') else 0]['csv']),encoded]+=1
   records.append(dict(query_id=qid,id=key,phase=phase,mode=mode,state=state,audit_line=line,slot_history=h))
  assert observed_failures==failed and set(success)<=used
  summary[phase+'/'+mode]=dict(attempted=16,verified=len(success),oom_failed=sum(failed.values()),failed_ids=dict(failed))
 assert len(used)==128 and actual==expected
 rounds=read(OUT/'scored/collection.json')['rounds']
 metrics={r['mode']:{k:r[k] for k in ['expected','verified','failed_or_missing','workload_wall_seconds','verified_queries_per_second']} for r in rounds if r['phase']=='measured'}
 result=dict(status='audited_with_oom',summary=summary,formal_metrics=metrics,rows=records,
  scope='Original all-success gate remains failed; no full expansion. All128 FE query IDs and actual slots verified. Failed client events are associated at batch/query group level by exact SQL and start-time window, not individual client identity. OOM wording comes from client records, FE ERR confirms grouped failure. No successful-only latency superiority claim.',
  source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),OUT/'scored/events.jsonl',OUT/'scored/independent_verification.json',OUT/'SLOT_HISTORY.json',OUT/'PREDICTOR_REQUESTS.json']})
 (OUT/'OVERLOAD_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
 lines=['# 报告查询原生预算小测：保留内存超限结果','',result['scope'],'', '| 模式 | 正式成功/尝试 | 整批秒数 | 成功QPS |','|---|---:|---:|---:|']
 for mode,m in metrics.items():lines.append(f"| {mode} | {m['verified']}/{m['expected']} | {m['workload_wall_seconds']:.3f} | {m['verified_queries_per_second']:.4f} |")
 lines+=['','固定预算原生模式预热4次、正式2次BE内存超限；其他模式全部完成。没有重试或删除失败项，原FE及配置恢复。原始全成功门槛未通过，故不自动扩大90条。预测预算改善了本次原生模式完成率，但不能在不同完成率下直接比较延迟。']
 (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');print(summary,metrics)

if __name__=='__main__':main()
