"""Fixed-duration closed-loop SQL streams with FE admission and full evidence."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import itertools
import json
import os
from pathlib import Path
import random
import threading
import time

import pymysql
import torch
from autodop.engine import PolicyEngine
from autodop_server import AutoDopHandler,AutoDopHttpServer
from collect_paper_evaluations import Journal,ConcurrentTraces,load_queries,validate_execution_trace
from collect_trusted_dataset import fetch_timed,result_digest,frontend_settings
from report90_execute import check,RUN,ROOT
from report90_queue_extension import settings_guard,SETTINGS


def connect():
    return pymysql.connect(host='127.0.0.1',port=9030,user='root',autocommit=True,
                           connect_timeout=10,read_timeout=210,write_timeout=30)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True)
    parser.add_argument('--manifest',default=str(RUN/'manifest.json'))
    parser.add_argument('--trusted',default=str(ROOT/'runs/preference_random200_20260911/random200/trusted_merged.json'))
    parser.add_argument('--streams',default='4,8')
    parser.add_argument('--modes',default='native,policy_static,policy_load')
    parser.add_argument('--queue-cap',type=int,default=4)
    parser.add_argument('--duration',type=float,default=60)
    parser.add_argument('--settle',type=float,default=20)
    parser.add_argument('--seed',type=int,default=2026091481)
    args=parser.parse_args()
    assert args.queue_cap>0 and args.duration>0 and args.settle>=0
    out=Path(args.output).resolve();out.mkdir(exist_ok=False)
    (out/'raw').mkdir();torch.set_num_threads(1);os.sched_setaffinity(0,{27,28,29,30,31,32,33,34})
    streams=[int(x) for x in args.streams.split(',')];modes=args.modes.split(',')
    assert all(s>0 for s in streams) and set(modes)<= {'native','policy_static','policy_load','policy_cached'}
    queries=load_queries(Path(args.manifest).resolve(),Path(args.trusted).resolve())
    policy=Path(json.loads((RUN/'PROTOCOL.json').read_text())['model'])
    sources=[Path(__file__),Path(args.manifest),Path(args.trusted),policy,ROOT/'collect_paper_evaluations.py',
             ROOT/'collect_trusted_dataset.py',ROOT/'autodop/engine.py',ROOT/'autodop_server.py']
    hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
    protocol=dict(status='frozen_before_sql',settings=vars(args),queries=[q['id'] for q in queries],
        scope='Same cyclic shuffled global query sequence at all stream levels, zero think time, fixed completion-count window after settling. Count all result failures. Drain separately; no fixed-batch tail in window QPS. FE queue cap is shared by all modes; baseline is queue-controlled native, not queue-disabled product default. No training or query filtering by results.',
        source_sha256=hashes)
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    check(out/'IDLE.json')
    SETTINGS['query_queue_concurrency_limit']=str(args.queue_cap)
    SETTINGS['query_queue_pending_timeout_second']='180'
    events=Journal(out/'events.jsonl');decision_log=Journal(out/'decisions.jsonl')
    traces=ConcurrentTraces(out/'raw');summaries=[]
    slot_log=Journal(out/'slot_samples.jsonl');monitor_stop=threading.Event()
    active_case=[None];monitor_errors=[]

    def monitor_slots():
        while not monitor_stop.wait(2):
            case=active_case[0]
            if case is None:continue
            try:
                with pymysql.connect(host='127.0.0.1',port=9030,user='root',autocommit=True,
                                     connect_timeout=5,read_timeout=5) as conn,conn.cursor() as cursor:
                    cursor.execute("SELECT QUERY_ID,STATE,ALLOCATE_SLOTS FROM information_schema.warehouse_queries WHERE STATE IN ('ALLOCATED','REQUIRING')")
                    rows=[dict(query_id=str(q),state=str(s),slots=int(n)) for q,s,n in cursor.fetchall()]
                slot_log.write(dict(mode=case[0],streams=case[1],monotonic=time.monotonic(),rows=rows))
            except Exception as exc:
                record=dict(mode=case[0],streams=case[1],monotonic=time.monotonic(),error=repr(exc))
                monitor_errors.append(record);slot_log.write(record)

    class Recorded:
        def __init__(self,engine,mode):self.engine,self.mode=engine,mode
        def decide(self,request):
            start=time.perf_counter();response=self.engine.decide(request)
            # Append only: no cumulative JSON snapshot on the decision path.
            decision_log.write(dict(query_id=request.get('query_id'),mode=self.mode,request=request,
                                    response=response,service_ms=1000*(time.perf_counter()-start)))
            return response

    engines={m:Recorded(PolicyEngine(policy,{'cpu_threshold':.4,'mem_threshold':.65,'floor':.1} if m in ('policy_load','policy_cached') else None,cache_capacity=128 if m=='policy_cached' else 0),m) for m in modes if m!='native'}
    server=AutoDopHttpServer(('127.0.0.1',18082),AutoDopHandler);server.verbose=False
    threading.Thread(target=server.serve_forever,daemon=True).start()
    monitor=threading.Thread(target=monitor_slots,daemon=True);monitor.start()
    try:
        with settings_guard(out),connect() as control:
            with frontend_settings(control.cursor(),{'auto_dop_endpoint':'http://127.0.0.1:18082',
                    'auto_dop_trace_dir':str(out/'raw'),'auto_dop_fail_on_error':'false',
                    'auto_dop_timeout_ms':'1000','enable_auto_dop':'false'},
                    out/'frontend_settings.json',restore_connection_factory=connect):
                for level,stream_count in enumerate(streams):
                    order=list(modes);random.Random(args.seed+level).shuffle(order)
                    for mode in order:
                        active_case[0]=(mode,stream_count)
                        if mode!='native':
                            server.engine=engines[mode]
                            server.engine.engine.clear_decision_cache()
                        jobs=list(queries);random.Random(args.seed).shuffle(jobs)
                        tickets=itertools.count();ticket_lock=threading.Lock();clock={}
                        barrier=threading.Barrier(stream_count,action=lambda:clock.update(start=time.monotonic()))
                        records=[]
                        def worker(client):
                            local=[]
                            with connect() as conn,conn.cursor() as cursor:
                                for setting in ['enable_pipeline_engine=true',f'enable_auto_dop={str(mode!="native").lower()}',
                                        f'pipeline_dop={0 if mode=="native" else 4}','enable_runtime_adaptive_dop=false',
                                        'enable_query_cache=false','enable_spill=false','auto_dop_max_dop=16','query_timeout=180',
                                        'enable_profile=false']:
                                    cursor.execute('SET '+setting)
                                barrier.wait(timeout=60);database=None
                                while time.monotonic()<clock['start']+args.settle+args.duration:
                                    with ticket_lock:ticket=next(tickets)
                                    q=jobs[ticket%len(jobs)]
                                    event=dict(mode=mode,streams=stream_count,client=client,ticket=ticket,id=q['id'],sql_sha256=q['sql_sha256'])
                                    try:
                                        if database!=q['database']:
                                            cursor.execute('USE `'+q['database'].replace('`','``')+'`');database=q['database']
                                        rows=fetch_timed(cursor,q['sql'],event)
                                        digest=result_digest(rows)
                                        event['result_digest']=digest
                                        assert digest==q['native_result_digest'],'SQL result mismatch'
                                        cursor.execute('SELECT /*+ SET_VAR(enable_auto_dop=false) */ last_query_id()')
                                        event['query_id']=str(cursor.fetchone()[0]);event['status']='sql_verified'
                                    except Exception as exc:
                                        event.update(status='failed',error=repr(exc))
                                    event['completion_monotonic']=event.get('sql_finished_monotonic',time.monotonic())
                                    local.append(event)
                            return local
                        with ThreadPoolExecutor(max_workers=stream_count) as executor:
                            futures=[executor.submit(worker,i) for i in range(stream_count)]
                            for future in futures:records.extend(future.result())
                        drained=time.monotonic()
                        for event in records:
                            if event['status']=='sql_verified':
                                try:
                                    if mode!='native':
                                        trace=traces.wait(event['query_id'],10)
                                        event['dop_validation']=validate_execution_trace(trace,event['query_id'])
                                        event['trace']=trace
                                    event['status']='verified'
                                except Exception as exc:event.update(status='failed',error=repr(exc))
                            events.write(event)
                        lower=clock['start']+args.settle;upper=lower+args.duration
                        window=[e for e in records if lower<=e['completion_monotonic']<upper]
                        row=dict(mode=mode,streams=stream_count,start_monotonic=clock['start'],
                            window_start=lower,window_end=upper,window_seconds=args.duration,
                            window_verified=sum(e['status']=='verified' for e in window),
                            window_failed=sum(e['status']!='verified' for e in window),
                            total_executions=len(records),total_failures=sum(e['status']!='verified' for e in records),
                            drain_seconds=max(0,drained-upper),mode_order=order)
                        row['verified_qps']=row['window_verified']/args.duration
                        summaries.append(row)
                        (out/'PROGRESS.json').write_text(json.dumps(dict(status='running',rounds=summaries),indent=2)+'\n')
                        print(json.dumps(row),flush=True)
                        if row['total_failures']:raise RuntimeError('Pilot failure retained; stop expansion')
    finally:
        active_case[0]=None;monitor_stop.set();monitor.join(timeout=12)
        server.shutdown();server.server_close()
    for p,d in hashes.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==d,p
    (out/'RESULT.json').write_text(json.dumps(dict(status='completed_sustained_collection',rounds=summaries,
        frontend_restored=json.loads((out/'frontend_settings.json').read_text()).get('restored'),
        queue_restored=json.loads((out/'QUEUE_SETTINGS.json').read_text())['restored'],
        monitor_errors=monitor_errors,protocol_sha256=hashlib.sha256((out/'PROTOCOL.json').read_bytes()).hexdigest()),indent=2)+'\n')


if __name__=='__main__':main()
