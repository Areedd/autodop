"""Broader parity check after the small batched scoring pilot passed."""
import collections
import itertools
import json
import os
from pathlib import Path
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from report90_batched_cost import score_batch
from report90_neighborhood_prepare import RUN,sha
BASE=RUN/'structure_coverage20';OUT=RUN/'batched_cost_verification'


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1)
    pilot=RUN/'batched_cost_pilot/RESULT.json';r=json.loads(pilot.read_text());assert r['status']=='verified_batch_inference_pilot' and r['pair_order_unchanged'] and r['all_median_costs_lower']
    assert not OUT.exists();OUT.mkdir();data=BASE/'merged_dataset';samples,pairs,metadata=load_dataset(data);assert len(samples)==1577
    groups=collections.defaultdict(list)
    for s in samples:groups[s['plan_key']].append(s)
    models={'multistage':BASE/'prepared/cost.pt','ema17':BASE/'hard_pair_ema_pilot/pilot/transformer_h0/best.pt','ema29':BASE/'hard_pair_ema_stability/seed29/transformer_h0/best.pt','ema43':BASE/'hard_pair_ema_stability/seed43/transformer_h0/best.pt'}
    protocol={'models':{k:str(p) for k,p in models.items()},'chunk_size':16,'samples':1577,'unknown_dop_modes':[False,True],'tolerance':{'atol':1e-5,'rtol':1e-5},'scope':'Full local numerical verification of existing examples, not a deployment or speed benchmark. Ranking checks only for known DOP, since all-unknown inputs do not encode a candidate choice. Exact ties and near-ties may be sensitive to float32 batching; all order changes reported.', 'source_sha256':{str(p):sha(p) for p in [Path(__file__),Path(__file__).with_name('report90_batched_cost.py'),pilot,data/'samples.jsonl',data/'metadata.json',Path(__file__).parents[1]/'autodop/model.py',*models.values()]}}
    (OUT/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n');results={}
    for unknown in [False,True]:
        built={plan:[build_graph(s,metadata,unknown_dop=unknown) for s in rows] for plan,rows in groups.items()}
        for name,path in models.items():
            model,_=load_cost_model(path);model.eval();record={'samples':0,'max_abs_error':0.,'order_changes':0,'eligible_order_changes':0,'eligible_pairs':0,'top_choice_changes':0,'changed_pairs':[]}
            with torch.inference_mode():
                for plan,graphs in built.items():
                    a=torch.stack([model(g) for g in graphs]);b=torch.cat([score_batch(model,graphs[i:i+16]) for i in range(0,len(graphs),16)])
                    torch.testing.assert_close(a,b,atol=1e-5,rtol=1e-5);record['samples']+=len(graphs);record['max_abs_error']=max(record['max_abs_error'],float((a-b).abs().max()))
                    if not unknown:
                        rows=groups[plan]
                        winner=lambda scores:min(range(len(rows)),key=lambda i:(-float(scores[i]),rows[i]['config_key']))
                        record['top_choice_changes']+=winner(a)!=winner(b)
                        for i,j in itertools.combinations(range(len(rows)),2):
                            changed=int(torch.sign(a[i]-a[j]))!=int(torch.sign(b[i]-b[j]));eligible=max(rows[i]['latency_ms'],rows[j]['latency_ms'])/min(rows[i]['latency_ms'],rows[j]['latency_ms'])>=1.03
                            record['order_changes']+=changed;record['eligible_pairs']+=eligible;record['eligible_order_changes']+=changed and eligible
                            if changed:record['changed_pairs'].append({'plan_key':plan,'configs':[rows[i]['config_key'],rows[j]['config_key']],'scalar_scores':[float(a[i]),float(a[j])],'batch_scores':[float(b[i]),float(b[j])],'eligible':eligible})
            results[name+('_unknown' if unknown else '_known')]=record
            print(name,unknown,{k:v for k,v in record.items() if k!='changed_pairs'},flush=True)
    for p,d in protocol['source_sha256'].items():assert sha(Path(p))==d
    result={'status':'verified_batched_numerical_parity','evaluated_scores':sum(r['samples'] for r in results.values()),'models':results,'known_order_unchanged':all(r['order_changes']==0 for n,r in results.items() if n.endswith('_known')),'known_top_choice_unchanged':all(r['top_choice_changes']==0 for n,r in results.items() if n.endswith('_known')),'scope':protocol['scope'],'protocol_sha256':sha(OUT/'PROTOCOL.json')}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 候选批量评分完整数值核验','',protocol['scope'],'','| 模型与DOP模式 | 样本数 | 最大绝对差 | 已知DOP排序变化 | 已知DOP有效对变化 | 首选变化 |','|---|---:|---:|---:|---:|---:|']
    for name,r in results.items():lines.append(f"| {name} | {r['samples']} | {r['max_abs_error']:.3g} | {r['order_changes']} | {r['eligible_order_changes']} | {r['top_choice_changes']} |")
    lines+=['','unknown模式的排序与首选列为未评估的默认计数，不代表该模式的候选排序保证。未进入生产路径；局部批量评分加速不能直接套用于顺序依赖的MCTS，构图成本也不在本次计时中。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')

if __name__=='__main__':main()
