"""Audit completed pressure screen, including failed SQL without query IDs. No SQL executed."""
import collections
import datetime
import hashlib
import json
from pathlib import Path

from report90_execute import RUN, accept_concurrent_evidence

OUT = RUN/'development17_pressure'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    scored = OUT/'scored'
    proof_path = scored/'independent_verification.json'
    proof = read(proof_path)
    assert proof['expected_slots'] == proof['recorded_sql_slots'] == 204
    accept_concurrent_evidence(proof_path)
    for name, expected in proof['source_sha256'].items():
        assert sha(Path(name)) == expected
    assert read(OUT/'QUEUE_SETTINGS.json')['restored'] and read(scored/'frontend_settings.json')['restored']
    events = [json.loads(line) for line in (scored/'events.jsonl').open()]
    decisions = [json.loads(line) for line in (scored/'decisions.jsonl').open()]
    rounds = read(scored/'collection.json')['rounds']
    assert len(rounds) == 6 and len(events) == 204
    # Failed SQL can lack last_query_id; retain it in all denominators, never invent a trace link.
    by_qid = {e['query_id']: e for e in events if e.get('query_id')}
    assert len(by_qid) == sum(bool(e.get('query_id')) for e in events)
    metrics = {}
    for mode in ['native', 'policy_static', 'policy_load']:
        selected = [e for e in events if e['mode'] == mode]
        formal = [r for r in rounds if r['mode'] == mode and r['phase'] == 'measured']
        assert len(selected) == 68 and len(formal) == 1
        for phase in ['warmup', 'measured']:
            counts = collections.Counter(e['id'] for e in selected if e['phase'] == phase)
            assert len(counts) == 17 and set(counts.values()) == {2}
        success = sum(e['status'] == 'verified' for e in selected if e['phase'] == 'measured')
        assert success == formal[0]['verified']
        metrics[mode] = {'all_phase_failures': sum(e['status'] != 'verified' for e in selected),
                         'formal_verified': success, 'formal_attempts': 34,
                         'formal_goodput': success/formal[0]['workload_wall_seconds'],
                         'workload_wall_seconds': formal[0]['workload_wall_seconds'],
                         'linked_successful_formal_decisions': 0, 'installed_corrected_successful_formal_queries': 0,
                         'unlinked_decisions_all_phases': 0, 'max_fresh_memory_all_decisions': 0.,
                         'max_fresh_cpu_all_decisions': 0.}
        if mode == 'native':
            metrics[mode]['max_fresh_memory_all_decisions'] = None
            metrics[mode]['max_fresh_cpu_all_decisions'] = None
    for d in decisions:
        m = metrics[d['mode']]
        e = by_qid.get(d['query_id'])
        if e is None:
            m['unlinked_decisions_all_phases'] += 1
        elif e['phase'] == 'measured' and e['status'] == 'verified':
            assert e['mode'] == d['mode']
            m['linked_successful_formal_decisions'] += 1
            corrected = any('load_corrected' in f.get('reason','') for f in d['response']['decisions'])
            m['installed_corrected_successful_formal_queries'] += int(corrected and e['dop_validation']['applied'])
        for load in d['request'].get('worker_loads', {}).values():
            if load.get('fresh'):
                m['max_fresh_memory_all_decisions'] = max(m['max_fresh_memory_all_decisions'], load['mem_used_pct'])
                m['max_fresh_cpu_all_decisions'] = max(m['max_fresh_cpu_all_decisions'], load['cpu_used'])
    load = metrics['policy_load']
    gate = (load['all_phase_failures'] == 0 and load['installed_corrected_successful_formal_queries'] > 0
            and all(load['formal_goodput'] >= 1.03*metrics[m]['formal_goodput'] for m in ['native', 'policy_static']))
    result = {'status': 'complete_with_observed_memory_failures' if proof['failed_slots'] else 'complete',
              'screen_passed': gate, 'metrics': metrics, 'failed_slots': proof['failed_slots'],
              'source_sha256': {str(p): sha(p) for p in [Path(__file__), proof_path, OUT/'PROTOCOL.json', OUT/'QUEUE_SETTINGS.json', scored/'frontend_settings.json']},
              'scope': 'Development only, 17 training queries, 34 tasks per mode per phase. Complete attempts including failures. Unlinked decisions are not assigned to failed queries or claimed as installed. No full90 expansion.'}
    (OUT/'AUDITED_RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
    lines = ['# 历史训练查询资源压力小测', '',
             '三种模式共同准入上限16，16客户端；17条SQL每轮各执行两次，每模式1轮预热、1轮正式执行，共204次尝试。独立核验保留全部执行及真实BE内存上限失败；FE与队列设置均已恢复。', '',
             '| 模式 | 正式成功/尝试 | 正式有效吞吐 查询/秒 | 全阶段失败数 | 已核验安装修正的正式成功查询 |',
             '|---|---:|---:|---:|---:|']
    for mode, m in metrics.items():
        lines.append(f"| {mode} | {m['formal_verified']}/34 | {m['formal_goodput']:.4f} | {m['all_phase_failures']} | {m['installed_corrected_successful_formal_queries']} |")
    lines += ['', '预先规定的筛选门槛：负载修正所有执行成功，且正式有效吞吐至少高于原生和静态策略各3%。',
              f"本次门槛结果：{'通过' if gate else '未通过'}。不自动扩展至报告90查询。", '',
              '成功查询的低延迟不能替代整体完成率。吞吐分母包含失败执行占用的工作负载时间，未重试或删除失败任务。失败SQL可能未取得query_id，其决策不强行关联、不声称实际安装修正。', '',
              '这是短开发压力试验，不能证明稳态、统计显著性或合同验收达标。初始runner若在查询完成后的统计环节失败，该状态保留；本报告从独立核验证据离线生成，未重跑SQL。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'source_sha256'}, indent=2))


if __name__ == '__main__':
    main()
