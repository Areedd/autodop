"""Extend the independently verified calibration pilot to the predeclared three seeds."""
import datetime
import os
from pathlib import Path
import subprocess
import sys

import torch
import report90_coverage_stability as common
from report90_interaction_model import load_interaction_model
from autodop.training import file_sha256

BASE = common.BASE
OUT = BASE / 'pair_calibration_full'
SOURCE = BASE / 'interaction_ranking/seed17_trainer.py'


def main():
    os.sched_setaffinity(0, {35})
    torch.set_num_threads(1)
    common.load_cost_model = load_interaction_model
    pilot = common.read(BASE / 'pair_calibration_pilot/RESULT.json')
    audit = common.read(BASE / 'pair_calibration_pair_audit/RESULT.json')
    assert pilot['status'] == 'verified' and pilot['improves_matched_reference']
    assert audit['status'] == 'verified_independent_pair_replay'
    assert audit['models']['transformer']['macro_accuracy'] == pilot['after']['transformer']['weighted_rank_accuracy']
    for p, digest in audit['source_sha256'].items():
        assert file_sha256(p) == digest
    assert not OUT.exists()
    OUT.mkdir()
    common.save(OUT / 'PROTOCOL.json', {
        'at': datetime.datetime.now().astimezone().isoformat(), 'seeds': [17, 29, 43], 'epochs': 100,
        'gate': 'Completed30-epoch pilot improved the matched30-epoch interaction reference; all920 pair results independently replayed. It still trails XGBoost on primary accuracy. Extension tests learning curve and seed stability, not a declaration of superiority.',
        'loss': 'softplus(log(slow/fast)-a+b)+0.1*smooth_l1(a-b,log(slow/fast))',
        'unchanged': 'Same multi-stage initialization, zero-initialized DOP interaction, fixed train/valid split, equal cohort/plan pair sampling, batch16, Adam1e-4, cosine100 to1e-5, no preservation, evaluate every10.',
        'selection': 'Two-cohort equal-weight pair accuracy, regret tie break, earlier epoch. All three seeds reported, no seed selection or report90 label fitting/selection.',
        'scope': 'Development-only full training following pilot; no automatic SQL or deployment. Same original XGBoost depth3/6,200trees; remaining flat controls reused from accuracy-first baselines.',
        'source_sha256': {str(p): file_sha256(p) for p in [Path(__file__), SOURCE, Path(common.__file__),
            Path(__file__).with_name('report90_interaction_model.py'), BASE / 'pair_calibration_pilot/RESULT.json',
            BASE / 'pair_calibration_pair_audit/RESULT.json']}})
    for seed in [17, 29, 43]:
        folder = OUT / f'seed{seed}'
        text = SOURCE.read_text()
        substitutions = {
            repr(str(BASE / 'interaction_ranking/seed17')): repr(str(folder)),
            repr(str(BASE / 'interaction_ranking/PROTOCOL.json')): repr(str(OUT / 'PROTOCOL.json')),
            'torch.manual_seed(17);rng=random.Random(17)': f'torch.manual_seed({seed});rng=random.Random({seed})',
            'n_jobs=1,random_state=17,': f'n_jobs=1,random_state={seed},',
            'ranking.append(torch.nn.functional.softplus(target-a+b))':
                'ranking.append(torch.nn.functional.softplus(target-a+b)+0.1*torch.nn.functional.smooth_l1_loss(a-b,target))',
        }
        changes = {}
        for old, new in substitutions.items():
            count = text.count(old)
            assert count == (2 if old == repr(str(BASE / 'interaction_ranking/PROTOCOL.json')) else 1), (old, count)
            text = text.replace(old, new)
            changes[old] = {'replacement': new, 'occurrences': count}
        script = OUT / f'seed{seed}_trainer.py'
        compile(text, str(script), 'exec')
        script.write_text(text)
        common.save(OUT / f'seed{seed}_SOURCE_TRANSFORM.json', {'original_sha256': file_sha256(SOURCE),
            'generated_sha256': file_sha256(script), 'changes': changes})
        common.save(OUT / 'STATUS.json', {'status': 'running', 'seed': seed, 'pid': os.getpid()})
        with (OUT / f'seed{seed}.log').open('w') as stream:
            subprocess.run([sys.executable, str(script)], stdout=stream, stderr=subprocess.STDOUT, check=True)
        common.replay(folder)
    common.save(OUT / 'RESULT.json', {'status': 'verified',
        'seeds': {str(s): common.read(OUT / f'seed{s}/SCORE_REPLAY.json')['models'] for s in [17, 29, 43]},
        'protocol_sha256': file_sha256(OUT / 'PROTOCOL.json')})
    common.save(OUT / 'STATUS.json', {'status': 'complete'})


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        if OUT.exists():
            common.save(OUT / 'STATUS.json', {'status': 'failed', 'error': repr(error)})
        raise
