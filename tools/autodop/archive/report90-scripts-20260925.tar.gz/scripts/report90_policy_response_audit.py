"""Independently replay journaled policy requests, including rejected low-confidence responses."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import torch
from autodop.engine import PolicyEngine


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def records(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def verify_response(event, decision, engine, threshold=.5):
    assert event['status']=='verified' and event['autodop_enabled']
    assert decision['mode']==event['mode'] and decision['query_id']==event['query_id']
    assert decision['request']['query_id']==event['query_id']
    response=decision['response'];assert response['query_id']==event['query_id']
    replay=engine.decide(decision['request'])
    assert replay['version']==response['version'] and replay['decisions']==response['decisions']
    difference=abs(replay['confidence']-response['confidence'])
    assert math.isfinite(response['confidence']) and difference<=1e-6
    applied=event['dop_validation']['applied']
    if applied:
        assert response['confidence']>=threshold and event['trace']['response']==response
    else:
        assert event['dop_validation']['fallback_category']=='low_confidence'
        assert 'confidence is below the configured threshold' in event['trace']['skip_reason']
        assert response['confidence']<threshold
    return difference,applied


def audit(directory, output, selected_modes=None, threshold=.5):
    directory=Path(directory).resolve();output=Path(output)
    assert not output.exists()
    proof=directory/'independent_verification.json'
    assert json.loads(proof.read_text())['all_expected_executions_verified']
    variants_path=directory/'policy_variants.json'
    variants=json.loads(variants_path.read_text())
    events=records(directory/'events.jsonl')
    modes=set(selected_modes) if selected_modes is not None else {r['mode'] for r in events}
    assert modes and modes<=set(variants)
    engines={};sources=[Path(__file__),proof,variants_path,directory/'events.jsonl',directory/'decisions.jsonl']
    torch.set_num_threads(1)
    for mode in sorted(modes):
        variant=variants[mode];assert variant['load_correction'] is False
        checkpoint=Path(variant['checkpoint']);assert sha(checkpoint)==variant['checkpoint_sha256']
        engines[mode]=PolicyEngine(checkpoint);sources.append(checkpoint)
    decisions={}
    for row in records(directory/'decisions.jsonl'):
        assert row['query_id'] not in decisions
        decisions[row['query_id']]=row
    counts={mode:dict(executions=0,applied=0,low_confidence_fallback=0,max_confidence_difference=0.) for mode in modes}
    for event in events:
        mode=event['mode']
        if mode not in modes: continue
        decision=decisions[event['query_id']]
        difference,applied=verify_response(event,decision,engines[mode],threshold)
        count=counts[mode];count['executions']+=1
        count['max_confidence_difference']=max(count['max_confidence_difference'],difference)
        if applied:
            count['applied']+=1
        else:
            count['low_confidence_fallback']+=1
    assert all(c['executions']>0 for c in counts.values())
    result=dict(status='verified_policy_response_replay',modes=counts,threshold=threshold,
                all_collection_modes_replayed=modes=={r['mode'] for r in events},
                scope='Checkpoint replay verifies response identity and DOP/confidence, including legitimate low-confidence fallback. Request failures, invalid responses and other skip reasons fail this functional gate. No new SQL or latency measurements.',
                source_sha256={str(p):sha(p) for p in sources})
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,indent=2)+'\n')
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--collection-dir',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--modes')
    args=parser.parse_args()
    result=audit(args.collection_dir,args.output,args.modes.split(',') if args.modes else None)
    print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'},indent=2))
