"""Capture the real native pre-admission CSV via EXPLAIN SCHEDULER only."""
import argparse
import csv
import datetime
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import os
from pathlib import Path
import subprocess
import threading
import time
import uuid
import pymysql
from collect_trusted_dataset import frontend_settings
from report90_execute import ROOT,RUN,check


def main(phase):
    out=RUN/f'native_memory_features17_{phase}';out.mkdir(exist_ok=False)
    save=lambda n,d:(out/n).write_text(json.dumps(d,indent=2)+'\n')
    save('STATUS.json',dict(status='running',pid=os.getpid()))
    os.sched_setaffinity(0,set(range(27,35)))
    manifest=RUN/'DEVELOPMENT17_MANIFEST.json'
    queries=json.loads(manifest.read_text())['queries'];assert len(queries)==17
    if phase=='pilot':queries=queries[:2]
    else:assert json.loads((RUN/'native_memory_features17_pilot/STATUS.json').read_text())['status']=='verified'
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    save('PROTOCOL.json',dict(phase=phase,queries=len(queries),pipeline_dops=[0,4],
         scope='Native physical-plan CSV captured before admission. EXPLAIN SCHEDULER only; no query execution latency measurement. '
               'Temporary localhost predictor returns0; no prediction model, no production admission changes.',
         sources={str(p):sha(p) for p in [Path(__file__),manifest,ROOT/'collect_trusted_dataset.py']}))
    connection=lambda:pymysql.connect(host='127.0.0.1',port=9030,user='root',autocommit=True,
                                      connect_timeout=5,read_timeout=30)
    lock=threading.Lock();active=None;records=[];errors=[]
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_GET(self):
            self.send_response(200 if self.path=='/health_check' else 404);self.end_headers();self.wfile.write(b'OK')
        def do_POST(self):
            try:
                assert self.path=='/predict_csv'
                n=int(self.headers['Content-Length']);assert 0<n<1000000
                body=self.rfile.read(n).decode();rows=list(csv.reader(io.StringIO(body)))
                assert len(rows)==2 and len(rows[0])==len(rows[1]) and len(set(rows[0]))==len(rows[0])
                values=[int(v) for v in rows[1]];assert rows[0][:3]==['tables_0','tables_1','tables_2']
                with lock:
                    assert active is not None,'Unassociated predictor request'
                    records.append(dict(**active,at=datetime.datetime.now().astimezone().isoformat(),
                                        header=rows[0],values=values,csv=body))
                self.send_response(200);self.end_headers();self.wfile.write(b'0')
            except Exception as e:
                errors.append(repr(e));self.send_response(500);self.end_headers()
    server=None
    try:
        check(out/'IDLE.json')
        server=ThreadingHTTPServer(('127.0.0.1',18083),Handler)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        with connection() as control,connection() as client:
            with frontend_settings(control.cursor(),{
                'query_cost_prediction_service_address':'http://127.0.0.1:18083',
                'enable_query_cost_prediction':'true'},out/'frontend_settings.json',restore_connection_factory=connection):
                with client.cursor() as cursor:
                    for setting in ['enable_auto_dop=false','enable_runtime_adaptive_dop=false',
                                    'enable_query_cache=false','enable_spill=false','enable_profile=false']:
                        cursor.execute('SET '+setting)
                    for query in queries:
                        path=Path(query['sql_file']);assert sha(path)==query['sql_sha256']
                        cursor.execute('USE `'+query['database'].replace('`','``')+'`')
                        for dop in [0,4]:
                            cursor.execute('SET pipeline_dop='+str(dop))
                            token='autodop_memory_features_'+uuid.uuid4().hex
                            descriptor=dict(id=query['id'],sql_sha256=query['sql_sha256'],
                                            database=query['database'],pipeline_dop=dop,audit_token=token)
                            with lock:
                                active=descriptor;before=len(records)
                            sql='EXPLAIN SCHEDULER /* '+token+' */ '+path.read_text().strip().rstrip(';')
                            start=time.monotonic();cursor.execute(sql);plan=cursor.fetchall();elapsed=time.monotonic()-start
                            with lock:
                                assert len(records)==before+1,(descriptor,len(records)-before,errors)
                                record=records[-1];record['explain_seconds']=elapsed;record['scheduler_plan']=plan
                                record['explain_sql']=sql;active=None
                            save('CAPTURE.json',dict(records=records,errors=errors))
        assert not errors and len(records)==len(queries)*2
        header=records[0]['header'];assert all(r['header']==header for r in records)
        # Return the raw evidence first; FE statement identity is corroborated separately.
        save('RESULT.json',dict(status='captured',records=records,errors=errors,header=header,
                               note='Each serial EXPLAIN produced exactly one HTTP request. Audit tokens retained for FE identity verification.'))
        assert json.loads((out/'frontend_settings.json').read_text())['restored']
        save('STATUS.json',dict(status='captured',records=len(records),columns=len(header)))
        print('Captured native feature rows:',len(records),'columns:',len(header))
    except BaseException as error:
        save('CAPTURE.json',dict(records=records,errors=errors));save('STATUS.json',dict(status='failed',error=repr(error)));raise
    finally:
        if server is not None:server.shutdown();server.server_close()


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['pilot','full'],required=True)
    main(p.parse_args().phase)
