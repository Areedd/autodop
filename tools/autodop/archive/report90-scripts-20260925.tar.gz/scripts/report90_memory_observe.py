"""Bounded direct-BE/FE memory observation; never alters server configuration."""
import argparse
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import statistics
import time
import urllib.request

import pymysql


def fetch(port):
    started = datetime.datetime.now().astimezone().isoformat()
    begin = time.monotonic()
    url = f'http://127.0.0.1:{port}/metrics/memory'
    with urllib.request.urlopen(url, timeout=3) as response:
        raw = response.read()
    end = time.monotonic()
    tree = json.loads(raw)
    process = [r for r in tree if r['name'] == 'process']
    assert len(process) == 1
    query = [r for r in process[0]['child'] if r['name'] == 'query_pool']
    assert len(query) == 1
    used, queries = int(process[0]['size']), int(query[0]['size'])
    assert used >= 0 and queries >= 0
    return dict(url=url, started_at=started, ended_at=datetime.datetime.now().astimezone().isoformat(),
                fetch_ms=(end-begin)*1000, process_bytes=used, query_bytes=queries,
                response_bytes=len(raw), raw=tree)


def observe(output, samples=20, interval=1, stop=None):
    assert 1 <= samples <= 3600 and interval >= 1
    os.sched_setaffinity(0, set(range(27, 35)))
    rows = []
    with output.open('x') as stream, concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        stream.write(json.dumps(dict(type='protocol', samples=samples, interval_seconds=interval,
                                    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                                    scope='Observation cost is HTTP/SQL wall time, not server CPU overhead. '
                                          'Direct counters are not atomic snapshots across workers or tracker nodes. '
                                          'FE percentages are rounded; request smoothing is observed separately.'))+'\n')
        with pymysql.connect(host='127.0.0.1', port=9030, user='root', connect_timeout=5,
                             read_timeout=5, autocommit=True,
                             cursorclass=pymysql.cursors.DictCursor) as connection:
            initial_ids = None
            for index in range(samples):
                if stop is not None and stop.is_set():
                    break
                start = time.monotonic()
                at = datetime.datetime.now().astimezone().isoformat()
                futures = {port: pool.submit(fetch, port) for port in (8040,8041,8042)}
                with connection.cursor() as cursor:
                    sql_start = time.monotonic()
                    cursor.execute('SHOW BACKENDS')
                    backends = cursor.fetchall()
                    sql_ms = (time.monotonic()-sql_start)*1000
                selected = {int(b['HttpPort']): b for b in backends if int(b['HttpPort']) in futures}
                assert set(selected) == set(futures)
                ids = {p:str(b['BackendId']) for p,b in selected.items()}
                if initial_ids is None:
                    initial_ids = ids
                assert ids == initial_ids, 'Backend identity changed'
                workers = []
                for port,future in futures.items():
                    b = selected[port]; assert b['Alive'] is True or str(b['Alive']).lower()=='true'
                    workers.append(dict(backend_id=ids[port], direct=future.result(),
                                        fe={k:b[k] for k in ('BackendId','HttpPort','HeartbeatPort',
                                                           'Alive','MemUsedPct','MemLimit','CpuUsedPct')},
                                        fe_memory_fraction=float(str(b['MemUsedPct']).rstrip('%'))/100))
                elapsed = time.monotonic()-start
                record=dict(type='sample', index=index, at=at, elapsed_seconds=elapsed,
                            show_backends_ms=sql_ms, overran_interval=elapsed>interval, workers=workers)
                stream.write(json.dumps(record,default=str)+'\n');stream.flush();rows.append(record)
                if index+1<samples:
                    wait=max(0,interval-(time.monotonic()-start))
                    if stop is not None:
                        stop.wait(wait)
                    else:
                        time.sleep(wait)
    costs=[w['direct']['fetch_ms'] for r in rows for w in r['workers']]
    return dict(status='verified', samples=len(rows), http_requests=len(costs),
                median_http_ms=statistics.median(costs) if costs else None,
                max_http_ms=max(costs,default=None),
                median_show_backends_ms=statistics.median(r['show_backends_ms'] for r in rows) if rows else None,
                overruns=sum(r['overran_interval'] for r in rows),
                backend_ids=initial_ids,
                scope='Read-only sampling pilot; not a query benchmark or proof of negligible CPU overhead.')


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--samples',type=int,default=20)
    parser.add_argument('--interval',type=float,default=1)
    args=parser.parse_args()
    result=observe(args.output,args.samples,args.interval)
    args.output.with_suffix('.summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
