"""Pair all repeated jobs across scheduler arms; stratify by frozen budget class."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import re
import statistics

RUN = Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def load_arm(name):
    out = RUN/('report90_native_budget_mixed_'+name)
    proof = json.loads((out/'ALLOCATION_AUDIT.json').read_text())
    assert proof['status']=='verified' and proof['executions']==128
    for path,expected in proof['source_sha256'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==expected, path
    events = {e['query_id']:e for e in map(json.loads,(out/'scored/events.jsonl').read_text().splitlines())}
    assert len(events)==128
    rows = {}
    for row in proof['rows']:
        e = events[row['query_id']]
        key = (e['phase'],e['mode'],e['id'],e['client'],e['sequence'])
        assert key not in rows and e['status']=='verified'
        match = re.search(r'\|PendingTimeMs=(\d+)\|',row['audit_line'])
        assert match
        rows[key] = dict(wait_ms=int(match[1]),client_ms=e['client_latency_ms'],
                         slots=row['slots'],dop=e.get('dop_validation'))
    return rows


def main():
    arms = {name:load_arm(name) for name in ('swrr','fifo')}
    assert arms['swrr'].keys()==arms['fifo'].keys()
    selection = RUN/'native_mixed_budget_pilot_support/SELECTION.json'
    classes = {r['id']:r['native_slots'] for r in json.loads(selection.read_text())['queries']}
    assert set(classes.values())=={24,48}
    groups = defaultdict(list)
    rows = []
    for key,a in arms['swrr'].items():
        b = arms['fifo'][key]
        phase,mode,query,client,sequence = key
        predicted_class = classes[query]
        expected = predicted_class if mode.endswith('budget') else 24
        assert a['slots']==b['slots']==expected
        row = dict(phase=phase,mode=mode,id=query,client=client,sequence=sequence,
                   frozen_slots=predicted_class,actual_slots=expected,
                   swrr_wait_ms=a['wait_ms'],fifo_wait_ms=b['wait_ms'],
                   wait_delta_ms=b['wait_ms']-a['wait_ms'],
                   client_delta_ms=b['client_ms']-a['client_ms'])
        if mode.startswith('policy'):
            da,db=a['dop'],b['dop'];assert da is not None and db is not None
            row['application_changed']=da['applied']!=db['applied']
            row['vector_changed']=da.get('installed_dop')!=db.get('installed_dop')
        rows.append(row)
        groups[f'{phase}/{mode}/class{predicted_class}'].append(row)
    assert len(rows)==128 and all(len(group)==8 for group in groups.values())
    summary = {key:dict(count=len(group),
                        mean_wait_delta_ms=statistics.mean(r['wait_delta_ms'] for r in group),
                        mean_client_delta_ms=statistics.mean(r['client_delta_ms'] for r in group))
               for key,group in sorted(groups.items())}
    sources = [Path(__file__),selection]
    for name in arms:
        out=RUN/('report90_native_budget_mixed_'+name)
        sources += [out/'ALLOCATION_AUDIT.json',out/'scored/events.jsonl']
    result = dict(status='paired_diagnostic',pairs=len(rows),summary=summary,rows=rows,
                  application_changes=sum(r.get('application_changed',False) for r in rows),
                  vector_changes=sum(r.get('vector_changed',False) for r in rows),
                  scope='Same planned client/sequence/query; real arrival times and runtime contention can differ. Eight repeated jobs per query/class/batch, not eight independent queries. FIFO minus SWRR: positive means slower. No causal/significance claim.',
                  source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    out=RUN/'native_mixed_scheduler_wait_analysis';out.mkdir(exist_ok=True)
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 混合预算调度配对诊断','',result['scope'],'','| 阶段/模式/预算类别 | 配对数 | 平均等待变化 ms | 平均请求变化 ms |','|---|---:|---:|---:|']
    for key,row in summary.items():
        lines.append(f"| {key} | {row['count']} | {row['mean_wait_delta_ms']:.2f} | {row['mean_client_delta_ms']:.2f} |")
    lines += ['',f"AutoDOP 应用状态变化：{result['application_changes']}；安装向量变化：{result['vector_changes']}。"]
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))


if __name__=='__main__':main()
