"""Align raw BE gauges with audited stream windows, retaining coverage gaps."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import statistics


BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/distillation_concurrency_extension'
GAUGES=['starrocks_be_process_mem_bytes','starrocks_be_query_mem_bytes',
        'starrocks_be_resource_group_inuse_cpu_cores{name="default_wg"}',
        'starrocks_be_resource_group_cpu_use_ratio{name="default_wg"}']


def main():
    parser=argparse.ArgumentParser();parser.add_argument('folder',type=Path);args=parser.parse_args()
    result=json.loads((args.folder/'RESULT.json').read_text());assert result['status']=='completed_sustained_collection'
    done=json.loads((BASE/'RESOURCE_MONITOR_RESULT.json').read_text());assert done['status']=='finished'
    path=BASE/'stream_resources.jsonl.gz'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==done['samples_sha256']
    with gzip.open(path,'rt') as f:raw=[json.loads(line) for line in f]
    assert len(raw)==done['samples']
    errors=[r for r in raw if 'error' in r];assert len(errors)==done['errors']
    rows=[]
    for cell in result['rounds']:
        selected=[r for r in raw if cell['window_start']<=r['monotonic']<cell['window_end'] and 'prometheus_raw' in r and ':8030/' not in r['url']]
        per_be={}
        for url in sorted({r['url'] for r in selected}):
            samples=[r for r in selected if r['url']==url];values={key:[] for key in GAUGES}
            for sample in samples:
                for line in sample['prometheus_raw'].splitlines():
                    fields=line.split()
                    if len(fields)==2 and fields[0] in values:values[fields[0]].append(float(fields[1]))
            times=[r['monotonic'] for r in samples]
            per_be[url]=dict(samples=len(samples),first_offset_seconds=min(times)-cell['window_start'],
                last_offset_seconds=max(times)-cell['window_start'],
                gauges={key:dict(samples=len(v),mean=statistics.mean(v),max=max(v)) for key,v in values.items() if v})
        rows.append(dict(mode=cell['mode'],streams=cell['streams'],window_seconds=cell['window_seconds'],by_be=per_be))
    files=[Path(__file__),args.folder/'RESULT.json',BASE/'RESOURCE_MONITOR_PROTOCOL.json',BASE/'RESOURCE_MONITOR_RESULT.json',path]
    audit=dict(status='aligned_resource_samples',cells=rows,errors=errors,
        scope='Sidecar started during first cell. Per-endpoint offsets explicitly expose missing coverage. Memory bytes are BE tracked gauges, not proof that the entire database is resident. Resource-group CPU gauges are not host CPU utilization.',
        source_sha256={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
    (BASE/'RESOURCE_AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n');print('Aligned',len(rows),'cells;',len(errors),'HTTP errors')


if __name__=='__main__':main()
