"""Decompose observed time without treating residual as BE execution time."""
from collections import defaultdict
from pathlib import Path
import hashlib
import json
import re
import statistics

RUN = Path(__file__).resolve().parents[1] / 'runs/report90_20260912'


def field(line, key):
    match = re.search(r'\|' + re.escape(key) + r'=(\d+)(?:\||$)', line)
    assert match, key
    return int(match[1])


def main():
    sources = [Path(__file__)]
    batches = defaultdict(list)
    for arm in ('power2', 'integer'):
        out = RUN / ('report90_native_budget_rounding_' + arm)
        proof = json.loads((out/'ALLOCATION_AUDIT.json').read_text())
        assert proof['status'] == 'verified' and proof['executions'] == 128
        for name, digest in proof['source_sha256'].items():
            assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
        events = {e['query_id']: e for e in map(json.loads, (out/'scored/events.jsonl').read_text().splitlines())}
        for row in proof['rows']:
            e = events[row['query_id']]
            total, pending = field(row['audit_line'], 'Time'), field(row['audit_line'], 'PendingTimeMs')
            assert 0 <= pending <= total
            item = dict(arm=arm, phase=e['phase'], mode=e['mode'], id=e['id'], client=e['client'],
                        query_id=e['query_id'], slots=row['slots'], pending_ms=pending,
                        fe_total_ms=total, non_pending_ms=total-pending,
                        client_ms=e['client_latency_ms'],
                        sql_start_monotonic=e['sql_finished_monotonic']-e['client_latency_ms']/1000,
                        fe_timestamp_ms=field(row['audit_line'], 'Timestamp'),
                        cpu_ns=field(row['audit_line'], 'CpuCostNs'),
                        memory_bytes=field(row['audit_line'], 'MemCostBytes'))
            batches[arm, e['phase'], e['mode']].append(item)
        sources += [out/'ALLOCATION_AUDIT.json', out/'scored/events.jsonl']
    summaries = []
    rows = []
    for (arm, phase, mode), batch in sorted(batches.items()):
        assert len(batch) == 16
        begin = min(r['sql_start_monotonic'] for r in batch)
        for r in batch:
            r['submit_offset_ms'] = 1000*(r['sql_start_monotonic']-begin)
        summaries.append(dict(arm=arm, phase=phase, mode=mode,
                              submit_spread_ms=max(r['submit_offset_ms'] for r in batch),
                              fe_arrival_spread_ms=max(r['fe_timestamp_ms'] for r in batch)-min(r['fe_timestamp_ms'] for r in batch),
                              queries={q:dict(count=sum(r['id']==q for r in batch), **{
                                  k:statistics.mean(r[k] for r in batch if r['id']==q)
                                  for k in ('pending_ms','non_pending_ms','client_ms','submit_offset_ms','cpu_ns','memory_bytes')})
                                  for q in sorted({r['id'] for r in batch})}))
        rows.extend(batch)
    changes = []
    index = {(s['arm'],s['phase'],s['mode']):s for s in summaries}
    for phase in ('warmup','measured'):
        for mode in ('native','native_budget','policy_static','policy_budget'):
            a,b = index['power2',phase,mode],index['integer',phase,mode]
            for q in a['queries']:
                changes.append(dict(phase=phase,mode=mode,id=q, **{
                    k: b['queries'][q][k]-a['queries'][q][k]
                    for k in ('pending_ms','non_pending_ms','client_ms','submit_offset_ms')}))
    scope = ('All 256 observations retained. Integer minus power2 differences. Time minus PendingTimeMs includes planning, prediction, execution and other FE costs; it is not isolated BE time. Monotonic SQL submission spread measures the client, and FE Timestamp measures request arrival, neither measures admission queue insertion order. Existing collector has a start barrier. No causal inference or significance claim.')
    result = dict(status='descriptive_timing_audit',executions=len(rows),scope=scope,batches=summaries,changes=changes,rows=rows,
                  source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    out=RUN/'native_rounding_timing_diagnostic';out.mkdir(exist_ok=True)
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 并发时间分解', '',scope,'','整数取整减原取整，正值为耗时增加。','',
           '| 正式模式 | 查询 | 排队变化 ms | 非排队变化 ms | 客户端变化 ms |',
           '|---|---|---:|---:|---:|']
    for r in changes:
        if r['phase']=='measured':
            lines.append(f"| {r['mode']} | {r['id']} | {r['pending_ms']:.2f} | {r['non_pending_ms']:.2f} | {r['client_ms']:.2f} |")
    lines += ['', '各批次提交时间跨度（ms）：'+', '.join(f"{s['arm']}/{s['phase']}/{s['mode']}={s['submit_spread_ms']:.3f}" for s in summaries)]
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines))


if __name__=='__main__':main()
