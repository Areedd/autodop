"""Serial actual-query native feature/latency capture with unique audit corroboration."""
import argparse,csv,hashlib,io,json,os,re,threading,time,uuid
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import pymysql
from collect_trusted_dataset import frontend_settings,fetch_timed,result_digest
from report90_execute import check
from report90_wait_for_idle import wait_for_idle

ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'runs/report90_20260912';BASE=RUN/'matched_development_duration'

def main(phase):
    manifest=json.loads((BASE/'manifest.json').read_text())
    for path,h in manifest['source_sha256'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h
    if phase=='full':assert json.loads((BASE/'pilot/RESULT.json').read_text())['status']=='verified'
    queries=[q for q in manifest['queries'] if phase=='full' or q['id'] in manifest['pilot_ids']]
    out=BASE/phase;out.mkdir(exist_ok=False)
    save=lambda n,r:(out/n).write_text(json.dumps(r,indent=2)+'\n')
    save('STATUS.json',dict(status='preflight',pid=os.getpid()))
    wait_for_idle(check,out/'IDLE.json')
    os.sched_setaffinity(0,{35})
    connect=lambda:pymysql.connect(host='127.0.0.1',port=9030,user='root',autocommit=True,connect_timeout=5,read_timeout=190)
    lock=threading.Lock();active=None;calls=[];errors=[];executions=[];healthy=threading.Event()
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_GET(self):
            self.send_response(200 if self.path=='/health_check' else 404);self.end_headers();self.wfile.write(b'OK')
            if self.path=='/health_check':healthy.set()
        def do_POST(self):
            started=time.monotonic_ns()
            try:
                assert self.path=='/predict_csv'
                size=int(self.headers['Content-Length']);assert 0<size<1000000
                body=self.rfile.read(size).decode();rows=list(csv.reader(io.StringIO(body)))
                assert len(rows)==2 and len(rows[0])==len(rows[1])==384
                assert len(set(rows[0]))==384
                values=[int(v) for v in rows[1]]
                with lock:
                    assert active is not None,'Unassociated callback'
                    r=dict(active,header=rows[0],values=values,csv=body,service_ns=time.monotonic_ns()-started)
                    calls.append(r)
                self.send_response(200);self.end_headers();self.wfile.write(str(r['sentinel_bytes']).encode())
            except BaseException as e:
                with lock:errors.append(repr(e))
                self.send_response(500);self.end_headers()
    class Server(ThreadingHTTPServer):
        daemon_threads=False
        block_on_close=True
    server=None
    try:
        server=Server(('127.0.0.1',18083),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
        audit=ROOT.parents[1]/'output/fe/log/fe.audit.log'
        cursor_start=dict(path=str(audit),inode=audit.stat().st_ino,offset=audit.stat().st_size)
        save('AUDIT_START.json',cursor_start)
        save('PROTOCOL.json',dict(queries=len(queries),executions=2*len(queries),phase=phase,pipeline_dop=0,
             scope='Actual native data queries, one CSV callback each. V2 disabled, AutoDOP off, query cache/spill/adaptive DOP off. Unique positive response sentinels corroborated by FE audit; not memory predictions. Client latency includes callback overhead; no profiles requested. Native resource group must remain default_wg. No report90 latency labels or model updates.',
             source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),BASE/'manifest.json',ROOT/'collect_trusted_dataset.py',ROOT/'scripts/report90_wait_for_idle.py']}))
        with connect() as control,connect() as client:
            with control.cursor() as c:
                c.execute("ADMIN SHOW FRONTEND CONFIG LIKE 'enable_query_queue_v2'")
                row=c.fetchone();assert str(row[2]).lower()=='false'
            with frontend_settings(control.cursor(),{'query_cost_prediction_service_address':'http://127.0.0.1:18083','enable_query_cost_prediction':'true'},out/'frontend_settings.json',restore_connection_factory=connect):
                assert healthy.wait(45),'Prediction health check not received'
                with client.cursor() as c:
                    for setting in ['enable_auto_dop=false','pipeline_dop=0','enable_runtime_adaptive_dop=false','enable_query_cache=false','enable_spill=false','enable_profile=false','query_timeout=180']:
                        c.execute('SET '+setting)
                    save('STATUS.json',dict(status='running',pid=os.getpid()))
                    for stage in ['warmup','measured']:
                        for q in queries:
                            c.execute('USE `'+q['database']+'`')
                            token='autodop_matched_'+uuid.uuid4().hex
                            sentinel=1024**3+len(executions)+1
                            sql='/* '+token+' */ '+Path(q['sql_file']).read_text().strip().rstrip(';')
                            event=dict(id=q['id'],sql_sha256=q['sql_sha256'],split=q['split'],database=q['database'],phase=stage,token=token,sentinel_bytes=sentinel,sql=sql)
                            with lock:active=dict(event);before=len(calls)
                            rows=fetch_timed(c,sql,event);digest=result_digest(rows)
                            assert digest==q['native_result_digest'],'Result differs from trusted native output'
                            with lock:
                                assert len(calls)==before+1 and not errors,(len(calls)-before,errors)
                                event['feature_record']=calls[-1];active=None
                            event.update(result_digest=digest,status='result_verified');executions.append(event)
                            save('CAPTURE.json',dict(executions=executions,calls=calls,errors=errors))
                            print(json.dumps(dict(completed=len(executions),expected=2*len(queries),id=q['id'],phase=stage)),flush=True)
        assert json.loads((out/'frontend_settings.json').read_text())['restored']
        server.shutdown();server.server_close();server=None
        assert len(executions)==2*len(queries) and len(calls)==len(executions) and not errors
        tokens={r['token']:r for r in executions};matches={}
        # Read only this capture's appended audit section; reject rotation rather than silently losing evidence.
        with audit.open('rb') as f:
            assert os.fstat(f.fileno()).st_ino==cursor_start['inode'],'Audit rotated'
            f.seek(cursor_start['offset'])
            for raw in f:
                line=raw.decode();m=re.search(r'autodop_matched_[0-9a-f]{32}',line)
                if not m or m[0] not in tokens:continue
                token=m[0];assert token not in matches
                r=tokens[token]
                assert '|State=EOF|' in line and '|ErrorCode=|' in line and '|ResourceGroup=default_wg|' in line
                assert '|Db='+r['database']+'|' in line and '|PredictMemBytes='+str(r['sentinel_bytes'])+'|' in line
                normalize=lambda s:' '.join(s.split()).rstrip(';').rstrip()
                assert normalize(line.split('|Stmt=',1)[1].split('|Digest=',1)[0])==normalize(r['sql'])
                matches[token]=dict(query_id=re.search(r'\|QueryId=([0-9a-f-]+)\|',line)[1],audit_line=line.rstrip())
        assert set(matches)==set(tokens)
        assert len({r['query_id'] for r in matches.values()})==len(executions)
        for r in executions:r.update(matches[r['token']],status='verified')
        save('RESULT.json',dict(status='verified',queries=len(queries),executions=executions,errors=errors,
             scope='Actual-plan native CSV and serial client duration joined through serialized callback and unique FE audit response sentinel. Not a concurrency or heterogeneous-DOP duration model. Callback overhead included.',
             source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),out/'CAPTURE.json',out/'frontend_settings.json',BASE/'manifest.json']}))
        save('STATUS.json',dict(status='verified',executions=len(executions),restored=True))
    except BaseException as e:
        save('CAPTURE.json',dict(executions=executions,calls=calls,errors=errors));save('STATUS.json',dict(status='failed',error=repr(e)));raise
    finally:
        if server is not None:server.shutdown();server.server_close()

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=['pilot','full'],required=True)
    main(parser.parse_args().phase)
