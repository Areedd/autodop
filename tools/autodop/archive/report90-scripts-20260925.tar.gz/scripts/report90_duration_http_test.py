"""Run actual loopback HTTP through the experimental FE predictor; synthetic plan features."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[3]
SOURCE = r'''
import com.starrocks.common.Config;
import com.starrocks.qe.ConnectContext;
import com.starrocks.qe.scheduler.slot.ReportDurationBridge;
import com.starrocks.sql.optimizer.OptExpression;
import com.starrocks.sql.optimizer.cost.feature.*;
import com.starrocks.sql.plan.ExecPlan;
import com.starrocks.thrift.TUniqueId;
import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicReference;
import mockit.Mock;
import mockit.MockUp;

public class DurationHttpHarness {
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        try { run(); System.exit(0); }
        catch (Throwable error) { error.printStackTrace(); System.exit(1); }
    }
    static void run() throws Exception {
        new MockUp<FeatureExtractor>() {
            @Mock public PlanFeatures extractFeatures(OptExpression expression) { return new PlanFeatures(); }
        };
        new MockUp<PlanFeatures>() {
            @Mock public String toFeatureCsv() { return "1,2,3"; }
        };
        var header = new AtomicReference<String>("42.5");
        var body = new AtomicReference<String>("12345");
        var received = new AtomicReference<String>();
        var receivedId = new AtomicReference<String>();
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/predict_csv", exchange -> {
            received.set(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            receivedId.set(exchange.getRequestHeaders().getFirst("X-AutoDOP-Execution-Id"));
            if (header.get() != null) exchange.getResponseHeaders().add("X-AutoDOP-Duration-Ms", header.get());
            byte[] response = body.get().getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(200, response.length);
            try (var stream = exchange.getResponseBody()) { stream.write(response); }
        });
        server.start();
        String previous = Config.query_cost_prediction_service_address;
        try {
            Config.query_cost_prediction_service_address = "http://127.0.0.1:" + server.getAddress().getPort();
            ConnectContext context = new ConnectContext();
            var id = new TUniqueId(27, 43);
            context.setExecutionId(id); context.setThreadLocalInfo();
            var predictor = CostPredictor.ServiceBasedCostPredictor.getInstance();
            check(predictor.predictMemoryBytes(new ExecPlan()) == 12345, "memory unchanged");
            check(received.get().endsWith("\n1,2,3"), "actual CSV transport");
            if (ReportDurationBridge.ENABLED) {
                check(com.starrocks.common.util.UUIDUtil.fromTUniqueid(id).toString().equals(receivedId.get()), "request execution ID transport");
                check(ReportDurationBridge.REGISTRY.take(id) == 42.5, "execution ID binding");
            } else {
                check(receivedId.get() == null, "disabled request has no extra header");
                check(ReportDurationBridge.REGISTRY.size() == 0, "disabled registry untouched");
            }
            for (String value : new String[]{null, "bad", "NaN", "-1", "Infinity", "3600001"}) {
                header.set(value);
                check(predictor.predictMemoryBytes(new ExecPlan()) == 12345, "optional header must not break memory");
                check(ReportDurationBridge.REGISTRY.size() == 0, "bad header cleanup");
            }
            header.set("42.5"); body.set("invalid-memory");
            check(predictor.tryPredictMemoryBytes(new ExecPlan()) == 0, "memory error fallback");
            check(ReportDurationBridge.REGISTRY.size() == 0, "failed memory cleanup");
            body.set("12345"); ConnectContext.remove();
            check(predictor.predictMemoryBytes(new ExecPlan()) == 12345, "context absent memory unchanged");
            check(receivedId.get() == null, "context absent no identity header");
            check(ReportDurationBridge.REGISTRY.size() == 0, "context absent no binding");
            System.out.println("HTTP_CHECKS_PASSED enabled=" + ReportDurationBridge.ENABLED + " requests=9");
        } finally {
            ConnectContext.remove(); Config.query_cost_prediction_service_address = previous; server.stop(0);
        }
    }
}
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('integration', type=Path)
    args = parser.parse_args()
    integration = args.integration.resolve()
    out = integration / 'http_validation'
    out.mkdir(exist_ok=False)
    source = out / 'DurationHttpHarness.java'
    source.write_text(SOURCE)
    compile_base = json.loads((integration / 'COMPILE_COMMAND.json').read_text())
    cp = str(integration / 'classes') + ':' + compile_base[compile_base.index('-cp') + 1]
    commands = [('compile', ['javac', '--release', '17', '-proc:none', '-cp', cp, '-d', str(out), str(source)])]
    for enabled in ['false', 'true']:
        commands.append((enabled, ['/usr/lib/jvm/java-17-openjdk-amd64/bin/java',
            '-javaagent:/home/shaokun/.m2/repository/com/github/hazendaz/jmockit/jmockit/1.49.4/jmockit-1.49.4.jar',
            '--add-opens=java.base/java.lang=ALL-UNNAMED', '-Dautodop.report.durationQueue=' + enabled,
            '-cp', str(out) + ':' + cp, 'DurationHttpHarness']))
    result = dict(status='running', scope='Actual loopback HTTP and FE predictor with mocked plan features; no SQL or live FE deployment.')
    try:
        for name, cmd in commands:
            (out / (name + '.command.json')).write_text(json.dumps(cmd, indent=2) + '\n')
            with (out / (name + '.log')).open('w') as log:
                process = subprocess.run(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=60)
            result[name] = process.returncode
            if process.returncode:
                result['status'] = 'failed'
                raise RuntimeError(str(out / (name + '.log')))
            if name != 'compile':
                assert 'HTTP_CHECKS_PASSED enabled=' + name in (out / (name + '.log')).read_text()
        result['status'] = 'verified_http_synthetic_features'
    finally:
        result['source_sha256'] = hashlib.sha256(source.read_bytes()).hexdigest()
        (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(dict(output=str(out), **result), indent=2))


if __name__ == '__main__':
    main()
