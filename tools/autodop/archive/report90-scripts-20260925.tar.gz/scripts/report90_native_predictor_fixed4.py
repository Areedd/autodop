"""Post-OOM fixed-four baseline; learned predictions remain byte-identical."""
from report90_native_predictor import NativePredictor as FrozenNativePredictor

class NativePredictor(FrozenNativePredictor):
    def predict_csv(self,body,mode='predicted'):
        if mode!='fixed4':return super().predict_csv(body,mode)
        result=super().predict_csv(body,'fixed8') # Original schema/environment validation.
        return dict(result,mode='fixed4',encoded_cost_bytes=8*self.slot_bytes,
                    expected_physical_slots=24,nominal_bytes_per_worker=8*self.slot_bytes)
