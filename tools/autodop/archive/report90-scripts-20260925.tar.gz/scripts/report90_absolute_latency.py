"""Presentation-only conversion to measured latency; never invert rounded gains."""
import json
import re
import statistics
import os


def convert(md, run, out, read):
    summary = json.loads(read(run/'SUMMARY.json'))
    serial = summary['serial']
    modes = ['native', 'uniform4', 'best_uniform', 'policy_static']
    labels = ['原生StarRocks', '固定DOP4', '逐查询最佳统一DOP', 'AutoDOP']
    stats = serial['query_mean_latency_ms']
    def table(headers, rows):
        return '| '+' | '.join(headers)+' |\n|'+ '|'.join(['---']*len(headers))+'|\n'+''.join('| '+' | '.join(map(str,r))+' |\n' for r in rows)
    def fmt(v, best=False):
        s=f'{v:.2f}'
        return f'**{s}**' if best else s
    def replace_table(header,new):
        nonlocal md
        pat=re.escape(header)+r'\n(?:\|[^\n]*\n)+'
        md,n=re.subn(pat,lambda _:new,md,count=1)
        assert n==1,header
    mainrows=[]
    for m,label in zip(modes,labels):
        mainrows.append([label]+[fmt(stats[m][k],stats[m][k]==min(stats[x][k] for x in modes)) for k in ['mean','p50','p90','p99']])
    replace_table('| 基线 | 平均延迟降低 | p50 降低 | p90 降低 | p99 降低 | 更快查询数 |',
                  table(['方案','平均延迟 ms','p50 ms','p90 ms','p99 ms'],mainrows))
    # Reconstruct round means directly from verified observations, including whole-query repairs.
    repaired=set(summary['serial_repair']['replaced_queries']);events={}
    for folder in ['serial','serial_repair']:
        for line in read(run/folder/'scored/events.jsonl').splitlines():
            x=json.loads(line)
            if folder=='serial' and x['id'] in repaired:continue
            if x['phase']=='warmup':continue
            assert x['status']=='verified'
            key=(x['mode'],x['round'],x['id']);assert key not in events
            events[key]=x['client_latency_ms']
    ids=sorted(serial['per_query_mean_ms']['native'])
    best={q:min(['uniform1','uniform2','uniform4','uniform8','uniform16'],key=lambda m:serial['per_query_mean_ms'][m][q]) for q in ids}
    roundrows=[]
    for i in range(3):
        values=[statistics.mean(events[best[q] if m=='best_uniform' else m,i,q] for q in ids) for m in modes]
        roundrows.append([str(i+1)]+[fmt(v,v==min(values)) for v in values])
    replace_table('| 正式轮次编号 | 相对原生降低 | 相对固定 4 降低 | 相对最佳统一配置降低 |',
                  table(['正式轮次']+[x+' ms' for x in labels],roundrows))
    rows=[]
    for name,x in serial['structure_subgroups'].items():
        a,b=x['policy_mean_ms'],x['best_uniform_mean_ms']
        rows.append([name,str(x['queries']),fmt(a,a<=b),fmt(b,b<=a),str(x['faster_queries'])])
    replace_table('| 分组 | 查询数 | 在线策略平均 ms | 最佳统一配置平均 ms | 平均延迟降低 | 更快查询数 |',
                  table(['分组','查询数','AutoDOP平均 ms','最佳统一DOP平均 ms','更快查询数'],rows))
    # Keep the existing absolute-valued ablation and finite-batch tables; remove duplicate gain tables.
    md=re.sub(r'完整组相对各消融组的延迟降低（正数为完整组更好）：\n\n\| 对照[^\n]*\n(?:\|[^\n]*\n)+',
              '上表为各组实测延迟；各延迟列的最小值以黑色粗体标记。\n',md)
    md=re.sub(r'\| 对照（正数为改善）[^\n]*\n(?:\|[^\n]*\n)+','',md)
    search=read(run/'search_budget_report90/collection/PAIRED_REPORT.md')
    search_table=re.search(r'\| 配置来源[^\n]*\n(?:\|[^\n]*\n)+',search).group()
    md=md.replace('已有720次配置回放中，64预算改进搜索平均SQL延迟比随机高2.00%、p99低12.50%；该项保留为输出质量参考。',
                  '已有720次配置回放的实测SQL延迟如下，计时不含离线搜索开销。同预算内逐列比较，粗体标记较低延迟；不跨预算标记最优。\n\n'+search_table+'\n')
    replacements={
      '主串行实验相对原生、固定DOP4、逐查询最佳候选统一DOP的平均延迟分别降低36.71%、36.57%、23.83%。':'主串行实验的平均延迟为：AutoDOP **1617.94 ms**、原生2556.51 ms、固定DOP4 2550.90 ms、逐查询最佳候选统一DOP 2124.21 ms。',
      '对每条查询的正式重复取均值，再对固定查询集求平均；降幅为1－AutoDOP均值/基线均值':'对每条查询的正式重复取均值，再对固定查询集求平均；以毫秒报告各方案实测值',
      '固定查询集逐查询均值的p50、p90、p99及其相对降幅':'固定查询集逐查询均值的p50、p90、p99，以毫秒报告',
      '更快查询数/总查询数、逐查询相对降幅分布、退化查询及幅度':'更快查询数/总查询数、逐查询实测延迟分布、退化查询及绝对时间差',
      '前期测量中78条三轮均正收益、50条平均优势至少20%。':'前期测量中78条三轮均正收益。',
      '原筛选相对最佳统一DOP平均降低43.62%。':'前期实测AutoDOP为**866.56 ms**，最佳统一DOP为1537.13 ms。',
      '学生相对教师SQL平均延迟变化：降低 11.18%；64/90条更快。':'学生SQL平均延迟为**1497.98 ms**，教师配置为1686.45 ms；64/90条学生配置更快。',
      '完整异构预测预算相对同预算原生平均请求延迟降低25.69%、整批耗时降低24.98%；在异构内部，预算相对静态平均降低11.49%，但p90、p99分别增加约18.70%、24.95%。':'异构预测预算与同预算原生的平均请求延迟分别为**18479.55 ms**和24868.21 ms，整批耗时分别为**125.835 s**和167.729 s；异构静态方案平均为20879.32 ms。尾延迟方面，异构预测预算p90/p99为33651.39/38831.28 ms，异构静态方案为**28349.73/31076.40 ms**。',
    }
    for old,new in replacements.items():
        assert old in md,old
        md=md.replace(old,new)
    md=re.sub(r'^\| controller占查询总延迟[^\n]*\n','',md,flags=re.M)
    # Bold actual minima within each comparison group, not the favored method by name.
    def mark(match):
        text=match.group();lines=text.strip().splitlines();header=[c.strip() for c in lines[0].strip('|').split('|')]
        rows=[[c.strip() for c in line.strip('|').split('|')] for line in lines[2:]]
        if not rows:return text
        if header[0]=='配置来源':groups=[[i for i,r in enumerate(rows) if r[0].endswith(b)] for b in ['32','64']];cols=range(1,5)
        elif header[0]=='SQL配置来源' or (header[0]=='配置' and '平均 ms' in header):groups=[list(range(len(rows)))];cols=range(1,5)
        elif header[0]=='模式' and '整批秒数' in header:groups=[list(range(len(rows)))];cols=range(1,6)
        elif header[0]=='同一请求上的本地决策':groups=[list(range(len(rows)))];cols=[1]
        else:return text
        for group in groups:
            for col in cols:
                vals=[float(rows[i][col].replace('**','')) for i in group];bestval=min(vals)
                for i,v in zip(group,vals):
                    raw=rows[i][col].replace('**','');rows[i][col]=f'**{raw}**' if v==bestval else raw
        return table(header,rows)
    md=re.sub(r'^\|[^\n]*\n\|[-: |]+\n(?:\|[^\n]*\n)+',mark,md,flags=re.M)
    md=md.replace('## 4. 异构查询端到端性能','## 4. 异构查询端到端性能\n\n全部查询延迟采用实测绝对值，单位为ms（批次耗时为s）。同一表、同一比较范围内，各延迟指标的最小值以黑色粗体标记；分组及逐查询表按行比较。粗体不表示统计显著性。')
    # Replace the old primary figure with an absolute-latency figure.
    os.environ.setdefault('MPLCONFIGDIR','/tmp/autodop-matplotlib')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    fig,axes=plt.subplots(2,2,figsize=(10,6.7))
    for ax,k in zip(axes.flat,['mean','p50','p90','p99']):
        values=[stats[m][k] for m in modes]
        bars=ax.bar(np.arange(4),values,color=['#8b9bad','#6584a6','#365c80','#187b78'])
        ax.set_xticks(range(4),['Native','Uniform 4','Best uniform','AutoDOP'],fontsize=9)
        ax.set_ylabel('Measured latency (ms)');ax.set_title(k);ax.set_ylim(0,max(values)*1.2)
        for bar,v in zip(bars,values):ax.text(bar.get_x()+bar.get_width()/2,v+max(values)*.015,f'{v:.2f}',ha='center',fontsize=9,color='black',weight='bold' if v==min(values) else 'normal')
    fig.suptitle('90 queries: per-query mean across three measured executions')
    fig.tight_layout();p=out/'PRIMARY_ABSOLUTE_LATENCY.png';fig.savefig(p,dpi=180);plt.close(fig)
    md=md.replace('](PRIMARY_LATENCY.png)',f']({p})')
    return md
