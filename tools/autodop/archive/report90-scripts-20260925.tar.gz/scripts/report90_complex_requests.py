"""Recover verified development requests, including confidence fallback, without SQL."""
import hashlib
import json
from pathlib import Path
from report90_execute import RUN
from verify_paper_evaluations import request_plan_key
from autodop.data import _hash

BASE=RUN/'complex_development24'
OUT=BASE/'prepass'


def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    proof_path=OUT/'scored/independent_verification.json';proof=read(proof_path)
    assert proof['all_expected_executions_verified'] and proof['expected_slots']==96
    assert read(OUT/'scored/frontend_settings.json')['restored']
    for name,expected in proof['source_sha256'].items():assert sha(Path(name))==expected
    events=[json.loads(l) for l in (OUT/'scored/events.jsonl').open()]
    rows=[json.loads(l) for l in (OUT/'scored/decisions.jsonl').open()]
    decisions={d['query_id']:d for d in rows}
    policy=[e for e in events if e['mode']=='policy_static']
    assert len(policy)==len(rows)==len(decisions)==48
    assert set(decisions)=={e['query_id'] for e in policy}
    requests={};seen={}
    for e in policy:
        d=decisions[e['query_id']];request=d['request']
        assert d['mode']==e['mode'] and request['query_id']==e['query_id']
        if e['dop_validation']['applied']:
            assert e['trace']['request']==request
        key=request_plan_key(request);qid=e['id'];seen.setdefault(qid,set())
        if key not in seen[qid]:
            seen[qid].add(key);requests.setdefault(qid,[]).append({'plan_key':key,'request':request})
    assert len(requests)==24
    manifest=read(BASE/'manifest.json')['queries']
    train={v['plan_key'] for q in manifest if q['split']=='train' for v in requests[q['id']]}
    valid={v['plan_key'] for q in manifest if q['split']=='valid' for v in requests[q['id']]}
    historical=Path(read(RUN/'PROTOCOL.json')['training_dataset'])/'samples.jsonl'
    previous=set()
    for line in historical.open():
        sample=json.loads(line)
        previous.add(_hash({'fragments':[{k:v for k,v in f.items() if k!='worker_ids'} for f in sample['fragments']], 'edges':sample['edges']}))
    separation={'new_train_valid_raw_plan_overlap':sorted(train&valid),
                'new_valid_previous_cost_raw_plan_overlap':sorted(valid&previous),
                'new_train_previous_cost_raw_plan_overlap':sorted(train&previous),
                'note':'Raw normalized graph fingerprints, not SQL-namespaced dataset plan IDs. Fingerprint separation is not proof of algebraic or distribution independence.'}
    (OUT/'PLAN_SEPARATION.json').write_text(json.dumps(separation,indent=2)+'\n')
    assert not train&valid and not valid&previous, 'Development validation graph overlap requires investigation before training'
    (OUT/'REQUESTS.json').write_text(json.dumps(requests,indent=2)+'\n')
    result={'status':'complete','verified_executions':96,'queries':24,'request_variants':sum(map(len,requests.values())),
            'fragment_counts':{q['id']:len(requests[q['id']][0]['request']['fragments']) for q in manifest},
            'verified_applied_executions':proof['verified_applied_executions'],'fallback_executions':len(policy)-proof['verified_applied_executions'],
            'scope':'Correctness/discovery only. Fallback decisions linked by exact SQL query_id; not asserted to be installed. No latency labels used for selection.',
            'source_sha256':{str(p):sha(p) for p in [Path(__file__),proof_path,historical,OUT/'PLAN_SEPARATION.json']}}
    (OUT/'AUDITED_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
