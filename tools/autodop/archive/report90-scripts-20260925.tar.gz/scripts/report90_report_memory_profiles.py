"""Frozen report90 evaluation profiles, pilot before complete90-query collection."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from report90_execute import ROOT, RUN, SOURCE, check


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main(phase):
    out=RUN/f'report90_memory_profiles_{phase}'
    out.mkdir(exist_ok=False)
    save=lambda n,d:(out/n).write_text(json.dumps(d,indent=2)+'\n')
    save('STATUS.json',dict(status='running',pid=os.getpid(),stage='preflight'))
    try:
        os.sched_setaffinity(0,set(range(27,35)))
        source=RUN/'manifest.json'
        manifest=json.loads(source.read_text())
        assert len(manifest['queries'])==90
        if phase=='pilot':
            manifest['queries']=manifest['queries'][:2]
        else:
            pilot=RUN/'report90_memory_profiles_pilot'
            assert json.loads((pilot/'STATUS.json').read_text())['status']=='complete'
            assert json.loads((pilot/'MEMORY_PROFILE_CHECK.json').read_text())['status']=='verified'
        save('manifest.json',manifest)
        protocol=json.loads((RUN/'PROTOCOL.json').read_text())
        model=Path(protocol['model']);assert digest(model)==protocol['model_sha256']
        save('PROTOCOL.json',dict(at=datetime.datetime.now().astimezone().isoformat(),
             scope='Frozen report90 memory-demand evaluation with profiles enabled; not a latency benchmark. '
                   'No training or tuning on these results. Pilot is first two manifest queries; full uses all90.',
             modes=['native','policy_static'],warmup=1,repetitions=1,pipeline_profile_level=1,
             expected_slots=len(manifest['queries'])*4,source_manifest_sha256=digest(source)))
        sources=[Path(__file__),ROOT/'collect_paper_evaluations.py',ROOT/'scripts/verify_paper_evaluations.py',
                 source,out/'manifest.json',SOURCE/'random200/trusted_merged.json',model]
        save('SOURCE_SHA256.json',{str(p):digest(p) for p in sources})
        check(out/'IDLE.json')
        command=[sys.executable,str(ROOT/'collect_paper_evaluations.py'),
                 '--manifest',str(out/'manifest.json'),'--trusted-collection',str(SOURCE/'random200/trusted_merged.json'),
                 '--output-dir',str(out/'scored'),'--policy-model',str(model),'--modes','native,policy_static',
                 '--scenario','profiles','--pipeline-profile-level','1','--warmup','1','--repetitions','1',
                 '--seed',str(protocol['seed']),'--query-timeout-s','180','--auto-dop-max-dop','16',
                 '--torch-threads','1','--decision-timeout-ms','1000']
        save('COMMAND.json',command)
        save('STATUS.json',dict(status='running',pid=os.getpid(),stage='collecting_profiles'))
        subprocess.run(command,check=True)
        proof=out/'scored/independent_verification.json'
        subprocess.run([sys.executable,str(ROOT/'scripts/verify_paper_evaluations.py'),
                        '--collection-dir',str(out/'scored'),'--output',str(proof)],check=True)
        evidence=json.loads(proof.read_text());assert evidence['all_expected_executions_verified']
        assert evidence['expected_slots']==len(manifest['queries'])*4
        assert json.loads((out/'scored/frontend_settings.json').read_text())['restored']
        events=[json.loads(s) for s in (out/'scored/events.jsonl').read_text().splitlines()]
        assert len(events)==len(manifest['queries'])*4
        for e in events:
            assert e['status']=='verified' and 'profile_error' not in e
            p=Path(e['profile_file']);assert digest(p)==e['profile_sha256']
        save('STATUS.json',dict(status='complete',profiles=len(events),
             note='SQL/profile identity verified; memory field semantics require separate audit before full expansion.'))
        print('Profiles collected and independently verified:',len(events))
    except BaseException as error:
        save('STATUS.json',dict(status='failed',error=repr(error)));raise


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=['pilot','full'],required=True)
    main(parser.parse_args().phase)
