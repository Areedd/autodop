"""Training-only fit diagnostics after a completed, independently replayed comparison."""
import json
from pathlib import Path
import numpy as np
import torch
import xgboost as xgb
from report90_execute import ROOT,RUN
from report90_complex_retrain import validation
from report90_models import flat_features
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from autodop.training import select_partition,file_sha256

BASE=RUN/'complex_development24';OUT=BASE/'retrained'

def main():
    torch.set_num_threads(1)
    result=json.loads((OUT/'RESULT.json').read_text())
    assert result['status']=='complete'
    assert json.loads((OUT/'SCORE_REPLAY.json').read_text())['status']=='verified_selected_model_replay'
    samples,pairs,metadata=load_dataset(BASE/'merged_dataset')
    contract=json.loads((OUT/'CONTRACT.json').read_text());train,_=select_partition(samples,pairs,contract,'train')
    assert len(train)==1205 and all(s['split']=='train' for s in train)
    graphs=[build_graph(s,metadata) for s in train]
    norms=np.load(OUT/'FEATURE_NORMALIZATION.npz');xx=np.stack([(flat_features(g,metadata)-norms['mean'])/norms['std'] for g in graphs])
    evaluated={};sources={}
    for kind,selected in result['selected'].items():
        path=Path(selected['model']);assert file_sha256(path)==selected['model_sha256'];sources[str(path)]=selected['model_sha256']
        if kind=='transformer':
            model,ck=load_cost_model(path);model.eval()
            with torch.no_grad():scores=[float(model(g)) for g in graphs]
        else:
            model=xgb.XGBRanker();model.load_model(path);model.set_params(n_jobs=1);scores=model.predict(xx)
        evaluated[kind]=validation(train,scores)
    model,ck=load_cost_model(BASE/'warmstart/cost.pt');model.eval()
    with torch.no_grad():scores=[float(model(g)) for g in graphs]
    evaluated['original_multistage_teacher']=validation(train,scores)
    audit={'status':'complete','scope':'Training fit only; no fitting, model selection or SQL execution. Training accuracy is not held-out quality.',
           'train_samples':len(train),'models':evaluated,'source_sha256':sources|{str(Path(__file__)):file_sha256(__file__)}}
    (OUT/'TRAIN_FIT_DIAGNOSTIC.json').write_text(json.dumps(audit,indent=2)+'\n')
    for name,q in evaluated.items():print(name,{c:{k:v[k] for k in ['mean_regret','rank_accuracy']} for c,v in q['cohorts'].items()})

if __name__=='__main__':main()
