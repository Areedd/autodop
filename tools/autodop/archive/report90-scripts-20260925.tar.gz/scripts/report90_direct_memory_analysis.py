"""Attribute direct tracker samples to corroborated failing BE identities."""
import collections
import datetime as dt
import hashlib
import json
import re
from pathlib import Path


def main():
    out=Path(__file__).resolve().parents[1]/'runs/report90_20260912/development17_memory_observed'
    read=lambda name:json.loads((out/name).read_text())
    assert read('STATUS.json')['status']=='complete'
    identities=read('FAILURE_IDENTITY_AUDIT.json');assert identities['status']=='verified'
    assert read('DECISION_AUDIT.json')['status']=='verified'
    audit=read('FAILED_ATTEMPT_AUDIT_LINES.json')
    parse=lambda s:dt.datetime.fromisoformat(s).timestamp()
    requests={r['query_id']:r for r in map(json.loads,(out/'scored/decisions.jsonl').read_text().splitlines())}
    failures={}
    for e in map(json.loads,(out/'scored/events.jsonl').read_text().splitlines()):
        for a in e['sql_attempts']:
            if a['status']=='failed':
                q=a['failed_query_id_candidate'];assert q not in failures
                m=re.search(r'Used: (\d+), Limit: (\d+).*BE:(\d+)',a['error']);assert m
                used,limit,worker=map(int,m.groups())
                failures[q]={'error_bytes':used,'limit_bytes':limit,'worker_id':str(worker)}
    assert failures.keys()==identities['failures'].keys()==audit.keys()
    series=collections.defaultdict(list)
    for r in map(json.loads,(out/'DIRECT_MEMORY.jsonl').read_text().splitlines()):
        if r['type']!='sample':continue
        for w in r['workers']:
            direct=w['direct'];start=parse(direct['started_at']);end=parse(direct['ended_at'])
            assert end>=start
            series[w['backend_id']].append(dict(start=start,end=end,midpoint=(start+end)/2,
                                               process_bytes=direct['process_bytes'],query_bytes=direct['query_bytes'],
                                               fe_memory_fraction=w['fe_memory_fraction']))
    assert len(series)==3
    rows=[]
    for q,link in identities['failures'].items():
        f=failures[q];line=audit[q]
        start=int(re.search(r'\|Timestamp=(\d+)\|',line)[1])/1000
        end=start+int(re.search(r'\|Time=(\d+)\|',line)[1])/1000
        request=requests.get(q)
        pivot=parse(request['at']) if request else start
        readings=series[f['worker_id']]
        before=[s for s in readings if s['end']<=pivot]
        previous=before[-1] if before else None
        # Entire HTTP interval lies in the execution window; crossing samples excluded.
        during=[s for s in readings if s['start']>=pivot and s['end']<=end]
        load=request['request']['worker_loads'].get(f['worker_id']) if request else None
        maximum=max((s['process_bytes'] for s in during),default=None)
        rows.append(dict(query_id=q,**link,**f,sql_start_epoch=start,sql_end_epoch=end,
                         request_epoch=pivot if request else None,request_worker_load=load,
                         previous=previous,previous_age_seconds=pivot-previous['end'] if previous else None,
                         during_count=len(during),sampled_max_bytes=maximum,
                         sampled_max_fraction=maximum/f['limit_bytes'] if maximum is not None else None,
                         during_samples=during))
    groups=collections.defaultdict(collections.Counter)
    for r in rows:
        c=groups[(r['mode'],r['phase'])];c['failures']+=1;c['sampled_during']+=r['during_count']>0
        recent=r['previous_age_seconds'] is not None and r['previous_age_seconds']<=2
        c['previous_within_2s']+=recent
        p=r['previous'];low=r['request_worker_load'] and r['request_worker_load']['fresh'] and r['request_worker_load']['mem_used_pct']<=.65
        c['low_fresh_request']+=bool(low)
        c['low_request_but_direct_previously_high']+=bool(low and recent and p['process_bytes']/r['limit_bytes']>.65)
        c['sampled_above_90pct']+=(r['sampled_max_fraction'] or 0)>.9
        c['sampled_crossing_65pct_after_low_start']+=bool(recent and p['process_bytes']/r['limit_bytes']<=.65 and (r['sampled_max_fraction'] or 0)>.65)
    summary=[dict(mode=k[0],phase=k[1],**v) for k,v in sorted(groups.items())]
    sources=[out/n for n in ('STATUS.json','RESULT.json','FAILURE_IDENTITY_AUDIT.json',
             'FAILED_ATTEMPT_AUDIT_LINES.json','DECISION_AUDIT.json','scored/events.jsonl',
             'scored/decisions.jsonl','DIRECT_MEMORY.jsonl','DIRECT_MEMORY_SUMMARY.json')]+[Path(__file__).resolve()]
    result=dict(status='verified',summaries=summary,rows=rows,
                scope='Same-BE direct tracker samples within HTTP timing bounds; not true peaks or causal per-query allocations. Shared executions reuse samples, so counts are not independent trials. Request loads may have stale/fresh semantics; no installation claim for failed SQL.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    dest=out/'DIRECT_MEMORY_ANALYSIS.json';assert not dest.exists()
    dest.write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 失败BE的直接内存时间线','',
           '| 模式 | 阶段 | 失败尝试 | 执行期有采样 | 低请求读数但前序直接内存高 | 采样超过90% | 从低于65%到超过65% |',
           '|---|---|---:|---:|---:|---:|---:|']
    for r in summary:
        lines.append(f"| {r['mode']} | {r['phase']} | {r['failures']} | {r['sampled_during']} | {r['low_request_but_direct_previously_high']} | {r['sampled_above_90pct']} | {r['sampled_crossing_65pct_after_low_start']} |")
    lines+=['',result['scope'],'',
            '前序直接读数仅使用请求前2秒内完成的HTTP采样；执行期仅使用整个HTTP请求都落在SQL区间内的采样。不能据此还原采样间隙中的峰值。']
    (out/'DIRECT_MEMORY_ANALYSIS.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
