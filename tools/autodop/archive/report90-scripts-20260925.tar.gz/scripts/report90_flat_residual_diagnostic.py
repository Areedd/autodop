"""Post-hoc component scores of the frozen hybrid checkpoint, not retrained ablations."""
import json
import os
from pathlib import Path
import numpy as np
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import CostModel
from autodop.training import select_partition
from report90_models import flat_features
from report90_flat_residual_model import load_flat_residual_model
from report90_interaction_pair_audit import BASE,sha,make_pairs,accuracy

OUT=BASE/'flat_residual_pilot/COMPONENT_DIAGNOSTIC.json'

def main():
    os.sched_setaffinity(0,{33});torch.set_num_threads(1);assert not OUT.exists()
    root=BASE/'flat_residual_pilot/pilot';result=json.loads((root/'RESULT.json').read_text());chosen=result['selected']['transformer'];path=Path(chosen['model']);assert sha(path)==chosen['model_sha256']
    model,checkpoint=load_flat_residual_model(path);model.eval();samples,pairs,meta=load_dataset(BASE/'merged_dataset');assert meta==checkpoint['metadata']
    contract=json.loads((root/'CONTRACT.json').read_text());scores={};counts={}
    for partition in ['train','valid']:
        selected,stored=select_partition(samples,pairs,contract,partition);lookup={(s['plan_key'],s['config_key']):i for i,s in enumerate(selected)}
        pool=([{'plan_key':p['plan_key'],'cohort':selected[lookup[(p['plan_key'],p['fast_config_key'])]]['source_cohort'],
            'fast_index':lookup[(p['plan_key'],p['fast_config_key'])],'slow_index':lookup[(p['plan_key'],p['slow_config_key'])]} for p in stored] if partition=='train' else make_pairs(selected))
        values={'full':[],'trained_graph_only':[],'trained_residual_only':[]}
        with torch.no_grad():
            for sample in selected:
                graph=build_graph(sample,meta);full=model(graph);base=CostModel.forward(model,graph)
                feature=torch.as_tensor(flat_features(graph,meta));residual=model.flat_scorer((feature-model.flat_mean)/model.flat_std).squeeze(-1)
                assert torch.equal(full,base+residual)
                for name,value in zip(values,[full,base,residual]):values[name].append(float(value))
        counts[partition]={'samples':len(selected),'pairs':len(pool),'models':{name:accuracy(pool,value) for name,value in values.items()}}
    expected=chosen['selected']['validation']['weighted_rank_accuracy'];assert counts['valid']['models']['full']['macro_accuracy']==expected
    result={'status':'verified_posthoc_component_scores','partitions':counts,
        'scope':'Frozen jointly trained checkpoint components; not separately trained ablations or feature-causality proof. Training accuracy uses6702stored within-batch pairs, validation uses920 canonical3% pairs. No candidate selection, fitting or report90 queries.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),path,root/'RESULT.json',root/'CONTRACT.json',BASE/'merged_dataset/samples.jsonl',BASE/'merged_dataset/pairs.jsonl']}}
    OUT.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({split:{k:v['macro_accuracy'] for k,v in x['models'].items()} for split,x in counts.items()}))

if __name__=='__main__':main()
