"""Report both scheduler arms without selecting favorable modes or queries."""
from collections import Counter
import hashlib
import json
from pathlib import Path

RUN = Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def main():
    out = RUN/'native_journal_scheduler_comparison'
    arms = {}
    sources = [Path(__file__)]
    for name in ('swrr', 'fifo'):
        directory = RUN/('report90_native_budget_journal_'+name)
        path = directory/'ALLOCATION_AUDIT.json'
        audit = json.loads(path.read_text())
        assert audit['status']=='verified' and audit['executions']==128
        protocol = json.loads((directory/'PROTOCOL.json').read_text())
        assert protocol['schedule'].lower()==name
        arms[name] = dict(metrics=audit['metrics'], protocol=protocol,
                          slot_counts=dict(Counter(str(row['slots']) for row in audit['rows'])))
        sources.extend([path, directory/'PROTOCOL.json', directory/'SCHEDULE.json'])
        if (directory/'IDLE_WAIT_POLICY.json').exists():
            sources.append(directory/'IDLE_WAIT_POLICY.json')
    # Same frozen model/SQL/collector; only schedule and per-arm output differ.
    assert arms['swrr']['protocol']['source_sha256']==arms['fifo']['protocol']['source_sha256']
    assert all(arm['slot_counts'] == {'24':128} for arm in arms.values())
    reductions = {mode:{key:100*(1-arms['fifo']['metrics'][mode][key]/base[key])
                           for key in ('batch_seconds','mean_ms','p50_ms','p90_ms','p99_ms')}
                  for mode,base in arms['swrr']['metrics'].items()}
    out.mkdir(exist_ok=True)
    result = dict(status='verified_pilot', executions=256, fifo_reduction_percent=reductions,
                  metrics={k:v['metrics'] for k,v in arms.items()},
                  slot_counts={k:v['slot_counts'] for k,v in arms.items()},
                  scope='Two fixed report queries repeated across 16 clients, one warmup and one measured batch per mode per arm. SWRR then FIFO with FE restart between arms and the same package; FIFO has bounded pre-measurement idle waiting. Not randomized or causal proof. All requests use 24 slots; this is an equal-budget control and cannot test 24/48-slot priority bias. All four modes retained. No automatic expansion or significance/generalization claim.',
                  source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# SWRR/FIFO 同日志小测','','正值表示 FIFO 延迟降低，负值表示恶化。','','| 模式 | 整批时间 | 平均 | p50 | p90 | p99 |','|---|---:|---:|---:|---:|---:|']
    for mode,row in reductions.items():
        lines.append('| '+mode+' | '+' | '.join(f'{v:.2f}%' for v in row.values())+' |')
    lines+=['',result['scope']]
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
