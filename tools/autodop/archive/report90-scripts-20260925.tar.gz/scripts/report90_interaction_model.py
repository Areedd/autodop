"""Experimental graph cost model with explicit DOP-feature interactions.

The deployment model and its loader are unchanged. New checkpoints have a
distinct kind to prevent accidental loading as production cost checkpoints.
"""
import torch
from torch import nn
from autodop.model import CostModel, GraphEncoder, MODEL_FORMAT_VERSION
from autodop.model import save_checkpoint as base_save_checkpoint


class InteractionEncoder(GraphEncoder):
    def __init__(self, metadata, model_config=None):
        super().__init__(metadata, model_config)
        category_width = len(self.category_embeddings)*self.config['category_embedding_dim']
        width = 1+len(metadata['numeric_features'])+category_width
        self.dop_interaction = nn.Linear(width,self.config['hidden_dim'],bias=False)
        nn.init.zeros_(self.dop_interaction.weight)
        self.register_buffer('dop_values',torch.tensor([0]+metadata['dop_classes'],dtype=torch.float32),persistent=False)

    def forward(self, graph):
        categories = [embedding(graph['categorical'][:,i]) for i,embedding in enumerate(self.category_embeddings)]
        category_features = torch.cat(categories,dim=-1)
        numerical = graph['numerical']
        features = torch.cat(categories+[numerical,self.dop_embedding(graph['dop_ids'])],dim=-1)
        d = torch.log1p(self.dop_values[graph['dop_ids']]).unsqueeze(-1)
        interactions = torch.cat([d,d*numerical,d*category_features],dim=-1)
        nodes = self.input(features)+self.dop_interaction(interactions)
        for layer in self.layers:
            competition = graph['competition'] if self.config['competition_edges'] else torch.zeros_like(graph['competition'])
            nodes = layer(nodes,graph['dependency'],competition)
        return nodes


class InteractionCostModel(CostModel):
    def __init__(self, metadata, model_config=None):
        super().__init__(metadata,model_config)
        self.encoder = InteractionEncoder(metadata,model_config)


def load_interaction_model(path,device='cpu'):
    checkpoint = torch.load(path,map_location=device,weights_only=False)
    if checkpoint.get('format_version') != MODEL_FORMAT_VERSION:
        raise ValueError('Unsupported checkpoint format')
    if checkpoint.get('kind') not in ['cost','cost_dop_interaction']:
        raise ValueError('Not a compatible cost checkpoint')
    model = InteractionCostModel(checkpoint['metadata'],checkpoint['model_config'])
    if checkpoint['kind'] == 'cost':
        missing,unexpected = model.load_state_dict(checkpoint['model_state'],strict=False)
        if missing != ['encoder.dop_interaction.weight'] or unexpected:
            raise ValueError('Warm-start state differs beyond the new interaction projection')
    else:
        model.load_state_dict(checkpoint['model_state'],strict=True)
    return model.to(device),checkpoint


def save_interaction_checkpoint(path,kind,model,metadata,training=None):
    if kind != 'cost' or not isinstance(model,InteractionCostModel):
        raise ValueError('Interaction checkpoint requires an experimental cost model')
    base_save_checkpoint(path,'cost_dop_interaction',model,metadata,training)
