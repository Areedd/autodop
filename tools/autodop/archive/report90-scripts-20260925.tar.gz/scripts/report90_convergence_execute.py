"""Run frozen convergence diagnostic only after the shared queue experiment finishes."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from report90_execute import ROOT, RUN, check

OUT = RUN / 'convergence_execution_20260913'
QUEUE = RUN / 'queue_extension_20260913_attempt3'


def status(state, **extra):
    path = OUT / 'STATUS.json'
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps({'status': state, 'pid': os.getpid(),
        'at': datetime.datetime.now().astimezone().isoformat(), **extra}, indent=2) + '\n')
    temporary.replace(path)


def stage(pilot):
    folder = OUT / ('pilot' if pilot else 'full')
    folder.mkdir(exist_ok=False)
    status('running', stage=folder.name)
    for attempt in range(20):
        try:
            check(folder / f'IDLE_{attempt}.json')
            break
        except RuntimeError:
            if attempt == 19:
                raise
            time.sleep(15)
    protocol = json.loads((RUN / 'PROTOCOL.json').read_text())
    command = [sys.executable, str(ROOT / 'collect_paper_evaluations.py'),
        '--manifest', str(RUN / ('pilot.json' if pilot else 'manifest.json')),
        '--trusted-collection', str(ROOT / 'runs/preference_random200_20260911/random200/trusted_merged.json'),
        '--output-dir', str(folder / 'scored'), '--policy-model', protocol['model'],
        '--modes', 'extended_transformer_pool,cost_xgb_rank', '--scenario', 'serial',
        '--query-timeout-s', '180', '--auto-dop-max-dop', '16', '--torch-threads', '1',
        '--decision-timeout-ms', '1000', '--warmup', '1', '--repetitions', '1' if pilot else '2',
        '--seed', str(protocol['seed']), '--decision-vectors', str(OUT / 'vectors.json')]
    (folder / 'COMMAND.json').write_text(json.dumps(command, indent=2) + '\n')
    subprocess.run(command, check=True)
    proof = folder / 'scored/independent_verification.json'
    subprocess.run([sys.executable, str(ROOT / 'scripts/verify_paper_evaluations.py'),
                    '--collection-dir', str(folder / 'scored'), '--output', str(proof)], check=True)
    assert json.loads(proof.read_text())['all_expected_executions_verified'], 'Do not expand invalid evidence'


def main():
    assert (OUT / 'PROTOCOL.json').exists() and (OUT / 'vectors.json').exists()
    assert not (OUT / 'EXECUTION_PROTOCOL.json').exists()
    evidence = {'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                'vectors_sha256': hashlib.sha256((OUT / 'vectors.json').read_bytes()).hexdigest(),
                'queue_predecessor': str(QUEUE), 'be_replacement_allowed_during_run': False}
    (OUT / 'EXECUTION_PROTOCOL.json').write_text(json.dumps(evidence, indent=2) + '\n')
    status('running', stage='wait_queue_completion')
    while True:
        state = json.loads((QUEUE / 'STATUS.json').read_text())
        if state['status'] == 'complete':
            break
        assert state['status'] == 'running', state
        os.kill(state['pid'], 0)
        assert b'report90_queue_extension.py' in Path(f"/proc/{state['pid']}/cmdline").read_bytes()
        time.sleep(20)
    for name in ['pilot_c16', 'full_c8', 'full_c16', 'full_c20']:
        folder = QUEUE / name
        assert json.loads((folder / 'QUEUE_SETTINGS.json').read_text())['restored']
        assert json.loads((folder / 'scored/independent_verification.json').read_text())['all_expected_executions_verified']
    stage(True)
    stage(False)
    status('complete', stage='complete')


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        status('failed', error=repr(error))
        raise
