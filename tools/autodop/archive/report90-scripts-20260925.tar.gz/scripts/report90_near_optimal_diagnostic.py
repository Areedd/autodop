"""Partition existing development pairs by measured distance from their plan optimum."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[1] / 'runs/report90_20260912/structure_coverage20'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    folders = [BASE / f'accuracy_pair_audit_seed{s}' for s in [17, 29, 43]]
    folders += [BASE / f'interaction_pair_audit_seed{s}' for s in [17, 29]]
    folders += [BASE / 'pair_calibration_pair_audit']
    result = {}
    sources = [Path(__file__)]
    common_pool = None
    for folder in folders:
        audit_path, pool_path = folder / 'RESULT.json', folder / 'PAIR_POOL.json'
        audit = json.loads(audit_path.read_text())
        assert audit['status'] == 'verified_independent_pair_replay'
        for path, digest in audit['source_sha256'].items():
            assert sha(Path(path)) == digest
        sources += [audit_path, pool_path]
        pool = json.loads(pool_path.read_text())
        if common_pool is None:
            common_pool = pool
        assert pool == common_pool
        samples = pool['samples']
        best = {}
        for s in samples:
            best[s['plan_key']] = min(best.get(s['plan_key'], float('inf')), s['latency_ms'])
        groups = {}
        for pair in pool['pairs']:
            fast, slow = samples[pair['fast_index']], samples[pair['slow_index']]
            cutoff = 1.2 * best[pair['plan_key']]
            bucket = 'both_within20pct' if slow['latency_ms'] <= cutoff else 'fast_only_within20pct' if fast['latency_ms'] <= cutoff else 'neither_within20pct'
            key = pair['cohort'] + '/' + bucket
            g = groups.setdefault(key, {'pairs': 0, 'correct': {m: 0 for m in audit['models']}})
            g['pairs'] += 1
            for model, values in audit['models'].items():
                g['correct'][model] += values['scores'][pair['fast_index']] > values['scores'][pair['slow_index']]
        assert sum(g['pairs'] for g in groups.values()) == 920
        for g in groups.values():
            g['accuracy'] = {m: n / g['pairs'] for m, n in g['correct'].items()}
        result[folder.name] = groups
    out = BASE / 'NEAR_OPTIMAL_DIAGNOSTIC.json'
    assert not out.exists()
    out.write_text(json.dumps({'status': 'verified_development_diagnostic', 'groups': result,
        'definition': 'Near-optimal means measured latency <=1.2 times the fastest observed validation configuration of the same plan; this is not the full configuration-space optimum.',
        'scope': 'Partition all920 already audited development pairs; no pairs removed from the primary metric, no training or checkpoint selection. Fixed20% diagnostic cutoff, not a tuned acceptance threshold. Shared-query pairs are dependent. Completed seed subsets explicitly identified; no claim about pending seeds.',
        'source_sha256': {str(p): sha(p) for p in sources}}, indent=2) + '\n')
    for name, groups in result.items():
        print(name)
        for group, value in groups.items():
            print(group, value['pairs'], {m: round(value['accuracy'][m] * 100, 2) for m in ['transformer', 'xgboost_pairs', 'mlp_regression']})


if __name__ == '__main__':
    main()
