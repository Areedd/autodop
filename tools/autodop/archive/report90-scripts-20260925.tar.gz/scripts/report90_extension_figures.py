"""Export un-smoothed report figures from audited extension data."""
import hashlib
import csv
import json
from pathlib import Path
import statistics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/distillation_concurrency_extension'


def main():
    result=json.loads((BASE/'EXTENSION_RESULT.json').read_text())
    assert 'sql' in result and 'concurrency' in result
    for p,d in result['source_sha256'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==d,p
    out=BASE/'figures';out.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    colors={'native':'#777777','policy_load':'#0072B2'}
    fig,axes=plt.subplots(1,2,figsize=(10,3.5),layout='constrained')
    rows=result['concurrency']['summaries']
    fields=['mode','streams','qps','window_verified','window_unique_queries','total_unique_queries',
            'window_mean_client_ms','max_observed_running','max_observed_pending','applied','fallbacks']
    with (out/'sustained_streams.csv').open('w',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=fields,extrasaction='ignore');writer.writeheader();writer.writerows(rows)
    for mode in sorted({r['mode'] for r in rows}):
        subset=sorted([r for r in rows if r['mode']==mode],key=lambda r:r['streams'])
        label={'native':'Native, admission cap 4','policy_load':'AutoDOP, admission cap 4'}[mode]
        axes[0].plot([r['streams'] for r in subset],[r['qps'] for r in subset],'-o',label=label,color=colors[mode])
        axes[1].plot([r['streams'] for r in subset],[r['max_observed_pending'] for r in subset],'-o',label=label,color=colors[mode])
    for ax in axes:
        ax.set_xlabel('Client streams');ax.set_xticks(sorted({r['streams'] for r in rows}));ax.grid(alpha=.2)
    axes[0].set_ylabel('Verified queries / second');axes[0].set_ylim(bottom=0);axes[0].legend(fontsize=8)
    axes[1].set_ylabel('Maximum observed waiting queries');axes[1].set_ylim(bottom=0)
    fig.suptitle('One fixed 240-second window per cell; all observed points retained',fontsize=10)
    for ext in ('png','pdf'):fig.savefig(out/f'sustained_streams.{ext}',dpi=180)
    plt.close(fig)
    choices=json.loads((BASE/'distillation_report90/CHOICES.json').read_text())
    sql=json.loads(Path(result['sql']['source']).read_text())['per_query_ms']
    with (out/'matched_distillation.csv').open('w',newline='') as handle:
        writer=csv.writer(handle)
        writer.writerow(['query','teacher_local_median_ms','student_local_median_ms','teacher_raw_sql_ms','student_raw_sql_ms','student_confidence'])
        for row in choices:
            q=row['query'];writer.writerow([q,statistics.median(row['timings_ms']['matched_teacher']),
                statistics.median(row['timings_ms']['matched_student']),sql['matched_teacher'][q],sql['matched_student'][q],row['outputs']['matched_student']['confidence']])
    fig,axes=plt.subplots(1,2,figsize=(10,3.5),layout='constrained')
    for mode,color,label in [('matched_teacher','#D55E00','Teacher search'),('matched_student','#0072B2','Distilled student')]:
        costs=sorted(statistics.median(r['timings_ms'][mode]) for r in choices)
        delays=sorted(sql[mode].values())
        axes[0].plot(costs,[(i+1)/len(costs) for i in range(len(costs))],label=label,color=color)
        axes[1].plot(delays,[(i+1)/len(delays) for i in range(len(delays))],label=label,color=color)
    axes[0].set_xscale('log');axes[0].set_xlabel('Local decision cost (ms, log scale)')
    axes[1].set_xlabel('Raw-vector SQL replay latency (ms)')
    for ax in axes:ax.set_ylabel('Fraction of 90 queries');ax.grid(alpha=.2);ax.legend(fontsize=8)
    fig.suptitle('Fresh matched distillation; replay bypasses confidence rejection',fontsize=10)
    for ext in ('png','pdf'):fig.savefig(out/f'matched_distillation.{ext}',dpi=180)
    plt.close(fig)
    files=[BASE/'EXTENSION_RESULT.json',Path(__file__),*sorted(out.glob('*.png')),*sorted(out.glob('*.pdf')),*sorted(out.glob('*.csv'))]
    (out/'SOURCES.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
    print(out)


if __name__=='__main__':main()
