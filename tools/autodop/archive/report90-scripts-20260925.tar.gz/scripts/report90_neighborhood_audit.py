"""Independently score the three models fitted in the neighborhood training pilot."""
import json
import os
from pathlib import Path

import numpy as np
import torch
import xgboost as xgb
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.training import select_partition
from report90_interaction_model import load_interaction_model
from report90_interaction_pair_audit import make_pairs, accuracy
from report90_models import flat_features
from report90_neighborhood_prepare import OUT as BASE, sha


def main():
    os.sched_setaffinity(0, {33})
    torch.set_num_threads(1)
    folder = BASE / 'training_pilot/pilot'
    assert json.loads((folder / 'SCORE_REPLAY.json').read_text())['status'] == 'verified'
    primary = json.loads((folder / 'RESULT.json').read_text())
    for path, digest in json.loads((folder / 'EXECUTION_SOURCE_SHA256.json').read_text()).items():
        assert sha(Path(path)) == digest
    samples, pairs, metadata = load_dataset(BASE / 'augmented_dataset')
    valid, _ = select_partition(samples, pairs, json.loads((folder / 'CONTRACT.json').read_text()), 'valid')
    valid.sort(key=lambda s: (s['plan_key'], s['config_key']))
    assert len(valid) == 212
    pool = make_pairs(valid)
    assert len(pool) == 920
    graphs = [build_graph(s, metadata) for s in valid]
    norm = np.load(folder / 'FEATURE_NORMALIZATION.npz')
    flat = np.stack([(flat_features(g, metadata) - norm['mean']) / norm['std'] for g in graphs])
    models = {}
    sources = [Path(__file__), folder / 'RESULT.json', folder / 'SCORE_REPLAY.json', folder / 'EXECUTION_SOURCE_SHA256.json',
               folder / 'CONTRACT.json', folder / 'FEATURE_NORMALIZATION.npz', BASE / 'augmented_dataset/samples.jsonl', BASE / 'augmented_dataset/metadata.json']
    for kind, record in primary['selected'].items():
        path = Path(record['model'])
        assert sha(path) == record['model_sha256']
        sources.append(path)
        if kind == 'transformer':
            model, ck = load_interaction_model(path)
            assert ck['metadata'] == metadata
            model.eval()
            with torch.no_grad():
                scores = [float(model(g)) for g in graphs]
        else:
            model = xgb.XGBRanker()
            model.load_model(path)
            model.set_params(n_jobs=1)
            scores = model.predict(flat).astype(float)
        measured = accuracy(pool, scores)
        expected = record['selected']['validation']
        assert measured['macro_accuracy'] == expected['weighted_rank_accuracy']
        assert all(measured['cohorts'][c]['accuracy'] == v['rank_accuracy'] for c, v in expected['cohorts'].items())
        models[kind] = {**measured, 'scores': [float(s) for s in scores], 'model_sha256': sha(path)}
    out = BASE / 'training_pair_audit'
    assert not out.exists()
    out.mkdir()
    manifest = [{k: s[k] for k in ['plan_key', 'config_key', 'latency_ms', 'source_cohort', 'sql_sha256']} for s in valid]
    (out / 'PAIR_POOL.json').write_text(json.dumps({'samples': manifest, 'pairs': pool}, indent=2) + '\n')
    sources.append(out / 'PAIR_POOL.json')
    result = {'status': 'verified_independent_pair_replay', 'models': models,
              'scope': 'Neighborhood augmentation pilot: seed17,30 epochs; Transformer and two XGBoost ranking controls fitted on the same augmented data. All920 original development validation pairs, no changed threshold. Additional MLP/regression models have not been refitted for this dataset; not a complete model-comparison claim.',
              'source_sha256': {str(p): sha(p) for p in sources}}
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: {m: v[m] for m in ['macro_accuracy', 'pooled_accuracy']} for k, v in models.items()}, indent=2))


if __name__ == '__main__':
    main()
