"""Summarize censored first-hit counts and time; retain unsuccessful trials."""
import hashlib
import json
from pathlib import Path

import numpy as np

RUN = Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    base = RUN/'retrieval_timing_pilot'
    protocol = json.loads((base/'PROTOCOL.json').read_text())
    result = json.loads((base/'RESULT.json').read_text())
    assert result['status'] == 'verified_timed_traces' and result['timed_searches'] == 216
    assert result['protocol_sha256'] == sha(base/'PROTOCOL.json')
    for p, digest in protocol['source_sha256'].items():
        assert sha(Path(p)) == digest
    trials, summary = [], []
    for method in protocol['modes']:
        for query in protocol['queries']:
            for seed in protocol['seeds']:
                rows = [r for r in result['rows'] if (r['method'],r['query'],r['seed']) == (method,query,seed)]
                assert len(rows) == 3
                for target_name, target in protocol['targets'][query].items():
                    hits = [next((t for t in r['trace'] if t['score'] >= target), None) for r in rows]
                    assert all(h is None for h in hits) or all(h is not None for h in hits)
                    if hits[0] is not None:
                        assert len({h['evaluations'] for h in hits}) == 1
                    trials.append(dict(method=method, query=query, seed=seed, target=target_name,
                        hit=hits[0] is not None,
                        evaluations=hits[0]['evaluations'] if hits[0] is not None else None,
                        median_hit_ms=float(np.median([h['available_ms'] for h in hits])) if hits[0] is not None else None,
                        hit_times_ms=[h['available_ms'] for h in hits] if hits[0] is not None else [],
                        median_total_ms=float(np.median([r['total_ms'] for r in rows]))))
        for target in ['0.9','0.95','1.0']:
            cells = [r for r in trials if r['method'] == method and r['target'] == target]
            assert len(cells) == 12
            hits = [r for r in cells if r['hit']]
            summary.append(dict(method=method, target=target, trials=12, hits=len(hits),
                hit_by_evaluations={str(b):sum(r['hit'] and r['evaluations'] <= b for r in cells) for b in [16,32,64]},
                hit_by_median_time_ms={str(t):sum(r['hit'] and r['median_hit_ms'] <= t for r in cells) for t in [50,100,200,400]},
                successful_only_median_hit_ms=float(np.median([r['median_hit_ms'] for r in hits])) if hits else None,
                mean_trial_median_full_search_ms=float(np.mean([r['median_total_ms'] for r in cells]))))
    output = dict(status='verified_first_hit_summary', summary=summary, trials=trials,
        source_sha256={str(p):sha(p) for p in [Path(__file__),base/'RESULT.json',base/'PROTOCOL.json']},
        scope='12 query-seed trials per method,3 repeated timings each; no independent36-trial claim. Unreached targets remain missing, not finite hitting times. Targets from archived empirical teacher-score pools, not SQL or global optimality.')
    (base/'SUMMARY.json').write_text(json.dumps(output,indent=2)+'\n')
    labels = dict(original_mcts='Original MCTS',refined='Refined MCTS',no_attention='Without attention order',
                  no_equivalence='Without equivalence groups',random_scalar='Random scalar',random_batch='Random batch16')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1,2,figsize=(11,4.3),layout='constrained')
    for method in protocol['modes']:
        cells = [r for r in trials if r['method']==method and r['target']=='0.95']
        budget = np.arange(0,65)
        duration = np.linspace(0,400,201)
        axes[0].step(budget,[sum(r['hit'] and r['evaluations']<=b for r in cells)/12 for b in budget],where='post',label=labels[method])
        axes[1].step(duration,[sum(r['hit'] and r['median_hit_ms']<=t for r in cells)/12 for t in duration],where='post',label=labels[method])
    for ax in axes:
        ax.set_ylim(0,1.03)
        ax.set_ylabel('Fraction of query-seed trials reaching target')
        ax.grid(alpha=.2)
    axes[0].set_xlabel('Candidate scores consumed (batch charged in full)')
    axes[1].set_xlabel('Elapsed local search time (ms; median of 3 repeats)')
    axes[0].set_title('Frozen empirical score target: 95th percentile')
    axes[1].set_title('Cache setup and importance encoding included')
    axes[0].legend(fontsize=8,loc='upper left')
    fig.savefig(base/'CONVERGENCE.png',dpi=180)
    fig.savefig(base/'CONVERGENCE.pdf')
    plt.close(fig)
    lines = ['# 搜索检索效率与实际命中耗时小测', '',
        '4条已有开发查询、3固定种子、6方法；每方法每查询先预热1次，每种子正式计时3次，共216次正式搜索和24次预热，不执行SQL。三个计时重复不当作额外独立查询。', '',
        '所有方法使用同一冻结教师、合法DOP候选域、竞争边优化和静态特征缓存；等价类方法限制共享组的DOP，随机及移除等价类的对照搜索独立fragment空间，这项差异明确保留。计时从每次缓存初始化前开始，包含重要性编码、构图、评分、搜索及轨迹记录，不含模型加载、请求解析、HTTP、FE或SQL。', '',
        '目标在本轮计时前冻结，来自先前改进搜索与随机搜索的共同经验候选池。此参考池与这两种方法有关，不是方法中立的全局最优标准；因此结果属于开发检索诊断。每查询单独计算评分分位数，全部90/95/100百分位目标均报告。', '',
        '| 评分目标 | 方法 | 16/32/64次内命中（/12） | 50/100/200/400ms内命中（/12） | 完整64候选耗时ms |',
        '|---|---|---|---|---:|']
    for r in summary:
        lines.append(f"| {100*float(r['target']):.0f}%分位 | {r['method']} | "+'/'.join(str(v) for v in r['hit_by_evaluations'].values())+' | '+ '/'.join(str(v) for v in r['hit_by_median_time_ms'].values())+f" | {r['mean_trial_median_full_search_ms']:.2f} |")
    lines += ['', '时间命中率采用每查询/种子三次命中时间的中位数；未命中保留为失败，不参与“成功样本平均耗时”的误导性跨方法比较。完整搜索耗时取每查询/种子三次中位数，再在12组上平均。随机批量16个分数同时可用，命中时计入整批评分次数和实际整批耗时，不按批内索引虚构提前命中。', '',
        '![共同目标下的评分次数与实际时间收敛](CONVERGENCE.png)', '',
        '全部方法的重复轨迹一致；改进搜索及随机搜索与旧预算实验的配置轨迹一致，旧分数在1e-6容差内复现；逐条与批量随机使用同样候选并验证分数容差。所有运行时模块绑定恢复，没有修改生产实现。', '',
        '评分目标的检索优势不等于执行延迟优势，先前90条SQL延迟和教师排序诊断继续保留。该小测不能直接证明任意查询或全量90查询的检索效率。', '',
        '[汇总与全部命中时间](SUMMARY.json)、[完整计时轨迹](RESULT.json)、[冻结协议](PROTOCOL.json)、[导出PDF](CONVERGENCE.pdf)。']
    (base/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps([r for r in summary if r['target']=='0.95'],indent=2))


if __name__ == '__main__':
    main()
