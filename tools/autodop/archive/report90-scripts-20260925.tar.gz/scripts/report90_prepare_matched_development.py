"""Freeze existing development SQLs and trusted outputs before new measurements."""
from pathlib import Path
from collections import Counter
import hashlib,json

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'runs/report90_20260912'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    out=RUN/'matched_development_duration';out.mkdir(exist_ok=False)
    sources=[('historical17','DEVELOPMENT17_MANIFEST.json','DEVELOPMENT17_TRUSTED.json'),
             ('complex24','complex_development24/manifest.json','complex_development24/TRUSTED_NATIVE.json'),
             ('coverage20','structure_coverage20/manifest.json','structure_coverage20/TRUSTED_NATIVE.json')]
    report=RUN/'manifest.json';forbidden={q['sql_sha256'] for q in json.loads(report.read_text())['queries']}
    seen={};provenance=[Path(__file__),report];duplicates=[];pilot=[]
    for family,manifest,trust in sources:
        m,t=RUN/manifest,RUN/trust;provenance += [m,t]
        trusted={q['id']:q for q in json.loads(t.read_text())['queries']}
        first=None
        for item in json.loads(m.read_text())['queries']:
            q=dict(item);path=Path(q['sql_file']);digest=sha(path)
            assert digest==q['sql_sha256'] and digest not in forbidden
            target=trusted[q['id']];assert target['sql_sha256']==digest
            assert target['status']=='accepted'
            q.update(native_result_digest=target['native_result_digest'],source_family=family)
            assert q['split'] in ('train','valid')
            provenance.append(path)
            if digest in seen:
                assert seen[digest]['split']==q['split'],'Cross-split SQL duplicate'
                assert seen[digest]['native_result_digest']==q['native_result_digest']
                duplicates.append(dict(id=q['id'],canonical=seen[digest]['id'],sql_sha256=digest))
                continue
            seen[digest]=q
            if first is None and q['split']=='train':first=q['id']
        assert first is not None;pilot.append(first)
    queries=list(seen.values())
    result=dict(status='frozen_not_collected',query_count=len(queries),queries=queries,duplicates=duplicates,
                split_counts=dict(Counter(q['split'] for q in queries)),source_counts=dict(Counter(q['source_family'] for q in queries)),
                pilot_ids=pilot,report_sql_overlap=0,
                scope='Existing development data only. Preserve original train/valid split; previously used validation is not a new independent holdout. Selection uses provenance and SQL identity, not new latency. Query IDs never become model inputs.',
                source_sha256={str(p):sha(p) for p in provenance})
    (out/'manifest.json').write_text(json.dumps(result,indent=2)+'\n')
    protocol=dict(status='prepared_not_run',pilot=dict(queries=len(pilot),phases=['warmup','measured'],mode='native',pipeline_dop=0),
                  collection='Capture native CSV callback during the actual serial data query; use trusted output digest and query ID audit to corroborate association. Exactly one workload callback per execution; helper callbacks labelled separately. V2 disabled, no FE restart needed.',
                  costs='Record callback service time separately; observed SQL duration includes feature/prediction callback and profiling overhead, no subtraction claimed.',
                  expansion_gate='Pilot result identities, callback counts, schema, query association and configuration restoration all pass before full collection.',
                  prohibition='Do not fit report90 latency labels, merge original validation into training, claim development validation independence or claim EXPLAIN identity equals execution identity.')
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['queries','source_sha256']},indent=2))

if __name__=='__main__':main()
