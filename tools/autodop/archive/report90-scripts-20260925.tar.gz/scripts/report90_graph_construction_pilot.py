"""Exact graph-construction optimization pilot; no core edits or SQL execution."""
import hashlib
import inspect
import json
import os
from pathlib import Path
import random
import time
from unittest.mock import patch

import torch
from autodop import graph, mcts
from autodop.model import load_cost_model
from report90_search_refinement import search

RUN = Path(__file__).resolve().parents[1] / 'runs/report90_20260912'
OUT = RUN / 'graph_construction_pilot'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    os.sched_setaffinity(0, {35})
    torch.set_num_threads(1)
    assert not OUT.exists()
    OUT.mkdir()
    original = graph._competition
    source = inspect.getsource(original)
    changes = {
        'torch.zeros((size, size), dtype=torch.float32)': '[[0.0 for _ in range(size)] for _ in range(size)]',
        'matrices[name][left, right] = value': 'matrices[name][left][right] = value',
        'matrices[name][right, left] = value': 'matrices[name][right][left] = value',
        'return matrices': 'return {name: torch.tensor(values, dtype=torch.float32).reshape(size, size) for name, values in matrices.items()}',
    }
    for old, new in changes.items():
        assert source.count(old) == 1
        source = source.replace(old, new)
    namespace = dict(vars(graph))
    exec(compile(source, '<experimental_competition>', 'exec'), namespace)
    optimized = namespace['_competition']
    (OUT / 'competition_staged.py').write_text(source)
    dev = RUN / 'search_refinement_development'
    protocol = json.loads((dev / 'PROTOCOL.json').read_text())
    vectors = json.loads((dev / 'vectors.json').read_text())
    queries = protocol['queries']
    assert len(queries) == 4
    sources = [Path(__file__), Path(graph.__file__), Path(mcts.__file__), dev / 'PROTOCOL.json', dev / 'vectors.json', Path(protocol['model'])]
    save(OUT / 'PROTOCOL.json', {'queries': queries, 'modes': ['original_mcts', 'refined_full', 'independent_random'],
        'score_budget': 64, 'seed': 17, 'changes': changes,
        'scope': 'Four previously used development queries, no label use or SQL. Both old and refined search receive identical implementation optimization. Each timing includes graph construction and model scoring. CPU35 shared with other offline training; descriptive paired timings, not exclusive resource benchmark.',
        'source_sha256': {str(p): sha(p) for p in sources}})
    model, checkpoint = load_cost_model(protocol['model'])
    model.eval()
    metadata = checkpoint['metadata']
    records = []
    verified_graphs = 0
    for number, query in enumerate(queries):
        request = vectors['refined_full'][query]['request']
        sample = graph.sample_from_request(request)
        sample['dop_config'] = [1 if f.get('is_gather_root') else 4 for f in sample['fragments']]
        domains = [graph.supported_dops(f, metadata['dop_classes']) for f in sample['fragments']]
        rng = random.Random(17)
        configs = [[rng.choice(d) for d in domains] for _ in range(8)]
        for config in configs:
            for unknown in [False, True]:
                candidate = {**sample, 'dop_config': config}
                baseline = graph.build_graph(candidate, metadata, unknown_dop=unknown)
                with patch.object(graph, '_competition', optimized):
                    fast = graph.build_graph(candidate, metadata, unknown_dop=unknown)
                assert baseline.keys() == fast.keys()
                for key in baseline:
                    assert torch.equal(baseline[key], fast[key]) if isinstance(baseline[key], torch.Tensor) else baseline[key] == fast[key], key
                with torch.no_grad():
                    assert torch.equal(model(baseline), model(fast))
                verified_graphs += 1
        for mode in ['original_mcts', 'refined_full', 'independent_random']:
            outputs = {}
            for version in (['baseline', 'optimized'] if number % 2 == 0 else ['optimized', 'baseline']):
                with patch.object(graph, '_competition', original if version == 'baseline' else optimized):
                    started = time.perf_counter()
                    if mode == 'original_mcts':
                        config, score = mcts.search(sample, model, metadata, iterations=64, seed=17)
                        trace = None
                    elif mode == 'refined_full':
                        value = search(sample, model, metadata, budget=64, seed=17)
                        config, score, trace = value['config'], value['score'], value['records']
                    else:
                        rng = random.Random(17)
                        choices = []
                        with torch.no_grad():
                            for _ in range(64):
                                cfg = [rng.choice(d) for d in domains]
                                choices.append((cfg, float(model(graph.build_graph({**sample, 'dop_config': cfg}, metadata)))))
                        config, score = max(choices, key=lambda x: x[1])
                        trace = choices
                    elapsed = time.perf_counter() - started
                outputs[version] = {'config': list(config), 'score': float(score), 'trace': trace}
                records.append({'query': query, 'mode': mode, 'version': version, 'seconds': elapsed})
            assert outputs['baseline'] == outputs['optimized'], (query, mode)
            save(OUT / 'PROGRESS.json', {'status': 'running', 'verified_graphs': verified_graphs, 'timings': records})
    assert graph._competition is original
    aggregate = {}
    for mode in ['original_mcts', 'refined_full', 'independent_random']:
        means = {v: sum(r['seconds'] for r in records if r['mode'] == mode and r['version'] == v) / 4 for v in ['baseline', 'optimized']}
        aggregate[mode] = {**means, 'reduction_pct': 100 * (1 - means['optimized'] / means['baseline'])}
    save(OUT / 'RESULT.json', {'status': 'verified', 'graphs_exact': verified_graphs, 'search_outputs_exact': 12,
        'timings': records, 'aggregate_seconds': aggregate, 'protocol_sha256': sha(OUT / 'PROTOCOL.json'),
        'scope': 'Experimental implementation only; production files unchanged. Speedup of shared graph construction is not evidence that one search algorithm outperforms another.'})
    print(json.dumps(aggregate, indent=2), flush=True)


if __name__ == '__main__':
    main()
