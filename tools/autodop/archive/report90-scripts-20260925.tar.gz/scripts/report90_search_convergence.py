"""Recheck search components with the validation-selected extended cost model."""
import hashlib
import json
import math
import os
from pathlib import Path
import random
import subprocess
import sys
import time
from unittest.mock import patch

import torch

from autodop import mcts
from autodop.data import supported_dops
from autodop.graph import build_graph, sample_from_request
from autodop.model import load_cost_model
from report90_execute import ROOT, RUN, check

OUT = RUN / 'search_convergence_20260913'
MODES = ['search_extended_full', 'search_extended_no_equivalence',
         'search_extended_no_attention', 'search_extended_random']


def save(name, value):
    path = OUT / name
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def state(status, **extra):
    save('STATUS.json', {'status': status, 'pid': os.getpid(), **extra})


def prepare():
    torch.set_num_threads(1)
    selection = json.loads((RUN / 'convergence_20260913/SELECTED.json').read_text())
    model_path = Path(selection['model'])
    assert hashlib.sha256(model_path.read_bytes()).hexdigest() == selection['sha256']
    model, ck = load_cost_model(model_path)
    model.eval()
    source = RUN / 'teacher_extension_20260913/CHOICES_v2.json'
    rows = json.loads(source.read_text())
    sources = {folder: json.loads((RUN / folder / 'vectors.json').read_text()) for folder in {r['source'] for r in rows}}
    save('PROTOCOL.json', {'scope': 'Exploratory search component recheck after training-budget diagnostic; no test latency used for configuration selection or search-budget selection.',
        'model': selection, 'modes': MODES, 'score_evaluations_per_search': 64, 'seed': 17,
        'pilot': {'queries': 2, 'warmup': 1, 'measured': 1},
        'full': {'queries': 90, 'warmup': 1, 'measured': 1},
        'constraints': 'Same candidate domains, original grouping and attention functions; ablate grouping or attention order individually, or uniformly sample configurations. Attention importance forward pass included in reported search time. No algorithm changes.',
        'execution': 'Replay excludes offline search cost; record search time separately. Strict pilot success before full execution. Preserve every query and outcome.',
        'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__), Path(mcts.__file__), model_path, source, RUN / 'manifest.json']}})
    vectors = {mode: {} for mode in MODES}
    records = []
    def no_equivalence(sample, candidates):
        return [(index,) for index in range(len(candidates))]
    def natural(sample, model, metadata, candidates, device='cpu'):
        return mcts.equivalence_groups(sample, candidates)
    for row in rows:
        q = row['id']
        request = sources[row['source']]['cost_transformer_rank'][q]['request']
        sample = sample_from_request(request)
        sample['dop_config'] = [1 if f.get('is_gather_root') else 4 for f in sample['fragments']]
        candidates = [supported_dops(f, ck['metadata']['dop_classes']) for f in sample['fragments']]
        assert all(d in options for d, options in zip(sample['dop_config'], candidates))
        order = list(MODES)
        random.Random(17).shuffle(order)
        for mode in order:
            begin = time.perf_counter()
            if mode.endswith('_random'):
                rng = random.Random(17)
                best = -float('inf')
                config = None
                for _ in range(64):
                    proposal = [rng.choice(options) for options in candidates]
                    with torch.no_grad():
                        score = float(model(build_graph({**sample, 'dop_config': proposal}, ck['metadata'])))
                    assert math.isfinite(score)
                    if score > best:
                        config, best = proposal, score
            elif mode.endswith('_no_equivalence'):
                with patch.object(mcts, 'equivalence_groups', no_equivalence):
                    config, best = mcts.search(sample, model, ck['metadata'], iterations=64, seed=17)
            elif mode.endswith('_no_attention'):
                with patch.object(mcts, 'attention_guided_groups', natural):
                    config, best = mcts.search(sample, model, ck['metadata'], iterations=64, seed=17)
            else:
                config, best = mcts.search(sample, model, ck['metadata'], iterations=64, seed=17)
            assert math.isfinite(best) and all(d in options for d, options in zip(config, candidates))
            records.append({'id': q, 'source': row['source'], 'mode': mode, 'dops': config,
                            'score': best, 'search_seconds': time.perf_counter() - begin})
            entry = {'request': request, 'fragment_dops': dict(zip(sample['fragment_ids'], config))}
            if q in vectors[mode]:
                vectors[mode][q].setdefault('alternatives', []).append(entry)
            else:
                vectors[mode][q] = entry
        state('running', stage='prepare', plan_variants=len(records) // len(MODES))
    assert all(len(v) == 90 for v in vectors.values())
    save('vectors.json', vectors)
    save('CHOICES.json', records)


def execute(pilot):
    folder = OUT / ('pilot' if pilot else 'full')
    folder.mkdir(exist_ok=False)
    state('running', stage=folder.name)
    for attempt in range(20):
        try:
            check(folder / f'IDLE_{attempt}.json')
            break
        except RuntimeError:
            if attempt == 19:
                raise
            time.sleep(15)
    proto = json.loads((RUN / 'PROTOCOL.json').read_text())
    command = [sys.executable, str(ROOT / 'collect_paper_evaluations.py'),
        '--manifest', str(RUN / ('pilot.json' if pilot else 'manifest.json')),
        '--trusted-collection', str(ROOT / 'runs/preference_random200_20260911/random200/trusted_merged.json'),
        '--output-dir', str(folder / 'scored'), '--policy-model', proto['model'],
        '--modes', ','.join(MODES), '--scenario', 'serial', '--query-timeout-s', '180',
        '--auto-dop-max-dop', '16', '--torch-threads', '1', '--decision-timeout-ms', '1000',
        '--warmup', '1', '--repetitions', '1', '--seed', str(proto['seed']),
        '--decision-vectors', str(OUT / 'vectors.json')]
    (folder / 'COMMAND.json').write_text(json.dumps(command, indent=2) + '\n')
    subprocess.run(command, check=True)
    proof = folder / 'scored/independent_verification.json'
    subprocess.run([sys.executable, str(ROOT / 'scripts/verify_paper_evaluations.py'),
                    '--collection-dir', str(folder / 'scored'), '--output', str(proof)], check=True)
    assert json.loads(proof.read_text())['all_expected_executions_verified'], 'Do not expand invalid pilot/full evidence'


if __name__ == '__main__':
    for name in ['queue_extension_20260913_attempt3', 'convergence_execution_20260913']:
        assert json.loads((RUN / name / 'STATUS.json').read_text())['status'] == 'complete'
    OUT.mkdir(exist_ok=False)
    try:
        state('running', stage='prepare')
        prepare()
        # Keep SQL orchestration on the same CPUs used by preceding collectors.
        os.sched_setaffinity(0, set(range(27, 35)))
        execute(True)
        execute(False)
        state('complete', stage='complete')
    except BaseException as error:
        state('failed', error=repr(error))
        raise
