"""One prespecified equal parameter average of all three hard-pair EMA models."""
import json
import os
from pathlib import Path
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model,save_checkpoint
from autodop.training import select_partition
from report90_complex_retrain import validation
from report90_interaction_pair_audit import make_pairs,accuracy
from report90_neighborhood_prepare import RUN,sha
BASE=RUN/'structure_coverage20';OUT=BASE/'hard_ema_parameter_average'


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1);assert not OUT.exists()
    stability_path=BASE/'hard_pair_ema_stability/RESULT.json';stability=json.loads(stability_path.read_text());assert stability['status']=='verified_three_seed_summary'
    selected=[];sources=[Path(__file__),stability_path,BASE/'merged_dataset/samples.jsonl',BASE/'merged_dataset/pairs.jsonl',BASE/'merged_dataset/metadata.json',BASE/'merged_dataset/CONTRACT.json',BASE/'hard_pair_ema_ensemble/RESULT.json']
    for seed in [17,29,43]:
        folder=BASE/('hard_pair_ema_pilot/pilot' if seed==17 else f'hard_pair_ema_stability/seed{seed}')
        p=folder/'RESULT.json';r=json.loads(p.read_text());record=r['selected']['transformer'];path=Path(record['model']);assert sha(path)==record['model_sha256'];selected.append(record);sources += [p,path]
    old=json.loads((BASE/'parameter_average3/PROTOCOL.json').read_text());assert {x['model_sha256'] for x in old['models']}.isdisjoint({x['model_sha256'] for x in selected})
    OUT.mkdir();protocol={'seeds':[17,29,43],'weights':[1/3]*3,'models':selected,'rule':'One fixed float64 arithmetic average of all floating state tensors, cast to original dtype; nonfloating states must be equal. No weight search, seed subset, gradient fitting or90query selection.',
        'selection':'No selection among averages; only one candidate. Gate is higher equal-cohort validation accuracy than every nonTransformer three-seed control maximum and each fixed score-ensemble control. Original score ensemble also reported.',
        'scope':'One averaged model built from3previously validation-selected training runs. Reused development set, not3independent trials of this averaging procedure. Same inference architecture and parameter count; training requires all3parent runs. No SQL or deployment.',
        'source_sha256':{str(p):sha(p) for p in sources}}
    (OUT/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    loaded=[load_cost_model(x['model']) for x in selected];reference=loaded[0][1]
    assert all(c['metadata']==reference['metadata'] and c['model_config']==reference['model_config'] for _,c in loaded)
    states=[m.state_dict() for m,_ in loaded];averaged={}
    for k,v in states[0].items():
        assert all(s.keys()==states[0].keys() and s[k].dtype==v.dtype and s[k].shape==v.shape for s in states)
        if v.is_floating_point():averaged[k]=torch.stack([s[k].double() for s in states]).mean(0).to(v.dtype)
        else:
            assert all(torch.equal(s[k],v) for s in states);averaged[k]=v.clone()
    model=loaded[0][0];model.load_state_dict(averaged);model.eval()
    samples,pairs,metadata=load_dataset(BASE/'merged_dataset');assert metadata==reference['metadata']
    valid,_=select_partition(samples,pairs,json.loads((BASE/'merged_dataset/CONTRACT.json').read_text()),'valid');valid=sorted(valid,key=lambda s:(s['plan_key'],s['config_key']));assert len(valid)==212
    graphs=[build_graph(s,metadata) for s in valid]
    with torch.no_grad():scores=[float(model(g)) for g in graphs]
    path=OUT/'cost.pt';save_checkpoint(path,'cost',model,metadata,{'protocol':str(OUT/'PROTOCOL.json'),'parents':[x['model_sha256'] for x in selected],'experimental_only':True})
    restored,_=load_cost_model(path);restored.eval()
    with torch.no_grad():replayed=[float(restored(g)) for g in graphs]
    assert scores==replayed
    pool=make_pairs(valid);assert len(pool)==920
    q=accuracy(pool,scores);other=validation(valid,scores);assert abs(q['macro_accuracy']-other['weighted_rank_accuracy'])<1e-12
    ensemble=json.loads((BASE/'hard_pair_ema_ensemble/RESULT.json').read_text());assert ensemble['status']=='verified_fixed_score_ensemble'
    controls={k:v['macro_accuracy']['maximum'] for k,v in stability['models'].items() if k!='transformer'}
    controls.update({k+'_score_ensemble':v['macro_accuracy'] for k,v in ensemble['models'].items() if k!='transformer'})
    gate=all(q['macro_accuracy']>v for v in controls.values())
    for p,d in protocol['source_sha256'].items():assert sha(Path(p))==d
    result={'status':'verified_fixed_parameter_average','quality':q,'validation':other,'controls':controls,'score_ensemble_transformer_macro':ensemble['models']['transformer']['macro_accuracy'],'development_gate_passed':gate,'model':str(path),'model_sha256':sha(path),'state_tensors':len(averaged),'parameters':sum(p.numel() for p in model.parameters()),'prediction_reload_exact':True,'protocol_sha256':sha(OUT/'PROTOCOL.json'),'scope':protocol['scope']}
    (OUT/'SCORES.json').write_text(json.dumps(scores)+'\n');(OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 错对强化与EMA模型的三种子参数平均','',protocol['scope'],'',f"两组等权准确率{100*q['macro_accuracy']:.3f}%，汇总准确率{100*q['pooled_accuracy']:.3f}%；同父模型的分数平均准确率{100*result['score_ensemble_transformer_macro']:.3f}%。",'',f'是否超过全部非Transformer对照：{gate}。保留全部三个种子，未按结果选择权重或子集。', '', '与更早parameter_average3使用不同父检查点；浮点参数以float64累计并恢复原精度。模型保存重载后212个预测逐值相等；两种指标实现交叉核对920对一致。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'macro':q['macro_accuracy'],'pooled':q['pooled_accuracy'],'gate':gate,'controls':controls}))

if __name__=='__main__':main()
