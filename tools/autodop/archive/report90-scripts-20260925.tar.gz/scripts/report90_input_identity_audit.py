"""Check DOP preservation and exact input collisions for both model representations."""
import collections
import hashlib
import itertools
import json
import os
from pathlib import Path
import numpy as np
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.training import select_partition
from report90_models import flat_features
from report90_neighborhood_prepare import RUN,sha
BASE=RUN/'structure_coverage20';OUT=BASE/'input_identity_audit'
CONSUMED=['categorical','numerical','dop_ids','dependency','competition']


def tensor_digest(graph):
    digest=hashlib.sha256()
    for key in CONSUMED:
        value=graph[key].detach().cpu().contiguous()
        digest.update(json.dumps([key,list(value.shape),str(value.dtype)]).encode())
        digest.update(value.numpy().tobytes())
    return digest.hexdigest()


def collisions(rows,field):
    groups=collections.defaultdict(list)
    for row in rows:groups[(row['plan_key'],row[field])].append(row)
    found=[]
    for (plan,digest),items in groups.items():
        if len(items)<2:continue
        eligible=0
        for a,b in itertools.combinations(items,2):
            eligible+=max(a['latency_ms'],b['latency_ms'])/min(a['latency_ms'],b['latency_ms'])>=1.03
        found.append({'plan_key':plan,'config_keys':[r['config_key'] for r in items],'dop_vectors':[r['dop_config'] for r in items],'latencies_ms':[r['latency_ms'] for r in items],'eligible_point_label_pairs':eligible})
    return found


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1);assert not OUT.exists()
    data=BASE/'merged_dataset';samples,pairs,metadata=load_dataset(data)
    contract=json.loads((data/'CONTRACT.json').read_text());rows=[]
    for sample in samples:
        graph=build_graph(sample,metadata)
        assert all(torch.isfinite(graph[k]).all() for k in CONSUMED)
        decoded=[metadata['dop_classes'][int(i)-1] for i in graph['dop_ids']]
        assert all(int(i)>0 for i in graph['dop_ids']) and decoded==sample['dop_config']
        flat=flat_features(graph,metadata);assert len(flat)==1088 and np.isfinite(flat).all()
        rows.append({**{k:sample[k] for k in ['plan_key','config_key','dop_config','latency_ms','split']},'graph_digest':tensor_digest(graph),'flat_digest':hashlib.sha256(flat.tobytes()).hexdigest()})
    assert len(rows)==1577
    totals={};details={}
    for split in ['train','valid']:
        subset=[r for r in rows if r['split']==split];details[split]={}
        for name,field in [('graph','graph_digest'),('flat','flat_digest')]:
            cs=collisions(subset,field);details[split][name]=cs
        totals[split]={'samples':len(subset),'graph_collision_groups':len(details[split]['graph']),'flat_collision_groups':len(details[split]['flat']),'graph_indistinguishable_eligible_point_pairs':sum(c['eligible_point_label_pairs'] for c in details[split]['graph']),'flat_indistinguishable_eligible_point_pairs':sum(c['eligible_point_label_pairs'] for c in details[split]['flat'])}
    train,tp=select_partition(samples,pairs,contract,'train');lookup={(r['plan_key'],r['config_key']):r for r in rows}
    training_collisions={name:sum(lookup[p['plan_key'],p['fast_config_key']][field]==lookup[p['plan_key'],p['slow_config_key']][field] for p in tp) for name,field in [('graph','graph_digest'),('flat','flat_digest')]}
    OUT.mkdir();result={'status':'verified_input_identity_audit','totals':totals,'stored_training_pair_input_collisions':training_collisions,'collision_details':details,'dop_roundtrip_samples':len(rows),
        'scope':'Exact float32 tensor identity in the existing fragment order, not graph-isomorphism or learned-representation equivalence. Graph fields are those consumed by CostModel.forward; flat features are deterministic transformations of those inputs with no latency/queryID. Point-label collision diagnostics are separate from stored within-batch training-pair labels. No training, selection, SQL or model replacement.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),data/'samples.jsonl',data/'pairs.jsonl',data/'metadata.json',data/'CONTRACT.json',Path(__file__).parents[1]/'autodop/graph.py',Path(__file__).parents[1]/'autodop/model.py',Path(__file__).with_name('report90_models.py')]}}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');(OUT/'INPUT_DIGESTS.json').write_text(json.dumps(rows,indent=2)+'\n')
    lines=['# 模型输入可区分性核对','',result['scope'],'','| 划分 | 样本数 | 图输入碰撞组 | 平坦特征碰撞组 | 图碰撞的有效点标签对 | 平坦特征碰撞的有效点标签对 |','|---|---:|---:|---:|---:|---:|']
    for split,v in totals.items():lines.append(f"| {split} | {v['samples']} | {v['graph_collision_groups']} | {v['flat_collision_groups']} | {v['graph_indistinguishable_eligible_point_pairs']} | {v['flat_indistinguishable_eligible_point_pairs']} |")
    lines += ['',f'全部{len(rows)}个DOP向量经图编码后均可无损还原。原批次训练标签中，输入相同的配置对记录数：{training_collisions}。', '', '没有精确碰撞并不证明模型能够学到正确排序；图同构、信息压缩和泛化仍是不同问题。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'totals':totals,'stored_training_pair_input_collisions':training_collisions}))

if __name__=='__main__':main()
