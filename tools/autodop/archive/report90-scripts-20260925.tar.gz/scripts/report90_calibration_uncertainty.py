"""Query-cluster bootstrap for reused-development calibration ranking; no model selection."""
import hashlib
import json
from pathlib import Path
import numpy as np

BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20'
OUT=BASE/'calibration_accuracy_comparison/QUERY_BOOTSTRAP.json'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    assert not OUT.exists()
    audits=[BASE/f'calibration_pair_audit_seed{s}' for s in [17,29,43]]
    pools=[json.loads((a/'PAIR_POOL.json').read_text()) for a in audits]
    assert pools[0]==pools[1]==pools[2]
    results=[json.loads((a/'RESULT.json').read_text()) for a in audits]
    assert all(r['status']=='verified_independent_pair_replay' for r in results)
    for r in results:
        for path,digest in r['source_sha256'].items():assert sha(Path(path))==digest
    pairs=pools[0]['pairs'];models=list(results[0]['models']);cohorts=sorted({p['cohort'] for p in pairs})
    observed={};counts={};grouped={}
    for cohort in cohorts:
        plans=sorted({p['plan_key'] for p in pairs if p['cohort']==cohort})
        counts[cohort]=np.array([sum(p['plan_key']==plan for p in pairs) for plan in plans])
        grouped[cohort]={}
        for kind in models:
            correct=[]
            for plan in plans:
                pp=[p for p in pairs if p['plan_key']==plan]
                correct.append(np.mean([sum(r['models'][kind]['scores'][p['fast_index']]>r['models'][kind]['scores'][p['slow_index']] for p in pp) for r in results]))
            grouped[cohort][kind]=np.array(correct)
    rng=np.random.default_rng(20260914);reps=10000;draws={}
    for cohort in cohorts:
        n=len(counts[cohort]);draws[cohort]=rng.integers(0,n,size=(reps,n))
    distributions={}
    for kind in models:
        observed[kind]=np.mean([grouped[c][kind].sum()/counts[c].sum() for c in cohorts])
        distributions[kind]=np.mean([grouped[c][kind][draws[c]].sum(1)/counts[c][draws[c]].sum(1) for c in cohorts],axis=0)
        expected=np.mean([r['models'][kind]['macro_accuracy'] for r in results])
        assert abs(observed[kind]-expected)<1e-12
    contrasts={}
    for kind in models:
        if kind=='transformer':continue
        delta=distributions['transformer']-distributions[kind]
        contrasts[kind]={'transformer_minus_control_pp':100*(observed['transformer']-observed[kind]),
            'percentile95_interval_pp':(100*np.quantile(delta,[.025,.975])).tolist()}
    sources=[Path(__file__),*[a/name for a in audits for name in ['RESULT.json','PAIR_POOL.json']]]
    result={'status':'verified_query_cluster_bootstrap','repetitions':reps,'random_seed':20260914,
        'queries_per_cohort':{c:len(v) for c,v in counts.items()},'unique_pairs':len(pairs),
        'metric':'Average pair correctness across all three fixed seeds, then equal-cohort pair-weighted accuracy. Paired query-cluster bootstrap stratified by cohort; all pairs of a drawn query move together.',
        'contrasts':contrasts,'limitations':'Reused validation selected models and tuning variants. Intervals describe conditional query composition uncertainty; not selection-adjusted, not blind-test confidence, not SQL repetition or training-seed uncertainty. No independence assumption for individual pairs and no model/checkpoint selection.',
        'source_sha256':{str(p):sha(p) for p in sources}}
    OUT.write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 排序准确率的查询级重采样区间','',result['metric'],'', '| 对照 | Transformer减对照（百分点） | 95%区间（百分点） |','|---|---:|---:|']
    for kind,v in contrasts.items():
        lo,hi=v['percentile95_interval_pp'];lines.append(f"| {kind} | {v['transformer_minus_control_pp']:.3f} | [{lo:.3f}, {hi:.3f}] |")
    lines+=['',result['limitations']]
    OUT.with_suffix('.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(contrasts,indent=2))

if __name__=='__main__':main()
