"""Matched six-arm, from-scratch comparison. No database execution or deployment."""
import argparse
import collections
import csv
import hashlib
import io
import json
import math
import os
from pathlib import Path
import random
import statistics
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'scripts'),'/tmp/autodop-report-deps']
import numpy as np
import torch
import xgboost as xgb
from autodop.data import load_dataset,build_metadata
from autodop.graph import build_graph
from autodop.model import CostModel,LatencyRegressionModel,dynamic_margin_ranking_loss
from autodop.training import select_partition,file_sha256
from report90_models import MLP,flat_features
from report90_complex_retrain import validation,pair_index,epoch_pairs,key,COHORTS

RUN=ROOT/'runs/report90_20260912'
DATA=RUN/'structure_coverage20/merged_dataset'
OUT=RUN/'basic_four_control_20260920'
KINDS=['mlp_rank','mlp_regression','xgb_rank','xgb_regression']


def save(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    t=p.with_suffix('.tmp');t.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');t.replace(p)


def state_hash(model):
    h=hashlib.sha256()
    for k,v in model.state_dict().items():h.update(k.encode());h.update(v.detach().numpy().tobytes())
    return h.hexdigest()


def quality(samples,scores):
    q=validation(samples,scores)
    # Independently enumerate evaluation pairs, with ties counted incorrect.
    audit=[];groups=collections.defaultdict(list)
    for i,s in enumerate(samples):groups[s['plan_key']].append(i)
    lat=[];oracle=[]
    for plan,ix in groups.items():
        chosen=min(ix,key=lambda i:(-scores[i],samples[i]['config_key']))
        lat.append(samples[chosen]['latency_ms']);oracle.append(min(samples[i]['latency_ms'] for i in ix))
        for j,a in enumerate(ix):
            for b in ix[j+1:]:
                la,lb=samples[a]['latency_ms'],samples[b]['latency_ms']
                if abs(la-lb)/min(la,lb)<.03:continue
                audit.append(dict(plan=plan,cohort=samples[a]['source_cohort'],a=samples[a]['config_key'],b=samples[b]['config_key'],correct=int((scores[a]-scores[b])*(lb-la)>0)))
    for c in COHORTS:
        rows=[x for x in audit if x['cohort']==c]
        assert len(rows)==q['cohorts'][c]['ranking_pairs']
        assert statistics.mean(x['correct'] for x in rows)==q['cohorts'][c]['rank_accuracy']
    assert len(audit)==920
    q.update(micro_accuracy=sum(x['correct'] for x in audit)/len(audit),effective_pairs=len(audit),
             selected_observed_latency_mean_ms=statistics.mean(lat),oracle_observed_latency_mean_ms=statistics.mean(oracle))
    return q,audit


def main(stage):
    dest=OUT/stage
    if dest.exists():raise RuntimeError('Preserve existing run: '+str(dest))
    if stage=='full':assert json.loads((OUT/'pilot/RESULT.json').read_text())['status']=='verified'
    dest.mkdir(parents=True)
    cpus=os.sched_getaffinity(0);cpu=34 if 34 in cpus else min(cpus);os.sched_setaffinity(0,{cpu})
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    seeds=[17] if stage=='pilot' else [17,29,43]
    settings=[0] if stage=='pilot' else [0,1]
    epochs=2 if stage=='pilot' else 30
    protocol=dict(stage=stage,seeds=seeds,models=KINDS,epochs=epochs,learning_rates=[.0003,.001],
                  batch_pairs=16,pair_draws_per_epoch=624,xgb_depths=[3,6],xgb_trees=5 if stage=='pilot' else 200,
                  cpu=cpu,threads=1,initialization='All fresh; neural regression/rank same family seed gives identical parameter tensors.',
                  neural_supervision='Both losses use exactly the same sampled pair endpoints and batch-specific measured latencies; regression MSE on train-weighted standardized log1p latency, ranking dynamic-margin hinge.',
                  tree_supervision='Identical complete train-pair endpoint rows; rank:pairwise groups of two, regression point MSE; equivalent cohort/plan/pair weighting normalized to mean one.',
                  features='No explicit DOP products. MLP zeroes 532 normalized product columns to preserve 1088 input shape and identical initialization; XGBoost physically removes those columns and uses 556 features. Raw DOP, numerical/category and edge summaries retained. Full-feature reference remains available.',
                  selection='Evaluate every 5 epochs (pilot final); maximize historical/complex equal-weight pair accuracy, then minimize equal-weight regret, then earlier epoch/lower setting. All seeds retained.',
                  scope='Reused development validation, not blind test. Equal budgets within neural objective pairs; XGB trees versus neural epochs are not equal compute budgets. No historical pretrained initialization, EMA, mining or preservation. No SQL execution or online replacement.',
                  versions=dict(python=sys.version,torch=torch.__version__,numpy=np.__version__,xgboost=xgb.__version__),
                  timestamp=time.strftime('%Y-%m-%d %H:%M:%S %z'))
    save(dest/'PROTOCOL.json',protocol)
    sources=[Path(__file__),ROOT/'scripts/report90_six_model_control.py',ROOT/'scripts/report90_models.py',ROOT/'scripts/report90_complex_retrain.py',ROOT/'autodop/model.py',ROOT/'autodop/graph.py',ROOT/'autodop/data.py',ROOT/'autodop/training.py']+[DATA/x for x in ['samples.jsonl','pairs.jsonl','metadata.json','CONTRACT.json']]
    hashes={str(p):file_sha256(p) for p in sources};save(dest/'SOURCE_SHA256.json',hashes)
    start=time.perf_counter();samples,pairs,_=load_dataset(DATA);contract=json.loads((DATA/'CONTRACT.json').read_text())
    tr,tp=select_partition(samples,pairs,contract,'train');va,_=select_partition(samples,pairs,contract,'valid')
    assert (len(tr),len(va))==(1365,212)
    assert not {s['plan_key'] for s in tr}&{s['plan_key'] for s in va}
    meta=build_metadata(tr);save(dest/'METADATA.json',meta);save(dest/'CONTRACT.json',contract)
    graphs={key(s):build_graph(s,meta) for s in tr+va}
    raw={k:flat_features(g,meta) for k,g in graphs.items()}
    x=np.stack([raw[key(s)] for s in tr]);mean=x.mean(0);std=x.std(0);std[std<1e-6]=1
    flat={k:torch.tensor((v-mean)/std,dtype=torch.float32) for k,v in raw.items()}
    n=len(meta['numeric_features']);c=sum(len(meta['category_vocab'][k]) for k in meta['category_features']);width=2*n+2*c+5
    masked=[pool*width+j for pool in range(4) for j in range(n+c+1,2*n+2*c+1)]
    keep=[j for j in range(len(mean)) if j not in set(masked)]
    assert len(mean)==1088 and len(masked)==532 and len(keep)==556
    reference=np.load(RUN/'six_model_control_20260919/full/NORMALIZATION.npz')
    assert np.array_equal(mean,reference['mean']) and np.array_equal(std,reference['std'])
    for value in flat.values():value[masked]=0
    save(dest/'MASK.json',dict(zeroed_columns=masked,retained_columns=keep,mlp_input_width=1088,xgb_input_width=556,normalization_matches_full=True))
    np.savez(dest/'NORMALIZATION.npz',mean=mean,std=std)
    by=pair_index(tr,tp);px=[];py=[];weights=[];pairweights=[]
    for cohort in COHORTS:
        for plan,pp in sorted(by[cohort].items()):
            for p in pp:
                w=.5/len(by[cohort])/len(pp);pairweights.append(w)
                for which in ['fast','slow']:
                    px.append(flat[(plan,p[which+'_config_key'])].numpy());py.append(math.log1p(p[which+'_latency_ms']));weights.append(w/2)
    px=np.stack(px)[:,keep];py=np.array(py);weights=np.array(weights)
    assert abs(weights.sum()-1)<1e-9
    target_mean=float(weights@py);target_std=float(np.sqrt(weights@((py-target_mean)**2)))
    py=(py-target_mean)/target_std
    vx=torch.stack([flat[key(s)] for s in va]);vgraphs=[graphs[key(s)] for s in va]
    save(dest/'PREPARATION.json',dict(seconds=time.perf_counter()-start,train_configs=len(tr),valid_configs=len(va),train_plans=len({s['plan_key'] for s in tr}),valid_plans=len({s['plan_key'] for s in va}),train_pairs=len(tp),flat_width=len(mean),target_mean=target_mean,target_std=target_std,train_only_metadata=True,paired_endpoint_rows=len(py)))
    results=[];initials={}
    def order(q):return (-q['weighted_rank_accuracy'],q['weighted_regret'])
    for seed in seeds:
        for kind in KINDS:
            for setting in settings:
                folder=dest/f'{kind}_s{seed}_h{setting}';folder.mkdir()
                save(dest/'STATUS.json',dict(status='running',model=kind,seed=seed,setting=setting,pid=os.getpid()))
                torch.manual_seed(seed);rng=random.Random(seed);history=[];best=None;fit_seconds=0
                begin=time.perf_counter();reg=kind.endswith('regression');tree=kind.startswith('xgb');graph=kind.startswith('transformer')
                if tree:
                    params=dict(n_estimators=protocol['xgb_trees'],max_depth=protocol['xgb_depths'][setting],learning_rate=.05,n_jobs=1,random_state=seed,tree_method='hist',subsample=1.,colsample_bytree=1.)
                    model=xgb.XGBRegressor(objective='reg:squarederror',**params) if reg else xgb.XGBRanker(objective='rank:pairwise',**params)
                    t=time.perf_counter()
                    if reg:model.fit(px,py,sample_weight=weights*len(weights))
                    else:model.fit(px,np.tile([1,0],len(pairweights)),group=np.full(len(pairweights),2),sample_weight=np.array(pairweights)*len(pairweights))
                    fit_seconds=time.perf_counter()-t
                    scores=model.predict(vx[:,keep].numpy()).astype(float)*(-1 if reg else 1);q,_=quality(va,scores)
                    best=dict(epoch=None,quality=q);path=folder/'model.ubj';model.save_model(path)
                    loaded=xgb.XGBRegressor() if reg else xgb.XGBRanker();loaded.load_model(path);loaded.set_params(n_jobs=1)
                    init=None
                else:
                    model=(LatencyRegressionModel(meta) if reg else CostModel(meta)) if graph else MLP(len(mean))
                    init=state_hash(model);family=kind.split('_')[0];ik=(family,seed)
                    if ik in initials:assert initials[ik]==init
                    else:initials[ik]=init
                    optim=torch.optim.Adam(model.parameters(),lr=protocol['learning_rates'][setting]);path=folder/'model.pt'
                    for epoch in range(1,epochs+1):
                        t=time.perf_counter();model.train();jobs=epoch_pairs(by,rng);losses=[]
                        for offset in range(0,len(jobs),16):
                            batch=jobs[offset:offset+16];optim.zero_grad()
                            keys=[(p['plan_key'],p[w+'_config_key']) for p in batch for w in ['fast','slow']]
                            pred=torch.stack([model(graphs[k]) for k in keys]) if graph else model(torch.stack([flat[k] for k in keys]))
                            if reg:
                                target=pred.new_tensor([(math.log1p(p[w+'_latency_ms'])-target_mean)/target_std for p in batch for w in ['fast','slow']]);loss=(pred-target).square().mean()
                            else:loss=torch.stack([dynamic_margin_ranking_loss(pred[2*i],pred[2*i+1],p['fast_latency_ms'],p['slow_latency_ms']) for i,p in enumerate(batch)]).mean()
                            assert torch.isfinite(loss);loss.backward();optim.step();losses.append(float(loss.detach()))
                        fit_seconds+=time.perf_counter()-t;entry=dict(epoch=epoch,loss=statistics.mean(losses))
                        if epoch%5==0 or epoch==epochs:
                            model.eval()
                            with torch.no_grad():scores=(np.array([float(model(g)) for g in vgraphs]) if graph else model(vx).numpy().astype(float))*(-1 if reg else 1)
                            q,_=quality(va,scores);entry['quality']=q
                            if best is None or order(q)<order(best['quality']):
                                best=dict(epoch=epoch,quality=q);torch.save(model.state_dict(),path)
                            print(stage,kind,seed,setting,epoch,round(q['weighted_rank_accuracy'],6),flush=True)
                        history.append(entry);save(folder/'PROGRESS.json',dict(history=history,fit_seconds=fit_seconds))
                    loaded=(LatencyRegressionModel(meta) if reg else CostModel(meta)) if graph else MLP(len(mean));loaded.load_state_dict(torch.load(path,weights_only=True));loaded.eval()
                total=time.perf_counter()-begin
                with torch.no_grad():replay=(loaded.predict(vx[:,keep].numpy()).astype(float) if tree else np.array([float(loaded(g)) for g in vgraphs]) if graph else loaded(vx).numpy().astype(float))*(-1 if reg else 1)
                q,audit=quality(va,replay);assert q==best['quality']
                save(folder/'PREDICTIONS.json',[dict(plan_key=s['plan_key'],config_key=s['config_key'],cohort=s['source_cohort'],latency_ms=s['latency_ms'],score=float(v)) for s,v in zip(va,replay)])
                save(folder/'PAIR_AUDIT.json',audit)
                times=[]
                with torch.no_grad():
                    for repeat in range(4):
                        for i in range(len(va)):
                            t=time.perf_counter()
                            if tree:loaded.predict(vx[i:i+1,keep].numpy())
                            elif graph:loaded(vgraphs[i])
                            else:loaded(vx[i:i+1])
                            if repeat:times.append((time.perf_counter()-t)*1000)
                record=dict(kind=kind,seed=seed,setting=setting,selected=best,fit_seconds=fit_seconds,train_select_save_reload_seconds=total,
                            inference_mean_ms=statistics.mean(times),inference_p50_ms=float(np.median(times)),inference_p90_ms=float(np.percentile(times,90)),inference_samples=len(times),
                            timing_scope='Single-candidate CPU model API, prebuilt normalized inputs; one full warmup plus three passes; excludes graph/flat feature building, SQL and HTTP.',
                            model=str(path),model_sha256=file_sha256(path),initial_state_sha256=init,parameters=None if tree else sum(p.numel() for p in loaded.parameters()),independent_reload_verified=True)
                save(folder/'RESULT.json',record);results.append(record)
                save(dest/'PARTIAL.json',results)
    selected=[min([x for x in results if x['seed']==seed and x['kind']==kind],key=lambda x:(*order(x['selected']['quality']),x['setting'])) for seed in seeds for kind in KINDS]
    for p,h in hashes.items():assert file_sha256(p)==h
    aggregate={}
    for kind in KINDS:
        rr=[x for x in selected if x['kind']==kind];qs=[x['selected']['quality'] for x in rr]
        aggregate[kind]=dict(macro_accuracy_mean=statistics.mean(q['weighted_rank_accuracy'] for q in qs),macro_accuracy_sd=statistics.stdev(q['weighted_rank_accuracy'] for q in qs) if len(qs)>1 else 0,
             micro_accuracy_mean=statistics.mean(q['micro_accuracy'] for q in qs),regret_mean=statistics.mean(q['weighted_regret'] for q in qs),selected_observed_latency_mean_ms=statistics.mean(q['selected_observed_latency_mean_ms'] for q in qs),
             training_fit_mean_seconds=statistics.mean(x['fit_seconds'] for x in rr),inference_mean_ms=statistics.mean(x['inference_mean_ms'] for x in rr),total_tuning_fit_seconds=sum(x['fit_seconds'] for x in results if x['kind']==kind))
    result=dict(status='verified',selected=selected,candidates=results,aggregate=aggregate,source_sha256=hashes,protocol=protocol)
    save(dest/'RESULT.json',result);save(dest/'STATUS.json',dict(status='complete',selected_models=len(selected),candidate_models=len(results)))
    report(dest,result)
    print('COMPLETE',stage,flush=True)


def report(dest,result):
    lines=['# 六组模型统一条件对照','', '全部从头训练；训练数据、评价对、输入来源和选模规则固定。Transformer/MLP的两种目标采用相同初始参数、相同抽样端点和更新次数。XGBoost保留完整显式交互项，其排序使用原生pairwise目标。验证集参与检查点与参数选择，结果是开发集结果，不能称独立盲测。','',
           '| 模型 | 等权排序准确率 | 种子标准差（百分点） | 微平均准确率 | 等权候选损失 | 候选池已测时延均值 ms | 训练循环 s | 单配置推理 ms |', '|---|---:|---:|---:|---:|---:|---:|---:|']
    for kind,q in result['aggregate'].items():lines.append(f"| {kind} | {100*q['macro_accuracy_mean']:.3f}% | {100*q['macro_accuracy_sd']:.3f} | {100*q['micro_accuracy_mean']:.3f}% | {100*q['regret_mean']:.3f}% | {q['selected_observed_latency_mean_ms']:.2f} | {q['training_fit_mean_seconds']:.2f} | {q['inference_mean_ms']:.4f} |")
    lines+=['','候选池时延取已测验证配置的标签，不是本轮新执行SQL，也不是90条报告查询的端到端结果。推理为预建输入的单配置CPU API调用，不含特征构建、HTTP、FE或SQL。训练列为所选设置训练循环，所有调参成本另存RESULT.json。历史/复杂分别699/221对，共920对；等权准确率是两个队列准确率的算术平均。','', '| 模型 | seed | 设置 | 所选epoch | 等权准确率 | 历史准确率 | 复杂准确率 |','|---|---:|---:|---:|---:|---:|---:|']
    for r in result['selected']:
        q=r['selected']['quality'];lines.append(f"| {r['kind']} | {r['seed']} | {r['setting']} | {r['selected']['epoch']} | {100*q['weighted_rank_accuracy']:.3f}% | {100*q['cohorts']['historical']['rank_accuracy']:.3f}% | {100*q['cohorts']['complex_new']['rank_accuracy']:.3f}% |")
    (dest/'REPORT.md').write_text('\n'.join(lines)+'\n')
    with (dest/'METRICS.csv').open('w',newline='') as f:
        fields=['model']+list(next(iter(result['aggregate'].values())))
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(dict(model=k,**v) for k,v in result['aggregate'].items())


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['pilot','full'],required=True);args=parser.parse_args()
    try:main(args.stage)
    except BaseException as error:
        if (OUT/args.stage).exists():save(OUT/args.stage/'FAILURE.json',dict(error=repr(error),pid=os.getpid()))
        raise
