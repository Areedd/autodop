"""Run the predeclared stream curve only after the matched SQL job verifies."""
import json
from pathlib import Path
import subprocess
import sys
import time


ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'runs/report90_20260912/distillation_concurrency_extension'


def main():
    stage=BASE/'SEQUENCE_STATUS.json'
    def save(**values):stage.write_text(json.dumps(values,indent=2)+'\n')
    dependency=BASE/'distillation_report90/collection_attempt1'
    save(status='waiting_for_matched_sql',dependency=str(dependency))
    deadline=time.monotonic()+1800
    while True:
        state=json.loads((dependency/'STATUS.json').read_text())
        if state['status']=='verified':break
        if state['status']=='failed':raise RuntimeError('Matched SQL failed; do not start dependent stage')
        if time.monotonic()>deadline:raise TimeoutError('Matched SQL did not complete within30minutes')
        time.sleep(10)
    assert json.loads((dependency/'RESULT.json').read_text())['executions']==360
    subprocess.run([sys.executable,str(ROOT/'scripts/report90_extension_report.py')],check=True)
    plan=json.loads((BASE/'FULL_STREAM_PLAN.json').read_text())
    for attempt in range(3):
        out=BASE/('streams_report90' if attempt==0 else f'streams_report90_attempt{attempt}')
        assert not out.exists(),out
        command=[sys.executable,str(ROOT/'scripts/report90_sustained_streams.py'),'--output',str(out),
            '--streams',','.join(map(str,plan['streams'])),'--modes',','.join(plan['modes']),
            '--duration',str(plan['window_seconds']),'--settle',str(plan['settle_seconds']),
            '--queue-cap',str(plan['common_FE_admission_cap'])]
        save(status='running_stream_curve',attempt=attempt,output=str(out),command=command)
        completed=subprocess.run(command)
        if completed.returncode==0:break
        idle=out/'IDLE.json'
        if not idle.exists() or json.loads(idle.read_text())['status']!='busy':
            raise RuntimeError('Stream collection failed after/before idle gate; evidence retained')
        if (out/'events.jsonl').exists():raise RuntimeError('Unexpected SQL evidence in idle-rejected attempt')
        save(status='idle_gate_rejected_retry_pending',attempt=attempt,output=str(out))
        if attempt==2:raise RuntimeError('Three idle gates rejected; no stream measurement started')
        time.sleep(30)
    subprocess.run([sys.executable,str(ROOT/'scripts/report90_sustained_audit.py'),str(out)],check=True)
    subprocess.run([sys.executable,str(ROOT/'scripts/report90_extension_report.py'),'--streams-folder',str(out)],check=True)
    audit=json.loads((out/'AUDIT.json').read_text())
    save(status='collected_and_audited',output=str(out),observed_monotonicity=audit['by_mode'],
         scope='Collection completion is separate from throughput nondegradation acceptance.')


if __name__=='__main__':
    try:main()
    except BaseException as error:
        (BASE/'SEQUENCE_FAILURE.json').write_text(json.dumps(dict(error=repr(error)),indent=2)+'\n')
        raise
