"""Deterministic diagnostic release schedule; does not guarantee FE enqueue order."""
import math
import time


def build_schedule(queues, first_id, interval_seconds=0.25):
    if not math.isfinite(interval_seconds) or interval_seconds <= 0:
        raise ValueError('Positive finite interval required')
    if len(queues)!=16 or any(len(q)!=1 for q in queues):
        raise ValueError('Diagnostic requires sixteen single-job clients')
    ids={q[0]['id'] for q in queues}
    if len(ids)!=2 or first_id not in ids or any(sum(q[0]['id']==i for q in queues)!=8 for i in ids):
        raise ValueError('Exactly eight jobs per frozen query required')
    order=sorted(range(len(queues)),key=lambda i:(queues[i][0]['id']!=first_id,i))
    return {client:dict(rank=rank,offset_seconds=rank*interval_seconds,id=queues[client][0]['id'])
            for rank,client in enumerate(order)}


def wait_until(deadline, clock=time.monotonic, sleeper=time.sleep):
    while True:
        remaining=deadline-clock()
        if remaining<=0:return
        sleeper(remaining)
