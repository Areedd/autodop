"""Combine disjoint development queries, preserving both batches and all controls."""
import hashlib
import json
from pathlib import Path
from statistics import mean
from report90_search_refinement_execute import percentile

RUN = Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def main():
    folders = [RUN/'search_refinement_development', RUN/'search_refinement_complement']
    combined = {}
    sources = [Path(__file__), Path(__file__).with_name('report90_search_refinement_execute.py')]
    batches = {}
    reference = None
    for folder in folders:
        p = folder/'PROTOCOL.json'
        protocol = json.loads(p.read_text())
        signature = {k:protocol[k] for k in ['model','score_evaluations','seeds','online_seed','modes']}
        if reference is None: reference = signature
        else: assert signature == reference
        for source, digest in protocol['source_sha256'].items():
            assert hashlib.sha256(Path(source).read_bytes()).hexdigest() == digest
        result_path = folder/'pilot/RESULT.json'
        result = json.loads(result_path.read_text())
        assert result['status'] == 'verified' and result['executions'] == 64
        for source, digest in result['source_sha256'].items():
            assert hashlib.sha256(Path(source).read_bytes()).hexdigest() == digest
        sources += [p, result_path]
        batches[folder.name] = result['statistics']
        for mode, values in result['per_query_ms'].items():
            assert set(values) == set(protocol['queries'])
            target = combined.setdefault(mode,{})
            assert not set(target)&set(values)
            target.update(values)
    assert all(len(values)==8 for values in combined.values())
    stats = {m:dict(mean_ms=mean(v.values()), **{f'p{int(q*100)}_ms':percentile(v.values(),q) for q in [.5,.9,.99]})
             for m,v in combined.items()}
    comparisons = {}
    for mode in reference['modes']:
        if mode == 'refined_full': continue
        comparisons[mode] = {k:100*(1-stats['refined_full'][k]/stats[mode][k]) for k in stats[mode]}
        comparisons[mode]['faster_queries'] = sum(combined['refined_full'][q]<t for q,t in combined[mode].items())
    result = dict(status='verified_disjoint_development_summary', queries=8, executions_including_warmup=128,
                  statistics=stats, comparisons=comparisons, batches=batches, per_query_ms=combined,
                  scope='Two sequential batches of four disjoint, reused development queries. One measured observation per query/mode. '
                        'All eight included; not repeated trials, independent testing, or a robustness claim. SQL latency excludes offline search.',
                  source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    out = RUN/'search_refinement_summary'
    out.mkdir(exist_ok=False)
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines = ['# 八条开发查询搜索对照', '', result['scope'], '',
             '| 完整改进组相对对照 | 平均延迟降低 | p50降低 | p90降低 | p99降低 | 更快查询数 |',
             '|---|---:|---:|---:|---:|---:|']
    for mode,v in comparisons.items():
        cells = ' | '.join(f'{v[k]:.2f}%' for k in ['mean_ms','p50_ms','p90_ms','p99_ms'])
        lines.append(f"| {mode} | {cells} | {v['faster_queries']}/8 |")
    lines += ['', '完整组总体平均延迟低于所有对照，但部分分位数和逐查询胜出比例不占优。'
              '尤其去等价分组对照中，完整组只在3/8条更快；总体均值优势不能替代稳定性证据。', '',
              '两批结果分别见 [首批](../search_refinement_development/pilot/REPORT.md) 和 '
              '[剩余查询](../search_refinement_complement/pilot/REPORT.md)。第二批完整组平均慢于原MCTS，所有不利结果保留。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines))


if __name__ == '__main__':main()
