"""Run the frozen training-side load calibration after report90 predecessors finish."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from report90_execute import RUN, check
from report90_queue_extension import settings_guard
from report90_extension_summary import summarize

OUT = RUN / 'development17_calibration'


def read(path):
    return json.loads(path.read_text())


def save(name, value):
    path = OUT / name
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2) + '\n')
    tmp.replace(path)


def run(wait):
    assert not (OUT / 'STATUS.json').exists(), 'Preserve previous calibration attempt'
    save('STATUS.json', {'status': 'running', 'stage': 'waiting_for_predecessor', 'pid': os.getpid()})
    predecessor = RUN / 'queue_cpu_corrected_20260913'
    while True:
        state = read(predecessor / 'STATUS.json')
        if state['status'] == 'complete':
            break
        assert state['status'] == 'running' and wait, state
        os.kill(state['pid'], 0)
        assert b'report90_cpu_queue.py' in Path(f"/proc/{state['pid']}/cmdline").read_bytes()
        time.sleep(20)
    for name in ['pilot_c16', 'full_c8', 'full_c16', 'full_c20']:
        assert read(predecessor / name / 'CPU_GATE.json')['status'] == 'passed'
        assert read(predecessor / name / 'QUEUE_SETTINGS.json')['restored']
        assert read(predecessor / name / 'scored/frontend_settings.json')['restored']
    preparation = read(OUT / 'PREPARATION.json')
    for name, key in [('collector_candidate.py', 'candidate_sha256'),
                      ('verifier_candidate.py', 'verifier_candidate_sha256')]:
        assert hashlib.sha256((OUT / name).read_bytes()).hexdigest() == preparation[key]
    assert read(OUT / 'PARAMETER_TESTS.json')['status'] == 'passed_isolated_parameter_tests'
    assert read(OUT / 'VERIFIER_COMPATIBILITY.json')['all_expected_executions_verified']
    assert read(OUT / 'VERIFIER_PARAMETER_TEST.json')['status'] == 'passed'
    protocol = read(RUN / 'DEVELOPMENT17_CALIBRATION_PROTOCOL.json')
    manifest = RUN / 'DEVELOPMENT17_MANIFEST.json'
    assert hashlib.sha256(manifest.read_bytes()).hexdigest() == protocol['manifest_sha256']
    test_hashes = {q['sql_sha256'] for q in read(RUN / 'manifest.json')['queries']}
    queries = read(manifest)['queries']
    assert len(queries) == 17 and not test_hashes & {q['sql_sha256'] for q in queries}
    assert all(q['split'] == 'train' and q['training_eligible'] for q in queries)
    model_protocol = read(RUN / 'PROTOCOL.json')
    assert hashlib.sha256(Path(model_protocol['model']).read_bytes()).hexdigest() == model_protocol['model_sha256']
    variants = {mode: {'checkpoint': model_protocol['model'], 'load_correction': True,
                      'load_parameters': protocol['load_parameters'][mode]}
                for mode in ['policy_floor50', 'policy_floor75']}
    save('variants.json', variants)
    sources = [Path(__file__), OUT/'collector_candidate.py', OUT/'verifier_candidate.py',
               OUT/'variants.json', manifest, RUN/'DEVELOPMENT17_TRUSTED.json',
               RUN/'DEVELOPMENT17_CALIBRATION_PROTOCOL.json', Path(model_protocol['model'])]
    save('EXECUTION_SOURCE_SHA256.json', {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    os.sched_setaffinity(0, set(range(27, 35)))
    for attempt in range(20):
        try:
            check(OUT / f'IDLE_{attempt}.json')
            break
        except RuntimeError:
            if attempt == 19:
                raise
            time.sleep(15)
    command = [sys.executable, str(OUT / 'collector_candidate.py'),
               '--manifest', str(manifest), '--trusted-collection', str(RUN / 'DEVELOPMENT17_TRUSTED.json'),
               '--output-dir', str(OUT / 'scored'), '--policy-model', model_protocol['model'],
               '--policy-variants', str(OUT / 'variants.json'), '--modes', ','.join(protocol['modes']),
               '--scenario', 'concurrent', '--clients', '16', '--minimum-per-client', '1',
               '--warmup', '1', '--repetitions', '1', '--seed', str(model_protocol['seed']),
               '--query-timeout-s', '180', '--auto-dop-max-dop', '16', '--torch-threads', '1',
               '--decision-timeout-ms', '1000', '--metrics-urls',
               'http://127.0.0.1:8040/metrics,http://127.0.0.1:8041/metrics,http://127.0.0.1:8042/metrics,http://127.0.0.1:8030/metrics']
    save('COMMAND.json', command)
    save('STATUS.json', {'status': 'running', 'stage': 'development_small_batch', 'pid': os.getpid()})
    with settings_guard(OUT):
        subprocess.run(command, check=True)
    subprocess.run([sys.executable, str(OUT / 'verifier_candidate.py'), '--collection-dir', str(OUT / 'scored'),
                    '--output', str(OUT / 'scored/independent_verification.json')], check=True)
    proof = read(OUT / 'scored/independent_verification.json')
    assert proof['all_expected_executions_verified'] and proof['expected_slots'] == 170
    pending = []
    for line in (OUT / 'scored/resources.jsonl').open():
        row = json.loads(line)
        if row.get('url') == 'http://127.0.0.1:8030/metrics':
            pending += [float(metric.split()[-1]) for metric in row.get('prometheus_raw', '').splitlines()
                        if metric.startswith('starrocks_fe_query_queue_pending ')]
    save('QUEUE_ACTIVITY.json', {'samples': len(pending), 'max_pending': max(pending, default=0),
                               'clients': 16, 'native_queue_shared_by_all_modes': True})
    assert max(pending, default=0) > 0
    summary = summarize(OUT)
    assert summary['status'] == 'verified'
    applied = {row['query_id']: row['mode'] for line in (OUT / 'scored/events.jsonl').open()
               if (row := json.loads(line))['phase'] == 'measured' and row.get('dop_validation', {}).get('applied')}
    counts = {mode: 0 for mode in protocol['load_parameters']}
    for line in (OUT / 'scored/decisions.jsonl').open():
        row = json.loads(line)
        if row['mode'] in counts and applied.get(row['query_id']) == row['mode']:
            counts[row['mode']] += int(any('load_corrected' in d.get('reason', '') for d in row['response']['decisions']))
    reference = summary['modes']['policy_static']['verified_queries_per_second']
    eligible = [mode for mode in counts if counts[mode] > 0 and
                summary['modes'][mode]['verified_queries_per_second'] >= 1.03*reference]
    winner = max(eligible, key=lambda mode: summary['modes'][mode]['verified_queries_per_second']) if eligible else None
    save('RESULT.json', {'status': 'complete', 'summary': summary, 'applied_corrected_queries': counts,
                         'selected_mode': winner, 'eligible_modes': eligible,
                         'scope': 'Training-side finite-batch screen only. No automatic report90 expansion or deployment parameter change.'})
    save('STATUS.json', {'status': 'complete', 'selected_mode': winner,
                         'at': datetime.datetime.now().astimezone().isoformat()})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--wait', action='store_true')
    args = parser.parse_args()
    if (OUT / 'STATUS.json').exists():
        parser.error('Existing calibration status must be preserved; inspect it before retrying')
    try:
        run(args.wait)
    except BaseException as error:
        save('STATUS.json', {'status': 'failed', 'error': repr(error), 'pid': os.getpid()})
        raise
