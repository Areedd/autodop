"""Symmetric projection of two opposing cohort gradients, training only."""
import torch


def assign_gradients(task_losses, parameters):
    groups=[v for k,v in sorted(task_losses.items()) if v]
    if not 1 <= len(groups) <= 2:
        raise ValueError('expected one or two nonempty training cohorts')
    params=list(parameters);total=sum(map(len,groups));gradients=[]
    for index,losses in enumerate(groups):
        loss=torch.stack(losses).sum()/total
        gs=torch.autograd.grad(loss,params,retain_graph=index+1<len(groups))
        gradients.append(torch.cat([g.detach().double().flatten() for g in gs]))
    projected=False;dot=None
    if len(gradients)==2:
        a,b=gradients;dot=a@b
        if dot<0:
            aa=a@a;bb=b@b
            # Both projections use the original gradients, without task-order effects.
            combined=(a-dot/bb*b)+(b-dot/aa*a);projected=True
        else:combined=a+b
    else:combined=gradients[0]
    assert torch.isfinite(combined).all()
    offset=0
    for p in params:
        p.grad=combined[offset:offset+p.numel()].reshape_as(p).to(p.dtype).clone();offset+=p.numel()
    return {'projected':projected,'dot':None if dot is None else float(dot),'cohorts':len(groups)}
