"""Replay verified pilot decisions to isolate load correction from policy prediction."""
import collections
import hashlib
import json
from pathlib import Path
import statistics

import torch
from autodop.engine import PolicyEngine
from autodop.load_correction import fragment_factor
from report90_extension_summary import RUN, summarize


def main():
    stage = RUN / 'queue_cpu_corrected_20260913/pilot_c16'
    summary = summarize(stage)
    assert summary['status'] == 'verified'
    protocol = json.loads((RUN / 'cpu_capacity_fix/LOAD_CORRECTION_PROTOCOL.json').read_text())
    model = Path(protocol['model'])
    assert hashlib.sha256(model.read_bytes()).hexdigest() == protocol['model_sha256']
    torch.set_num_threads(1)
    engine = PolicyEngine(model)
    formal = {row['query_id'] for line in (stage / 'scored/sql_executions.jsonl').open()
              if (row := json.loads(line))['mode'] == 'policy_load' and row['phase'] == 'measured'}
    rows = []
    transitions = collections.Counter()
    for line in (stage / 'scored/decisions.jsonl').open():
        record = json.loads(line)
        if record['query_id'] not in formal:
            continue
        request = record['request']
        base = engine.decide(request)
        engine.load_correction = {'cpu_threshold': .4, 'mem_threshold': .65, 'floor': .1}
        corrected = engine.decide(request)
        engine.load_correction = {}
        assert corrected['decisions'] == record['response']['decisions'], 'Saved decision replay mismatch'
        fragments = {f['fragment_id']: f for f in request['fragments']}
        after = {d['fragment_id']: d for d in corrected['decisions']}
        changes = []
        for before in base['decisions']:
            fragment = fragments[before['fragment_id']]
            decision = after[before['fragment_id']]
            if before['dop'] != decision['dop']:
                transitions[(before['dop'], decision['dop'])] += 1
                changes.append({'fragment_id': before['fragment_id'], 'base_dop': before['dop'],
                                'corrected_dop': decision['dop'],
                                'factor': fragment_factor(fragment, request['worker_loads'])})
        rows.append({'query_id': record['query_id'], 'changes': changes})
    assert len(rows) == len(formal) == 32
    factors = [c['factor'] for r in rows for c in r['changes']]
    result = {'status': 'verified_exact_decision_replay', 'formal_requests': len(rows),
              'changed_fragments': len(factors), 'median_factor': statistics.median(factors),
              'transitions': [{'base': a, 'corrected': b, 'fragments': n} for (a, b), n in sorted(transitions.items())],
              'rows': rows, 'model_sha256': protocol['model_sha256'],
              'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in
                               [Path(__file__), stage / 'scored/decisions.jsonl', stage / 'scored/independent_verification.json']}}
    (stage / 'CORRECTION_DIAGNOSTIC.json').write_text(json.dumps(result, indent=2) + '\n')
    lines = ['# CPU 负载修正诊断', '',
             f"32 次正式请求的模型重放结果与已保存响应逐 fragment 完全一致。共 {len(factors)} 个 fragment 的 DOP 被下调，修正因子中位数为 {statistics.median(factors):.4f}。", '',
             '| 原策略 DOP | 修正后 DOP | fragment 次数 |', '|---:|---:|---:|']
    lines += [f'| {a} | {b} | {n} |' for (a, b), n in sorted(transitions.items())]
    lines += ['', '容器 CPU 接近满载时，现有线性公式将修正因子压到接近 0.1。CPU 充分利用并不单独证明需要降低 DOP；在已有共同准入控制时，过强下调可能损失并行收益。该解释由修正幅度与同期性能对照支持，但不是独立改变修正强度的因果实验。', '',
              '未修改阈值、公式或线上模型；完整90查询仍按冻结协议运行。该两查询诊断不用于筛除查询或声称整体优势。']
    (stage / 'CORRECTION_DIAGNOSTIC.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ['rows', 'source_sha256']}))


if __name__ == '__main__':
    main()
