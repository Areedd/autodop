"""Training-budget diagnostic; never reads fixed90 queries or measured runtimes."""
import argparse
import collections
import hashlib
import json
import os
import random
import time
from pathlib import Path

import numpy as np
import torch

from report90_models import DATA, RUN, prepare_data, metrics
from autodop.graph import build_graph
from autodop.model import CostModel, dynamic_margin_ranking_loss, save_checkpoint

OUT = RUN / 'convergence_20260913'


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def train(name, epochs, settings):
    folder = OUT / name
    folder.mkdir(exist_ok=False)
    torch.set_num_threads(1)
    samples, train_samples, valid, pairs, meta, contract = prepare_data()
    save(folder / 'CONTRACT.json', contract)
    save(folder / 'METADATA.json', meta)
    graphs = {(s['plan_key'], s['config_key']): build_graph(s, meta) for s in samples}
    pair_by = collections.defaultdict(list)
    for pair in pairs:
        pair_by[pair['plan_key']].append(pair)
    assert len(pair_by) == 78 and len(train_samples) == 1077 and len(valid) == 148
    results = []
    for setting in settings:
        torch.manual_seed(17)
        rng = random.Random(17)
        target = folder / f'h{setting}'
        target.mkdir()
        model = CostModel(meta)
        optimizer = torch.optim.Adam(model.parameters(), lr=3e-4 if setting == 0 else 1e-3)
        history = []
        best = None
        started = time.perf_counter()
        for epoch in range(1, epochs + 1):
            model.train()
            jobs = [rng.choice(pair_by[plan]) for plan in sorted(pair_by) for _ in range(4)]
            rng.shuffle(jobs)
            losses = []
            for offset in range(0, len(jobs), 16):
                optimizer.zero_grad()
                batch = []
                for item in jobs[offset:offset + 16]:
                    plan = item['plan_key']
                    fast = model(graphs[(plan, item['fast_config_key'])])
                    slow = model(graphs[(plan, item['slow_config_key'])])
                    batch.append(dynamic_margin_ranking_loss(fast, slow, item['fast_latency_ms'], item['slow_latency_ms']))
                loss = torch.stack(batch).mean()
                assert torch.isfinite(loss)
                loss.backward()
                optimizer.step()
                losses.append(float(loss.detach()))
            entry = {'epoch': epoch, 'loss': float(np.mean(losses))}
            if epoch % 10 == 0 or epoch == epochs:
                model.eval()
                with torch.no_grad():
                    scores = [float(model(graphs[(s['plan_key'], s['config_key'])])) for s in valid]
                quality = metrics(valid, scores)
                entry['validation'] = quality
                order = (quality['mean_regret'], -quality['rank_accuracy'], epoch)
                if best is None or order < best[0]:
                    best = (order, {'epoch': epoch, 'validation': quality})
                    save_checkpoint(target / 'best.pt', 'cost', model, meta, contract)
            history.append(entry)
            save(target / 'PROGRESS.json', {'status': 'running', 'pid': os.getpid(), 'history': history})
            print(name, setting, epoch, entry['loss'], flush=True)
        save_checkpoint(target / 'last.pt', 'cost', model, meta, contract)
        result = {'setting': setting, 'epochs': epochs, 'seconds': time.perf_counter() - started,
                  'selected': best[1], 'history': history,
                  'checkpoint_sha256': hashlib.sha256((target / 'best.pt').read_bytes()).hexdigest()}
        save(target / 'RESULT.json', result)
        results.append(result)
    save(folder / 'RESULT.json', {'status': 'complete', 'results': results})
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['pilot', 'full'], required=True)
    args = parser.parse_args()
    OUT.mkdir(exist_ok=True)
    if args.stage == 'pilot':
        assert not (OUT / 'PROTOCOL.json').exists()
        save(OUT / 'PROTOCOL.json', {
            'scope': 'Historical train/validation-only Transformer ranking training-budget diagnostic; no fixed90 data read or online benchmark result replacement.',
            'data': str(DATA), 'train_plans': 78, 'valid_plans': 14,
            'seed': 17, 'learning_rates': [3e-4, 1e-3], 'maximum_epochs': 200,
            'pair_draws_per_plan_per_epoch': 4, 'batch_size': 16,
            'selection': 'Validation mean observed-candidate regret, ranking accuracy tie-break, earliest epoch tie-break; evaluate every10epochs.',
            'pilot': '2epochs first learning rate, verify finite training and valid metrics before full run.',
            'limitation': 'Validation reused for checkpoint selection; 200epochs is a fixed ceiling, not proof of convergence. Added search budget must be disclosed before any downstream comparison.',
            'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'baseline_source_sha256': hashlib.sha256((Path(__file__).parent / 'report90_models.py').read_bytes()).hexdigest(),
        })
        train('pilot', 2, [0])
    else:
        assert json.loads((OUT / 'pilot/RESULT.json').read_text())['status'] == 'complete'
        train('full', 200, [0, 1])


if __name__ == '__main__':
    main()
