"""Wait for complete coverage comparison, replay model scores, and report all controls."""
import json
import os
from pathlib import Path
import time
import numpy as np
import torch
import xgboost as xgb
from report90_execute import RUN
from report90_complex_retrain import validation
from report90_models import flat_features
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from autodop.training import select_partition,file_sha256

BASE=RUN/'structure_coverage20';OUT=BASE/'retrained';JOB=BASE/'report_job'
def read(p):return json.loads(p.read_text())
def save(v):
    p=JOB/'STATUS.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(v,indent=2)+'\n');t.replace(p)

def main():
    JOB.mkdir(exist_ok=False);save({'status':'running','stage':'waiting_training','pid':os.getpid()})
    while True:
        state=read(OUT/'STATUS.json')
        if state['status']=='complete':break
        assert state['status']=='running',state
        pid=state['pid'];os.kill(pid,0)
        assert b'report90_structure_coverage_retrain.py' in Path(f'/proc/{pid}/cmdline').read_bytes()
        time.sleep(15)
    save({'status':'running','stage':'score_replay','pid':os.getpid()})
    os.sched_setaffinity(0,{35});torch.set_num_threads(1)
    for p,expected in read(OUT/'EXECUTION_SOURCE_SHA256.json').items():assert file_sha256(p)==expected
    samples,pairs,metadata=load_dataset(BASE/'merged_dataset');valid,_=select_partition(samples,pairs,read(OUT/'CONTRACT.json'),'valid');assert len(valid)==212
    graphs=[build_graph(s,metadata) for s in valid];norm=np.load(OUT/'FEATURE_NORMALIZATION.npz')
    xx=np.stack([(flat_features(g,metadata)-norm['mean'])/norm['std'] for g in graphs]);r=read(OUT/'RESULT.json');verified={}
    for kind,selected in r['selected'].items():
        path=Path(selected['model']);assert file_sha256(path)==selected['model_sha256']
        if kind=='transformer':
            model,ck=load_cost_model(path);model.eval();assert ck['metadata']==metadata
            with torch.no_grad():scores=[float(model(g)) for g in graphs]
        else:
            model=xgb.XGBRanker();model.load_model(path);model.set_params(n_jobs=1);scores=model.predict(xx)
        q=validation(valid,scores);assert q==selected['selected']['validation'];verified[kind]=q
    prior_root=RUN/'complex_development24'
    prior_t=read(prior_root/'preservation_ablation/SCORE_REPLAY.json');assert prior_t['status']=='verified'
    prior_x=read(prior_root/'retrained/SCORE_REPLAY.json');assert prior_x['status']=='verified_selected_model_replay'
    before={'transformer':next(x['quality'] for x in prior_t['candidates'] if x['weight']==0),
            **{k:prior_x['models'][k] for k in ['xgboost_points','xgboost_pairs']}}
    audit={'status':'verified','after':verified,'before_previously_verified':before,'development_gate_passed':r['development_gate_passed'],
        'scope':'Same212 development-validation samples; after-label-coverage augmentation. Validation previously used, no untouched-test or SQL superiority claim.',
        'source_sha256':{str(p):file_sha256(p) for p in [Path(__file__),OUT/'RESULT.json',OUT/'EXECUTION_SOURCE_SHA256.json',prior_root/'preservation_ablation/SCORE_REPLAY.json',prior_root/'retrained/SCORE_REPLAY.json']}}
    (OUT/'SCORE_REPLAY.json').write_text(json.dumps(audit,indent=2)+'\n')
    lines=['# 四分支覆盖补充后的模型对照','','新增20条训练SQL后，训练集为114个计划、1365个配置样本；验证集仍为原22个计划、212个样本。复杂训练部分从16条增至36条。Transformer固定原多阶段起点、seed17、学习率1e-4、100轮、保留权重0。XGBoost两种监督组织使用同一扩充数据，沿用原深度候选与选模规则。','','| 数据阶段 | 模型 | 历史验证选择损失 | 复杂验证选择损失 | 等权选择损失 | 历史/复杂排序准确率 |','|---|---|---:|---:|---:|---:|']
    for phase,models in [('补充前（复用已核验结果）',before),('补充后（新评分回放）',verified)]:
        for kind,q in models.items():
            h=q['cohorts']['historical'];n=q['cohorts']['complex_new']
            lines.append(f"| {phase} | {kind} | {100*h['mean_regret']:.2f}% | {100*n['mean_regret']:.2f}% | {100*q['weighted_regret']:.2f}% | {100*h['rank_accuracy']:.2f}% / {100*n['rank_accuracy']:.2f}% |")
    lines+=['',f"开发门槛：{'通过' if r['development_gate_passed'] else '未通过'}。要求Transformer的等权及复杂验证选择损失均不差于两种XGBoost。",'',
        '新模型均已重新加载，分数与训练记录完全一致。此前结果来自对应独立回放，不冒充同期SQL重跑。新数据和训练专用词表扩充共同构成这次变化；扩充前后全部1577个配置的初始模型预测严格一致。', '',
        '本结果属于已使用过验证集的开发比较，不能据此声称独立测试或90条查询的端到端性能已改善。所有查询、候选和失败记录保留。', '',
        '| 模型 | 本轮候选训练数 | 累计候选耗时（秒） |', '|---|---:|---:|']
    for kind in verified:
        cs=[c for c in r['candidates'] if c['kind']==kind];lines.append(f"| {kind} | {len(cs)} | {sum(c['seconds'] for c in cs):.2f} |")
    lines+=['','候选耗时包含拟合、验证与记录/保存操作，不包含SQL采集、等待及历史预训练。不是严格等工作量训练速度比较。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
    path=BASE/'REPORT.md';original=path.read_text();(JOB/'REPORT.before.md').write_text(original)
    original=original.replace('当前尚未训练或部署使用本小集的模型，也不据此声称取得性能收益。','本小集的离线训练及独立评分核验现已完成，见下方报告；尚未部署或据此证明SQL执行收益。')
    path.write_text(original+'\n\n## 模型比较\n\n完整数据合并、接续训练和两种XGBoost对照见 [模型报告](retrained/REPORT.md)。\n')
    save({'status':'complete','development_gate_passed':r['development_gate_passed']})

if __name__=='__main__':
    if JOB.exists():raise SystemExit('Preserve existing report job')
    try:main()
    except BaseException as e:
        if JOB.exists():save({'status':'failed','error':repr(e),'pid':os.getpid()})
        raise
