"""Bounded lower-cap diagnostic after the cap5 profile failed to improve."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import report90_sustained_streams as collector


BASE=collector.RUN/'distillation_concurrency_extension'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    out=args.output.resolve();assert not out.exists();spec=out.with_suffix('.PROFILE.json')
    manifest=BASE/'STREAM_PILOT_MANIFEST.json'
    command=[str(Path(collector.__file__)),'--output',str(out),'--manifest',str(manifest),
        '--streams','16,20','--modes','policy_load','--queue-cap','3','--duration','60','--settle','15']
    protocol=dict(status='frozen_before_sql',profile='memory_cap3',settings=dict(cap=3,memory_limit_pct=75),command=command,
        scope='Sequential hardware/workload calibration, not an independent blind test: cap5+75percentmemorygate returned30/60s at both16/20streams, against cap4 control31/60s. Probe one lower cap3 with the same memory gate, fixed four-query manifest and two short windows. Keep all profiles and the original90curve.',
        source_sha256={str(p.resolve()):sha(p) for p in [Path(__file__),Path(collector.__file__),manifest,
            BASE/'guard_pilot_cap4/AUDIT.json',BASE/'guard_pilot_memory_cap5/AUDIT.json']})
    with spec.open('x') as f:json.dump(protocol,f,indent=2)
    collector.SETTINGS['query_queue_mem_used_pct_limit']='75'
    collector.SETTINGS['query_queue_cpu_used_permille_limit']='0'
    sys.argv=command;collector.main()
    queue=json.loads((out/'QUEUE_SETTINGS.json').read_text());assert queue['restored']
    assert queue['requested']['query_queue_concurrency_limit']=='3'
    assert queue['requested']['query_queue_mem_used_pct_limit']=='75'
    subprocess.run([sys.executable,str(collector.ROOT/'scripts/report90_sustained_audit.py'),str(out)],check=True)
    for p,d in protocol['source_sha256'].items():assert sha(Path(p))==d,p
    result=dict(status='verified_profile_pilot',profile='memory_cap3',
        source_sha256={str(p):sha(p) for p in [spec,out/'AUDIT.json',out/'QUEUE_SETTINGS.json']})
    (out/'PROFILE_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':main()
