"""Compare retained graph structure coverage without reading report-query latency labels."""
import collections
import hashlib
import json
from pathlib import Path
import numpy as np

RUN=Path(__file__).resolve().parents[1]/'runs/report90_20260912'
OUT=RUN/'training_structure_audit'


def stats(values):
    return {'min':int(min(values)),'median':float(np.median(values)),
            'p90':float(np.percentile(values,90)),'max':int(max(values))}


def main():
    OUT.mkdir(exist_ok=True)
    dataset=Path(json.loads((RUN/'PROTOCOL.json').read_text())['training_dataset'])
    sources=[dataset/'samples.jsonl',RUN/'models_full/CONTRACT.json',RUN/'repair_vectors.json',Path(__file__)]
    samples=[json.loads(line) for line in sources[0].open()]
    contract=json.loads(sources[1].read_text())
    train_keys=set(contract['train_plan_keys']);valid_keys=set(contract['valid_plan_keys'])
    plans={s['plan_key']:s for s in samples}
    train=[plans[key] for key in sorted(train_keys)]
    valid=[plans[key] for key in sorted(valid_keys)]
    vectors=json.loads(sources[2].read_text())['policy_vector']
    report=[{'id':qid,**entry['request']} for qid,entry in sorted(vectors.items())]
    assert len(train)==78 and len(valid)==14 and len(report)==90
    signatures={f['operator_signature'] for p in train for f in p['fragments']}
    train_max=max(len(p['fragments']) for p in train)
    result={'status':'complete','unit':'Unique training/validation plan versus one canonical replay request per frozen report SQL; alternative physical plans excluded from this diagnostic.',
            'training_graphs':len(train),'validation_graphs':len(valid),'report_graphs':len(report),
            'training_fragment_counts':stats([len(p['fragments']) for p in train]),
            'validation_fragment_counts':stats([len(p['fragments']) for p in valid]),
            'report_fragment_counts':stats([len(p['fragments']) for p in report]),
            'report_graphs_larger_than_any_training_graph':sum(len(p['fragments'])>train_max for p in report),
            'report_graphs_with_unseen_operator_signature':sum(any(f['operator_signature'] not in signatures for f in p['fragments']) for p in report),
            'unseen_report_operator_signatures':dict(collections.Counter(f['operator_signature'] for p in report for f in p['fragments'] if f['operator_signature'] not in signatures)),
            'training_operator_signature_count':len(signatures),
            'scope':'Input coverage diagnosis only; no latency labels read, no SQL selected by performance, and no claim that size/novelty causally explains model rankings.',
            'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 成本模型训练结构覆盖检查','','只比较图结构，不读取报告查询的延迟标签。训练/验证以去重计划计数，报告查询以冻结回放中的主请求计数，替代物理计划不计入此诊断。','',
           '| 集合 | 图数量 | fragment 最小/中位/p90/最大 |','|---|---:|---|']
    for title,count,key in [('训练',78,'training_fragment_counts'),('验证',14,'validation_fragment_counts'),('报告查询',90,'report_fragment_counts')]:
        s=result[key];lines.append(f"| {title} | {count} | {s['min']} / {s['median']:.1f} / {s['p90']:.1f} / {s['max']} |")
    lines+=['',f"报告查询中，{result['report_graphs_larger_than_any_training_graph']}/90 的 fragment 数超过训练集最大值；{result['report_graphs_with_unseen_operator_signature']}/90 包含训练图未出现的 operator_signature。",'',
            '该检查用于决定是否需要补充训练结构覆盖，不能单独解释 Transformer 与 XGBoost 的性能差异，也不证明任何模型泛化成功或失败。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['source_sha256','unseen_report_operator_signatures']},indent=2))


if __name__=='__main__':main()
