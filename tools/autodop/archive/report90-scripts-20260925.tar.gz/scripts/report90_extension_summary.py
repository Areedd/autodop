"""Summarize verified extension runs without selecting queries or hiding failures."""
import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path

import numpy as np

RUN = Path(__file__).resolve().parents[1] / 'runs/report90_20260912'


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def queue_plots(stages, folder):
    groups = collections.defaultdict(list)
    for stage in stages:
        if stage['status'] == 'verified' and stage['stage'].startswith('full_c') and stage.get('queue_activity'):
            groups[stage['run']].append(stage)
    plots = []
    for run, entries in sorted(groups.items()):
        if len(entries) < 2:
            continue
        os.environ.setdefault('MPLCONFIGDIR', '/tmp/autodop-report-matplotlib')
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        entries.sort(key=lambda s: s['queue_activity']['clients'])
        clients = [s['queue_activity']['clients'] for s in entries]
        assert len(set(clients)) == len(clients)
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        for mode, label, color in [('native', 'Native', '#888888'),
                                   ('policy_static', 'AutoDOP static', '#346888'),
                                   ('policy_load', 'AutoDOP load', '#558855')]:
            axes[0].plot(clients, [s['modes'][mode]['verified_queries_per_second'] for s in entries],
                         marker='o', label=label, color=color)
            axes[1].plot(clients, [s['modes'][mode]['query_mean_latency_ms'] / 1000 for s in entries],
                         marker='o', label=label, color=color)
        for ax in axes:
            ax.set_xlabel('Concurrent clients')
            ax.set_xticks(clients)
            ax.set_ylim(bottom=0)
            ax.grid(alpha=.2)
            ax.legend()
        axes[0].set_ylabel('Verified queries / second')
        axes[1].set_ylabel('Mean client latency incl. queue (s)')
        runtime = 'BE with corrected CPU accounting' if run.startswith('queue_cpu_corrected_') else 'Original BE'
        fig.suptitle(runtime + '\nShared native admission cap = 8; fixed 90-query finite batches')
        fig.tight_layout()
        name = run + '_CONCURRENCY'
        for extension in ['png', 'pdf']:
            fig.savefig(folder / (name + '.' + extension), dpi=160, bbox_inches='tight')
        plt.close(fig)
        plots.append({'run': run, 'png': name + '.png', 'pdf': name + '.pdf', 'clients': clients})
    return plots


def summarize(stage):
    scored = stage / 'scored'
    proof_path = scored / 'independent_verification.json'
    if not proof_path.exists():
        state_path = stage.parent / 'STATUS.json'
        state = read(state_path) if state_path.exists() else {}
        return {'run': stage.parent.name, 'stage': stage.name,
                'status': 'runner_failed_before_verification' if state.get('status') == 'failed' else 'pending_independent_verification',
                'runner_error': state.get('error')}
    proof = read(proof_path)
    # Check source identity as well as the verifier's verdict.
    for name, expected in proof['source_sha256'].items():
        assert digest(Path(name)) == expected, f'Verified input changed: {name}'
    rows = [json.loads(line) for line in (scored / 'sql_executions.jsonl').read_text().splitlines()]
    result = {'run': stage.parent.name, 'stage': stage.name, 'all_verified': proof['all_expected_executions_verified'],
              'status_counts': dict(collections.Counter(r['status'] for r in rows)),
              'verification_sha256': digest(proof_path), 'modes': {}}
    if not result['all_verified']:
        result['status'] = 'failed_verification_no_performance_claim'
        return result
    result['status'] = 'verified'
    means = {}
    for mode in sorted({r['mode'] for r in rows}):
        selected = [r for r in rows if r['mode'] == mode and r['phase'] == 'measured']
        by_query = collections.defaultdict(list)
        for r in selected:
            assert r['status'] == 'verified'
            by_query[r['id']].append(r['client_latency_ms'])
        means[mode] = {q: float(np.mean(v)) for q, v in by_query.items()}
        values = list(means[mode].values())
        entry = {'queries': len(values), 'executions': len(selected),
                 'repetitions_per_query': sorted({len(v) for v in by_query.values()}),
                 'query_mean_latency_ms': float(np.mean(values)),
                 'query_mean_percentiles_ms': dict(zip(['p50', 'p90', 'p99'],
                    map(float, np.percentile(values, [50, 90, 99])))),
                 'successful_execution_percentiles_ms': dict(zip(['p50', 'p90', 'p99'],
                    map(float, np.percentile([r['client_latency_ms'] for r in selected], [50, 90, 99]))))}
        collection = read(scored / 'collection.json')
        rounds = [r for r in collection['rounds'] if r['mode'] == mode and r['phase'] == 'measured']
        entry['rounds'] = rounds
        entry['verified_queries_per_second'] = sum(r['verified'] for r in rounds) / sum(r['workload_wall_seconds'] for r in rounds)
        result['modes'][mode] = entry
    result['paired_comparisons'] = []
    target = ('original_teacher_pool' if 'original_teacher_pool' in means else
              'extended_transformer_pool' if 'extended_transformer_pool' in means else
              'search_extended_full' if 'search_extended_full' in means else 'native')
    for other in sorted(set(means) - {target}):
        assert set(means[target]) == set(means[other])
        ids = sorted(means[target])
        a = np.array([means[target][q] for q in ids])
        b = np.array([means[other][q] for q in ids])
        result['paired_comparisons'].append({
            'reference': target, 'candidate': other, 'queries': len(ids),
            'candidate_mean_latency_reduction_pct': float(100 * (1 - b.mean() / a.mean())),
            'candidate_faster_queries': int((b < a).sum()),
            'candidate_at_least_3pct_faster_queries': int((b <= .97 * a).sum()),
            'reference_at_least_3pct_faster_queries': int((a <= .97 * b).sum())})
    result['per_query_mean_latency_ms'] = means
    policy_rows = {r['query_id']: r for r in rows if r['phase'] == 'measured'
                   and r['mode'] in ('policy_static', 'policy_load')}
    if policy_rows:
        applied = {}
        for line in (scored / 'events.jsonl').open():
            event = json.loads(line)
            if event.get('query_id') in policy_rows:
                applied[event['query_id']] = bool(event.get('dop_validation', {}).get('applied'))
        diagnostics = {}
        for mode in sorted({r['mode'] for r in policy_rows.values()}):
            diagnostics[mode] = {'formal_executions': sum(r['mode'] == mode for r in policy_rows.values()),
                                 'linked_decisions': 0, 'returned_corrected_queries': 0,
                                 'applied_corrected_queries': 0, 'returned_corrected_fragments': 0,
                                 'max_reported_cpu': 0, 'max_reported_memory': 0}
        seen = set()
        for line in (scored / 'decisions.jsonl').open():
            decision = json.loads(line)
            qid = decision['query_id']
            if qid not in policy_rows:
                continue
            assert qid not in seen, 'Duplicate policy decision linkage'
            seen.add(qid)
            row = policy_rows[qid]
            assert row['mode'] == decision['mode']
            d = diagnostics[row['mode']]
            d['linked_decisions'] += 1
            corrected = sum('load_corrected' in f.get('reason', '') for f in decision['response'].get('decisions', []))
            d['returned_corrected_queries'] += int(corrected > 0)
            d['applied_corrected_queries'] += int(corrected > 0 and applied.get(qid, False))
            d['returned_corrected_fragments'] += corrected
            for load in decision['request'].get('worker_loads', {}).values():
                if load.get('fresh'):
                    d['max_reported_cpu'] = max(d['max_reported_cpu'], load['cpu_used'])
                    d['max_reported_memory'] = max(d['max_reported_memory'], load['mem_used_pct'])
        assert seen == set(policy_rows), 'Some formal policy requests lack a linked decision'
        result['load_diagnostics'] = diagnostics
    if (stage / 'QUEUE_SETTINGS.json').exists():
        result['queue_settings'] = read(stage / 'QUEUE_SETTINGS.json')
        result['queue_activity'] = read(stage / 'QUEUE_ACTIVITY.json') if (stage / 'QUEUE_ACTIVITY.json').exists() else None
        if not result['queue_settings']['restored']:
            result['status'] = 'awaiting_queue_settings_restoration'
        elif result['queue_activity'] is None:
            result['status'] = 'pending_queue_activity_verification'
        else:
            settings = result['queue_settings']
            normalize = lambda value: float({'true': '1', 'false': '0'}.get(str(value).lower(), str(value)))
            applied = settings.get('applied', {})
            assert all(key in applied and normalize(applied[key]) == normalize(value)
                       for key, value in settings['requested'].items()), 'Queue settings differ from protocol'
            pending = []
            resource_path = scored / 'resources.jsonl'
            for line in resource_path.open():
                entry = json.loads(line)
                if entry.get('url') != 'http://127.0.0.1:8030/metrics':
                    continue
                for metric in entry.get('prometheus_raw', '').splitlines():
                    if metric.startswith('starrocks_fe_query_queue_pending '):
                        value = float(metric.split()[-1])
                        assert np.isfinite(value) and value >= 0
                        pending.append(value)
            activity = result['queue_activity']
            assert activity['samples'] == len(pending) and activity['max_pending'] == max(pending, default=0)
            assert {r['clients'] for r in rows} == {activity['clients']}
            result['queue_resource_sha256'] = digest(resource_path)
            result['queue_settings_sha256'] = digest(stage / 'QUEUE_SETTINGS.json')
            if not pending or (activity['clients'] > 8 and max(pending) <= 0):
                result['status'] = 'queue_activation_not_verified'
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=RUN / 'EXTENSION_SUMMARY.json')
    args = parser.parse_args()
    stages = [RUN / 'teacher_extension_20260913' / name for name in ['pilot', 'pilot_v2', 'full_v2']]
    stages += [RUN / 'queue_extension_20260913' / name for name in ['pilot_c16', 'full_c8', 'full_c16', 'full_c20']]
    for attempt in sorted(RUN.glob('queue_extension_20260913_attempt*')):
        if attempt.is_dir():
            stages += [attempt / name for name in ['pilot_c16', 'full_c8', 'full_c16', 'full_c20']]
    if (RUN / 'convergence_execution_20260913').exists():
        stages += [RUN / 'convergence_execution_20260913' / name for name in ['pilot', 'full']]
    if (RUN / 'search_convergence_20260913').exists():
        stages += [RUN / 'search_convergence_20260913' / name for name in ['pilot', 'full']]
    if (RUN / 'queue_cpu_corrected_20260913').exists():
        stages += [RUN / 'queue_cpu_corrected_20260913' / name for name in ['pilot_c16', 'full_c8', 'full_c16', 'full_c20']]
    result = {'generated_at': datetime.datetime.now().astimezone().isoformat(),
              'scope': 'Frozen posthoc positive90; all outcomes retained. Candidate replay excludes model selection cost. Concurrent results are finite batches with shared native admission, not steady-state or standard TPCH throughput.',
              'percentiles': 'Serial headline percentiles across per-query repetition means; execution percentiles also retained. Queue waiting included in client latency.',
              'stages': [summarize(p) if p.exists() else {'run': p.parent.name, 'stage': p.name, 'status': 'not_started'} for p in stages]}
    for stage in result['stages']:
        if stage['run'] != 'queue_cpu_corrected_20260913':
            continue
        stage['runtime_scope'] = 'Rebuilt BE plus libunwind runtime; compare modes within this image, separately from original vendor BE results.'
        gate_path = RUN / stage['run'] / stage['stage'] / 'CPU_GATE.json'
        if gate_path.exists():
            gate = read(gate_path)
            observation = RUN / stage['run'] / (stage['stage'] + '_CPU.jsonl')
            assert digest(observation) == gate['observer_sha256'], 'CPU observation changed after gate'
            assert gate['query_summary']['verification_sha256'] == stage['verification_sha256']
            stage['cpu_gate'] = {k: v for k, v in gate.items() if k != 'query_summary'}
            stage['cpu_gate_sha256'] = digest(gate_path)
            if stage['status'] == 'verified' and gate['status'] != 'passed':
                stage['status'] = 'cpu_mechanism_not_verified'
        elif stage['status'] == 'verified':
            stage['status'] = 'pending_cpu_mechanism_verification'
    result['plots'] = queue_plots(result['stages'], args.output.parent)
    temporary = args.output.with_suffix('.tmp')
    temporary.write_text(json.dumps(result, indent=2) + '\n')
    temporary.replace(args.output)
    lines = ['# 补充实验结果', '', f"生成时间：{result['generated_at']}", '',
             '固定使用此前选出的 90 条查询，不依据本次结果再次筛选。候选配置回放不含模型选优成本；并发实验为共同原生准入控制下的有限批次，延迟包含排队。', '']
    for plot in result['plots']:
        lines += [f"![{plot['run']} 并发结果]({plot['png']})", '',
                  '图中仅包含通过查询、参数与排队证据核验的完整批次。单轮正式测量不提供跨日期稳定性或微小差异的显著性证明。', '']
    for stage in result['stages']:
        lines += [f"## {stage['run']} / {stage['stage']}", '', f"状态：`{stage['status']}`。", '']
        if stage.get('runtime_scope'):
            lines += ['本阶段使用修复后的重建 BE 镜像及其 libunwind 依赖。仅在该镜像内比较三种模式，与原镜像实验分开报告。', '']
        if stage.get('runner_error'):
            lines += [f"运行错误：`{stage['runner_error']}`。", '']
        if 'status_counts' in stage:
            lines += [f"全部执行状态：`{json.dumps(stage['status_counts'])}`。", '']
        if stage['status'] != 'verified':
            continue
        lines += ['| 模式 | 查询数 | 正式执行数 | 平均延迟 ms | p50 | p90 | p99 | 完成查询/秒 |',
                  '|---|---:|---:|---:|---:|---:|---:|---:|']
        for mode, v in stage['modes'].items():
            p = v['query_mean_percentiles_ms']
            lines.append(f"| {mode} | {v['queries']} | {v['executions']} | {v['query_mean_latency_ms']:.2f} | {p['p50']:.2f} | {p['p90']:.2f} | {p['p99']:.2f} | {v['verified_queries_per_second']:.4f} |")
        lines += ['', '分位数按逐查询重复均值计算；小样本 p99 不能证明总体尾延迟。', '']
        for pair in stage['paired_comparisons']:
            lines += [f"- {pair['candidate']} 相对 {pair['reference']} 平均延迟降低 {pair['candidate_mean_latency_reduction_pct']:.2f}%；更快 {pair['candidate_faster_queries']}/{pair['queries']} 条。"]
        lines.append('')
        load = stage.get('load_diagnostics', {}).get('policy_load')
        if load:
            lines += [f"正式阶段 policy_load 共关联 {load['linked_decisions']} 次决策，返回负载修正 {load['returned_corrected_queries']} 次，其中实际安装修正 {load['applied_corrected_queries']} 次。最大上报 CPU 比例 {load['max_reported_cpu']:.4f}，最大上报内存比例 {load['max_reported_memory']:.4f}。", '']
            if not load['returned_corrected_queries']:
                lines += ['本阶段未触发负载修正，因此不能将该模式与静态模式的小幅差异归因于负载修正。CPU 容量口径修复及其后续测试另行记录。', '']
        if stage.get('cpu_gate'):
            gate = stage['cpu_gate']
            lines += [f"独立 CPU 容量核验通过；正式阶段确认 {len(gate['cpu_only_applied_fragments'])} 个 fragment 的修正实际安装，且其目标节点内存均低于修正阈值、CPU 超过阈值。该证据证明 CPU 修正被触发，性能收益需由同期配置对照判断。", '']
    args.output.with_suffix('.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps([{'stage': s['stage'], 'status': s['status']} for s in result['stages']]))


if __name__ == '__main__':
    main()
