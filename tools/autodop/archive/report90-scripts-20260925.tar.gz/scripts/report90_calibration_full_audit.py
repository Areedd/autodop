"""Replay completed calibrated-model seeds using the original independent pair auditor."""
import argparse
import json
from pathlib import Path
import runpy

from report90_interaction_pair_audit import BASE, sha


def main(seed):
    root = BASE / 'pair_calibration_full'
    assert json.loads((root / f'seed{seed}/SCORE_REPLAY.json').read_text())['status'] == 'verified'
    original = Path(__file__).with_name('report90_interaction_pair_audit.py')
    text = original.read_text()
    changes = {
        "BASE = Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20'": "BASE = Path(" + repr(str(BASE)) + ")",
        "BASE/f'interaction_ranking/seed{seed}'": "BASE/f'pair_calibration_full/seed{seed}'",
        "BASE/f'interaction_pair_audit_seed{seed}'": "BASE/f'calibration_pair_audit_seed{seed}'",
        "Path(__file__).with_name('report90_interaction_model.py')": "Path(" + repr(str(original.with_name('report90_interaction_model.py'))) + ")",
        "sources = [Path(__file__),": "sources = [Path(__file__), Path(" + repr(str(original)) + "), Path(" + repr(str(Path(__file__))) + "),",
        'Interaction-augmented Transformer; unchanged flat controls.': 'Pair-calibrated Transformer100-epoch training; unchanged flat controls.',
    }
    for old, new in changes.items():
        assert text.count(old) == 1, old
        text = text.replace(old, new)
    generated = root / f'audit_seed{seed}_staged.py'
    assert not generated.exists()
    compile(text, str(generated), 'exec')
    generated.write_text(text)
    (root / f'AUDIT_TRANSFORM_seed{seed}.json').write_text(json.dumps({
        'original_sha256': sha(original), 'generated_sha256': sha(generated), 'wrapper_sha256': sha(Path(__file__)),
        'changes': changes}, indent=2) + '\n')
    runpy.run_path(str(generated), run_name='calibration_audit')['main'](seed)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, choices=[17, 29, 43], required=True)
    main(parser.parse_args().seed)
