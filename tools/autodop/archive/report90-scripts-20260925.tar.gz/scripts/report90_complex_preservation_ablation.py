"""Execute frozen multistage continuation and two XGBoost supervision controls."""
import collections
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import time
import numpy as np
import torch
from report90_execute import ROOT,RUN
from report90_models import flat_features,metrics
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model,save_checkpoint,dynamic_margin_ranking_loss
from autodop.training import select_partition,file_sha256

BASE=RUN/'complex_development24'
OUT=BASE/'preservation_ablation'
COHORTS=['historical','complex_new']


def read(p):return json.loads(p.read_text())
def save(p,v):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(v,indent=2)+'\n');tmp.replace(p)
def key(s):return s['plan_key'],s['config_key']


def validation(samples,scores):
    quality={}
    for cohort in COHORTS:
        indices=[i for i,s in enumerate(samples) if s['source_cohort']==cohort]
        assert indices
        quality[cohort]=metrics([samples[i] for i in indices],[scores[i] for i in indices])
    return {'cohorts':quality,'weighted_regret':sum(q['mean_regret'] for q in quality.values())/2,
            'weighted_rank_accuracy':sum(q['rank_accuracy'] or 0 for q in quality.values())/2}


def order(q):return q['weighted_regret'],-q['weighted_rank_accuracy']


def pair_index(train,pairs):
    lookup={key(s):s for s in train};by={cohort:collections.defaultdict(list) for cohort in COHORTS}
    assert all(s['split']=='train' for s in train)
    for p in pairs:
        fast=lookup[(p['plan_key'],p['fast_config_key'])];slow=lookup[(p['plan_key'],p['slow_config_key'])]
        assert fast['source_cohort']==slow['source_cohort'] and 0<p['fast_latency_ms']<p['slow_latency_ms']
        by[fast['source_cohort']][p['plan_key']].append(p)
    assert all(by.values())
    return by


def epoch_pairs(by,rng):
    jobs=[]
    for cohort in COHORTS:
        plans=sorted(by[cohort])
        jobs.extend(rng.choice(by[cohort][rng.choice(plans)]) for _ in range(312))
    rng.shuffle(jobs)
    return jobs


def xgb_rows(train,pairs,flat,paired):
    lookup={key(s):s for s in train}
    assert all(s['split']=='train' for s in train)
    xx=[];yy=[];groups=[];weights=[]
    if paired:
        by=pair_index(train,pairs)
        for cohort in COHORTS:
            for plan in sorted(by[cohort]):
                for p in by[cohort][plan]:
                    xx.extend([flat[(plan,p['fast_config_key'])],flat[(plan,p['slow_config_key'])]])
                    yy.extend([1,0]);groups.append(2)
                    weights.append(.5/len(by[cohort])/len(by[cohort][plan]))
    else:
        by={cohort:collections.defaultdict(list) for cohort in COHORTS}
        for s in train:by[s['source_cohort']][s['plan_key']].append(s)
        assert all(by.values())
        for cohort in COHORTS:
            for plan in sorted(by[cohort]):
                samples=sorted(by[cohort][plan],key=lambda s:s['config_key'])
                latencies=sorted({s['latency_ms'] for s in samples},reverse=True)
                xx.extend(flat[key(s)] for s in samples);yy.extend(latencies.index(s['latency_ms']) for s in samples)
                groups.append(len(samples));weights.append(.5/len(by[cohort]))
    assert sum(groups)==len(xx)==len(yy) and abs(sum(weights)-1)<1e-9
    return np.stack(xx),np.array(yy),np.array(groups),np.array(weights)


def main():
    assert read(BASE/'retrained/SCORE_REPLAY.json')['status']=='verified_selected_model_replay'
    protocol=read(BASE/'PRESERVATION_ABLATION_PROTOCOL.json')
    for path,expected in protocol['source_sha256'].items():assert file_sha256(path)==expected
    OUT.mkdir(exist_ok=False);os.sched_setaffinity(0,{35});torch.set_num_threads(1)
    save(OUT/'STATUS.json',{'status':'running','stage':'preparation','pid':os.getpid()})
    dataset=BASE/'merged_dataset';warm=BASE/'warmstart/cost.pt'
    samples,pairs,meta=load_dataset(dataset);contract=read(dataset/'CONTRACT.json')
    train,tp=select_partition(samples,pairs,contract,'train');valid,_=select_partition(samples,pairs,contract,'valid')
    assert len(train)==1205 and len(valid)==212 and all(s['split']=='train' for s in train)
    by=pair_index(train,tp);historical=[s for s in train if s['source_cohort']=='historical']
    sources=[Path(__file__),ROOT/'scripts/report90_complex_merge.py',ROOT/'scripts/report90_models.py',
             BASE/'RETRAIN_PROTOCOL.json',BASE/'PRESERVATION_ABLATION_PROTOCOL.json',warm,
             dataset/'samples.jsonl',dataset/'pairs.jsonl',dataset/'CONTRACT.json',dataset/'metadata.json']
    save(OUT/'EXECUTION_SOURCE_SHA256.json',{str(p):file_sha256(p) for p in sources})
    save(OUT/'CONTRACT.json',contract);save(OUT/'METADATA.json',meta)
    begin=time.perf_counter();graphs={key(s):build_graph(s,meta) for s in samples}
    teacher,ck=load_cost_model(warm);teacher.eval();assert ck['metadata']==meta
    with torch.no_grad():anchors={key(s):teacher(graphs[key(s)]).detach() for s in historical}
    raw={k:flat_features(g,meta) for k,g in graphs.items()}
    X=np.stack([raw[key(s)] for s in train]);mean=X.mean(0);std=X.std(0);std[std<1e-6]=1
    flat={k:(v-mean)/std for k,v in raw.items()};np.savez(OUT/'FEATURE_NORMALIZATION.npz',mean=mean,std=std)
    save(OUT/'PREPARATION.json',{'seconds':time.perf_counter()-begin,'train_samples':len(train),'valid_samples':len(valid),
        'pair_eligible_plans':{c:len(by[c]) for c in COHORTS},
        'plans_without_stable_pairs':sorted({s['plan_key'] for s in train}-{k for c in COHORTS for k in by[c]}),
        'historical_training_anchors':len(anchors),'flat_width':len(mean),'feature_normalization_fit_on_train_only':True})
    candidates=[]
    for index,preservation_weight in enumerate([0.0,1.0]):
        lr=1e-4
        folder=OUT/f'preservation_{preservation_weight:g}';folder.mkdir();torch.manual_seed(17);rng=random.Random(17)
        model,_=load_cost_model(warm);optimizer=torch.optim.Adam(model.parameters(),lr=lr)
        history=[];best=None;started=time.perf_counter()
        save(OUT/'STATUS.json',{'status':'running','stage':folder.name,'pid':os.getpid()})
        for epoch in range(1,101):
            model.train();jobs=epoch_pairs(by,rng);losses=[]
            for offset in range(0,len(jobs),16):
                optimizer.zero_grad();ranking=[]
                for pair in jobs[offset:offset+16]:
                    plan=pair['plan_key'];a=model(graphs[(plan,pair['fast_config_key'])]);b=model(graphs[(plan,pair['slow_config_key'])])
                    ranking.append(dynamic_margin_ranking_loss(a,b,pair['fast_latency_ms'],pair['slow_latency_ms']))
                chosen=[rng.choice(historical) for _ in range(16)]
                preservation=torch.stack([(model(graphs[key(s)])-anchors[key(s)]).square() for s in chosen]).mean()
                loss=torch.stack(ranking).mean()+preservation_weight*preservation
                assert torch.isfinite(loss);loss.backward();optimizer.step();losses.append(float(loss.detach()))
            entry={'epoch':epoch,'loss':float(np.mean(losses))}
            if epoch%10==0:
                model.eval()
                with torch.no_grad():scores=[float(model(graphs[key(s)])) for s in valid]
                q=validation(valid,scores);entry['validation']=q
                if best is None or (*order(q),epoch)<best[0]:
                    best=((*order(q),epoch),{'epoch':epoch,'validation':q})
                    save_checkpoint(folder/'best.pt','cost',model,meta,{'contract':contract,'parent_sha256':file_sha256(warm),'protocol':str(BASE/'PRESERVATION_ABLATION_PROTOCOL.json')})
            history.append(entry);save(folder/'PROGRESS.json',{'status':'running','history':history})
            if epoch%10==0:print(folder.name,epoch,entry['validation']['weighted_regret'],flush=True)
        result={'kind':'transformer','setting':index,'learning_rate':lr,'preservation_weight':preservation_weight,'seconds':time.perf_counter()-started,
                'selected':best[1],'model':str(folder/'best.pt'),'model_sha256':file_sha256(folder/'best.pt'),'history':history}
        save(folder/'RESULT.json',result);candidates.append(result)
    baseline=read(BASE/'retrained/transformer_h0/RESULT.json')
    candidates.append({**baseline,'preservation_weight':10.0,'baseline_reused':True})
    chosen=min(candidates,key=lambda c:(*order(c['selected']['validation']),c['preservation_weight']))
    q=chosen['selected']['validation'];controls=read(BASE/'retrained/RESULT.json')['selected']
    gate=all(q['weighted_regret']<=c['selected']['validation']['weighted_regret'] and
             q['cohorts']['complex_new']['mean_regret']<=c['selected']['validation']['cohorts']['complex_new']['mean_regret']
             for kind,c in controls.items() if kind!='transformer')
    save(OUT/'RESULT.json',{'status':'complete','candidates':candidates,'selected':chosen,
        'development_gate_passed':gate,'scope':'Post-diagnostic development training ablation. Same data, seed, learning rate and epochs; only preservation weight varies. No independent-test or SQL superiority claim.'})
    save(OUT/'STATUS.json',{'status':'complete','development_gate_passed':gate})

if __name__=='__main__':
    if OUT.exists():raise SystemExit('Preserve existing preservation ablation')
    try:main()
    except BaseException as error:
        if OUT.exists():save(OUT/'STATUS.json',{'status':'failed','error':repr(error),'pid':os.getpid()})
        raise
