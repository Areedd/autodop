"""Reproduce the frozen coverage training with two additional seeds, no best-seed selection."""
import argparse
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import numpy as np
import torch
import xgboost as xgb
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from autodop.training import file_sha256, select_partition
from report90_complex_retrain import validation
from report90_models import flat_features
from report90_coverage_choices import BASE, read

ROOT = BASE.parents[2]
OUT = BASE / 'seed_stability'
SOURCE = ROOT / 'scripts/report90_structure_coverage_retrain.py'


def save(path, value):
    tmp = path.with_suffix('.tmp'); tmp.write_text(json.dumps(value, indent=2) + '\n'); tmp.replace(path)


def staged_source(seed, folder, pilot):
    source = SOURCE.read_text()
    replacements = {
        "OUT=BASE/'retrained'": 'OUT=Path(' + repr(str(folder)) + ')',
        'torch.manual_seed(17);rng=random.Random(17)': f'torch.manual_seed({seed});rng=random.Random({seed})',
        'n_jobs=1,random_state=17,': f'n_jobs=1,random_state={seed},',
        "    subprocess.run([sys.executable,str(ROOT/'scripts/report90_structure_coverage_prepare.py')],check=True)":
            "    assert (BASE/'prepared/RESULT.json').exists(), 'Reuse already verified prepared data'",
        "'protocol':str(BASE/'RETRAIN_PROTOCOL.json')": "'protocol':" + repr(str(OUT / 'PROTOCOL.json')),
        "    save(OUT/'EXECUTION_SOURCE_SHA256.json',{str(p):file_sha256(p) for p in sources})":
            "    sources.append(Path(" + repr(str(OUT / 'PROTOCOL.json')) + "))\n    save(OUT/'EXECUTION_SOURCE_SHA256.json',{str(p):file_sha256(p) for p in sources})",
    }
    if pilot:
        replacements.update({'range(1,101)': 'range(1,3)', 'epoch%10==0': 'epoch%1==0', 'n_estimators=200': 'n_estimators=5'})
    counts = {}
    for old, new in replacements.items():
        count = source.count(old)
        assert count == (2 if old == 'epoch%10==0' else 1), (old, count)
        counts[old] = {'replacement': new, 'occurrences': count}
        source = source.replace(old, new)
    return source, counts


def replay(folder):
    result = read(folder / 'RESULT.json'); assert result['status'] == 'complete'
    for path, expected in read(folder / 'EXECUTION_SOURCE_SHA256.json').items(): assert file_sha256(path) == expected
    samples, pairs, meta = load_dataset(BASE / 'merged_dataset')
    valid, _ = select_partition(samples, pairs, read(folder / 'CONTRACT.json'), 'valid'); assert len(valid) == 212
    graphs = [build_graph(s, meta) for s in valid]; norm = np.load(folder / 'FEATURE_NORMALIZATION.npz')
    features = np.stack([(flat_features(g, meta) - norm['mean']) / norm['std'] for g in graphs])
    verified = {}
    for kind, selected in result['selected'].items():
        assert file_sha256(selected['model']) == selected['model_sha256']
        if kind == 'transformer':
            model, checkpoint = load_cost_model(selected['model']); model.eval(); assert checkpoint['metadata'] == meta
            with torch.no_grad(): scores = [float(model(g)) for g in graphs]
        else:
            model = xgb.XGBRanker(); model.load_model(selected['model']); model.set_params(n_jobs=1)
            scores = model.predict(features)
        quality = validation(valid, scores); assert quality == selected['selected']['validation']; verified[kind] = quality
    save(folder / 'SCORE_REPLAY.json', {'status': 'verified', 'models': verified,
        'result_sha256': file_sha256(folder / 'RESULT.json'), 'development_gate_passed': result['development_gate_passed']})
    return verified


def main(stage):
    torch.set_num_threads(1); os.sched_setaffinity(0, {35})
    if stage == 'pilot':
        assert not OUT.exists(), 'Preserve previous stability experiment'
        assert read(BASE / 'retrained/SCORE_REPLAY.json')['status'] == 'verified'
        OUT.mkdir()
        save(OUT / 'PROTOCOL.json', {'frozen_at': datetime.datetime.now().astimezone().isoformat(),
            'reference_seed': 17, 'additional_seeds': [29, 43], 'epochs': 100, 'pilot_epochs': 2,
            'learning_rate': 1e-4, 'preservation_weight': 0, 'xgb_depths': [3, 6], 'xgb_trees': 200,
            'scope': 'Training stochasticity replication, same prepared multistage initialization and data. Reuse all original sampling/update/selection code except documented seed, output, preparation reuse and provenance changes. Pilot shortens epochs/trees only.',
            'aggregation': 'Report all three seeds individually and their mean/range. Never select or deploy the best seed. Original validation has been used; not untouched-test evidence.',
            'gate': 'Original seed17 gate unchanged. No automatic SQL expansion or deployment from this job.',
            'source_sha256': {str(p): file_sha256(p) for p in [Path(__file__), SOURCE, BASE / 'RETRAIN_PROTOCOL.json', BASE / 'prepared/cost.pt', BASE / 'retrained/SCORE_REPLAY.json']}})
    protocol = read(OUT / 'PROTOCOL.json')
    for path, expected in protocol['source_sha256'].items(): assert file_sha256(path) == expected
    if stage == 'full': assert read(OUT / 'seed29_pilot/SCORE_REPLAY.json')['status'] == 'verified'
    seeds = [29] if stage == 'pilot' else protocol['additional_seeds']
    assert all(not (OUT / f'seed{seed}{"_pilot" if stage == "pilot" else ""}').exists() for seed in seeds)
    save(OUT / 'STATUS.json', {'status': 'running', 'stage': stage, 'pid': os.getpid()})
    for seed in seeds:
        name = f'seed{seed}' + ('_pilot' if stage == 'pilot' else '')
        folder = OUT / name; source, changes = staged_source(seed, folder, stage == 'pilot')
        script = OUT / (name + '_trainer.py'); script.write_text(source)
        compile(source, str(script), 'exec')
        save(OUT / (name + '_SOURCE_TRANSFORM.json'), {'original_sha256': file_sha256(SOURCE),
             'generated_sha256': file_sha256(script), 'literal_changes': changes})
        save(OUT / 'STATUS.json', {'status': 'running', 'stage': name, 'pid': os.getpid()})
        with (OUT / (name + '.log')).open('w') as log:
            subprocess.run([sys.executable, str(script)], stdout=log, stderr=subprocess.STDOUT, check=True)
        replay(folder)
    if stage == 'full':
        qualities = {'17': read(BASE / 'retrained/SCORE_REPLAY.json')['after'],
                     **{str(seed): read(OUT / f'seed{seed}/SCORE_REPLAY.json')['models'] for seed in seeds}}
        aggregates = {}
        for kind in qualities['17']:
            values = [q[kind]['weighted_regret'] for q in qualities.values()]
            aggregates[kind] = {'weighted_regret_mean': float(np.mean(values)), 'min': min(values), 'max': max(values)}
        save(OUT / 'RESULT.json', {'status': 'verified', 'seeds': qualities, 'aggregate': aggregates,
             'scope': protocol['aggregation'], 'source_sha256': protocol['source_sha256']})
        lines = ['# 补充结构数据后的训练种子复测', '', protocol['aggregation'], '',
                 '| 种子 | 模型 | 综合选择损失 | 复杂选择损失 |', '|---|---|---:|---:|']
        for seed, models in qualities.items():
            for kind, q in models.items():
                lines.append(f"| {seed} | {kind} | {100*q['weighted_regret']:.2f}% | {100*q['cohorts']['complex_new']['mean_regret']:.2f}% |")
        lines += ['', '全部模型重新加载复核，不按种子挑选结果。17复用先前完整训练及独立核验，29与43按相同流程新训练。复测不自动部署或启动SQL比较，原开发门槛不变。']
        (OUT / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    save(OUT / 'STATUS.json', {'status': 'pilot_verified' if stage == 'pilot' else 'complete'})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--stage', choices=['pilot', 'full'], required=True)
    args = parser.parse_args()
    try:
        main(args.stage)
    except BaseException as error:
        if OUT.exists(): save(OUT / 'STATUS.json', {'status': 'failed', 'error': repr(error), 'pid': os.getpid()})
        raise
