"""Fixed0.99 EMA validation on the matched hard-pair training trajectory."""
import os
from pathlib import Path
import random
import subprocess
import sys
import torch
from autodop.model import load_cost_model
from autodop.data import load_dataset
from autodop.training import select_partition
from report90_complex_retrain import pair_index, COHORTS
import report90_coverage_stability as common
from report90_neighborhood_prepare import RUN, sha

BASE=RUN/'structure_coverage20'
OUT=BASE/'hard_pair_ema_pilot'
SOURCE=BASE/'statistical_readout_pilot/pilot_original_readout_trainer.py'
REFERENCE=BASE/'statistical_readout_pilot/pilot_original_readout'
from report90_hard_pair_sampler import epoch_pairs

def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1)
    assert not OUT.exists()
    assert common.read(REFERENCE/'SCORE_REPLAY.json')['status']=='verified'
    for p,digest in common.read(REFERENCE/'EXECUTION_SOURCE_SHA256.json').items(): assert sha(Path(p))==digest
    samples,pairs,meta=load_dataset(BASE/'merged_dataset')
    train,tp=select_partition(samples,pairs,common.read(BASE/'merged_dataset/CONTRACT.json'),'train')
    by=pair_index(train,tp)
    empty={c:{p:[] for p in plans} for c,plans in by.items()}
    a=epoch_pairs(by,random.Random(17),empty);b=epoch_pairs(by,random.Random(17),empty)
    assert a==b and len(a)==624
    cohorts={plan:cohort for cohort,plans in by.items() for plan in plans}
    assert {c:sum(cohorts[p['plan_key']]==c for p in a) for c in COHORTS}==dict.fromkeys(COHORTS,312)
    assert all(p in by[cohorts[p['plan_key']]][p['plan_key']] for p in a)
    prior=BASE/'hard_pair_pilot'
    assert common.read(prior/'RESULT.json')['status']=='verified'
    for path,digest in common.read(prior/'PROTOCOL.json')['source_sha256'].items(): assert sha(Path(path))==digest
    OUT.mkdir()
    (OUT/'SAMPLER_BOUNDARY_TEST.json').write_bytes((prior/'SAMPLER_BOUNDARY_TEST.json').read_bytes())
    common.save(OUT/'SAMPLING_AUDIT.json',{'status':'verified','seed':17,'sampled_pairs':len(a),
        'cohorts':{c:{'plans':len(plans),'pairs':sum(map(len,plans.values())),
            'min_pairs_per_plan':min(map(len,plans.values())),'max_pairs_per_plan':max(map(len,plans.values()))} for c,plans in by.items()},
        'training_only':True,'reproducible':True})
    common.save(OUT/'PROTOCOL.json',{'seed':17,'smoke_epochs':2,'pilot_epochs':30,
        'hypothesis':'Reduce checkpoint oscillation with fixed0.99 exponential weight averaging after each optimizer step. Gradient updates and training-error mining use unchanged raw model.',
        'design':'Original multi-stage model+competition, same1365train/212valid,624pairs/epoch,batch16,Adam1e-4,cosine100 horizon,loss/checkpoints unchanged. Refresh training-only error pool at epochs1,11,21. Choose each cohort312times, choose plan uniformly, then50% wrong-or-tied pool and50% full pool; empty error pool falls back to full. Validation and saved selected checkpoint use EMA initialized from warm model and updated after every step. Raw training trajectory must match prior hard-pair pilot. Extra mining and EMA costs included in loop timing; not equal wall-time training budget.',
        'controls':'Retain strongest unchanged XGBoost points/pairs and previous MLP/regression controls; their query-weighted training remains documented. This is a training-method pilot, not an isolated architecture comparison.',
        'selection':'Equal-cohort validation pair accuracy, regret then earlier epoch. No report90 scoring or SQL. Reused development validation.',
        'gate':'Must exceed matched reference and both XGBoost controls to expand.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),SOURCE,REFERENCE/'RESULT.json',REFERENCE/'SCORE_REPLAY.json',Path(common.__file__),Path(__file__).with_name('report90_hard_pair_sampler.py'),OUT/'SAMPLING_AUDIT.json',prior/'RESULT.json',prior/'PROTOCOL.json',prior/'pair_audit/RESULT.json',OUT/'SAMPLER_BOUNDARY_TEST.json',Path(__file__).with_name('report90_ema_weights.py')]}})
    for stage in ['smoke','pilot']:
        folder=OUT/stage
        changes={repr(str(REFERENCE)):repr(str(folder)),repr(str(BASE/'statistical_readout_pilot/PROTOCOL.json')):repr(str(OUT/'PROTOCOL.json')),
            'def order(q):':'from report90_hard_pair_sampler import mine_pairs, epoch_pairs\n\ndef order(q):',
            'model.train();jobs=epoch_pairs(by,rng);losses=[]': 'if (epoch-1)%10==0:\n                mining_start=time.perf_counter();hard,counts=mine_pairs(model,train,graphs,by)\n                save(folder/f\"MINING_{epoch}.json\", {\"epoch\":epoch,\"counts\":counts,\"seconds\":time.perf_counter()-mining_start,\"training_samples\":len(train)})\n            model.train();jobs=epoch_pairs(by,rng,hard);losses=[]'}
        changes.update({
            'from autodop.model import load_cost_model, save_checkpoint': 'from autodop.model import load_cost_model, save_checkpoint\nfrom report90_ema_weights import initialize as initialize_ema, update as update_ema',
            'model,_=load_cost_model(warm);optimizer=': 'model,_=load_cost_model(warm);averaged=initialize_ema(model);optimizer=',
            'optimizer.step();losses.append': 'optimizer.step();update_ema(averaged,model);losses.append',
            'with torch.no_grad():scores=[float(model(graphs[key(s)])) for s in valid]': 'with torch.no_grad():scores=[float(averaged(graphs[key(s)])) for s in valid]',
            "save_checkpoint(folder/'best.pt','cost',model,meta,": "save_checkpoint(folder/'best.pt','cost',averaged,meta,",
            "        result={'kind':'transformer'": "        save_checkpoint(folder/'raw_final.pt','cost',model,meta,{'purpose':'Verify unchanged gradient trajectory'})\n        result={'kind':'transformer'",
        })
        if stage=='smoke':changes.update({'range(1,31)':'range(1,3)','epoch%10==0':'epoch%1==0','n_estimators=200':'n_estimators=5'})
        text=SOURCE.read_text(); applied={}
        for old,new in changes.items():
            count=text.count(old);assert count==(2 if old in [repr(str(BASE/'statistical_readout_pilot/PROTOCOL.json')),'epoch%10==0'] else 1),(old,count)
            text=text.replace(old,new);applied[old]={'replacement':new,'occurrences':count}
        script=OUT/f'{stage}_trainer.py';compile(text,str(script),'exec');script.write_text(text)
        common.save(OUT/f'{stage}_TRANSFORM.json',{'original_sha256':sha(SOURCE),'generated_sha256':sha(script),'changes':applied})
        common.save(OUT/'STATUS.json',{'status':'running','stage':stage,'pid':os.getpid()})
        with (OUT/f'{stage}.log').open('w') as stream:subprocess.run([sys.executable,str(script)],stdout=stream,stderr=subprocess.STDOUT,check=True)
        common.load_cost_model=load_cost_model;replay=common.replay(folder)
        print(stage,{k:v['weighted_rank_accuracy'] for k,v in replay.items()},flush=True)
    old=common.read(prior/'pilot/transformer_h0/RESULT.json')
    new=common.read(OUT/'pilot/transformer_h0/RESULT.json')
    assert old['selected']['epoch']==30
    assert [h['loss'] for h in old['history']]==[h['loss'] for h in new['history']]
    raw,_=load_cost_model(OUT/'pilot/transformer_h0/raw_final.pt')
    original,_=load_cost_model(old['model'])
    assert raw.state_dict().keys()==original.state_dict().keys()
    assert all(torch.equal(value,original.state_dict()[key]) for key,value in raw.state_dict().items())
    common.save(OUT/'TRAJECTORY_AUDIT.json',{'status':'verified_exact','loss_epochs':30,'state_tensors':len(raw.state_dict()),'reference_model_sha256':sha(Path(old['model'])),'raw_final_sha256':sha(OUT/'pilot/transformer_h0/raw_final.pt')})
    score=replay['transformer']['weighted_rank_accuracy'];reference=common.read(prior/'RESULT.json')['models']['transformer']['weighted_rank_accuracy']
    gate=score>reference and all(score>v['weighted_rank_accuracy'] for k,v in replay.items() if k!='transformer')
    common.save(OUT/'RESULT.json',{'status':'verified','models':replay,'reference_macro_accuracy':reference,'expansion_gate_passed':gate,'protocol_sha256':sha(OUT/'PROTOCOL.json')})
    common.save(OUT/'STATUS.json',{'status':'complete','expansion_gate_passed':gate})

if __name__=='__main__':
    try:main()
    except BaseException as error:
        if OUT.exists():common.save(OUT/'STATUS.json',{'status':'failed','error':repr(error)})
        raise
