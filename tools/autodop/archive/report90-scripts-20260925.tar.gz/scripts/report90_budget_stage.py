from pathlib import Path
import ast,json,hashlib,math,sys,datetime
root=Path('/home/shaokun/starrocks/tools/autodop');run=root/'runs/report90_20260912';phase=sys.argv[1]
assert phase in ['pilot','full']
if phase=='full':
 p=run/'development17_budget_pilot';assert json.loads((p/'STATUS.json').read_text())['status']=='complete';assert json.loads((p/'ADMISSION_AUDIT.json').read_text())['status']=='verified'
stage=run/f'development17_budget_{phase}_support';stage.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=run/'development17_memory_profiles_full/MEMORY_PROFILE_CHECK.json';d=json.loads(source.read_text());assert d['status']=='verified'
manifest=json.loads((run/'DEVELOPMENT17_MANIFEST.json').read_text());queries=manifest['queries']
limits={r['limit_bytes'] for r in json.loads((run/'development17_memory_observed/DIRECT_MEMORY_ANALYSIS.json').read_text())['rows']};assert len(limits)==1
limit=limits.pop();capacity=math.floor(.6*limit)
budgets={}
for q in queries:
 rs=[r for r in d['rows'] if r['id']==q['id']];assert len(rs)==4
 peak=max(r['peak_per_node']['upper_bytes'] for r in rs)
 amount=max(64*1024**2,math.ceil(1.25*peak));assert amount<=capacity
 budgets[q['id']]={'sql_sha256':q['sql_sha256'],'reservation_bytes':amount,'observed_peak_upper_bytes':peak}
spec={'created_at':datetime.datetime.now().astimezone().isoformat(),'capacity_bytes':capacity,'observed_process_limit_bytes':limit,'capacity_fraction':.6,'reservation_multiplier':1.25,'minimum_reservation_bytes':64*1024**2,'queries':budgets,'source_profile_sha256':sha(source),'scope':'Fixed development prototype: max of both native/static warm/formal prior profiles, same budget per SQL in both gated modes. Not trained prediction, no guarantee of future memory bound; FIFO reservation held across retries. Constants frozen before admission performance testing, not tuned against results.'}
(stage/'MEMORY_BUDGET.json').write_text(json.dumps(spec,indent=2)+'\n')
if phase=='pilot':manifest['queries']=queries[:2]
(stage/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
model=json.loads((run/'PROTOCOL.json').read_text())['model']
(stage/'policy_variants.json').write_text(json.dumps({'policy_budget':{'checkpoint':model,'load_correction':False}},indent=2)+'\n')
parents={}
for name in ['report90_memory_budget.py','report90_retry_capture.py','report90_failure_capture.py','report90_memory_observe.py']:
 p=root/'scripts'/name;q=stage/name;q.write_bytes(p.read_bytes());parents[str(q)]={'source':str(p),'sha256':sha(p),'change':'unchanged snapshot'}
p=run/'development17_retry_support/collector.py';s=p.read_text();assert 'from report90_retry_capture import fetch_timed' in s
s=s.replace('from report90_retry_capture import fetch_timed','from report90_memory_budget import fetch_timed');s=s.replace("MODES = ('native',", "MODES = ('native', 'native_budget',")
ast.parse(s);q=stage/'collector.py';q.write_text(s);parents[str(q)]={'source':str(p),'sha256':sha(p),'change':'fetch wrapper and native_budget mode alias only; alias keeps AutoDOP off and pipeline_dop=0'}
p=run/'development17_retry_support/runner.py';s=p.read_text();s=s.replace("OUT = RUN / 'development17_retry'",f"OUT = RUN / 'development17_budget_{phase}'")
s=s.replace("MODES = ['native', 'policy_static', 'policy_load']", "MODES = ['native', 'native_budget', 'policy_static', 'policy_budget']")
s=s.replace("manifest = RUN / 'DEVELOPMENT17_MANIFEST.json'",f"manifest = Path({str(stage/'manifest.json')!r})")
s=s.replace('assert len(queries) == 17',f"assert len(queries) == {2 if phase=='pilot' else 17}")
minimum=1 if phase=='pilot' else 2;tasks=16 if phase=='pilot' else 34;slots=8*tasks
s=s.replace("'queries': 17, 'clients': 16, 'minimum_per_client': 2",f"'queries': {len(manifest['queries'])}, 'clients': 16, 'minimum_per_client': {minimum}")
s=s.replace("'tasks_per_mode_per_phase': 34, 'expected_slots': 204",f"'tasks_per_mode_per_phase': {tasks}, 'expected_slots': {slots}")
s=s.replace("'minimum-per-client'", "'minimum-per-client'")
s=s.replace("'--minimum-per-client', '2'",f"'--minimum-per-client', '{minimum}'")
s=s.replace('Compare completion of identical logical task sets with the same bounded memory-error retries in all modes; development only.','Factorial diagnostic: native/static DOP crossed with no reservation/historical-profile FIFO reservation; client prototype, not deployed AutoDOP.')
s=s.replace("'load_parameters': {'cpu_threshold': .4, 'mem_threshold': .65, 'floor': .1}", "'memory_budget_sha256': digest(Path(__file__).with_name('MEMORY_BUDGET.json'))")
s=s.replace("'scope': 'Finite-batch development screen, not report90, steady state or significance proof. Same common admission cap for every mode. Native admission is not an AutoDOP contribution.'", "'scope': 'Development factorial screen, not report90 or production admission. Same native queue cap16 and bounded retries for all modes. Memory reservation constants frozen before outcomes. New reservation must not be attributed to preexisting AutoDOP.'")
s=s.replace("'/home/shaokun/starrocks/tools/autodop/runs/report90_20260912/development17_retry_support/", repr(str(stage)+'/')[0:-1])
# Above substitution preserves each original closing quote and path suffix.
s=s.replace("ROOT/'scripts/report90_retry_summary.py'", "Path(__file__).with_name('report90_retry_summary.py')")
s=s.replace("save('EXECUTION_SOURCE_SHA256.json', {str(p): digest(p) for p in sources})", "sources += [Path(__file__).with_name(n) for n in ['report90_memory_budget.py','MEMORY_BUDGET.json','policy_variants.json','report90_memory_observe.py']]\n    save('EXECUTION_SOURCE_SHA256.json', {str(p): digest(p) for p in sources})")
s=s.replace("    save('COMMAND.json', command)", "    command += ['--policy-variants',str(Path(__file__).with_name('policy_variants.json'))]\n    os.environ['AUTODOP_EXPERIMENT_MEMORY_BUDGET']=str(Path(__file__).with_name('MEMORY_BUDGET.json'))\n    os.environ['AUTODOP_EXPERIMENT_ADMISSION_JOURNAL']=str(OUT/'ADMISSION.jsonl')\n    save('COMMAND.json', command)")
s=s.replace('from report90_cpu_observe import observe, workers','from report90_cpu_observe import observe, workers\nfrom report90_memory_observe import observe as observe_memory')
s=s.replace('ThreadPoolExecutor(max_workers=1)','ThreadPoolExecutor(max_workers=2)')
s=s.replace("observation = executor.submit(observe, OUT/'CPU.jsonl', 2400, 3, stop)","observation = executor.submit(observe, OUT/'CPU.jsonl', 2400, 3, stop)\n        memory_observation=executor.submit(observe_memory, OUT/'DIRECT_MEMORY.jsonl', 2400, 1, stop)")
s=s.replace('            observation.result()',"            observation.result()\n            save('DIRECT_MEMORY_SUMMARY.json', memory_observation.result())")
s=s.replace("proof['expected_slots'] == 204 and proof['recorded_sql_slots'] == 204",f"proof['expected_slots'] == {slots} and proof['recorded_sql_slots'] == {slots}")
ast.parse(s);q=stage/'runner.py';q.write_text(s);parents[str(q)]={'source':str(p),'sha256':sha(p),'change':'four modes, pilot/full manifest and expected counts, frozen budget wrappers, equal direct observer; original verifier unchanged'}
p=root/'scripts/report90_retry_summary.py';s=p.read_text().replace('204',str(slots)).replace("['native','policy_static','policy_load']","['native','native_budget','policy_static','policy_budget']").replace('34',str(tasks))
s=s.replace("logical=[e['logical_request_latency_ms'] for e in formal]","logical=[e.get('admission_request_latency_ms',e['logical_request_latency_ms']) for e in formal]")
s=s.replace('17 historical development queries, bounded client retry policy identical for all modes.',f"{len(manifest['queries'])} historical development queries, factorial reservation experiment; all gated waiting included in batch/logical latency. Common retries and queue. Client prototype, not deployed AutoDOP.")
s=s.replace('"logical_latency_ms":','"logical_latency_ms":')
ast.parse(s);q=stage/'report90_retry_summary.py';q.write_text(s);parents[str(q)]={'source':str(p),'sha256':sha(p),'change':'expected slots/tasks/modes generalized; logical latency includes admission wait for gated modes'}
(stage/'SOURCE_TRANSFORM.json').write_text(json.dumps({'phase':phase,'parents':parents,'generated_sha256':{str(p):sha(p) for p in stage.iterdir() if p.is_file()}},indent=2)+'\n')
print(stage,'capacity',capacity,'slots',slots)
