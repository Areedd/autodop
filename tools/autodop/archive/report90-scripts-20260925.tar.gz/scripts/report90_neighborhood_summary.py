"""Describe neighborhood coverage and warm/formal consistency without fitting models."""
import itertools
import json
from pathlib import Path

from report90_neighborhood_prepare import OUT as BASE, sha


def main():
    folder = BASE / 'collection'
    result = json.loads((folder / 'RESULT.json').read_text())
    assert result['status'] == 'verified' and result['executions'] == 64
    for p, digest in result['source_sha256'].items():
        assert sha(Path(p)) == digest
    rows = [json.loads(l) for l in (folder / 'scored/events.jsonl').open()]
    phases = {}
    for row in rows:
        phases.setdefault(row['id'], {}).setdefault(row['phase'], {})[row['mode']] = float(row['trace']['latency_ms'])
    summaries = {}
    for query, groups in phases.items():
        warm, formal = groups['warmup'], groups['measured']
        assert set(warm) == set(formal) == {f'neighbor{i}' for i in range(8)}
        assert all(x > 0 for x in list(warm.values()) + list(formal.values()))
        best = min(formal.values())
        pair_counts = {'formal_eligible': 0, 'both_near_best': 0, 'eligible_in_both_phases': 0, 'same_order_in_both_phases': 0}
        for a, b in itertools.combinations(sorted(formal), 2):
            stable_formal = max(formal[a], formal[b]) / min(formal[a], formal[b]) >= 1.03
            stable_warm = max(warm[a], warm[b]) / min(warm[a], warm[b]) >= 1.03
            if stable_formal:
                pair_counts['formal_eligible'] += 1
                pair_counts['both_near_best'] += max(formal[a], formal[b]) <= 1.2 * best
            if stable_formal and stable_warm:
                pair_counts['eligible_in_both_phases'] += 1
                pair_counts['same_order_in_both_phases'] += (formal[a] < formal[b]) == (warm[a] < warm[b])
        summaries[query] = {'anchor_ms': formal['neighbor0'], 'best_observed_ms': best,
            'new_neighbors_within20pct_of_best': sum(v <= 1.2 * best for k, v in formal.items() if k != 'neighbor0'),
            'new_neighbors_at_least3pct_faster_than_anchor': sum(v <= formal['neighbor0'] / 1.03 for k, v in formal.items() if k != 'neighbor0'),
            'pair_counts': pair_counts, 'warmup_ms': warm, 'formal_ms': formal}
    total = {key: sum(q['pair_counts'][key] for q in summaries.values()) for key in next(iter(summaries.values()))['pair_counts']}
    output = {'status': 'verified_descriptive_summary', 'queries': summaries, 'total_pairs': total,
        'scope': 'All4 training queries and32 configurations retained. Near-best means within20% of the fastest of these8 observed configs, not a global optimum. Formal labels use FE trace latency consistent with training data. Warmup order comparison is a noise diagnostic, not an independent formal repetition or acceptance metric. No data merged and no model fitted.',
        'source_sha256': {str(p): sha(p) for p in [Path(__file__), folder / 'RESULT.json', folder / 'scored/events.jsonl']}}
    target = BASE / 'SUMMARY.json'
    assert not target.exists()
    target.write_text(json.dumps(output, indent=2) + '\n')
    lines = ['# 训练查询邻域采集小测', '', output['scope'], '',
             '| 查询 | 锚点 ms | 最快 ms | 新邻域中接近最快的数量 | 双端接近最快的有效对 |', '|---|---:|---:|---:|---:|']
    for q, value in summaries.items():
        lines.append(f"| {q} | {value['anchor_ms']:.2f} | {value['best_observed_ms']:.2f} | {value['new_neighbors_within20pct_of_best']}/7 | {value['pair_counts']['both_near_best']} |")
    lines += ['', f"有效正式候选对共{total['formal_eligible']}对，双端接近最快的有{total['both_near_best']}对。预热和正式均满足3%差距的{total['eligible_in_both_phases']}对中，排序一致{total['same_order_in_both_phases']}对。"]
    (BASE / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps(total))


if __name__ == '__main__':
    main()
