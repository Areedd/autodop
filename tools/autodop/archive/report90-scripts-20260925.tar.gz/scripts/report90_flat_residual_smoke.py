"""Verify exact warm-start scores, gradients and checkpoint isolation before training."""
import json
import os
from pathlib import Path

import numpy as np
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from report90_flat_residual_model import load_flat_residual_model, save_flat_residual_checkpoint
from report90_neighborhood_prepare import RUN, sha


def main():
    os.sched_setaffinity(0, {33})
    torch.set_num_threads(1)
    out = RUN / 'structure_coverage20/flat_residual_smoke'
    assert not out.exists()
    out.mkdir()
    source = RUN / 'structure_coverage20/prepared/cost.pt'
    dataset = RUN / 'structure_coverage20/merged_dataset'
    samples, _, metadata = load_dataset(dataset)
    # Independently recompute normalization from the unchanged training split only.
    from report90_models import flat_features
    from report90_flat_residual_model import NORMALIZATION
    train_samples=[s for s in samples if s['split']=='train']
    assert len(train_samples)==1365
    values=np.stack([flat_features(build_graph(s,metadata),metadata) for s in train_samples])
    mean=values.mean(0);std=values.std(0);std[std<1e-6]=1
    with np.load(NORMALIZATION) as norm:
        assert np.array_equal(mean,norm['mean']) and np.array_equal(std,norm['std'])
    original, _ = load_cost_model(source)
    model, _ = load_flat_residual_model(source)
    original.eval()
    model.eval()
    count = 0
    with torch.no_grad():
        for sample in samples:
            graph = build_graph(sample, metadata)
            assert torch.equal(original(graph), model(graph))
            count += 1
    assert count == 1577
    train = next(s for s in samples if s['split'] == 'train')
    altered = list(train['dop_config'])
    for i, fragment in enumerate(train['fragments']):
        alternatives = [d for d in fragment['candidate_dops'] if d != altered[i]]
        if alternatives:
            altered[i] = alternatives[0]
            break
    assert altered != train['dop_config']
    a, b = build_graph(train, metadata), build_graph({**train, 'dop_config': altered}, metadata)
    model.train()
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)
    loss = torch.nn.functional.softplus(model(a) - model(b))
    assert torch.isfinite(loss)
    loss.backward()
    assert model.flat_scorer[-1].weight.grad.abs().sum() > 0
    assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
    optimizer.step()
    model.eval()
    target = out / 'smoke_only.pt'
    save_flat_residual_checkpoint(target, 'cost', model, metadata, {'scope': 'Synthetic gradient check on training graph; not a trained candidate or checkpoint-selection result.'})
    restored, _ = load_flat_residual_model(target)
    restored.eval()
    with torch.no_grad():
        assert torch.equal(model(a), restored(a)) and torch.equal(model(b), restored(b))
    try:
        load_cost_model(target)
    except ValueError:
        pass
    else:
        raise AssertionError('Production loader accepted experimental checkpoint')
    result = {'status': 'verified', 'exact_warmstart_configurations': count, 'train_only_normalization_samples':1365, 'flat_width':len(mean), 'finite_gradients': True, 'checkpoint_reload_exact': True,
              'production_loader_rejects': True, 'scope': 'No performance claim. Smoke-only synthetic update uses a training graph; validation configurations are forward-only. Original graph encoder, competition edges and global attention retained. Fragment importance remains the original attention heuristic; the new residual head is not included in that heuristic.',
              'source_sha256': {str(p): sha(p) for p in [Path(__file__), Path(__file__).with_name('report90_flat_residual_model.py'), source, dataset / 'samples.jsonl', dataset / 'metadata.json', NORMALIZATION, Path(__file__).with_name('report90_models.py')]}}
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
