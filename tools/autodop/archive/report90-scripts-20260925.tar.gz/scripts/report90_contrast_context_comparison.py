"""Compare controlled contexts and query-level resource counters without mixing batch labels."""
import json
from pathlib import Path
from report90_neighborhood_prepare import RUN,sha

OUT=RUN/'training_conditional_contrasts/CONTEXT_COMPARISON.json'

def read(p):return json.loads(p.read_text())

def main():
    assert not OUT.exists();old=RUN/'training_contrasts_pilot_v2';new=RUN/'training_conditional_contrasts'
    a,b=read(old/'SUMMARY.json'),read(new/'SUMMARY.json');assert a['status']==b['status']=='verified_controlled_contrast_summary'
    for result in [a,b]:
        for path,digest in result['source_sha256'].items():assert sha(Path(path))==digest
    va,vb=read(old/'vectors.json'),read(new/'vectors.json');proposal=read(old/'PROPOSALS.json')
    events=[json.loads(x) for x in (old/'collection/scored/events.jsonl').read_text().splitlines()];measured={(r['id'],r['mode']):r for r in events if r['phase']=='measured'}
    result={}
    for q,current in b['queries'].items():
        previous=a['queries'][q];assert vb['anchor_low'][q]['fragment_dops']==va['group0_low'][q]['fragment_dops']
        effects=[]
        for contrast in current['contrasts']:
            i=contrast['group'];before=next(c for c in previous['contrasts'] if c['group']==i)
            for side in ['low','high']:
                mode=f'group{i}_{side}';x=va[mode][q]['fragment_dops'];y=vb[mode][q]['fragment_dops'];assert x.keys()==y.keys()
                anchor_old=va['anchor4'][q]['fragment_dops'];anchor_new=vb['anchor_low'][q]['fragment_dops']
                changed={fid for fid in x if x[fid]!=y[fid]};assert changed=={fid for fid in anchor_old if anchor_old[fid]!=anchor_new[fid]}
            effects.append({'group':i,'root_node':contrast['root_node'],'previous_high_vs_low_reduction_percent':before['high_vs_low_reduction_percent'],'conditional_high_vs_low_reduction_percent':contrast['high_vs_low_reduction_percent'],'previous_phase_consistent':before['both_phase_gap_ge3pct'] and before['same_order_in_both_phases'],'conditional_phase_consistent':contrast['both_phase_gap_ge3pct'] and contrast['same_order_in_both_phases']})
        lo,hi=[measured[(q,f'group0_{side}')]['trace']['query_statistics'] for side in ['low','high']]
        result[q]={'same_configuration_anchor_old_ms':previous['formal_ms']['group0_low'],'same_configuration_anchor_new_ms':current['anchor_ms'],'anchor_shift_percent':100*(current['anchor_ms']/previous['formal_ms']['group0_low']-1),'conditional_effects':effects,
            'initial_group0_resources':{'low':lo,'high':hi,'cpu_increase_percent':100*(hi['cpu_cost_ns']/lo['cpu_cost_ns']-1),'same_scan_rows_and_bytes':all(lo[k]==hi[k] for k in ['scan_rows','scan_bytes'])}}
    sources=[Path(__file__),old/'SUMMARY.json',new/'SUMMARY.json',old/'vectors.json',new/'vectors.json',old/'collection/scored/events.jsonl']
    output={'status':'verified_context_comparison','queries':result,
        'scope':'Different measurement batches; identical anchor configuration remeasured to diagnose drift. Never pool cross-batch labels. CPU/memory are query_statistics counters, not per-fragment CPU attribution or container peak memory. One formal observation per config, no statistical-significance or model-superiority claim.',
        'source_sha256':{str(p):sha(p) for p in sources}}
    OUT.write_text(json.dumps(output,indent=2)+'\n')
    lines=['# 条件对照与资源计数核对','',output['scope'],'','| 查询 | 同配置锚点变化 | 原局部聚合组高DOP的查询CPU增加 | 扫描行数及字节一致 |','|---|---:|---:|---|']
    for q,v in result.items():lines.append(f"| {q} | {v['anchor_shift_percent']:.2f}% | {v['initial_group0_resources']['cpu_increase_percent']:.2f}% | {v['initial_group0_resources']['same_scan_rows_and_bytes']} |")
    lines+=['','| 查询 | 组 | 原背景高DOP降低率 | 固定聚合DOP1后高DOP降低率 | 条件对照两阶段一致且≥3% |','|---|---:|---:|---:|---|']
    for q,v in result.items():
        for c in v['conditional_effects']:lines.append(f"| {q} | {c['group']} | {c['previous_high_vs_low_reduction_percent']:.2f}% | {c['conditional_high_vs_low_reduction_percent']:.2f}% | {c['conditional_phase_consistent']} |")
    (OUT.with_suffix('.md')).write_text('\n'.join(lines)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
