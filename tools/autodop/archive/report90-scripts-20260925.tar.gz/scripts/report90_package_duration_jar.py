"""Audit experimental jar contents and rerun HTTP/slot checks using the jar first."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[3]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('integration', type=Path)
    integration = parser.parse_args().integration.resolve()
    run = ROOT / 'tools/autodop/runs/report90_20260912'
    base = run / 'queue_timeline_validation/timeline-fe.jar'
    proof = json.loads((base.parent / 'BINARY_AUDIT.json').read_text())
    assert sha(base) == proof['timeline_sha256']
    source_proof = json.loads((integration / 'RESULT.json').read_text())
    for name, digest in source_proof['source_sha256'].items():
        assert sha(integration / 'src' / name) == digest
    for stage, expected in [('http_validation', 'verified_http_synthetic_features'),
                            ('slot_validation', 'verified_synthetic_slot_integration')]:
        assert json.loads((integration / stage / 'RESULT.json').read_text())['status'] == expected
    out = integration / 'jar_validation'
    out.mkdir(exist_ok=False)
    dest = out / 'duration-fe.jar'
    replacements = {p.relative_to(integration / 'classes').as_posix(): p.read_bytes()
                    for p in (integration / 'classes').rglob('*.class')}
    allowed = ['com/starrocks/qe/scheduler/slot/' + n for n in
               ['PredictedDurationQueue', 'PredictedDurationRegistry', 'ReportDurationBridge', 'SlotSelectionStrategyV2']]
    allowed.append('com/starrocks/sql/optimizer/cost/feature/CostPredictor')
    assert replacements and all(any(n == p + '.class' or n.startswith(p + '$') for p in allowed)
                                for n in replacements)
    with zipfile.ZipFile(base) as original, zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED) as jar:
        old_names = set(original.namelist())
        assert len(old_names) == len(original.namelist())
        for info in original.infolist():
            jar.writestr(info, replacements.get(info.filename, original.read(info.filename)))
        for name in sorted(set(replacements) - old_names): jar.writestr(name, replacements[name])
    with zipfile.ZipFile(base) as original, zipfile.ZipFile(dest) as jar:
        added = sorted(set(jar.namelist()) - old_names)
        changed = sorted(n for n in old_names if original.read(n) != jar.read(n))
        assert set(changed + added) <= set(replacements)
        assert all(jar.read(n) == value for n, value in replacements.items())
        assert len(jar.namelist()) == len(set(jar.namelist()))
    result = dict(status='packaged_testing', base_sha256=sha(base), jar_sha256=sha(dest),
                  changed_classes=changed, added_classes=added,
                  scope='Experimental single-FE jar, independent Java processes, no live deployment or SQL performance claim.')
    deployed = ROOT / 'output/fe/lib/starrocks-fe.jar'
    result['deployed_before_sha256'] = sha(deployed)
    try:
        for stage in ['http_validation', 'slot_validation']:
            for enabled in ['false', 'true']:
                cmd = json.loads((integration / stage / (enabled + '.command.json')).read_text())
                index = cmd.index('-cp') + 1
                components = cmd[index].split(':')
                components = [part for part in components if part != str(integration / 'classes')]
                cmd[index] = str(dest) + ':' + ':'.join(components)
                name = stage + '_' + enabled
                (out / (name + '.command.json')).write_text(json.dumps(cmd, indent=2) + '\n')
                with (out / (name + '.log')).open('w') as log:
                    process = subprocess.run(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=60)
                result[name] = process.returncode
                if process.returncode:
                    result['status'] = 'failed'
                    raise RuntimeError(str(out / (name + '.log')))
                output = (out / (name + '.log')).read_text()
                assert ('HTTP_CHECKS_PASSED' if stage == 'http_validation' else '4 tests successful') in output
        result['status'] = 'verified_jar_not_deployed'
    finally:
        result['deployed_after_sha256'] = sha(deployed)
        result['source_sha256'] = {str(p): sha(p) for p in [Path(__file__), integration / 'RESULT.json',
                                   *sorted((integration / 'src').rglob('*.java'))]}
        (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(dict(output=str(out), **result), indent=2))
    assert result['deployed_after_sha256'] == result['deployed_before_sha256']


if __name__ == '__main__':
    main()
