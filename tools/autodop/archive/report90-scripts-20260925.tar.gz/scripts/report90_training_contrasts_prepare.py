"""Freeze high-contrast single-equivalence-group training interventions before SQL."""
import json
from pathlib import Path
from autodop.graph import sample_from_request
from autodop.mcts import equivalence_groups
from collect_paper_evaluations import VectorEngine
from report90_neighborhood_prepare import RUN,sha

OUT=RUN/'training_contrasts_pilot'

def main():
    assert not OUT.exists()
    source=RUN/'training_neighborhood_pilot'
    manifest=json.loads((source/'manifest.json').read_text());old=json.loads((source/'PROPOSALS.json').read_text());requests=json.loads((source/'vectors.json').read_text())['neighbor0']
    samples=[json.loads(x) for x in (RUN/'structure_coverage20/merged_dataset/samples.jsonl').read_text().splitlines()]
    lookup={s['plan_key']:s for s in samples};protected={s['sql_sha256'] for s in samples if s['split']=='valid'}|{q['sql_sha256'] for q in json.loads((RUN/'manifest.json').read_text())['queries']}
    assert len(manifest['queries'])==4 and all(q['split']=='train' and q['sql_sha256'] not in protected for q in manifest['queries'])
    vectors={name:{} for name in ['anchor4']+[f'group{i}_{side}' for i in range(4) for side in ['low','high']]};proposals={}
    for q in manifest['queries']:
        qid=q['id'];request=requests[qid]['request'];sample=sample_from_request(request);plan=lookup[old[qid]['training_plan_key']]
        assert plan['split']=='train' and plan['sql_sha256']==q['sql_sha256']
        domains=[f['candidate_dops'] for f in plan['fragments']];groups=equivalence_groups(sample,domains)
        anchor=[min(domain,key=lambda d:(abs(d-4),d)) for domain in domains]
        available=[]
        for group in groups:
            domain=sorted(set.intersection(*(set(domains[i]) for i in group)))
            if len(domain)<3 or not (min(domain)<4<max(domain)):continue
            assert all(anchor[i]==4 for i in group)
            root=str(sample['fragments'][group[0]].get('root_node',''))
            weight=sum(max(0.,float(sample['fragments'][i].get('fragment_cost',0.))) for i in group)
            available.append({'indices':list(group),'low':min(domain),'high':max(domain),'root_node':root,'estimated_cost_sum':weight})
        available.sort(key=lambda g:(-g['estimated_cost_sum'],g['indices']))
        chosen=[];seen=set()
        for group in available:
            if group['root_node'] not in seen:chosen.append(group);seen.add(group['root_node'])
            if len(chosen)==4:break
        for group in available:
            if len(chosen)==4:break
            if group not in chosen:chosen.append(group)
        assert len(chosen)==4
        configs=[('anchor4',anchor,None)]
        for i,group in enumerate(chosen):
            for side in ['low','high']:
                dop=list(anchor)
                for j in group['indices']:dop[j]=group[side]
                assert {j for j,(a,b) in enumerate(zip(dop,anchor)) if a!=b}==set(group['indices'])
                configs.append((f'group{i}_{side}',dop,{'group':group['indices'],'action':group[side]}))
        assert len({tuple(dop) for _,dop,_ in configs})==9
        proposals[qid]={'training_plan_key':plan['plan_key'],'candidate_groups':len(available),'selected_groups':chosen,'configs':[]}
        for name,dop,change in configs:
            assert all(d in domain for d,domain in zip(dop,domains))
            vector={'request':request,'fragment_dops':dict(zip(sample['fragment_ids'],dop))};VectorEngine({qid:vector}).decide(request)
            vectors[name][qid]=vector;proposals[qid]['configs'].append({'mode':name,'dop_config':dop,'change':change})
    OUT.mkdir()
    def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
    save('manifest.json',manifest);save('vectors.json',vectors);save('PROPOSALS.json',proposals)
    sources=[Path(__file__),source/'manifest.json',source/'PROPOSALS.json',source/'vectors.json',RUN/'structure_coverage20/merged_dataset/samples.jsonl',RUN/'manifest.json']
    save('PROTOCOL.json',{'status':'frozen_before_measurement','queries':sorted(requests),'modes':list(vectors),'warmup':1,'repetitions':1,'expected_executions':72,
        'design':'Reuse first lexicographic training4-branch query per root inner/left/full/union. Uniform4 projected legal anchor; four movable equivalence groups selected by descending estimated cost, preferring distinct root operators, then cost-order fill. Each selected group independently set to legal minimum/maximum, all other groups fixed at anchor. No timing-based selection or dropping.',
        'scope':'Training-only acquisition pilot,36 configurations. No validation/report90 SQL, no active dataset mutation, fitting or deployment. Broad DOP contrasts may be slow; retain every observation. One formal observation only; does not establish statistical significance.',
        'source_sha256':{str(p):sha(p) for p in sources}})
    save('STATUS.json',{'status':'prepared','queries':4,'configs':36})
    print({q:[(g['root_node'],g['indices'],g['low'],g['high']) for g in v['selected_groups']] for q,v in proposals.items()})

if __name__=='__main__':main()
