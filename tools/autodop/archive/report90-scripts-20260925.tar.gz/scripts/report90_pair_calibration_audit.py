"""Independently replay the calibration pilot against all unchanged accuracy controls."""
import json
from pathlib import Path
import runpy

from report90_interaction_pair_audit import BASE, sha


def main():
    root = BASE / 'pair_calibration_pilot'
    assert json.loads((root / 'RESULT.json').read_text())['status'] == 'verified'
    original = Path(__file__).with_name('report90_interaction_pair_audit.py')
    text = original.read_text()
    changes = {
        "BASE = Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20'": "BASE = Path(" + repr(str(BASE)) + ")",
        "BASE/f'interaction_ranking/seed{seed}'": "BASE/'pair_calibration_pilot/pilot'",
        "BASE/f'interaction_pair_audit_seed{seed}'": "BASE/'pair_calibration_pair_audit'",
        "Path(__file__).with_name('report90_interaction_model.py')": "Path(" + repr(str(original.with_name('report90_interaction_model.py'))) + ")",
        "sources = [Path(__file__),": "sources = [Path(__file__), Path(" + repr(str(original)) + "), Path(" + repr(str(Path(__file__))) + "),",
        'Interaction-augmented Transformer; unchanged flat controls.': 'Pair-calibrated Transformer30-epoch pilot; unchanged full-budget flat controls. Single-seed development diagnostic, not final superiority evidence.',
    }
    for old, new in changes.items():
        assert text.count(old) == 1, old
        text = text.replace(old, new)
    generated = root / 'pair_audit_staged_v2.py'
    assert not generated.exists()
    compile(text, str(generated), 'exec')
    generated.write_text(text)
    (root / 'PAIR_AUDIT_TRANSFORM_v2.json').write_text(json.dumps({
        'original_sha256': sha(original), 'generated_sha256': sha(generated),
        'wrapper_sha256': sha(Path(__file__)), 'changes': changes}, indent=2) + '\n')
    module = runpy.run_path(str(generated), run_name='calibration_audit')
    module['main'](17)


if __name__ == '__main__':
    main()
