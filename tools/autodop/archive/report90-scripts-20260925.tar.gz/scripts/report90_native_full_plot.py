"""Plot audited full-report native admission outcomes without synthetic error bars."""
import json,re,os
os.environ.setdefault('MPLCONFIGDIR','/tmp/autodop-report-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from report90_execute import RUN

def main():
 out=RUN/'report90_native_budget_cap4_full'
 proof=json.loads((out/'ALLOCATION_AUDIT.json').read_text())
 assert proof['status']=='verified' and proof['executions']==720
 assert json.loads((RUN/'report90_native_budget_cap4_full_restart/RESTORATION.json').read_text())['restored']
 modes=['native','native_budget','policy_static','policy_budget']
 labels=['Native\nFixed budget\n(4 queries)','Native\nPredicted\nbudget','AutoDOP\nFixed budget\n(4 queries)','AutoDOP\nPredicted\nbudget']
 colors=['#78909c','#42a5f5','#558b2f','#ff9800']
 waits={m:[] for m in modes}
 for row in proof['rows']:
  if row['phase']=='measured':waits[row['mode']].append(int(re.search(r'\|PendingTimeMs=(\d+)\|',row['audit_line'])[1]))
 assert all(len(v)==90 for v in waits.values())
 metrics=proof['metrics']
 fig,axs=plt.subplots(1,3,figsize=(12,4),layout='constrained')
 series=[([metrics[m]['batch_seconds'] for m in modes],'Batch time (s)'),
         ([metrics[m]['mean_ms']/1000 for m in modes],'Mean request latency (s)'),
         ([sum(waits[m])/90000 for m in modes],'Mean admission wait (s)')]
 for ax,(values,title) in zip(axs,series):
  bars=ax.bar(labels,values,color=colors);ax.set_ylabel(title);ax.set_ylim(0,max(values)*1.18)
  ax.bar_label(bars,fmt='%.2f',fontsize=9);ax.tick_params(axis='x',labelsize=8)
 fig.suptitle('90 queries / 16 clients / one measured batch per mode')
 for ext in ['png','pdf']:fig.savefig(out/f'concurrency_comparison.{ext}',dpi=180,bbox_inches='tight',pad_inches=0.12)
 plt.close(fig)
 (out/'FIGURE_SCOPE.json').write_text(json.dumps(dict(status='rendered',mean_pending_ms={m:sum(waits[m])/90 for m in modes},scope='Observed finite-batch outcomes; no confidence intervals or steady-state claim. Fixed4 was calibrated after fixed8 OOM; cumulative logging overhead remains included.'),indent=2)+'\n')
 report=out/'REPORT.md'
 marker='## 完整指标与记录成本说明'
 text=report.read_text().split(marker)[0].rstrip()
 c=proof['latency_reduction_percent']['admission_heterogeneous']
 report.write_text(text+'\n\n'+marker+'\n\n'+
   f"预测预算相对统一4预算在异构模式下：平均请求延迟降低{c['mean_ms']:.2f}%，p90增加{-c['p90_ms']:.2f}%，p99增加{-c['p99_ms']:.2f}%。平均收益与尾部代价同时报告，不构成全面领先。\n\n"+
   '![完整90查询并发对照](concurrency_comparison.png)\n\n累计日志重写的序列化成本随记录数增长，已单独诊断；没有从端到端延迟扣除估算开销。单轮有限批次不支持稳定性或稳态吞吐结论。\n')
 print('Rendered audited full-query comparison')

if __name__=='__main__':main()
