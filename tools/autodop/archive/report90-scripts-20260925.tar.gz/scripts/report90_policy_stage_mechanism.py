"""Describe feature and action agreement; never filter performance rows."""
import argparse
import copy
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[1] / 'runs/report90_20260912/policy_final_stage_ablation'


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def features(request):
    value = copy.deepcopy(request)
    value.pop('query_id')
    value.pop('worker_loads')
    for fragment in value['fragments']:
        fragment['worker_ids'] = sorted(fragment['worker_ids'])
    value['fragments'].sort(key=lambda f: f['fragment_id'])
    value['edges'].sort(key=lambda edge: json.dumps(edge, sort_keys=True))
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=['pilot', 'full'], required=True)
    args = parser.parse_args()
    directory = BASE / ('online_' + args.phase)
    source = directory / 'scored'
    audit_path = directory / 'POLICY_RESPONSE_AUDIT.json'
    audit = json.loads(audit_path.read_text())
    assert audit['all_collection_modes_replayed']
    for path, expected in audit['source_sha256'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected
    events = [json.loads(line) for line in (source/'events.jsonl').read_text().splitlines()]
    decisions = [json.loads(line) for line in (source/'decisions.jsonl').read_text().splitlines()]
    by_id = {d['query_id']: d for d in decisions}
    assert len(by_id) == len(decisions) == len(events)
    rows = {}
    for event in events:
        decision = by_id[event['query_id']]
        assert decision['mode'] == event['mode']
        response = decision['response']
        rows[event['mode'], event['id'], event['phase']] = dict(
            feature_sha256=digest(features(decision['request'])),
            predicted_dops={r['fragment_id']: r['dop'] for r in response['decisions']},
            applied=bool(event['dop_validation']['applied']))
    protocol = json.loads((BASE/'EVALUATION_PROTOCOL.json').read_text())
    queries = protocol[args.phase+'_query_ids']
    modes = ['stage_'+arm for arm in protocol['checkpoints']]
    assert len(rows) == len(queries)*len(modes)*2
    comparisons = {}
    for mode in modes:
        if mode == 'stage_full':
            continue
        comparison = dict(same_features=0, same_predicted_dops=0, same_application_state=0,
                          both_applied_same_dops=0, both_fallback=0, changed_feature_queries=[])
        for query in queries:
            full, other = rows['stage_full', query, 'measured'], rows[mode, query, 'measured']
            same = full['feature_sha256'] == other['feature_sha256']
            comparison['same_features'] += same
            if not same:
                comparison['changed_feature_queries'].append(query)
            same_dops = full['predicted_dops'] == other['predicted_dops']
            comparison['same_predicted_dops'] += same_dops
            comparison['same_application_state'] += full['applied'] == other['applied']
            comparison['both_applied_same_dops'] += full['applied'] and other['applied'] and same_dops
            comparison['both_fallback'] += not full['applied'] and not other['applied']
        comparisons[mode] = comparison
    variants = {query: len({rows[mode, query, phase]['feature_sha256']
                           for mode in modes for phase in ['warmup', 'measured']}) for query in queries}
    sources = [Path(__file__), audit_path, source/'events.jsonl', source/'decisions.jsonl', BASE/'EVALUATION_PROTOCOL.json']
    result = dict(status='verified_response_feature_action_comparison', queries=len(queries),
                  formal_vs_full=comparisons, feature_variants_across_warmup_and_formal=variants,
                  scope='Canonical request features exclude query ID and worker loads and normalize list ordering. '
                        'Feature equality is not complete physical-plan equality; predicted actions are not actual installation. '
                        'Applied flags come from independently verified execution records. No rows filtered.',
                  source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    with (directory/'MECHANISM_AUDIT.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'source_sha256'}, indent=2))


if __name__ == '__main__':
    main()
