"""Report every mode after bounded plan warmup; no success-only selection."""
import hashlib
import json
from pathlib import Path

RUN=Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def main():
    sources=[Path(__file__)];metrics={};protocols={}
    for arm in ('swrr','fifo'):
        out=RUN/('report90_native_budget_stable_'+arm)
        proof=json.loads((out/'ALLOCATION_AUDIT.json').read_text())
        assert proof['status']=='verified' and proof['executions']==128
        for path,digest in proof['source_sha256'].items():
            assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
        metrics[arm]=proof['metrics']
        protocols[arm]=json.loads((out/'PROTOCOL.json').read_text())
        sources += [out/'ALLOCATION_AUDIT.json',out/'PLAN_STABILITY/RESULT.json',out/'PROTOCOL.json',out/'IDLE_WAIT_POLICY.json']
    assert protocols['swrr']['source_sha256']==protocols['fifo']['source_sha256']
    control_path=RUN/'native_stable_control_audit/RESULT.json';control=json.loads(control_path.read_text());sources.append(control_path)
    reductions={mode:{key:100*(1-metrics['fifo'][mode][key]/base[key]) for key in ('batch_seconds','mean_ms','p50_ms','p90_ms','p99_ms')}
                for mode,base in metrics['swrr'].items()}
    result=dict(status='measured',executions=256,plan_control_status=control['status'],
                fifo_reduction_percent=reductions,metrics=metrics,
                scope='Two frozen queries, 16 clients; three matching Explain plans before measurement, bounded at six per query/DOP. One warmup and one measured batch per mode; SWRR then FIFO, same FE. No randomized replication or significance claim. Captured plan/DOP consistency covers heterogeneous executions, not full native plan equivalence.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    out=RUN/'native_stable_scheduler_comparison';out.mkdir(exist_ok=True)
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 计划稳定性检查后的调度小测','',result['scope'],'',f"实测计划/DOP 一致性检查：{control['status']}。",'',
           '正值表示 FIFO 延迟降低，负值表示增加。','','| 模式 | 整批时间 | 平均 | p50 | p90 | p99 |','|---|---:|---:|---:|---:|---:|']
    for mode,values in reductions.items():lines.append('| '+mode+' | '+' | '.join(f'{v:.2f}%' for v in values.values())+' |')
    if control['status']!='passed':lines+=['','一致性检查未通过，不能单独归因于调度器。全部执行和指标保留。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('metrics','source_sha256')},indent=2))


if __name__=='__main__':main()
