"""Extend original multistage teacher vocabulary from new training graphs with exact score parity."""
import copy
import hashlib
import json
from pathlib import Path
import torch
from report90_execute import ROOT,RUN
from autodop.data import load_dataset
from autodop.graph import sample_from_request,build_graph
from autodop.model import CostModel,load_cost_model,save_checkpoint

BASE=RUN/'complex_development24'
OUT=BASE/'warmstart'
TEACHER=ROOT/'runs/multi_structure_feedback_cost05_20260910/model/cost.pt'


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())


def main():
    OUT.mkdir(exist_ok=False)
    torch.set_num_threads(1)
    manifest=read(BASE/'manifest.json')['queries'];requests=read(BASE/'prepass/REQUESTS.json')
    assert read(BASE/'prepass/AUDITED_RESULT.json')['status']=='complete'
    old,ck=load_cost_model(TEACHER);old.eval();metadata=copy.deepcopy(ck['metadata'])
    train=[sample_from_request(v['request']) for q in manifest if q['split']=='train' for v in requests[q['id']]]
    assert len(train)==16
    added={}
    for feature in metadata['category_features']:
        vocab=metadata['category_vocab'][feature]
        assert set(vocab.values())==set(range(len(vocab)))
        new=sorted({str(f.get(feature,'')) for s in train for f in s['fragments']}-set(vocab))
        added[feature]=new
        for value in new:vocab[value]=len(vocab)
    # Numeric normalization stays exactly as fitted in the incumbent training history.
    # Appended category vectors initially copy UNK, preserving even new-graph predictions.
    promoted=CostModel(metadata,ck['model_config']);state=promoted.state_dict();previous=old.state_dict()
    for key,value in state.items():
        if key.startswith('encoder.category_embeddings.'):
            index=int(key.split('.')[2]);feature=metadata['category_features'][index]
            value[:previous[key].shape[0]].copy_(previous[key])
            if value.shape[0]>previous[key].shape[0]:
                value[previous[key].shape[0]:].copy_(previous[key][ck['metadata']['category_vocab'][feature]['<UNK>']])
        else:
            assert value.shape==previous[key].shape,key
            value.copy_(previous[key])
    promoted.load_state_dict(state);promoted.eval()
    historical=Path(read(RUN/'PROTOCOL.json')['training_dataset'])
    samples,_,_=load_dataset(historical)
    groups={'historical_configurations':samples,'new_train_uniforms':[],'new_valid_uniforms':[]}
    for q in manifest:
        for entry in requests[q['id']]:
            sample=sample_from_request(entry['request'])
            for dop in [1,2,4,8,16]:
                candidate={**sample,'dop_config':[1 if f.get('is_gather_root') else dop for f in sample['fragments']]}
                groups['new_'+q['split']+'_uniforms'].append(candidate)
    parity={}
    with torch.no_grad():
        for label,rows in groups.items():
            maximum=0.
            for sample in rows:
                a=old(build_graph(sample,ck['metadata']));b=promoted(build_graph(sample,metadata))
                difference=abs(float(a)-float(b));maximum=max(maximum,difference)
                assert torch.equal(a,b),(label,difference)
            parity[label]={'configurations':len(rows),'max_absolute_score_difference':maximum}
    training={'stage':'vocabulary_extension_only_no_training','parent':str(TEACHER),'parent_sha256':sha(TEACHER),
              'new_categories_source':'16 new training request graphs only; no new validation values or latency labels used',
              'initialization':'Appended category rows copy previous UNK embedding; original rows and all other weights unchanged',
              'normalization':'Preserve incumbent training-only feature mean/std; no refit or validation statistics',
              'parity':parity}
    save_checkpoint(OUT/'cost.pt','cost',promoted,metadata,training)
    result={'status':'prepared_not_trained','added_categories':added,'parity':parity,
            'parameters_before':sum(p.numel() for p in old.parameters()),'parameters_after':sum(p.numel() for p in promoted.parameters()),
            'model_sha256':sha(OUT/'cost.pt'),'training':training,
            'source_sha256':{str(p):sha(p) for p in [Path(__file__),TEACHER,BASE/'manifest.json',BASE/'prepass/REQUESTS.json',historical/'samples.jsonl']}}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    (OUT/'METADATA.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['source_sha256','training','added_categories']},indent=2))


if __name__=='__main__':main()
