"""Run the frozen all-eight-query development pilot, without automatic expansion."""
import collections
import json
import os
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
from autodop.training import file_sha256
from report90_execute import ROOT, check
from report90_coverage_choices import BASE, COM, OUT, read
from report90_cpu_observe import workers


def save(name, data):
    path = OUT / name
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n')
    tmp.replace(path)


def main():
    assert not (OUT / 'STATUS.json').exists(), 'Preserve previous execution'
    protocol = read(OUT / 'PROTOCOL.json')
    assert read(BASE / 'retrained/SCORE_REPLAY.json')['development_gate_passed']
    for path, expected in protocol['source_sha256'].items():
        assert file_sha256(path) == expected, path
    save('STATUS.json', {'status': 'running', 'stage': 'preflight', 'pid': os.getpid()})
    os.sched_setaffinity(0, set(range(27, 35)))
    nodes = workers()
    assert all(n['image_id'] == 'sha256:73548ebadb50d11fec58e9937ebd5ee189205fd8f1acf8359fc63923132c476b' for n in nodes)
    save('DEPLOYMENT.json', nodes)
    for attempt in range(20):
        try:
            check(OUT / f'IDLE_{attempt}.json')
            break
        except RuntimeError:
            if attempt == 19:
                raise
            time.sleep(15)
    sources = [Path(__file__), ROOT / 'collect_paper_evaluations.py', ROOT / 'scripts/verify_paper_evaluations.py',
               OUT / 'PROTOCOL.json', OUT / 'vectors.json', OUT / 'manifest.json']
    save('EXECUTION_SOURCE_SHA256.json', {str(p): file_sha256(p) for p in sources})
    command = [sys.executable, str(ROOT / 'collect_paper_evaluations.py'),
               '--manifest', str(OUT / 'manifest.json'), '--trusted-collection', str(COM / 'TRUSTED_NATIVE.json'),
               '--output-dir', str(OUT / 'scored'), '--modes', ','.join(protocol['modes']),
               '--scenario', 'serial', '--query-timeout-s', '180', '--auto-dop-max-dop', '16',
               '--torch-threads', '1', '--decision-timeout-ms', '1000', '--warmup', '1', '--repetitions', '1',
               '--seed', str(protocol['seed']), '--decision-vectors', str(OUT / 'vectors.json')]
    save('COMMAND.json', command)
    save('STATUS.json', {'status': 'running', 'stage': 'executing', 'pid': os.getpid()})
    subprocess.run(command, check=True)
    proof_path = OUT / 'scored/independent_verification.json'
    subprocess.run([sys.executable, str(ROOT / 'scripts/verify_paper_evaluations.py'), '--collection-dir',
                    str(OUT / 'scored'), '--output', str(proof_path)], check=True)
    proof = read(proof_path)
    assert proof['all_expected_executions_verified'] and proof['expected_slots'] == 80
    assert read(OUT / 'scored/frontend_settings.json')['restored']
    measured = collections.defaultdict(dict)
    for line in (OUT / 'scored/events.jsonl').open():
        event = json.loads(line)
        if event['phase'] != 'measured':
            continue
        assert event['status'] == 'verified' and event['id'] not in measured[event['mode']]
        measured[event['mode']][event['id']] = event['client_latency_ms']
    assert set(measured) == set(protocol['modes']) and all(len(v) == 8 for v in measured.values())
    stats = {mode: {'mean_ms': float(np.mean(list(v.values()))),
                    **{f'p{p}_ms': float(np.percentile(list(v.values()), p)) for p in (50, 90, 99)}}
             for mode, v in measured.items()}
    t = stats['coverage_transformer']['mean_ms']
    passed = all(t <= stats[m]['mean_ms'] for m in ('coverage_xgboost_points', 'coverage_xgboost_pairs'))
    save('RESULT.json', {'status': 'complete', 'verified_executions': 80, 'statistics': stats,
                         'per_query_client_latency_ms': measured, 'execution_gate_passed': passed,
                         'scope': protocol['scope'], 'verification_sha256': file_sha256(proof_path)})
    lines = ['# 八条开发验证查询执行小测', '', protocol['scope'], '',
             '三个模型使用相同八配置候选池，选定配置在执行前冻结。统计包含客户端执行及取数时间，不包含离线模型评分/搜索。每条每模式一次预热、一次测量，仅作开发门槛，尾部分位数不代表稳定统计结论。', '',
             '| 模式 | 平均 ms | p50 ms | p90 ms | p99 ms |', '|---|---:|---:|---:|---:|']
    for mode, s in stats.items():
        lines.append(f"| {mode} | {s['mean_ms']:.2f} | {s['p50_ms']:.2f} | {s['p90_ms']:.2f} | {s['p99_ms']:.2f} |")
    lines += ['', f"全部80次执行独立核验通过。扩大实验的执行门槛：{'通过' if passed else '未通过'}。本脚本不自动扩大实验或部署模型。"]
    (OUT / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    save('STATUS.json', {'status': 'complete', 'execution_gate_passed': passed})


if __name__ == '__main__':
    if (OUT / 'STATUS.json').exists():
        raise SystemExit('Preserve previous execution')
    try:
        main()
    except BaseException as error:
        if OUT.exists():
            save('STATUS.json', {'status': 'failed', 'error': repr(error), 'pid': os.getpid()})
        raise
