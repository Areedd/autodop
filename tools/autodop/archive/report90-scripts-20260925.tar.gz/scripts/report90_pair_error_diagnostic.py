"""Describe paired errors on an already audited development pool; never select data."""
import argparse
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[1] / 'runs/report90_20260912/structure_coverage20'


def main(seed):
    folder = BASE / f'interaction_pair_audit_seed{seed}'
    result = json.loads((folder / 'RESULT.json').read_text())
    assert result['status'] == 'verified_independent_pair_replay'
    for path, expected in result['source_sha256'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected, path
    pool = json.loads((folder / 'PAIR_POOL.json').read_text())
    samples = pool['samples']
    names = {s['plan_key']: s['template_id'] for s in map(json.loads, (BASE / 'merged_dataset/samples.jsonl').open())}
    models = result['models']
    groups = {}
    for pair in pool['pairs']:
        i, j = pair['fast_index'], pair['slow_index']
        gap = samples[j]['latency_ms'] / samples[i]['latency_ms'] - 1
        band = '03_to_10pct' if gap < .1 else '10_to_25pct' if gap < .25 else '25pct_plus'
        correct = {name: item['scores'][i] > item['scores'][j] for name, item in models.items()}
        for key in [pair['cohort'], pair['cohort'] + '/' + band, 'plan/' + names[pair['plan_key']]]:
            group = groups.setdefault(key, {'pairs': 0, 'correct': {m: 0 for m in models},
                                           'transformer_vs_xgb_pairs': {'both_correct': 0, 'only_transformer': 0, 'only_xgb': 0, 'both_wrong': 0}})
            group['pairs'] += 1
            for name, value in correct.items():
                group['correct'][name] += int(value)
            a, b = correct['transformer'], correct['xgboost_pairs']
            category = 'both_correct' if a and b else 'only_transformer' if a else 'only_xgb' if b else 'both_wrong'
            group['transformer_vs_xgb_pairs'][category] += 1
    for group in groups.values():
        group['accuracy'] = {m: n / group['pairs'] for m, n in group['correct'].items()}
    output = {'status': 'verified_saved_score_diagnostic', 'seed': seed, 'groups': groups,
              'scope': 'All existing development pairs retained. Descriptive error localization, not independent test evidence or checkpoint selection. Pairs sharing queries are dependent.',
              'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in
                                [Path(__file__), folder / 'RESULT.json', folder / 'PAIR_POOL.json', BASE / 'merged_dataset/samples.jsonl']}}
    target = BASE / f'interaction_error_diagnostic_seed{seed}.json'
    assert not target.exists()
    target.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({k: v for k, v in groups.items() if not k.startswith('plan/')}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, choices=[17, 29, 43], required=True)
    main(parser.parse_args().seed)
