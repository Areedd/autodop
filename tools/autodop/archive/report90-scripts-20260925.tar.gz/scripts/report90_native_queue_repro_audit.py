"""Independent statement/slot/settings audit of the eight-query minimal reproduction."""
import hashlib,json,re
from pathlib import Path
from report90_execute import ROOT,RUN
out=RUN/'native_queue_repro8';read=lambda p:json.loads(p.read_text())
rows=read(out/'ROWS.json');assert len(rows)==8
assert all(r['before']==r['after']==[1,1,1] for r in rows)
trusted={q['id']:q for q in read(RUN/'DEVELOPMENT17_TRUSTED.json')['queries']}
wanted={r['query_id']:r for r in rows};assert len(wanted)==8
history={r['query_id']:r for r in read(out/'HISTORY_1.json')};assert wanted.keys()<=history.keys()
normalize=lambda s:' '.join(s.split()).rstrip(';').rstrip();matches={}
for line in (ROOT.parents[1]/'output/fe/log/fe.audit.log').open():
 if ' [query] ' not in line:continue
 m=re.search(r'\|QueryId=([0-9a-f-]+)\|',line)
 if not m or m[1] not in wanted:continue
 qid=m[1];assert qid not in matches;r=wanted[qid]
 assert '|State=EOF|' in line and '|ErrorCode=|' in line
 assert normalize(line.split('|Stmt=',1)[1].split('|Digest=',1)[0])==normalize(r['sql'])
 assert r['result_digest']==trusted[r['id']]['native_result_digest']
 n=re.search(r'\|Slots=(\d+)\|',line);assert n and int(n[1])>0
 slot=history[qid];assert slot['state']=='RELEASED' and int(slot['allocate_slots'])==int(slot['est_costs_slots'])==int(n[1])
 matches[qid]=dict(batch=r['batch'],client=r['client'],audit_line=line.rstrip('\n'),history=slot)
assert matches.keys()==wanted.keys()
for p in [out/'frontend_settings.json',out/'QUEUE_SETTINGS.json',RUN/'native_queue_repro_restart/RESTORATION.json']:assert read(p)['restored']
result=dict(status='verified',queries=8,matches=matches,scope='Two batches with four clients, same native DOP0, predictor and AutoDOP disabled. Both batches remain queued; this rules out a universal batch/last_query_id-only explanation, but not higher concurrency, prediction or policy integration.',source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),out/'ROWS.json',out/'HISTORY_1.json',out/'PROTOCOL.json',RUN/'native_queue_repro_restart/RESTORATION.json']})
(out/'AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');(out/'STATUS.json').write_text(json.dumps(dict(status='verified',queries=8))+'\n')
(out/'REPORT.md').write_text('# 原生准入连续批次最小复现\n\n两条开发查询，4客户端，连续2批，共8条数据查询。AutoDOP和成本预测均关闭，使用原生V2/MBE及现有成本回退。\n\n8条结果摘要和唯一SQL审计身份一致；两批队列全局/会话开关始终为1，每条均有Slots=96及全局RELEASED槽位记录。FE配置和运行时设置已恢复。\n\n该最小复现没有重现128条小测中后续批次绕过准入的问题；不能据此把原失败小测改判通过，也不能排除16客户端、预测服务或策略集成的影响。下一步在原采集流程中观测JobSpec判定条件。\n')
print('Eight statements, slot allocations/releases and restoration verified')
