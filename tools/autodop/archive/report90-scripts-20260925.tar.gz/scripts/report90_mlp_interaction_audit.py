"""Independent pair recount and input-mask audit for the paired MLP pilot."""
import json
import os
from pathlib import Path
import numpy as np
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.training import select_partition
from report90_models import MLP,flat_features
from report90_interaction_pair_audit import BASE,sha,make_pairs,accuracy


def main():
    torch.set_num_threads(1);os.sched_setaffinity(0,{35})
    out=BASE/'mlp_interaction_pilot'
    summary=json.loads((out/'RESULT.json').read_text())
    assert summary['status']=='completed_reload_verified_pending_independent_audit'
    for path,digest in summary['source_sha256'].items():assert sha(path)==digest
    samples,pairs,meta=load_dataset(BASE/'merged_dataset')
    contract=json.loads((BASE/'retrained/CONTRACT.json').read_text())
    valid,_=select_partition(samples,pairs,contract,'valid')
    valid=sorted(valid,key=lambda s:(s['plan_key'],s['config_key']))
    pool=make_pairs(valid);assert len(pool)==920 and len(valid)==212
    norm=np.load(BASE/'retrained/FEATURE_NORMALIZATION.npz')
    full=torch.tensor(np.stack([(flat_features(build_graph(s,meta),meta)-norm['mean'])/norm['std'] for s in valid]),dtype=torch.float32)
    mask=json.loads((out/'pilot_no_explicit_interaction/MASK.json').read_text())['zeroed_normalized_columns']
    assert len(mask)==len(set(mask))==532
    n=len(meta['numeric_features']);c=sum(len(meta['category_vocab'][k]) for k in meta['category_features']);w=2*n+2*c+5
    assert mask==[p*w+j for p in range(4) for j in range(n+c+1,2*n+2*c+1)]
    masked=full.clone();masked[:,mask]=0
    keep=[j for j in range(1088) if j not in set(mask)]
    assert torch.equal(masked[:,keep],full[:,keep]) and torch.count_nonzero(masked[:,mask])==0
    records={};sources=[Path(__file__),out/'RESULT.json',out/'PROTOCOL.json',out/'pilot_no_explicit_interaction/MASK.json',BASE/'retrained/FEATURE_NORMALIZATION.npz']
    for arm,features in [('full',full),('no_explicit_interaction',masked)]:
        folder=out/f'pilot_{arm}';r=json.loads((folder/'RESULT.json').read_text());sources.append(folder/'RESULT.json')
        for path,digest in r['source_sha256'].items():assert sha(path)==digest
        for kind,entry in r['selected'].items():
            path=Path(entry['model']);assert sha(path)==entry['model_sha256'];sources.append(path)
            ck=torch.load(path,map_location='cpu',weights_only=False);assert ck['width']==1088
            model=MLP(1088);model.load_state_dict(ck['state']);model.eval()
            with torch.no_grad():scores=model(features).numpy().astype(float)
            if kind=='mlp_regression':scores=-scores
            q=accuracy(pool,scores)
            assert q['macro_accuracy']==entry['selected']['validation']['weighted_rank_accuracy']
            records.setdefault(kind,{})[arm]=dict(**q,parameters=sum(p.numel() for p in model.parameters()),scores=scores.tolist(),selected_epoch=entry['selected']['epoch'],setting=entry['setting'])
    result=dict(status='verified_independent_pair_replay',models=records,validation_pairs=920,
                intervention='532 normalized interaction columns zero; all556other columns exactly retained; identical parameter dimensions.',
                source_sha256={str(p):sha(p) for p in sources})
    (out/'PAIR_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# MLP显式DOP交互项对照','',
           'seed17，两组均1088输入、64/64隐藏层，使用相同初始化规则、训练数据、采样和30轮预算。无交互组仅将归一化后的532个乘积项置零，556个其他特征保持不变。', '',
           '| 模型 | 完整特征准确率 | 无交互项准确率 | 完整减无交互（百分点） |','|---|---:|---:|---:|']
    for kind,r in records.items():
        a,b=r['full']['macro_accuracy'],r['no_explicit_interaction']['macro_accuracy']
        lines.append(f'| {kind} | {100*a:.4f}% | {100*b:.4f}% | {100*(a-b):+.4f} |')
    lines += ['', '各组学习率3e-4/1e-3，按两类查询等权排序准确率选择检查点；920有效对已独立重算。输入屏蔽保留图统计，其中仍可能包含DOP相关信息。', '',
              '两组先通过2轮冒烟检查，再各训练30轮。这是单种子小测；不能与此前100轮MLP结果混为同一训练预算，也不据此替换更强的已有对照。', '',
              '证据：[独立核验](PAIR_AUDIT.json)、[协议](PROTOCOL.json)、[训练结果](RESULT.json)。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:{a:r['macro_accuracy'] for a,r in v.items()} for k,v in records.items()},indent=2))


if __name__=='__main__':main()
