"""Prepare an isolated augmented dataset; preserve batch-local ranking supervision."""
import collections
import json
from pathlib import Path

from autodop.data import _hash, load_dataset, write_jsonl
from autodop.training import make_training_contract, select_partition
from report90_neighborhood_prepare import OUT as BASE, RUN, sha


def raw_plan(s):
    return _hash({'fragments': [{k: v for k, v in f.items() if k != 'worker_ids'} for f in s['fragments']], 'edges': s['edges']})


def main():
    source = RUN / 'structure_coverage20/merged_dataset'
    labels = BASE / 'verified_labels'
    proof = json.loads((labels / 'RESULT.json').read_text())
    assert proof['status'] == 'verified' and proof['formal_observations'] == 96
    for path, digest in proof['source_sha256'].items():
        assert sha(Path(path)) == digest
    old, old_pairs, metadata = load_dataset(source)
    new = [json.loads(line) for line in (labels / 'samples.jsonl').open()]
    diagnostics = [json.loads(line) for line in (labels / 'pair_diagnostics.jsonl').open()]
    assert len(old) == 1577 and len(new) == 32 and len(diagnostics) == 40
    validation = [s for s in old if s['split'] == 'valid']
    forbidden = {s['sql_sha256'] for s in validation}
    forbidden |= {q['sql_sha256'] for q in json.loads((RUN / 'manifest.json').read_text())['queries']}
    assert not forbidden & {s['sql_sha256'] for s in new}
    valid_raw = {raw_plan(s) for s in validation}
    assert not valid_raw & {raw_plan(s) for s in new}
    old_train = {s['plan_key'] for s in old if s['split'] == 'train'}
    assert {s['plan_key'] for s in new} <= old_train
    remap = {s['plan_key']: _hash({'parent_plan': s['plan_key'], 'measurement_batch': 'training_neighborhood_pilot_three_formal'}) for s in new}
    additions = [{**s, 'original_plan_key': s['plan_key'], 'plan_key': remap[s['plan_key']],
                  'measurement_batch': 'training_neighborhood_pilot_three_formal'} for s in new]
    pairs = list(old_pairs)
    for p in diagnostics:
        pairs.append({'plan_key': remap[p['plan_key']], 'fast_config_key': p['fast_config_key'], 'slow_config_key': p['slow_config_key'],
                      'fast_latency_ms': p['fast_latency_ms'], 'slow_latency_ms': p['slow_latency_ms'],
                      'same_sign_all3': p['same_sign_all3'], 'nonoverlapping_ranges': p['nonoverlapping_ranges']})
    samples = old + additions
    lookup = {(s['plan_key'], s['config_key']): s for s in samples}
    assert len(lookup) == 1609
    for p in pairs[len(old_pairs):]:
        a, b = lookup[(p['plan_key'], p['fast_config_key'])], lookup[(p['plan_key'], p['slow_config_key'])]
        assert a['split'] == b['split'] == 'train'
        assert a['latency_ms'] == p['fast_latency_ms'] < p['slow_latency_ms'] == b['latency_ms']
    out = BASE / 'augmented_dataset'
    assert not out.exists()
    out.mkdir()
    write_jsonl(out / 'samples.jsonl', samples)
    write_jsonl(out / 'pairs.jsonl', pairs)
    (out / 'metadata.json').write_text((source / 'metadata.json').read_text())
    splits = {split: sorted({s['plan_key'] for s in samples if s['split'] == split}) for split in ['train', 'valid', 'test']}
    (out / 'model_split.json').write_text(json.dumps(splits, indent=2) + '\n')
    contract = make_training_contract(samples, pairs, .2, 2026091403, out / 'model_split.json')
    train, tp = select_partition(samples, pairs, contract, 'train')
    valid, vp = select_partition(samples, pairs, contract, 'valid')
    assert len(train) == 1397 and len(valid) == 212
    assert sorted(valid, key=lambda s: (s['plan_key'], s['config_key'])) == sorted(validation, key=lambda s: (s['plan_key'], s['config_key']))
    assert len(splits['train']) == 118 and len(splits['valid']) == 22
    assert len({s.get('original_plan_key', s['plan_key']) for s in train}) == 114
    (out / 'CONTRACT.json').write_text(json.dumps(contract, indent=2) + '\n')
    result = {'status': 'verified_prepared_not_trained', 'train_samples': len(train), 'valid_samples': len(valid),
              'train_ranking_groups': 118, 'distinct_original_train_plans': 114, 'new_configs_including_remeasured_anchors': 32,
              'added_batch_local_pairs': 40, 'validation_unchanged': True, 'report90_overlap': 0,
              'cohorts': dict(collections.Counter(s['source_cohort'] + '/' + s['split'] for s in samples)),
              'scope': 'Immutable candidate augmentation only; active data unchanged. Four extra batch groups are not new query plans. No pairs cross old/new measurement batches. All40 median-gap pairs retained, with reliability annotations but no weighting/filtering applied. Original feature metadata frozen to isolate label augmentation; no validation-fitted transform.',
              'source_sha256': {str(p): sha(p) for p in [Path(__file__), source / 'samples.jsonl', source / 'pairs.jsonl', source / 'metadata.json', labels / 'RESULT.json', labels / 'samples.jsonl', labels / 'pair_diagnostics.jsonl']}}
    (out / 'ASSEMBLY_AUDIT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
