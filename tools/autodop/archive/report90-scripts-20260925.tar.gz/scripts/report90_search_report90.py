"""Stage unchanged search/execution logic for the frozen 90-query report set."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT/'runs/report90_20260912'
OUT = RUN/'search_refinement_report90'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n')


def stage_source(kind):
    original = ROOT/f'scripts/report90_search_refinement_{kind}.py'
    source = original.read_text()
    changes = {}
    replacements = {
        'ROOT = Path(__file__).resolve().parents[1]': 'ROOT = Path('+repr(str(ROOT))+')',
        "RUN/'search_refinement_development'": "RUN/'search_refinement_report90'",
        "COM = RUN/'complex_development24'": 'COM = RUN',
        "COM/'TRUSTED_NATIVE.json'": "ROOT/'runs/preference_random200_20260911/random200/trusted_merged.json'",
    } if kind=='prepare' else {
        'ROOT = Path(__file__).resolve().parents[1]': 'ROOT = Path('+repr(str(ROOT))+')',
        "RUN/'search_refinement_development'": "RUN/'search_refinement_report90'",
        "OUT = BASE/'pilot'": "OUT = BASE/'full'",
        "RUN/'complex_development24/TRUSTED_NATIVE.json'": "ROOT/'runs/preference_random200_20260911/random200/trusted_merged.json'",
        'expected=64': 'expected=1440',
        '== 64': '== 1440',
        'executions=64': 'executions=1440',
        'Four reused development queries, one measured execution per mode/query.':
            'Frozen90 historical favorable queries, one measured execution per mode/query. Not an unbiased generalization set.',
        '# 搜索改进开发小测': '# 90条报告查询的搜索对照',
        '四条': '90条',
    }
    if kind=='prepare':
        replacements.update({
            "assert len(queries) == 4 and all(q['split'] == 'valid' for q in queries.values())":
                "assert len(queries) == 90 and set(queries) == set(protocol['queries'])",
            "Path(__file__).with_name('report90_search_refinement.py')":
                "ROOT/'scripts/report90_search_refinement.py'",
        })
        start=source.index("    evidence_path = COM/'verified_labels/sample_evidence.jsonl'")
        end=source.index('    assert set(requests) == set(queries)',start)
        old=source[start:end]
        replacements[old] = '''    evidence_path = RUN/'policy_final_stage_ablation/online_full/scored/events.jsonl'
    trace_path = RUN/'policy_final_stage_ablation/online_full/scored/decisions.jsonl'
    wanted = {}
    for line in evidence_path.open():
        event = json.loads(line)
        if event['phase']=='measured' and event['mode']=='stage_full':
            assert event['status']=='verified'
            wanted[event['query_id']] = event['id']
    assert len(wanted)==90
    requests = {}
    for line in trace_path.open():
        decision = json.loads(line)
        if decision['query_id'] in wanted:
            assert decision['mode']=='stage_full'
            q = wanted[decision['query_id']]
            assert q not in requests
            requests[q] = decision['request']
'''
        replacements["save(OUT/'CHOICES.json', rows)\n        save(OUT/'PREPARATION_STATUS.json'"] = \
            "pass  # Save all mode records together after each query.\n        save(OUT/'CHOICES.json', rows)\n        save(OUT/'PREPARATION_STATUS.json'"
        replacements["json.dumps(value, indent=2)"] = "json.dumps(value,separators=(',',':'))"
        replacements['Development proposals only; no execution-latency selection or SQL performance claim.'] = \
            'Frozen report90 proposals only; request extraction does not use observed latency to select configurations.'
    for old,new in replacements.items():
        count=source.count(old)
        if old=='四条' and count==0:continue
        expected = 2 if old in ['expected=64','== 64'] else 1
        assert count==expected,(old,count,expected)
        source=source.replace(old,new)
        changes[old]=dict(replacement=new,occurrences=count)
    destination=OUT/(kind+'_staged.py')
    compile(source,str(destination),'exec')
    destination.write_text(source)
    save(kind+'_SOURCE_TRANSFORM.json',dict(original=str(original),original_sha256=sha(original),
         staged_sha256=sha(destination),literal_changes=changes))
    return destination


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['prepare','execute'],required=True)
    args=parser.parse_args()
    if args.stage=='prepare':
        assert not OUT.exists(), 'Preserve previous staging'
        development=json.loads((RUN/'search_refinement_summary/RESULT.json').read_text())
        assert development['status']=='verified_disjoint_development_summary'
        assert all(v['mean_ms']>0 for v in development['comparisons'].values())
        assert json.loads((RUN/'policy_final_stage_ablation/online_full/STATUS.json').read_text())['status']=='verified'
        protocol=json.loads((RUN/'search_refinement_development/PROTOCOL.json').read_text())
        manifest=json.loads((RUN/'manifest.json').read_text())
        protocol.update(status='frozen_before_report90_search',frozen_at=datetime.datetime.now().astimezone().isoformat(),
            queries=[q['id'] for q in manifest['queries']],seeds=[17],
            selection='All frozen90 SQL; no further query filtering. Primary seed17 unchanged. Development recorded three seeds; report90 generates and executes seed17 only.',
            rationale='Eight-query development mean favors full variant against all controls; mixed per-query and tail outcomes motivate full verification, not a claim of robust superiority.',
            expected_executions=1440)
        OUT.mkdir()
        protocol['source_sha256'].update({str(p):sha(p) for p in [Path(__file__),RUN/'manifest.json',
            RUN/'search_refinement_summary/RESULT.json',RUN/'policy_final_stage_ablation/online_full/STATUS.json']})
        save('PROTOCOL.json',protocol)
        script=stage_source('prepare')
    else:
        for path,expected in json.loads((OUT/'PROTOCOL.json').read_text())['source_sha256'].items():
            assert sha(path)==expected
        script=stage_source('execute')
    subprocess.run([sys.executable,str(script)],check=True)


if __name__=='__main__':main()
