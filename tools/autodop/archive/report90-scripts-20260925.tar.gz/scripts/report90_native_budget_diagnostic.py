"""Preserve partial native pilot evidence without accepting a failed admission gate."""
from collections import Counter,defaultdict
import csv,io,json,re,hashlib
from pathlib import Path
from report90_execute import ROOT,RUN
from report90_native_predictor import NativePredictor
out=RUN/'native_budget_pilot';read=lambda p:json.loads(p.read_text())
events=[json.loads(l) for l in (out/'scored/events.jsonl').read_text().splitlines()]
assert len(events)==128 and all(e['status']=='verified' for e in events)
assert read(out/'scored/independent_verification.json')['all_expected_executions_verified']
byid={e['query_id']:e for e in events};matches={};helpers=[]
for line in (ROOT.parents[1]/'output/fe/log/fe.audit.log').open():
 if ' [query] ' not in line:continue
 m=re.search(r'\|QueryId=([0-9a-f-]+)\|',line)
 if not m:continue
 if m[1] in byid:
  assert m[1] not in matches;matches[m[1]]=line.rstrip('\n')
 if '|Stmt=SELECT /*+ SET_VAR(enable_auto_dop=false) */ last_query_id()|' in line:helpers.append(line.rstrip('\n'))
assert matches.keys()==byid.keys()
client=lambda l:re.search(r'\|Client=([^|]+)\|',l)[1]
clients={client(l):qid for qid,l in matches.items()};assert len(clients)==128
timestamp=lambda l:int(re.search(r'\|Timestamp=(\d+)\|',l)[1])
helper_matches=[l for l in helpers if client(l) in clients and 0<=timestamp(l)-timestamp(matches[clients[client(l)]])<=300000];assert len(helper_matches)==128,len(helper_matches)
assert all(n==1 for n in Counter(client(l) for l in helper_matches).values())
slots={h['query_id']:h for h in read(out/'SLOT_HISTORY.json')['rows']}
counts=defaultdict(lambda:dict(executions=0,fe_slots_present=0,history_present=0));rows=[]
normalize=lambda s:' '.join(s.split()).rstrip(';').rstrip()
manifest={q['id']:q for q in read(RUN/'native_budget_pilot_support/manifest.json')['queries']}
for qid,e in byid.items():
 line=matches[qid];assert '|State=EOF|' in line and '|ErrorCode=|' in line
 assert normalize(line.split('|Stmt=',1)[1].split('|Digest=',1)[0])==normalize(Path(manifest[e['id']]['sql_file']).read_text())
 n=re.search(r'\|Slots=(\d+)\|',line);key=e['phase']+'/'+e['mode'];counts[key]['executions']+=1
 counts[key]['fe_slots_present']+=bool(n);counts[key]['history_present']+=qid in slots
 if n:assert qid in slots and slots[qid]['state']=='RELEASED' and int(slots[qid]['allocate_slots'])==int(n[1])
 rows.append(dict(query_id=qid,id=e['id'],mode=e['mode'],phase=e['phase'],audit_line=line,slot_history=slots.get(qid)))
calls=read(out/'PREDICTOR_REQUESTS.json');assert not calls['errors'];model=NativePredictor.load(RUN/'native_predictor_service17/MODEL.json')
mode_map={'bootstrap':'fixed8','native':'fixed8','policy_static':'fixed8','native_budget':'predicted','policy_budget':'predicted'}
for p in calls['records']:assert model.predict_csv(p['csv'],mode_map[p['mode']])==p['prediction']
zero_table=sum(list(csv.reader(io.StringIO(p['csv'])))[1][:3]==['0','0','0'] for p in calls['records'])
assert zero_table==128 and len(calls['records'])==257
restore=read(RUN/'native_budget_restart/RESTORATION.json');assert restore['restored']
result=dict(status='diagnostic_not_accepted',sql_verified=128,callbacks=257,zero_table_callbacks=128,helper_statements_verified=128,
            allocation_coverage=dict(counts),rows=rows,helper_audit_lines=helper_matches,restored=True,
            conclusion='Only first warmup batch has FE Slots and global released records. All formal batches lack admission evidence; cannot claim native budget comparison. Source of bypass remains under investigation. Original strict verifier and failure retained.',
            source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),out/'scored/independent_verification.json',out/'PREDICTOR_REQUESTS.json',out/'SLOT_HISTORY.json',out/'scored/events.jsonl']})
(out/'DIAGNOSTIC.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# 原生准入小测诊断：未通过准入核验','','128次SQL执行均成功，结果及适用时DOP核验通过；但不能作为固定预算与预测预算的有效性能对照。','','| 批次 | 成功SQL | FE槽位字段 | 全局槽位历史 |','|---|---:|---:|---:|']
for k,v in counts.items():lines.append(f"| {k} | {v['executions']} | {v['fe_slots_present']} | {v['history_present']} |")
lines+=['','仅第一组预热16条有实际分配/释放证据。正式64条均缺少Slots字段及全局历史，不能把其耗时解释为预算机制效果，也不能用来支持原生调度闭环的并发验收。', '', '共257次预测请求：1初始化、128数据查询及128零表特征请求。独立FE审计确认每条数据查询连接随后各有1次last_query_id辅助语句。全部响应可从原始CSV和冻结模型重新计算一致；单次回调数量假设错误与准入证据缺失分开记录。', '', '无数据扫描的小诊断未发现last_query_id的SET_VAR提示改变队列全局或会话开关。尚未定位后续批次绕过准入的根因；下一步先做带逐批开关、实际Slots断言的最小复现，不扩大查询集。', '', '原FE及运行时配置已恢复，原始性能数字、失败状态和严格审计器均保留。']
(out/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps(dict(status=result['status'],allocation_coverage=dict(counts))))
