"""Retrospective query-level admission audit; never infer continuous settings from setup alone."""
import json,re,os,hashlib
from pathlib import Path
from collections import defaultdict
from report90_execute import RUN,ROOT
os.sched_setaffinity(0,{35});out=RUN/'historical_admission_audit';out.mkdir(exist_ok=False)
paths=sorted((RUN/'queue_cpu_corrected_20260913').glob('*/scored/events.jsonl'))+sorted((RUN/'queue_extension_20260913').glob('*/scored/events.jsonl'))
byid={};sources={}
for path in paths:
 sources[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
 for line in path.open():
  e=json.loads(line)
  if e.get('status')!='verified' or not e.get('query_id'):continue
  qid=e['query_id'];assert qid not in byid
  byid[qid]=dict(query_id=qid,stage=str(path.parent.parent.relative_to(RUN)),mode=e['mode'],phase=e['phase'])
matched={};audit=ROOT.parents[1]/'output/fe/log/fe.audit.log'
for line in audit.open():
 if ' [query] ' not in line:continue
 m=re.search(r'\|QueryId=([0-9a-f-]+)\|',line)
 if not m or m[1] not in byid:continue
 qid=m[1];assert qid not in matched;pending=re.search(r'\|PendingTimeMs=(\d+)\|',line)
 matched[qid]=dict(**byid[qid],pending_ms=int(pending[1]) if pending else None,audit_line=line.rstrip('\n'))
summary=defaultdict(lambda:dict(expected=0,audit_found=0,pending_field_present=0,positive_wait=0))
for qid,e in byid.items():
 s=summary[e['stage']+'/'+e['phase']+'/'+e['mode']];s['expected']+=1
 if qid in matched:
  s['audit_found']+=1;ms=matched[qid]['pending_ms'];s['pending_field_present']+=ms is not None;s['positive_wait']+=ms is not None and ms>0
result=dict(status='audited',scope='Current FE audit log only; missing rows remain missing, no implied failure or fallback. PendingTimeMs indicates the global queue path was entered; it does not prove cap8 remained unchanged throughout a batch.',summaries=dict(summary),rows=list(matched.values()),source_sha256=sources)
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# 历史并发实验的逐查询准入证据复核','','| 阶段/批次/模式 | 预期 | 找到审计 | 有PendingTimeMs | 正等待 |','|---|---:|---:|---:|---:|']
for k,s in summary.items():lines.append(f"| {k} | {s['expected']} | {s['audit_found']} | {s['pending_field_present']} | {s['positive_wait']} |")
lines+=['',result['scope'],'','本复核不修改历史执行结果。发现缺少准入字段的批次，不再仅凭SET GLOBAL或某次队列指标，声称整批都在同一准入限制下运行。']
(out/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps(dict(queries=len(byid),found=len(matched),pending=sum(r['pending_ms'] is not None for r in matched.values()))))
