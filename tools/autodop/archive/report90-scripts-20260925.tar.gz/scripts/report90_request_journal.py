"""Append-only callback evidence; final JSON remains compatible with existing audits."""
import json
from pathlib import Path
import threading


class RequestJournal:
    def __init__(self, path):
        self.path = Path(path)
        # Never append a new experiment onto an existing experiment's evidence.
        self._stream = self.path.open('x', encoding='utf-8')
        self._lock = threading.Lock()
        self._sequence = 0

    def append(self, kind, value):
        if kind not in ('record', 'error'):
            raise ValueError(kind)
        with self._lock:
            event = dict(sequence=self._sequence, kind=kind, value=value)
            line = json.dumps(event, separators=(',', ':'), allow_nan=False) + '\n'
            self._stream.write(line)
            self._stream.flush()
            self._sequence += 1

    def close(self):
        with self._lock:
            self._stream.close()

    def export(self, destination):
        # Call only after request handlers have stopped. A truncated record is an
        # audit failure, never silently discarded as a successful callback.
        records, errors = [], []
        with self.path.open(encoding='utf-8') as source:
            for sequence, line in enumerate(source):
                if not line.endswith('\n'):
                    raise ValueError('Truncated callback journal')
                event = json.loads(line)
                if event['sequence'] != sequence:
                    raise ValueError('Noncontiguous callback journal')
                if event['kind'] == 'record':
                    records.append(event['value'])
                elif event['kind'] == 'error':
                    errors.append(event['value'])
                else:
                    raise ValueError('Unknown callback event')
        result = dict(records=records, errors=errors)
        Path(destination).write_text(json.dumps(result, indent=2) + '\n')
        return result
