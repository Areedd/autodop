"""Matched 2x2 measurement of graph construction and candidate scoring costs."""
import collections
import json
import os
from pathlib import Path
import statistics
import time
import types
import torch
from autodop import graph
from autodop.data import load_dataset
from autodop.model import load_cost_model
from report90_batched_cost import score_batch
from report90_neighborhood_prepare import RUN,sha
BASE=RUN/'structure_coverage20';OUT=RUN/'candidate_pipeline_cost'


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1);assert not OUT.exists()
    pilot_path=RUN/'batched_cost_pilot/RESULT.json';pilot=json.loads(pilot_path.read_text());assert pilot['status']=='verified_batch_inference_pilot'
    verified_path=RUN/'batched_cost_verification/RESULT.json';verified=json.loads(verified_path.read_text());assert verified['status']=='verified_batched_numerical_parity' and verified['known_top_choice_unchanged']
    proof_path=RUN/'graph_construction_verification/PROTOCOL.json';proof=json.loads(proof_path.read_text())
    for p,d in proof['source_sha256'].items():assert sha(Path(p))==d
    assert json.loads((RUN/'graph_construction_verification/RESULT.json').read_text())['status']=='verified'
    staged=RUN/'graph_construction_pilot/competition_staged.py';namespace=dict(vars(graph));exec(compile(staged.read_text(),str(staged),'exec'),namespace)
    fast_build=types.FunctionType(graph.build_graph.__code__,namespace,'fast_build_graph',graph.build_graph.__defaults__,graph.build_graph.__closure__)
    fast_build.__kwdefaults__=graph.build_graph.__kwdefaults__
    samples,pairs,metadata=load_dataset(BASE/'merged_dataset');by=collections.defaultdict(list)
    for s in samples:
        if s['split']=='train':by[s['plan_key']].append(s)
    # The 2-fragment boundary probe is excluded: current AutoDOP bypasses <5 fragments.
    plans=[r['plan_key'] for r in pilot['queries'] if r['fragments']>=5];assert len(plans)==3
    model_path=BASE/'prepared/cost.pt';model,_=load_cost_model(model_path);model.eval()
    variants=[('original_scalar',graph.build_graph,False),('original_batch',graph.build_graph,True),('fast_scalar',fast_build,False),('fast_batch',fast_build,True)]
    OUT.mkdir();protocol={'plans':plans,'configs_per_plan':8,'variants':[v[0] for v in variants],'timed_rounds':8,'warmups_per_variant':2,'order':'Rotate four variants by round index; each variant occupies each timing position twice.','scope':'Complete local build+score microbenchmark on preselected training configurations. Includes fresh graph construction, stacking, model scoring and output tensor. Excludes request parsing, HTTP, FE, search traversal and SQL. SingleCPU34/torch1thread on shared host. Same weights/configs for every arm; no deployment or direct MCTS batching claim.','source_sha256':{str(p):sha(p) for p in [Path(__file__),Path(graph.__file__),Path(__file__).with_name('report90_batched_cost.py'),staged,pilot_path,verified_path,proof_path,BASE/'merged_dataset/samples.jsonl',BASE/'merged_dataset/metadata.json',model_path]}}
    (OUT/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n');results=[]
    with torch.inference_mode():
        for plan in plans:
            selected=sorted(by[plan],key=lambda s:s['config_key'])[:8];assert len(selected)==8
            reference_graphs=[graph.build_graph(s,metadata) for s in selected]
            for s,g in zip(selected,reference_graphs):
                rebuilt=fast_build(s,metadata);assert rebuilt.keys()==g.keys()
                for k,v in g.items():
                    assert torch.equal(v,rebuilt[k]) if isinstance(v,torch.Tensor) else v==rebuilt[k]
            reference=torch.stack([model(g) for g in reference_graphs])
            def run(build,batch):
                start=time.perf_counter_ns();graphs=[build(s,metadata) for s in selected];built=time.perf_counter_ns()
                scores=score_batch(model,graphs) if batch else torch.stack([model(g) for g in graphs]);end=time.perf_counter_ns()
                torch.testing.assert_close(scores,reference,atol=1e-5,rtol=1e-5)
                return {'build_ms':(built-start)/1e6,'score_ms':(end-built)/1e6,'total_ms':(end-start)/1e6}
            for name,build,batch in variants:
                for _ in range(2):run(build,batch)
            timings={name:[] for name,_,_ in variants}
            for round_index in range(8):
                order=variants[round_index%4:]+variants[:round_index%4]
                for position,(name,build,batch) in enumerate(order):timings[name].append({'round':round_index,'position':position,**run(build,batch)})
            medians={name:{key:statistics.median(t[key] for t in rows) for key in ['build_ms','score_ms','total_ms']} for name,rows in timings.items()}
            results.append({'plan_key':plan,'fragments':len(selected[0]['fragments']),'configs':8,'timings':timings,'medians':medians,'combined_total_reduction_percent':100*(1-medians['fast_batch']['total_ms']/medians['original_scalar']['total_ms']),'batch_only_total_reduction_percent':100*(1-medians['original_batch']['total_ms']/medians['original_scalar']['total_ms'])})
            print(results[-1]['fragments'],medians,flush=True)
    for p,d in protocol['source_sha256'].items():assert sha(Path(p))==d
    result={'status':'verified_candidate_pipeline_cost','queries':results,'graph_module_unmodified':graph.build_graph.__globals__['_competition'] is not namespace['_competition'],'scope':protocol['scope'],'protocol_sha256':sha(OUT/'PROTOCOL.json')};assert result['graph_module_unmodified']
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 构图与候选评分的完整本地成本','',protocol['scope'],'','| fragment数 | 原构图逐条ms | 原构图批量ms | 优化构图逐条ms | 优化构图批量ms | 仅批量降低 | 合并降低 |','|---:|---:|---:|---:|---:|---:|---:|']
    for r in results:
        m=r['medians'];lines.append(f"| {r['fragments']} | {m['original_scalar']['total_ms']:.3f} | {m['original_batch']['total_ms']:.3f} | {m['fast_scalar']['total_ms']:.3f} | {m['fast_batch']['total_ms']:.3f} | {r['batch_only_total_reduction_percent']:.2f}% | {r['combined_total_reduction_percent']:.2f}% |")
    lines+=['','每格是8个候选的整条本地处理路径中位数，不是单候选耗时。构图和评分分项原始计时全部保存。2fragment绕过案例排除。构图张量逐值相等；每次计时输出满足1e-5绝对/相对容差。不能把分项中位数简单相加或直接套用到HTTP与顺序搜索。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')

if __name__=='__main__':main()
