"""Reconcile recent fixed-seed development trials and their actual expansion gates."""
import json
from pathlib import Path
from report90_neighborhood_prepare import RUN,sha
BASE=RUN/'structure_coverage20'
OUT=BASE/'recent_model_tuning_audit'
TRIALS=[('encoder_lr_pilot','降低编码器学习率'),('pair_sampling_pilot','类内均匀采样查询对'),('hard_pair_pilot','每10轮更新错对池'),('hard_pair_refresh_pilot','每轮更新错对池'),('hard_pair_ema_pilot','错对强化加EMA'),('flat_residual_pilot','固定特征残差分支'),('flat_residual_fast_pilot','残差分支较大学习率'),('pair_gap_pilot','纯成对延迟比回归'),('parameter_anchor_pilot','相对多阶段参数锚定'),('ranking_temperature_pilot','较低排序温度')]


def main():
    assert not OUT.exists()
    records=[];sources=[Path(__file__)]
    for name,title in TRIALS:
        folder=BASE/name;p=folder/'RESULT.json';r=json.loads(p.read_text());assert r['status']=='verified'
        protocol=folder/'PROTOCOL.json';assert sha(protocol)==r['protocol_sha256']
        models=r['models'];score=models['transformer']['weighted_rank_accuracy'];ref=r['reference_macro_accuracy']
        expected=score>ref and all(score>v['weighted_rank_accuracy'] for k,v in models.items() if k!='transformer')
        assert expected==r['expansion_gate_passed']
        records.append({'trial':name,'title':title,'seed':17,'epochs':30,'macro_accuracy':score,'matched_reference_macro_accuracy':ref,'xgboost_pair_macro_accuracy':models['xgboost_pairs']['weighted_rank_accuracy'],'expansion_gate_passed':expected})
        sources += [p,protocol]
    stability=BASE/'hard_pair_ema_stability/RESULT.json';s=json.loads(stability.read_text());assert s['status']=='verified_three_seed_summary'
    sources.append(stability)
    OUT.mkdir();result={'status':'verified_recent_trial_ledger','trials':records,'ema_three_seed_macro':s['models']['transformer']['macro_accuracy'],
        'scope':'Ten recent seed17/30epoch development pilots, not an exhaustive inventory of all historical experiments. Matched reference differs by row. All use reused development validation; gate is a pilot expansion decision, not final superiority acceptance. EMA passed pilot but its3seed mean did not beatXGBoost. Never select best seed or drop adverse trials.',
        'source_sha256':{str(p):sha(p) for p in sources}}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 近期训练小测核对','',result['scope'],'','| 变体 | 排序准确率 | 匹配对照 | XGBoost排序 | 小测扩大门槛 |','|---|---:|---:|---:|---|']
    for r in records:lines.append(f"| [{r['title']}](../{r['trial']}/REPORT.md) | {100*r['macro_accuracy']:.3f}% | {100*r['matched_reference_macro_accuracy']:.3f}% | {100*r['xgboost_pair_macro_accuracy']:.3f}% | {r['expansion_gate_passed']} |")
    lines += ['',f"EMA三种子平均{100*result['ema_three_seed_macro']['mean']:.3f}%，最低{100*result['ema_three_seed_macro']['minimum']:.3f}%，最高{100*result['ema_three_seed_macro']['maximum']:.3f}%。单次小测通过没有变成稳定领先。",'', '后续设计应明确提出新的机制或数据依据，避免重复已经测试过的变体。现有结果不足以把反复使用的开发集当成盲测。']
    assert all((BASE/name/'REPORT.md').exists() for name,title in TRIALS)
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps(records,indent=2))

if __name__=='__main__':main()
