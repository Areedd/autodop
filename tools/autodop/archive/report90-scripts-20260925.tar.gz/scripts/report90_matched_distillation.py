"""Matched frozen-teacher policy distillation; no report90 training or SQL."""
import hashlib
import json
import os
import random
import time
from pathlib import Path
from unittest.mock import patch

import torch
import torch.nn.functional as F

from autodop import graph,mcts
from autodop.data import load_dataset
from autodop.model import PolicyModel,load_cost_model,save_checkpoint,load_policy_model
from autodop.training import select_partition
from report90_prepared_graph import PreparedGraph
from report90_search_refinement import search

RUN=Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    os.sched_setaffinity(0,{35});torch.set_num_threads(1)
    parent=RUN/'distillation_concurrency_extension/matched_distillation'
    out=RUN/'distillation_concurrency_extension/matched_distillation_v2'
    out.mkdir(exist_ok=False)
    data=RUN/'structure_coverage20/merged_dataset'
    contract=json.loads((data/'CONTRACT.json').read_text())
    samples,pairs,_=load_dataset(data)
    train,_=select_partition(samples,pairs,contract,'train')
    valid,_=select_partition(samples,pairs,contract,'valid')
    by={}
    for s in samples:by.setdefault(s['plan_key'],s)
    keys={name:sorted({s['plan_key'] for s in rows}) for name,rows in [('train',train),('valid',valid)]}
    assert len(keys['train'])==114 and len(keys['valid'])==22
    assert not set(keys['train'])&set(keys['valid'])
    report=json.loads((RUN/'manifest.json').read_text())
    assert not {q['sql_sha256'] for q in report['queries']}&{s['sql_sha256'] for s in samples}
    teacher_path=RUN/'structure_coverage20/prepared/cost.pt'
    teacher,ck=load_cost_model(teacher_path);teacher.eval();meta=ck['metadata']
    comp_path=RUN/'graph_construction_pilot/competition_staged.py'
    ns=dict(vars(graph));exec(compile(comp_path.read_text(),str(comp_path),'exec'),ns)
    sources=[Path(__file__),parent/'source_before_fix.py',parent/'PROTOCOL.json',parent/'LABELS.json',teacher_path,comp_path,data/'CONTRACT.json',data/'samples.jsonl',data/'pairs.jsonl',RUN/'manifest.json',
             Path(__file__).with_name('report90_search_refinement.py'),Path(__file__).with_name('report90_prepared_graph.py')]
    protocol=dict(status='frozen_before_labels_and_training',teacher=str(teacher_path),teacher_sha256=sha(teacher_path),
        seed=17,teacher_seed=17,teacher_budget=64,train_plans=114,valid_plans=22,epochs=50,batch_size=8,
        encoder_lr=1e-4,classifier_lr=1e-3,selection='Lowest validation cross entropy every5epochs; ties earlier. No90query selection.',
        scope='Fresh policy with exact teacher encoder initialization and random classifier. Hard MCTS config labels only, no confidence-preservation stages. Same teacher retained for subsequent quality/cost evaluation. Teacher historical training disclosed; no new90query labels or gradients.',
        source_sha256={str(p):sha(p) for p in sources})
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    labels={};graphs={};label_records=[]
    inherited={r['plan_key']:r for r in json.loads((parent/'LABELS.json').read_text())}
    assert len(inherited)==136
    with patch.object(graph,'_competition',ns['_competition']),torch.inference_mode():
        for i,key in enumerate(keys['train']+keys['valid']):
            sample=by[key];prepared=PreparedGraph(sample,meta,ns['_competition'])
            def build(s,metadata,unknown_dop=False,device='cpu'):
                assert metadata is meta and s['fragments'] is sample['fragments']
                return prepared.build(s['dop_config'],unknown_dop,device)
            started=time.perf_counter()
            r=inherited[key]
            assert float(teacher(prepared.build(r['config']))) == r['score']
            labels[key]=torch.tensor([meta['dop_classes'].index(d) for d in r['config']])
            graphs[key]=prepared.build(sample['dop_config'],unknown_dop=True)
            label_records.append(dict(plan_key=key,partition='train' if key in keys['train'] else 'valid',
                config=r['config'],score=r['score'],search_seconds=r['search_seconds'],replay_seconds=time.perf_counter()-started,records=r['records']))
            if (i+1)%20==0:print('Teacher labels',i+1,'/136',flush=True)
    (out/'LABELS.json').write_text(json.dumps(label_records)+'\n')
    # Tensors allocated in inference_mode must be copied before autograd uses them.
    labels={k:v.clone() for k,v in labels.items()}
    graphs={k:{name:v.clone() if isinstance(v,torch.Tensor) else v for name,v in g.items()} for k,g in graphs.items()}
    torch.manual_seed(17);rng=random.Random(17)
    model=PolicyModel(meta,ck['model_config']);model.encoder.load_state_dict(teacher.encoder.state_dict())
    optimizer=torch.optim.Adam([{'params':model.encoder.parameters(),'lr':1e-4},{'params':model.classifier.parameters(),'lr':1e-3}])
    best=float('inf');history=[];started=time.perf_counter()
    for epoch in range(1,51):
        order=list(keys['train']);rng.shuffle(order);model.train();total=0
        for offset in range(0,len(order),8):
            optimizer.zero_grad();group=order[offset:offset+8]
            loss=torch.stack([F.cross_entropy(model(graphs[k]),labels[k]) for k in group]).mean()
            assert torch.isfinite(loss)
            loss.backward();assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
            optimizer.step();total+=float(loss.detach())*len(group)
        row=dict(epoch=epoch,train_cross_entropy=total/len(order))
        if epoch%5==0 or epoch==2:
            model.eval()
            with torch.no_grad():
                losses=[float(F.cross_entropy(model(graphs[k]),labels[k])) for k in keys['valid']]
                row['valid_cross_entropy']=sum(losses)/len(losses)
            if epoch%5==0 and row['valid_cross_entropy']<best:
                best=row['valid_cross_entropy'];row['selected']=True
                save_checkpoint(out/'policy.pt','policy',model,meta,training={**contract,
                    'teacher_sha256':sha(teacher_path),'labels_sha256':sha(out/'LABELS.json'),'policy_seed':17,'selected_epoch':epoch})
            print(json.dumps(row),flush=True)
        if epoch==2:
            save_checkpoint(out/'smoke.pt','policy',model,meta,training=contract)
            replay,_=load_policy_model(out/'smoke.pt');replay.eval();model.eval()
            with torch.no_grad():assert torch.equal(replay(graphs[keys['valid'][0]]),model(graphs[keys['valid'][0]]))
        history.append(row)
        (out/'PROGRESS.json').write_text(json.dumps(dict(epoch=epoch,history=history))+'\n')
    elapsed=time.perf_counter()-started
    chosen,saved=load_policy_model(out/'policy.pt');chosen.eval()
    metrics={}
    with torch.no_grad():
        for name,plans in keys.items():
            exact=correct=total=0
            for key in plans:
                pred=chosen(graphs[key]).argmax(-1);target=labels[key]
                exact+=int(torch.equal(pred,target));correct+=int((pred==target).sum());total+=len(target)
            metrics[name]=dict(plans=len(plans),exact_vectors=exact,node_correct=correct,nodes=total,node_accuracy=correct/total)
    for p,d in protocol['source_sha256'].items():assert sha(Path(p))==d,p
    (out/'RESULT.json').write_text(json.dumps(dict(status='verified_matched_distillation_training',
        selected_epoch=saved['training']['selected_epoch'],training_loop_seconds=elapsed,metrics=metrics,history=history,
        teacher_sha256=sha(teacher_path),policy_sha256=sha(out/'policy.pt'),protocol_sha256=sha(out/'PROTOCOL.json')),indent=2)+'\n')
    print(json.dumps(metrics),flush=True)


if __name__=='__main__':main()
