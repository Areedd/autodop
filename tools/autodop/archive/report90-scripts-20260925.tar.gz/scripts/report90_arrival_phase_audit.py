"""Descriptive phase breakdown; never overrides the original full-run gate."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path

RUN=Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def main():
    source=RUN/'native_arrival_control_audit/RESULT.json'
    audit=json.loads(source.read_text());groups=defaultdict(list)
    for row in audit['rows']:groups[row['phase'],row['id']].append(row)
    summaries=[]
    for (phase,query),rows in sorted(groups.items()):
        summaries.append(dict(phase=phase,id=query,count=len(rows),
                              plan_variants=len({r['plan'] for r in rows}),
                              dop_variants=len({r['vector'] for r in rows}),
                              arms=sorted({r['arm'] for r in rows})))
    result=dict(status='descriptive_only',original_gate_status=audit['status'],summary=summaries,
                scope='Post hoc phase breakdown of all heterogeneous observations. It does not replace the predeclared requirement for full-run plan/DOP consistency, discard warmups, or establish causal effects.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),source]})
    out=RUN/'native_arrival_phase_audit';out.mkdir(exist_ok=True)
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 实测计划一致性的阶段分解','',result['scope'],'',f"原定全程检查结果：{audit['status']}。",'',
           '| 阶段 | 查询 | 执行数 | 计划描述种类 | DOP 向量种类 |','|---|---|---:|---:|---:|']
    for r in summaries:lines.append(f"| {r['phase']} | {r['id']} | {r['count']} | {r['plan_variants']} | {r['dop_variants']} |")
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
