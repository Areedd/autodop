"""Read-only numerical audit of saved model metrics, choices and SQL evidence."""
import json,sys,hashlib
from pathlib import Path
from collections import defaultdict
import numpy as np
import torch
from report90_models import RUN,prepare_data,flat_features,metrics
from autodop.graph import build_graph,sample_from_request
from autodop.model import load_cost_model
import xgboost as xgb

torch.set_num_threads(1)
out=RUN/'model_comparison_audit';out.mkdir(exist_ok=True)
def save(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
samples,tr,va,pairs,meta,contract=prepare_data();normal=np.load(RUN/'models_full/FEATURE_NORMALIZATION.npz');selected=json.loads((RUN/'models_full/SELECTED.json').read_text());models={};report={'validation':{},'choices':{},'sql':{}}
for kind in ['transformer_rank','xgb_rank']:
 folder=RUN/'models_full'/selected[kind+'_s17']
 if kind=='transformer_rank':model,_=load_cost_model(folder/'model.pt');model.eval()
 else:model=xgb.XGBRanker();model.load_model(folder/'model.ubj');model.set_params(n_jobs=1)
 models[kind]=model

def score(kind,gs):
 if kind=='xgb_rank':return models[kind].predict(np.stack([(flat_features(g,meta)-normal['mean'])/normal['std'] for g in gs]))
 with torch.no_grad():return np.array([float(models[kind](g)) for g in gs])
graphs=[build_graph(s,meta) for s in va]
for kind in models:
 scores=score(kind,graphs);measured=metrics(va,scores);saved=json.loads((RUN/'models_full'/selected[kind+'_s17']/'RESULT.json').read_text())['validation'];assert measured==saved
 report['validation'][kind]=measured;print('Validation exactly reproduced',kind,flush=True)
# Load each archived plan variant and recalculate every score/argmax, including repairs.
for folder in [RUN/'choices',RUN/'choices_attempt1']:
 rows=json.loads((folder/'ROWS.json').read_text());vectors=json.loads((folder/'vectors.json').read_text())
 for row in rows:
  if row['type']!='cost_model' or row['mode'] not in [k+'_s17' for k in models]:continue
  kind=row['mode'].removesuffix('_s17');entry=vectors['cost_'+kind][row['id']];sample=sample_from_request(entry['request'])
  graphs=[build_graph({**sample,'dop_config':list(c)},meta) for c in row['configs']];scores=score(kind,graphs)
  assert np.allclose(scores,row['scores'],rtol=1e-6,atol=1e-6),(kind,row['id'])
  chosen=list(row['configs'][int(np.argmax(scores))]);assert chosen==list(row['selected_dops'])
  actual=[entry['fragment_dops'][fid] for fid in sample['fragment_ids']];assert chosen==actual
  report['choices'].setdefault(kind,{'plans_including_repair':0,'max_abs_score_difference':0})
  d=report['choices'][kind];d['plans_including_repair']+=1;d['max_abs_score_difference']=max(d['max_abs_score_difference'],float(np.max(np.abs(scores-np.array(row['scores'])))))
 print('Choices reproduced',folder.name,flush=True)
summary=json.loads((RUN/'SUMMARY.json').read_text());repaired=set(summary['serial_repair']['replaced_queries']);values=defaultdict(lambda:defaultdict(list))
for name in ['serial','serial_repair']:
 for line in (RUN/name/'scored/events.jsonl').open():
  e=json.loads(line)
  if e['phase']=='warmup' or e['mode'] not in ['cost_'+k for k in models]:continue
  if name=='serial' and e['id'] in repaired:continue
  assert e['status']=='verified'
  values[e['mode']][e['id']].append(e['client_latency_ms'])
for mode,qs in values.items():
 assert len(qs)==90 and all(len(v)==3 for v in qs.values())
 means={q:float(np.mean(v)) for q,v in qs.items()};assert means==summary['serial']['per_query_mean_ms'][mode]
 report['sql'][mode]={'queries':90,'observations':270,'mean_ms':float(np.mean(list(means.values())))}
a=summary['serial']['per_query_mean_ms']['cost_transformer_rank'];b=summary['serial']['per_query_mean_ms']['cost_xgb_rank']
report['paired_sql']={'xgb_faster':sum(b[q]<a[q] for q in a),'mean_reduction_percent':100*(1-np.mean(list(b.values()))/np.mean(list(a.values())))}
report['input_sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [RUN/'models_full/METADATA.json',RUN/'models_full/FEATURE_NORMALIZATION.npz',RUN/'choices/ROWS.json',RUN/'choices_attempt1/ROWS.json']}
save('AUDIT.json',report);print(json.dumps(report['sql']),flush=True)
