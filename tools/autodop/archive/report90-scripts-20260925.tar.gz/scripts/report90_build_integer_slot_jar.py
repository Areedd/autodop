"""Minimal optional integer-memory estimator on the checkpoint-isolated FE."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

RUN=Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def main():
    out=RUN/'integer_slot_estimator_validation';base=RUN/'checkpoint_variable_regression/fixed-fe.jar'
    assert hashlib.sha256(base.read_bytes()).hexdigest()==json.loads((base.parent/'BINARY_AUDIT.json').read_text())['fixed_sha256']
    prefix='com/starrocks/qe/scheduler/slot/'
    names=[prefix+n for n in ['SlotEstimatorFactory.class','SlotEstimatorFactory$EstimatorPolicy.class',
                             'SlotEstimatorFactory$MemoryBasedSlotsEstimator.class','SlotEstimatorFactory$IntegerMemoryBasedSlotsEstimator.class']]
    updates={name:(out/'classes'/name).read_bytes() for name in names};dest=out/'integer-fe.jar'
    with zipfile.ZipFile(base) as src,zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as dst:
        for info in src.infolist():dst.writestr(info,updates.get(info.filename,src.read(info.filename)))
        for name,data in updates.items():
            if name not in src.namelist():dst.writestr(name,data)
    with zipfile.ZipFile(base) as a,zipfile.ZipFile(dest) as b:
        changed=[n for n in a.namelist() if a.read(n)!=b.read(n)];added=sorted(set(b.namelist())-set(a.namelist()))
        assert set(changed+added)==set(names)
    testdir=out/'jar_tests';testdir.mkdir(exist_ok=True)
    for p in (out/'classes'/prefix).glob('IntegerMemorySlotsEstimatorTest*.class'):
        target=testdir/p.relative_to(out/'classes');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
    cmd=json.loads((out/'JUNIT_COMMAND.json').read_text());index=cmd.index('-cp')+1
    parts=cmd[index].split(':');cmd[index]=str(testdir)+':'+str(dest)+':'+':'.join(p for p in parts if p!=str(out/'classes'))
    (out/'JAR_JUNIT_COMMAND.json').write_text(json.dumps(cmd,indent=2)+'\n')
    p=subprocess.run(cmd,capture_output=True,text=True);(out/'JAR_JUNIT.log').write_text(p.stdout+p.stderr)
    result=dict(status='verified_not_deployed' if p.returncode==0 else 'failed',
                base_sha256=hashlib.sha256(base.read_bytes()).hexdigest(),integer_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),
                changed_classes=changed,added_classes=added,test_exit_code=p.returncode,
                scope='Only estimator factory, enum, shared memory-cost retrieval and new integer estimator differ from checkpoint-fixed FE. SWRR and AutoDOP model unchanged; no FIFO classes added. No SQL performance result.')
    (out/'BINARY_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
    if p.returncode:print((p.stdout+p.stderr)[-3000:]);raise SystemExit(p.returncode)


if __name__=='__main__':main()
