"""Verify all native admission pilot queries and report every factorial mode."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import csv, io
import time
import numpy as np

from report90_execute import ROOT, RUN
from report90_native_predictor import NativePredictor
from report90_native_budget_fixed17 import MODES, OUT, SUPPORT


def main():
    read = lambda p: json.loads(p.read_text())
    events = [json.loads(line) for line in (OUT/'scored/events.jsonl').read_text().splitlines()]
    assert len(events)==136 and all(e['status']=='verified' for e in events)
    assert read(OUT/'scored/independent_verification.json')['all_expected_executions_verified']
    manifest = {q['id']:q for q in read(SUPPORT/'manifest.json')['queries']}
    native = {(r['id'],r['pipeline_dop']):r for r in read(RUN/'native_memory_features17_full/RESULT.json')['records']}
    predictor = NativePredictor.load(RUN/'native_predictor_service17/MODEL.json')
    calls = read(OUT/'PREDICTOR_REQUESTS.json'); assert not calls['errors']
    calls = [r for r in calls['records'] if r['mode']!='bootstrap']
    assert len(calls)==272
    # The FE also predicts last_query_id() helpers. IDs only associate evidence;
    # the frozen model ignores IDs. Cold planner feature variants are replayed as captured.
    tables = lambda body: tuple(list(csv.reader(io.StringIO(body)))[1][:3])
    query_tables = {key:tables(r['csv']) for key,r in native.items() if key[0] in manifest}
    assert {key[0] for key in query_tables}==set(manifest)
    # Multiple queries share tables; association is explicitly a grouped multiset.
    # Individual query budget/slot/release identity is proven by FE audit and history.
    data_calls = [p for p in calls if tables(p['csv']) != ('0','0','0')]
    helper_calls = [p for p in calls if tables(p['csv']) == ('0','0','0')]
    assert len(data_calls)==len(helper_calls)==136
    for p in read(OUT/'PREDICTOR_REQUESTS.json')['records']:
        assert predictor.predict_csv(p['csv'],MODES.get(p['mode'],'fixed8'))==p['prediction']
    expected_responses = Counter((p['mode'],tables(p['csv']),p['prediction']['encoded_cost_bytes']) for p in data_calls)
    actual_responses = Counter()
    wanted = {e['query_id']:e for e in events};assert len(wanted)==136
    matches = {}
    for _ in range(15):
        matches = {}
        with (ROOT.parents[1]/'output/fe/log/fe.audit.log').open() as stream:
            for line in stream:
                if ' [query] ' not in line: continue
                m=re.search(r'\|QueryId=([0-9a-f-]+)\|',line)
                if not m or m[1] not in wanted: continue
                assert m[1] not in matches
                matches[m[1]]=line.rstrip('\n')
        if matches.keys()==wanted.keys(): break
        time.sleep(1)
    assert matches.keys()==wanted.keys()
    # Associate each helper with the latest preceding data query on its connection;
    # cap the interval and require one helper per data query, including reused clients.
    field = lambda line,key: re.search(r'\|'+key+r'=([^|]*)\|',line)[1]
    helper_matches={}
    with (ROOT.parents[1]/'output/fe/log/fe.audit.log').open() as stream:
        for line in stream:
            if '|Stmt=SELECT /*+ SET_VAR(enable_auto_dop=false) */ last_query_id()|' not in line: continue
            ts=int(field(line,'Timestamp')); client=field(line,'Client')
            candidates=[(int(field(v,'Timestamp')),k) for k,v in matches.items()
                        if field(v,'Client')==client and 0<=ts-int(field(v,'Timestamp'))<=300000]
            if not candidates: continue
            _,qid=max(candidates)
            assert qid not in helper_matches, 'Ambiguous helper association'
            assert '|State=EOF|' in line and '|ErrorCode=|' in line
            helper_matches[qid]=line.rstrip('\n')
    assert helper_matches.keys()==wanted.keys()
    assert Counter(p['mode'] for p in helper_calls)==Counter(e['mode'] for e in events)
    history = read(OUT/'SLOT_HISTORY.json')['rows']
    normalize = lambda s:' '.join(s.split()).rstrip(';').rstrip()
    rows=[]
    for qid,e in wanted.items():
        line=matches[qid];q=manifest[e['id']]
        assert '|State=EOF|' in line and '|ErrorCode=|' in line and '|Db='+q['database']+'|' in line
        assert normalize(line.split('|Stmt=',1)[1].split('|Digest=',1)[0])==normalize(Path(q['sql_file']).read_text())
        mem=re.search(r'\|PredictMemBytes=(\d+)\|',line); assert mem
        encoded=int(mem[1]); assert encoded>0 and encoded%predictor.slot_bytes==0
        per_worker=encoded//predictor.slot_bytes
        assert per_worker<=32 and per_worker & (per_worker-1)==0
        expected=per_worker*predictor.workers
        actual_responses[(e['mode'],query_tables[e['id'],4 if e['autodop_enabled'] else 0],encoded)]+=1
        assert '|Slots='+str(expected)+'|' in line
        assert '|PendingTimeMs=' in line
        slots=[h for h in history if h['query_id'].replace('-','')==qid.replace('-','')]
        assert len(slots)==1
        slot=slots[0];assert slot['state']=='RELEASED'
        assert int(slot['allocate_slots'])==int(slot['est_costs_slots'])==expected
        rows.append(dict(query_id=qid,id=e['id'],mode=e['mode'],phase=e['phase'],slots=expected,audit_line=line,slot_history=slot))
    assert actual_responses==expected_responses, 'Captured model responses disagree with query audit budgets'
    for p in [OUT/'QUEUE_SETTINGS.json',OUT/'frontend_settings.json',OUT/'scored/frontend_settings.json']:
        assert read(p)['restored']
    rounds=read(OUT/'scored/collection.json')['rounds'];assert len(rounds)==8
    result={}
    for mode in MODES:
        rs=[r for r in rounds if r['mode']==mode and r['phase']=='measured'];assert len(rs)==1
        es=[e for e in events if e['mode']==mode and e['phase']=='measured'];assert len(es)==17
        lat=np.array([e['client_latency_ms'] for e in es])
        result[mode]=dict(batch_seconds=rs[0]['workload_wall_seconds'],qps=rs[0]['verified_queries_per_second'],
                          mean_ms=float(lat.mean()),p50_ms=float(np.percentile(lat,50)),p90_ms=float(np.percentile(lat,90)),p99_ms=float(np.percentile(lat,99)))
    comparisons={}
    for name,base,new in [('admission_native','native','native_budget'),('admission_heterogeneous','policy_static','policy_budget'),('heterogeneous_fixed8','native','policy_static'),('heterogeneous_predicted','native_budget','policy_budget')]:
        comparisons[name]={k:100*(1-result[new][k]/result[base][k]) for k in ['batch_seconds','mean_ms','p50_ms','p90_ms','p99_ms']}
    proof=dict(status='verified',executions=136,rows=rows,helper_audit_lines=helper_matches,metrics=result,latency_reduction_percent=comparisons,
               scope='Only VariableMgr checkpoint isolation differs from original FE. Callback-to-query evidence is a mode/table/budget multiset, not individual HTTP trace identity. All17 historical development queries; one measured finite batch per mode. Frozen full-development memory fit. Native V2 MBE, identical result verification, no retries. No unseen-query generalization, steady-state or contract claim.')
    proof['source_sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),OUT/'PREDICTOR_REQUESTS.json',OUT/'SLOT_HISTORY.json',OUT/'scored/events.jsonl',OUT/'scored/collection.json',OUT/'scored/independent_verification.json']}
    (OUT/'ALLOCATION_AUDIT.json').write_text(json.dumps(proof,indent=2)+'\n')
    lines=['# 原生预算准入并发小测','','| 模式 | 整批秒数 | QPS | 平均请求毫秒 | p90毫秒 |','|---|---:|---:|---:|---:|']
    for k,v in result.items():lines.append(f"| {k} | {v['batch_seconds']:.3f} | {v['qps']:.4f} | {v['mean_ms']:.2f} | {v['p90_ms']:.2f} |")
    lines+=['','136次执行全部核对结果、唯一查询ID、实际DOP（适用时）、预算响应、FE审计Slots及实际分配/释放。每组17任务正式批次；排队和预测计入请求耗时。固定预算对应8并发，预测预算独立于查询级/异构DOP模式。未重试，不自动扩大。','',proof['scope']]
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
    (OUT/'STATUS.json').write_text(json.dumps(dict(status='verified',executions=136))+'\n')
    print(json.dumps(dict(metrics=result,comparisons=comparisons)),flush=True)


if __name__=='__main__':main()
