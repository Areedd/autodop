"""Report both DOP and admission effects from a fixed four-cell experiment."""
import argparse
import hashlib
import json
from pathlib import Path


def main(phase):
    out=Path(__file__).resolve().parents[1]/f'runs/report90_20260912/development17_budget_{phase}'
    read=lambda n:json.loads((out/n).read_text())
    result=read('RESULT.json');admission=read('ADMISSION_AUDIT.json');failures=read('FAILURE_IDENTITY_AUDIT.json')
    assert result['status']==admission['status']==failures['status']=='verified'
    assert read('DECISION_AUDIT.json')['status']=='verified'
    metrics=result['metrics'];comparisons={}
    for label,new,base in [('admission_with_native','native_budget','native'),
                            ('admission_with_static','policy_budget','policy_static'),
                            ('heterogeneous_under_same_admission','policy_budget','native_budget'),
                            ('heterogeneous_without_reservation','policy_static','native'),
                            ('combined_vs_native','policy_budget','native')]:
        a,b=metrics[new],metrics[base]
        complete=(a['completed_tasks']==a['logical_tasks'] and b['completed_tasks']==b['logical_tasks'])
        comparisons[label]=dict(new=new,baseline=base,both_complete=complete,
                                batch_time_reduction=1-a['batch_seconds']/b['batch_seconds'] if complete else None,
                                latency_reduction={k:1-a['logical_latency_ms'][k]/b['logical_latency_ms'][k]
                                                   for k in ['mean','p50','p90','p99']} if complete else None)
    paths=[out/n for n in ['RESULT.json','ADMISSION_AUDIT.json','FAILURE_IDENTITY_AUDIT.json',
                           'DECISION_AUDIT.json','DIRECT_MEMORY_SUMMARY.json']]+[Path(__file__).resolve()]
    proof=dict(status='verified',metrics=metrics,comparisons=comparisons,
               all_failed_attempts_corrobated=failures['failed_physical_attempts'],
               scope='Fixed development queries; one finite formal batch, not independent generalization or steady-state throughput. '
                     'Historical-profile FIFO reservation is an added client prototype, not preexisting AutoDOP. '
                     'Same per-SQL reservation table and total budget for native/static. All waiting and retries included.',
               source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    target=out/'FACTORIAL_SUMMARY.json';assert not target.exists()
    target.write_text(json.dumps(proof,indent=2)+'\n')
    lines=['# DOP与预算准入的四组开发对照','',proof['scope'],'',
           '| 模式 | 正式完成 | SQL尝试 | 内存失败尝试 | 整批秒数 | 请求平均毫秒（含等待与重试） |',
           '|---|---:|---:|---:|---:|---:|']
    for mode,r in metrics.items():
        lines.append(f"| {mode} | {r['completed_tasks']}/{r['logical_tasks']} | {r['physical_sql_attempts']} | {r['failed_physical_attempts']} | {r['batch_seconds']:.2f} | {r['logical_latency_ms']['mean']:.2f} |")
    lines+=['','| 对照 | 整批耗时降低 |','|---|---:|']
    for name,r in comparisons.items():
        value=f"{r['batch_time_reduction']:.2%}" if r['both_complete'] else '未全部完成，不计算'
        lines.append(f'| {name} | {value} |')
    lines+=['',f"全部阶段{failures['failed_physical_attempts']}次失败均匹配FE查询ID、SQL及内存错误码。预算记账无超额且全部释放；这不保证实际内存不会超额。",
            '原生队列和重试对所有模式一致。不能把新增客户端预算准入的效果归因于旧负载修正，也不能将profile查表视为未见查询预测模型。']
    (out/'FACTORIAL_SUMMARY.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(comparisons,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['pilot','full'],required=True)
    main(p.parse_args().phase)
