"""Audit explicit-product removal and publish transparent six-model comparison."""
import json
import os
import sys
from pathlib import Path
import statistics
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'scripts'),'/tmp/autodop-report-deps']
import numpy as np
import torch
import xgboost as xgb
from autodop.data import load_dataset,build_metadata
from autodop.graph import build_graph
from autodop.training import select_partition,file_sha256
from report90_models import MLP,flat_features
from report90_six_model_control import DATA,RUN,quality,key,state_hash,save


def main(stage):
    torch.set_num_threads(1)
    base=RUN/'basic_four_control_20260920';out=base/stage;full=RUN/'six_model_control_20260919/full'
    result=json.loads((out/'RESULT.json').read_text());ref=json.loads((full/'RESULT.json').read_text())
    for p,h in result['source_sha256'].items():assert file_sha256(p)==h
    previous_audit=json.loads((full/'FINAL_AUDIT.json').read_text())
    assert previous_audit['status']=='verified_independent_replay'
    assert previous_audit['source_sha256'][str(full/'RESULT.json')]==file_sha256(full/'RESULT.json')
    samples,pairs,_=load_dataset(DATA);contract=json.loads((out/'CONTRACT.json').read_text());tr,tp=select_partition(samples,pairs,contract,'train');va,_=select_partition(samples,pairs,contract,'valid')
    meta=json.loads((out/'METADATA.json').read_text());assert meta==build_metadata(tr)==json.loads((full/'METADATA.json').read_text())
    norm=np.load(out/'NORMALIZATION.npz');fnorm=np.load(full/'NORMALIZATION.npz');assert all(np.array_equal(norm[k],fnorm[k]) for k in ['mean','std'])
    raw=torch.tensor(np.stack([(flat_features(build_graph(s,meta),meta)-norm['mean'])/norm['std'] for s in va]))
    n=len(meta['numeric_features']);c=sum(len(meta['category_vocab'][k]) for k in meta['category_features']);w=2*n+2*c+5
    removed=[p*w+j for p in range(4) for j in range(n+c+1,2*n+2*c+1)];keep=[j for j in range(raw.shape[1]) if j not in removed]
    mask=json.loads((out/'MASK.json').read_text());assert removed==mask['zeroed_columns'] and keep==mask['retained_columns'];assert len(removed)==532 and len(keep)==556
    vx=raw.clone();vx[:,removed]=0;assert torch.equal(raw[:,keep],vx[:,keep]);assert torch.count_nonzero(vx[:,removed])==0
    records=[]
    for r in result['selected']:
        p=Path(r['model']);assert file_sha256(p)==r['model_sha256'];reg=r['kind'].endswith('regression');tree=r['kind'].startswith('xgb')
        if tree:
            model=xgb.XGBRegressor() if reg else xgb.XGBRanker();model.load_model(p);model.set_params(n_jobs=1);assert model.n_features_in_==556;scores=model.predict(vx[:,keep].numpy()).astype(float)
        else:
            torch.manual_seed(r['seed']);model=MLP(1088);assert state_hash(model)==r['initial_state_sha256']
            old=next(x for x in ref['candidates'] if (x['kind'],x['seed'],x['setting'])==(r['kind'],r['seed'],r['setting']));assert r['initial_state_sha256']==old['initial_state_sha256']
            model.load_state_dict(torch.load(p,weights_only=True));model.eval()
            with torch.no_grad():scores=model(vx).numpy().astype(float)
        if reg:scores=-scores
        assert np.isfinite(scores).all()
        stored=json.loads((p.parent/'PREDICTIONS.json').read_text());assert np.array_equal(scores,np.array([x['score'] for x in stored]))
        q,a=quality(va,scores);assert q==r['selected']['quality']
        records.append(dict(kind=r['kind'],seed=r['seed'],replay_exact=True,effective_pairs=len(a)))
    names={'transformer_rank':'Transformer＋排序损失','transformer_regression':'Transformer＋回归损失','mlp_rank':'MLP＋排序损失（无显式乘积）','mlp_regression':'MLP＋回归损失（无显式乘积）','xgb_rank':'XGBoost＋排序目标（无显式乘积）','xgb_regression':'XGBoost＋回归目标（无显式乘积）'}
    merged={k:v for k,v in ref['aggregate'].items() if k.startswith('transformer')};merged.update(result['aggregate'])
    if stage=='full':
        assert len(result['selected'])==12 and len(result['candidates'])==24
        for field in ['seeds','epochs','learning_rates','batch_pairs','pair_draws_per_epoch','xgb_depths','xgb_trees','selection','neural_supervision','tree_supervision']:
            assert result['protocol'][field]==ref['protocol'][field],field
        lines=['# 六模型对照：MLP与XGBoost移除显式DOP乘积项','',
          '本轮重新训练MLP与XGBoost的排序、回归四组；Transformer两组复用已核验的同条件从头训练结果。共同使用114个训练计划、1365条配置，监督来自6702条训练对的1363个配置端点；验证为212条配置和920个有效排序对。三种子17/29/43、两档参数及选模规则与完整特征版完全相同。验证集参与选模，属于开发集结果。','',
          '移除的是log1p(DOP)×数值特征及log1p(DOP)×类别one-hot特征，经四种池化后共532列。保留DOP自身统计、原始数值/类别汇总及依赖/竞争边统计。XGBoost实际输入556维；MLP保留1088维接口，将532个归一化乘积列置零，因此只有556个保留特征列，同时与完整特征版保持相同初始权重和网络容量。Transformer仍使用DOP嵌入与图结构，不输入这些手工乘积项。','',
          '| 模型 | 等权排序准确率 % | 种子标准差（百分点） | 已测候选时延均值 ms | 训练循环 s | 单配置推理 ms |','|---|---:|---:|---:|---:|---:|']
        for k,v in merged.items():
            cells=[]
            for field,scale,digits,better in [('macro_accuracy_mean',100,3,max),('macro_accuracy_sd',100,3,None),('selected_observed_latency_mean_ms',1,2,min),('training_fit_mean_seconds',1,2,min),('inference_mean_ms',1,4,min)]:
                text=f'{v[field]*scale:.{digits}f}'
                if better and v[field]==better(x[field] for x in merged.values()):text='**'+text+'**'
                cells.append(text)
            lines.append('| '+names[k]+' | '+' | '.join(cells)+' |')
        lines+=['','时延列为验证候选的既有实测标签，不是新增SQL或90条查询的端到端测量。推理为预建输入、单配置CPU调用，不含特征构造或SQL。Transformer成本来自前一批实验，四组成本来自本轮，属于不同时间批次。黑色粗体仅标记本表最优观测值，不代表统计显著性。','',
          '## 完整特征版保留对照','',
          '本轮是在观察过完整特征结果后新增的输入表示对照。移除手工交互项不等于消除模型学习交互的能力；相对无显式乘积基线的结果不代表优于所有输入表示。完整特征版不删除、不覆盖。','',
          '| 模型 | 完整特征准确率 % | 无显式乘积准确率 % |','|---|---:|---:|']
        for k,v in result['aggregate'].items():
            a=100*ref['aggregate'][k]['macro_accuracy_mean'];b=100*v['macro_accuracy_mean'];fa=f'{a:.3f}';fb=f'{b:.3f}'
            lines.append('| '+names[k].replace('（无显式乘积）','')+' | '+('**'+fa+'**' if a>=b else fa)+' | '+('**'+fb+'**' if b>=a else fb)+' |')
        lines+=['','| 模型 | seed | 等权准确率 % | 所选epoch | 参数档位 |','|---|---:|---:|---:|---:|']
        for r in result['selected']:lines.append(f"| {names[r['kind']]} | {r['seed']} | {100*r['selected']['quality']['weighted_rank_accuracy']:.3f} | {r['selected']['epoch'] or '—'} | {r['setting']} |")
        lines+=['',f'[本轮结果]({out}/RESULT.json)；[输入列掩码]({out}/MASK.json)；[完整特征对照]({full}/UNIFIED_REPORT.md)。']
        (out/'UNIFIED_REPORT.md').write_text('\n'.join(lines)+'\n')
        save(out/'COMBINED_RESULT.json',dict(status='verified',aggregate=merged,transformer_reused_from=str(full/'RESULT.json'),flat_models_from=str(out/'RESULT.json')))
    # Override the generic inherited summary with a feature-correct report.
    if stage=='full':(out/'REPORT.md').write_bytes((out/'UNIFIED_REPORT.md').read_bytes())
    else:(out/'REPORT.md').write_text('# 无显式DOP乘积项小测\n\n四组已完成训练与重载，移除532个乘积特征，保留556个特征列。小测仅检查训练和评估正确性，不据此判断模型性能。\n')
    save(out/'FINAL_AUDIT.json',dict(status='verified_product_removal_and_replay',records=records,removed_columns=532,retained_columns=556,
         mlp_initialization_matches_full=True,non_product_values_unchanged=True,source_sha256={str(Path(__file__)):file_sha256(__file__),str(out/'RESULT.json'):file_sha256(out/'RESULT.json'),str(full/'RESULT.json'):file_sha256(full/'RESULT.json')},
         report_sha256=file_sha256(out/'UNIFIED_REPORT.md') if stage=='full' else None))
    print(json.dumps(dict(stage=stage,status='verified',aggregate=result['aggregate']),ensure_ascii=False,indent=2))


if __name__=='__main__':main(sys.argv[1] if len(sys.argv)>1 else 'full')
