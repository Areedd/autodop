"""Compare pair-level mistakes of scalar and refitted linear heads on frozen features."""
import json
import os
from pathlib import Path
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from autodop.training import select_partition
from report90_interaction_pair_audit import make_pairs,accuracy
from report90_neighborhood_prepare import RUN,sha
BASE=RUN/'structure_coverage20';OUT=BASE/'frozen_representation_probe'


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1)
    r=json.loads((OUT/'RESULT.json').read_text());assert r['status']=='verified_frozen_representation_probe'
    assert sha(OUT/'SCORES.json')==r['scores_sha256']
    protocol=json.loads((OUT/'PROTOCOL.json').read_text());assert sha(OUT/'PROTOCOL.json')==r['protocol_sha256']
    for p,d in protocol['source_sha256'].items():assert sha(Path(p))==d
    samples,pairs,meta=load_dataset(BASE/'merged_dataset');contract=json.loads((BASE/'merged_dataset/CONTRACT.json').read_text())
    valid,_=select_partition(samples,pairs,contract,'valid');valid=sorted(valid,key=lambda s:(s['plan_key'],s['config_key']))
    model_path=BASE/'hard_pair_ema_pilot/pilot/transformer_h0/best.pt';model,_=load_cost_model(model_path);model.eval()
    with torch.no_grad():old=[float(model(build_graph(s,meta))) for s in valid]
    setting=r['models']['hard_ema_seed17_64']['selected']['setting'];new=json.loads((OUT/'SCORES.json').read_text())[f'hard_ema_seed17_64_alpha{setting}']
    pool=make_pairs(valid);assert len(pool)==920
    oldq,newq=accuracy(pool,old),accuracy(pool,new)
    assert abs(oldq['macro_accuracy']-r['original_scalar_models']['hard_ema_seed17']['weighted_rank_accuracy'])<1e-12
    assert abs(newq['macro_accuracy']-r['models']['hard_ema_seed17_64']['selected']['validation']['weighted_rank_accuracy'])<1e-12
    totals={};details=[]
    for p in pool:
        a,b=p['fast_index'],p['slow_index'];oc=old[a]>old[b];nc=new[a]>new[b]
        category='both_correct' if oc and nc else 'only_original_correct' if oc else 'only_linear_correct' if nc else 'both_wrong_or_tied'
        counts=totals.setdefault(p['cohort'],{k:0 for k in ['both_correct','only_original_correct','only_linear_correct','both_wrong_or_tied']});counts[category]+=1
        if oc!=nc:details.append({**p,'category':category,'original_gap':old[a]-old[b],'linear_gap':new[a]-new[b]})
    result={'status':'verified_pair_disagreement','cohorts':totals,'disagreements':details,'original':oldq,'linear':newq,'scope':'Reused development set; descriptors of mistakes, not a learned selection rule or evidence for test-set ensemble gains. No ensemble or query filtering performed.','source_sha256':{str(p):sha(p) for p in [Path(__file__),OUT/'RESULT.json',OUT/'PROTOCOL.json',OUT/'SCORES.json',model_path,BASE/'merged_dataset/samples.jsonl']}}
    target=OUT/'DISAGREEMENT.json';assert not target.exists();target.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(totals))

if __name__=='__main__':main()
