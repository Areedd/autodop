"""Small controlled feature ablation; never replaces the full-feature baseline."""
import json
import os
from pathlib import Path
import time

import numpy as np
import torch
import xgboost as xgb
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.training import select_partition, file_sha256
from report90_models import flat_features
from report90_complex_retrain import key, validation, xgb_rows

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'runs/report90_20260912/structure_coverage20'


def main():
    out = BASE/'xgb_feature_ablation_pilot'
    out.mkdir(exist_ok=False)
    def save(name, value):
        (out/name).write_text(json.dumps(value, indent=2)+'\n')
    torch.set_num_threads(1)
    os.sched_setaffinity(0, {34})
    dataset = BASE/'merged_dataset'
    samples, pairs, meta = load_dataset(dataset)
    contract = json.loads((dataset/'CONTRACT.json').read_text())
    train, tp = select_partition(samples, pairs, contract, 'train')
    valid, _ = select_partition(samples, pairs, contract, 'valid')
    assert (len(train), len(valid), len(tp)) == (1365, 212, 6702)
    assert not {s['plan_key'] for s in train} & {s['plan_key'] for s in valid}
    n = len(meta['numeric_features'])
    c = sum(len(meta['category_vocab'][name]) for name in meta['category_features'])
    width = 2*n+2*c+5
    interaction = set(range(n+c+1, 2*n+2*c+1))
    structure = set(range(width-4, width))
    masks = {}
    for arm, dropped in [('full',set()), ('no_explicit_dop_interaction',interaction),
                         ('no_structure_statistics',structure), ('neither',interaction|structure)]:
        cols = [pool*width+j for pool in range(4) for j in range(width) if j not in dropped]
        # Keep fragment count in every arm; remove only dependency/competition globals.
        cols += [4*width] if arm in ('no_structure_statistics','neither') else list(range(4*width,4*width+4))
        masks[arm] = cols
    protocol = dict(status='frozen_before_fit',seed=17,depths=[3,6],trees=200,learning_rate=.05,
                    train_samples=len(train),valid_samples=len(valid),stored_train_pairs=len(tp),
                    selection='Maximum equal-cohort macro pair accuracy, then minimum mean regret, then smaller depth.',
                    metric='Same-query latency gap >=3%; ties count wrong; historical/complex cohorts weighted equally.',
                    arms=masks,scope='Feature diagnostic only; full-feature XGBoost remains the acceptance comparator. No report90 labels used. One-seed pilot, no stability claim.',
                    caveat='Removing explicit interactions retains DOP-dependent competition statistics; removing structure statistics retains operator features. These are feature-block interventions, not removal of all DOP interactions or all structural information.',
                    source_sha256={str(p):file_sha256(p) for p in [Path(__file__),ROOT/'scripts/report90_models.py',ROOT/'scripts/report90_complex_retrain.py',ROOT/'autodop/graph.py',ROOT/'autodop/data.py',dataset/'samples.jsonl',dataset/'pairs.jsonl',dataset/'metadata.json',dataset/'CONTRACT.json']})
    save('PROTOCOL.json',protocol)
    save('STATUS.json',dict(status='running',stage='features',pid=os.getpid()))
    raw = {key(s):flat_features(build_graph(s,meta),meta) for s in samples}
    assert all(len(v)==1088 for v in raw.values())
    matrix = np.stack([raw[key(s)] for s in train])
    mean, std = matrix.mean(0), matrix.std(0)
    std[std<1e-6] = 1
    np.savez(out/'FEATURE_NORMALIZATION.npz',mean=mean,std=std)
    flat = {k:(v-mean)/std for k,v in raw.items()}
    xx, yy, groups, weights = xgb_rows(train,tp,flat,True)
    vx = np.stack([flat[key(s)] for s in valid])
    save('VALIDATION_ROWS.json',[{k:s[k] for k in ('plan_key','config_key','source_cohort','latency_ms')} for s in valid])
    results = []
    for arm, columns in masks.items():
        for depth in protocol['depths']:
            save('STATUS.json',dict(status='running',arm=arm,depth=depth,pid=os.getpid()))
            model = xgb.XGBRanker(objective='rank:pairwise',n_estimators=200,max_depth=depth,
                                  learning_rate=.05,n_jobs=1,random_state=17,tree_method='hist',
                                  subsample=1.,colsample_bytree=1.)
            begin = time.perf_counter()
            model.fit(xx[:,columns],yy,group=groups,sample_weight=weights)
            elapsed = time.perf_counter()-begin
            scores = model.predict(vx[:,columns])
            path = out/f'{arm}_d{depth}.ubj'
            model.save_model(path)
            restored = xgb.XGBRanker();restored.load_model(path)
            assert np.array_equal(scores,restored.predict(vx[:,columns]))
            q = validation(valid,scores)
            # Independent canonical pair enumeration, without calling report metrics.
            checks = {}
            for cohort in ('historical','complex_new'):
                correct = total = 0
                for i,a in enumerate(valid):
                    if a['source_cohort'] != cohort:continue
                    for j in range(i+1,len(valid)):
                        b = valid[j]
                        if a['plan_key'] != b['plan_key']:continue
                        if abs(a['latency_ms']-b['latency_ms'])/min(a['latency_ms'],b['latency_ms']) < .03:continue
                        total += 1
                        correct += int((float(scores[i])-float(scores[j]))*(b['latency_ms']-a['latency_ms'])>0)
                checks[cohort] = dict(correct=correct,total=total)
                assert total == q['cohorts'][cohort]['ranking_pairs']
                assert correct/total == q['cohorts'][cohort]['rank_accuracy']
            assert sum(v['total'] for v in checks.values())==920
            row = dict(arm=arm,depth=depth,features=len(columns),training_seconds=elapsed,
                       quality=q,independent_pair_counts=checks,scores=scores.tolist(),
                       checkpoint_sha256=file_sha256(path),exact_reload=True)
            results.append(row)
            save(f'{arm}_d{depth}.json',row)
            print(json.dumps({k:row[k] for k in ('arm','depth','features','training_seconds','independent_pair_counts')}),flush=True)
    selected = {arm:min([r for r in results if r['arm']==arm],key=lambda r:(-r['quality']['weighted_rank_accuracy'],r['quality']['weighted_regret'],r['depth'])) for arm in masks}
    save('RESULT.json',dict(status='verified',selected=selected,xgboost_version=xgb.__version__,protocol_sha256=file_sha256(out/'PROTOCOL.json'),scope=protocol['scope']))
    lines = ['# XGBoost 输入特征受控小测','',protocol['scope'],'',
             '| 特征组 | 维度 | 选定深度 | 两组等权排序准确率 |','|---|---:|---:|---:|']
    for arm,row in selected.items():
        lines.append(f"| {arm} | {row['features']} | {row['depth']} | {100*row['quality']['weighted_rank_accuracy']:.4f}% |")
    lines += ['', '每组使用相同数据、排序标签、训练权重、200棵树及深度3/6候选。验证集已被重复使用，不能作为盲测。',
              '', '移除显式DOP交互项后，竞争统计仍可能包含DOP信息；移除图统计后，算子类别等特征仍保留结构信息。',
              '', '全特征基线不变，不以削弱后的基线判断Transformer是否达标。每个模型均完成保存重载及920对独立重算。',
              '', '完整协议：[PROTOCOL.json](PROTOCOL.json)；结果：[RESULT.json](RESULT.json)。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    save('STATUS.json',dict(status='verified',models=len(results)))


if __name__=='__main__':main()
