"""Same frozen pilot, allowing bounded settling time before measurements."""
import hashlib
import json
from pathlib import Path

import report90_native_report_mixed_pilot as pilot
from report90_wait_for_idle import wait_for_idle


def main():
    original_check = pilot.check
    def checked(output):
        policy = dict(scope='Only pre-measurement idle checks differ; same 45% threshold. Six attempts, 10 seconds between busy checks. No query starts until the original gate passes.',
                      sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path(__file__).with_name('report90_wait_for_idle.py')]})
        (pilot.OUT/'IDLE_WAIT_POLICY.json').write_text(json.dumps(policy,indent=2)+'\n')
        wait_for_idle(original_check,output)
    pilot.check = checked
    pilot.main()


if __name__ == '__main__':main()
