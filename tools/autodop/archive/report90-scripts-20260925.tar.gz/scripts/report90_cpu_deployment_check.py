"""Read-only comparison of resolved Compose configuration and live experiment BEs."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

RUN = Path(__file__).resolve().parents[1] / 'runs/report90_20260912'
OUT = RUN / 'cpu_capacity_fix'
COMPOSE = Path('/home/shaokun/starrocks_deploy/docker-compose.yml')


def read_json(command):
    return json.loads(subprocess.check_output(command, text=True))


def check(expected_image, override=None):
    baseline = json.loads((OUT / 'DEPLOYMENT_BASELINE.json').read_text())
    command = ['docker', 'compose', '-p', 'starrocks_deploy', '-f', str(COMPOSE)]
    if override:
        command += ['-f', str(override)]
    resolved = read_json([*command, 'config', '--format', 'json'])
    assert set(resolved['services']) == {b['compose_service'] for b in baseline}
    records = []
    for b in baseline:
        service = resolved['services'][b['compose_service']]
        live = read_json(['docker', 'inspect', b['container']])[0]
        host = live['HostConfig']
        config = live['Config']
        assert live['State']['Running'] and live['Image'] == expected_image
        assert read_json(['docker', 'image', 'inspect', service['image']])[0]['Id'] == expected_image
        assert config['Labels']['com.docker.compose.project'] == b['compose_project']
        assert config['Labels']['com.docker.compose.service'] == b['compose_service']
        assert service['container_name'] == b['container']
        assert host['CpusetCpus'] == service['cpuset'] == b['cpuset']
        assert host['Memory'] == int(service['mem_limit']) == b['memory_limit']
        assert host['NetworkMode'] == service['network_mode'] == 'host'
        assert host['RestartPolicy']['Name'] == service['restart']
        assert config['Cmd'] == service['command']
        assert config['Hostname'] == service['hostname']
        normalize_caps = lambda values: {v.removeprefix('CAP_') for v in values}
        assert normalize_caps(host['CapAdd'] or []) == normalize_caps(service['cap_add'])
        limits = {v['Name']: {'soft': v['Soft'], 'hard': v['Hard']} for v in host['Ulimits']}
        assert limits == service['ulimits']
        env = dict(item.split('=', 1) for item in config['Env'])
        assert all(env.get(k) == str(v) for k, v in service['environment'].items())
        mounts = sorted((m['Type'], m['Source'], m['Destination']) for m in live['Mounts'])
        expected = sorted((m['type'], m['source'], m['destination']) for m in b['mounts'])
        composed = sorted((m['type'], m['source'], m['target']) for m in service['volumes'])
        assert mounts == expected == composed
        assert all(m['RW'] for m in live['Mounts'])
        conf = next(Path(m['source']) for m in b['mounts'] if m['destination'].endswith('/be.conf'))
        records.append({'container': b['container'], 'container_id': live['Id'],
                        'image_id': live['Image'], 'started_at': live['State']['StartedAt'],
                        'cpuset': b['cpuset'], 'memory_limit': b['memory_limit'],
                        'mounts': b['mounts'], 'config_sha256': hashlib.sha256(conf.read_bytes()).hexdigest()})
    return {'status': 'passed_read_only', 'at': datetime.datetime.now().astimezone().isoformat(),
            'expected_image': expected_image, 'containers': records,
            'compose_sha256': hashlib.sha256(COMPOSE.read_bytes()).hexdigest(),
            'override_sha256': hashlib.sha256(override.read_bytes()).hexdigest() if override else None,
            'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'scope': 'Image identity, running state and deployment settings; not FE health, SQL parity or CPU telemetry validation.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--image', required=True)
    parser.add_argument('--override', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists(), 'Preserve previous deployment evidence'
    result = check(args.image, args.override)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'containers': len(result['containers']), 'output': str(args.output)}))
