"""Read-only temporal audit of archived retry failures and BE metrics.

Fleet samples are not attributed to the failing worker. Scrape timestamps are
collector timestamps, not synchronized memory measurement timestamps.
"""
import collections
import datetime as dt
import hashlib
import json
import re
from pathlib import Path


RUN = Path(__file__).resolve().parents[1] / 'runs/report90_20260912/development17_retry'


def main():
    sources = [RUN / name for name in (
        'FAILURE_IDENTITY_AUDIT.json', 'FAILED_ATTEMPT_AUDIT_LINES.json',
        'DECISION_AUDIT.json', 'scored/events.jsonl', 'scored/decisions.jsonl',
        'scored/resources.jsonl')]
    read = lambda p: json.loads(p.read_text())
    identities = read(sources[0]); assert identities['status'] == 'verified'
    audit = read(sources[1])
    replay = read(sources[2]); assert replay['status'] == 'verified'
    decisions = {r['query_id']: r for r in replay['rows']}
    timestamp = lambda s: dt.datetime.fromisoformat(s).timestamp()
    requests = {r['query_id']: timestamp(r['at']) for r in
                map(json.loads, sources[4].read_text().splitlines())}
    failures = {}
    for event in map(json.loads, sources[3].read_text().splitlines()):
        for attempt in event['sql_attempts']:
            if attempt['status'] != 'failed':
                continue
            qid = attempt['failed_query_id_candidate']
            assert qid not in failures
            match = re.search(r'Used: (\d+), Limit: (\d+).*BE:(\d+)', attempt['error'])
            assert match, attempt['error']
            used, limit, worker = map(int, match.groups())
            assert used >= 0 and limit > 0
            failures[qid] = dict(error_used_bytes=used, error_limit_bytes=limit,
                                 error_worker_id=worker)
    assert failures.keys() == identities['failures'].keys() == audit.keys()
    limits = {r['error_limit_bytes'] for r in failures.values()}
    assert len(limits) == 1
    common_limit = limits.pop()
    samples = collections.defaultdict(list)
    for record in map(json.loads, sources[5].read_text().splitlines()):
        values = {}
        for metric in ('process_mem', 'query_mem'):
            match = re.search(r'^starrocks_be_' + metric + r'_bytes ([0-9.eE+\-]+)$',
                              record.get('prometheus_raw', ''), re.MULTILINE)
            if match:
                values[metric + '_bytes'] = float(match.group(1))
        if not values:
            continue  # FE metrics do not have BE memory counters.
        assert len(values) == 2
        samples[record['url']].append(dict(at=timestamp(record['at']), **values))
    assert len(samples) == 3
    for series in samples.values():
        assert all(a['at'] < b['at'] for a, b in zip(series, series[1:]))
    rows = []
    for qid, identity in identities['failures'].items():
        line = audit[qid]
        start = int(re.search(r'\|Timestamp=(\d+)\|', line)[1]) / 1000
        end = start + int(re.search(r'\|Time=(\d+)\|', line)[1]) / 1000
        logged = timestamp(line.split(' [query] ')[0])
        assert abs(logged - end) < .1
        request = requests.get(qid)
        if request is not None:
            assert start - .1 <= request <= end + .1
        pivot = request if request is not None else start
        per_url = {}
        for url, series in samples.items():
            previous = [s for s in series if s['at'] <= pivot]
            before = previous[-1] if previous else None
            during = [s for s in series if pivot <= s['at'] <= end]
            per_url[url] = {
                'previous_sample': before,
                'previous_age_seconds': pivot - before['at'] if before else None,
                'within_attempt_samples': len(during),
                'within_attempt_max_process_bytes': max(
                    (s['process_mem_bytes'] for s in during), default=None),
                'within_attempt_max_query_bytes': max(
                    (s['query_mem_bytes'] for s in during), default=None),
            }
        # A fleet comparison needs a recent sample from EVERY BE endpoint.
        recent = all(s['previous_age_seconds'] is not None and
                     s['previous_age_seconds'] <= 3 for s in per_url.values())
        before_max = max((s['previous_sample']['process_mem_bytes']
                          for s in per_url.values() if s['previous_sample']), default=None)
        within = [s['within_attempt_max_process_bytes'] for s in per_url.values()
                  if s['within_attempt_max_process_bytes'] is not None]
        d = decisions.get(qid, {})
        rows.append(dict(query_id=qid, **identity, **failures[qid], start_epoch=start,
                         end_epoch=end, decision_epoch=request,
                         decision_max_fresh_memory=d.get('max_fresh_memory'),
                         all_previous_samples_within_3_seconds=recent,
                         fleet_previous_max_fraction=before_max/common_limit if before_max else None,
                         fleet_within_sampled_max_fraction=max(within)/common_limit if within else None,
                         per_endpoint=per_url))
    groups = collections.defaultdict(collections.Counter)
    for row in rows:
        c = groups[(row['mode'], row['phase'])]; c['failures'] += 1
        c['all_previous_recent'] += row['all_previous_samples_within_3_seconds']
        c['sampled_during_attempt'] += row['fleet_within_sampled_max_fraction'] is not None
        low = row['decision_max_fresh_memory'] is not None and row['decision_max_fresh_memory'] <= .65
        c['request_memory_at_or_below_threshold'] += low
        recent = row['all_previous_samples_within_3_seconds']
        c['recent_fleet_already_above_threshold'] += recent and row['fleet_previous_max_fraction'] > .65
        c['low_request_but_recent_fleet_above_threshold'] += low and recent and row['fleet_previous_max_fraction'] > .65
        c['sampled_during_above_90pct'] += (row['fleet_within_sampled_max_fraction'] or 0) > .9
    summaries = [dict(mode=k[0], phase=k[1], **v) for k, v in sorted(groups.items())]
    limitations = [
        'Overlapping failures share fleet samples; rows are not independent observations.',
        'Collector scrape timestamps and FE audit timestamps are approximate alignment only.',
        'No endpoint-to-worker mapping is assumed; fleet maxima are not failing-worker measurements.',
        'All failure errors report the same limit; fractions use that observed limit, not container RAM.',
        'Sampled maxima are not true peaks. Prior samples older than 3 seconds are excluded from threshold comparisons.',
        'Some error messages report Used below Limit; error text memory is not assumed to be the trigger-time peak.',
        'No claim that memory growth belongs to this query, that smoothing caused failure, or failed DOP was installed.',
    ]
    result = dict(status='verified', scope='archived failed-attempt fleet resource timeline',
                  common_error_limit_bytes=common_limit, summaries=summaries, rows=rows,
                  limitations=limitations,
                  sources={str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                           for p in sources + [Path(__file__).resolve()]})
    dest = RUN / 'RESOURCE_TIMELINE_AUDIT.json'; assert not dest.exists()
    dest.write_text(json.dumps(result, indent=2) + '\n')
    lines = ['# 重试失败的资源时间线核对', '',
             '复用已归档执行记录，没有新增 SQL。阈值比较要求三个 BE 的前序采样均在请求前 3 秒内。', '',
             '| 模式 | 阶段 | 失败尝试 | 前序采样完整且较近 | 请求内存≤65% | 请求低但前序集群采样>65% | 执行期间采样>90% |',
             '|---|---|---:|---:|---:|---:|---:|']
    for r in summaries:
        lines.append(f"| {r['mode']} | {r['phase']} | {r['failures']} | {r['all_previous_recent']} | "
                     f"{r['request_memory_at_or_below_threshold']} | {r['low_request_but_recent_fleet_above_threshold']} | "
                     f"{r['sampled_during_above_90pct']} |")
    lines += ['', '以上为共享 BE 的采样，不能归因到单条查询，也不能当作真实峰值或证明平滑导致失败。',
              '原生模式无 AutoDOP 请求内存读数，相关计数为零不代表内存空闲。', '', *limitations]
    (RUN / 'RESOURCE_TIMELINE_AUDIT.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps(summaries, indent=2))


if __name__ == '__main__':
    main()
