"""Small matched pilot: preserve pretrained encoder with a 10x lower learning rate."""
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import torch
from autodop.model import load_cost_model
import report90_coverage_stability as common
from report90_neighborhood_prepare import RUN, sha

BASE = RUN / 'structure_coverage20'
OUT = BASE / 'encoder_lr_pilot'
SOURCE = BASE / 'statistical_readout_pilot/pilot_original_readout_trainer.py'
REFERENCE = BASE / 'statistical_readout_pilot/pilot_original_readout'

def main():
    os.sched_setaffinity(0, {34}); torch.set_num_threads(1)
    assert not OUT.exists(), 'Preserve previous experiment'
    assert common.read(REFERENCE / 'SCORE_REPLAY.json')['status'] == 'verified'
    for path, digest in common.read(REFERENCE / 'EXECUTION_SOURCE_SHA256.json').items():
        assert sha(Path(path)) == digest
    OUT.mkdir()
    protocol = {
        'hypothesis': 'Reduce pretrained encoder drift while adapting global readout and scorer to complex-query ranking.',
        'seed': 17, 'encoder_lr_multiplier': 0.1, 'readout_lr': 1e-4,
        'smoke_epochs': 2, 'pilot_epochs': 30,
        'design': 'Original multi-stage Transformer plus competition edges. Same calibration loss, original1365 train/212 valid,624pairs/epoch,batch16,cosine100 horizon. Only encoder learning-rate multiplier differs from matched original-readout reference. No new data, SQL, or report90 selection.',
        'selection': 'Fixed equal-cohort pair accuracy, regret tie-breaker, earliest epoch. Reused development validation, not blind testing.',
        'expansion_gate': 'Pilot macro accuracy must exceed both matched original-readout reference and XGBoost controls before further seeds/budget are considered.',
        'source_sha256': {str(p): sha(p) for p in [Path(__file__), SOURCE, REFERENCE/'RESULT.json', REFERENCE/'SCORE_REPLAY.json', Path(common.__file__)]},
    }
    common.save(OUT / 'PROTOCOL.json', protocol)
    for stage, epochs in [('smoke', 2), ('pilot', 30)]:
        folder = OUT / stage
        changes = {
            repr(str(REFERENCE)): repr(str(folder)),
            repr(str(BASE / 'statistical_readout_pilot/PROTOCOL.json')): repr(str(OUT / 'PROTOCOL.json')),
            'import json': 'import json\nimport math',
            'optimizer=torch.optim.Adam(model.parameters(),lr=lr)': "optimizer=torch.optim.Adam([{'params': model.encoder.parameters(), 'lr': lr*0.1}, {'params': list(model.global_readout.parameters())+list(model.scorer.parameters()), 'lr': lr}],lr=lr)",
            'scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=100,eta_min=1e-5)': 'scheduler=torch.optim.lr_scheduler.LambdaLR(optimizer,lr_lambda=lambda epoch: 0.1+0.9*(1+math.cos(math.pi*epoch/100))/2)',
            "'learning_rate':optimizer.param_groups[0]['lr']": "'learning_rate':optimizer.param_groups[1]['lr'],'encoder_learning_rate':optimizer.param_groups[0]['lr']",
        }
        if stage == 'smoke':
            changes.update({'range(1,31)': 'range(1,3)', 'epoch%10==0': 'epoch%1==0', 'n_estimators=200': 'n_estimators=5'})
        text = SOURCE.read_text(); applied = {}
        for old, new in changes.items():
            count = text.count(old)
            assert count == (2 if old in [repr(str(BASE / 'statistical_readout_pilot/PROTOCOL.json')), 'epoch%10==0'] else 1), (old, count)
            text = text.replace(old, new); applied[old] = {'replacement': new, 'occurrences': count}
        script = OUT / f'{stage}_trainer.py'; compile(text, str(script), 'exec'); script.write_text(text)
        common.save(OUT / f'{stage}_TRANSFORM.json', {'source_sha256': sha(SOURCE), 'generated_sha256': sha(script), 'changes': applied})
        common.save(OUT/'STATUS.json', {'status':'running','stage':stage,'pid':os.getpid()})
        with (OUT/f'{stage}.log').open('w') as stream:
            subprocess.run([sys.executable,str(script)],stdout=stream,stderr=subprocess.STDOUT,check=True)
        common.load_cost_model = load_cost_model
        replay = common.replay(folder)
        history = common.read(folder/'transformer_h0/RESULT.json')['history']
        assert all(abs(h['encoder_learning_rate']/h['learning_rate']-0.1)<1e-12 for h in history)
        print(stage, {k:v['weighted_rank_accuracy'] for k,v in replay.items()}, flush=True)
    score = replay['transformer']['weighted_rank_accuracy']
    reference = common.read(REFERENCE/'SCORE_REPLAY.json')['models']['transformer']['weighted_rank_accuracy']
    gate = score > reference and all(score>q['weighted_rank_accuracy'] for k,q in replay.items() if k!='transformer')
    common.save(OUT/'RESULT.json', {'status':'verified','models':replay,'reference_macro_accuracy':reference,
        'expansion_gate_passed':gate,'protocol_sha256':sha(OUT/'PROTOCOL.json')})
    common.save(OUT/'STATUS.json', {'status':'complete','expansion_gate_passed':gate})

if __name__=='__main__':
    try: main()
    except BaseException as error:
        if OUT.exists(): common.save(OUT/'STATUS.json', {'status':'failed','error':repr(error)})
        raise
