"""Read-only metrics sidecar; timestamps expose any incomplete cell coverage."""
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import time
import urllib.request


BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/distillation_concurrency_extension'


def main():
    os.sched_setaffinity(0,{36})
    endpoints=[f'http://127.0.0.1:{p}/metrics' for p in (8040,8041,8042,8030)]
    protocol=dict(status='started_after_first_cell_began',started_monotonic=time.monotonic(),
        started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),endpoints=endpoints,
        interval_seconds=5,timeout_seconds=3,scope='Read-only HTTP metrics; no SQL. Timestamp coverage must be reported, no backfill.',
        source_sha256={str(Path(__file__).resolve()):hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
    path=BASE/'RESOURCE_MONITOR_PROTOCOL.json'
    with path.open('x') as f:json.dump(protocol,f,indent=2)
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    deadline=time.monotonic()+5400;count=0;errors=0
    with gzip.open(BASE/'stream_resources.jsonl.gz','xt') as journal:
        while time.monotonic()<deadline:
            started=time.monotonic()
            for url in endpoints:
                record=dict(url=url,monotonic=time.monotonic())
                try:
                    with opener.open(url,timeout=3) as response:record['prometheus_raw']=response.read().decode()
                except Exception as exc:record['error']=repr(exc);errors+=1
                journal.write(json.dumps(record)+'\n');count+=1
            journal.flush()
            status=json.loads((BASE/'SEQUENCE_STATUS.json').read_text())['status']
            if status=='collected_and_audited' or (BASE/'SEQUENCE_FAILURE.json').exists():break
            time.sleep(max(.1,5-(time.monotonic()-started)))
    result=dict(status='finished',samples=count,errors=errors,finished_monotonic=time.monotonic(),
                protocol_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                samples_sha256=hashlib.sha256((BASE/'stream_resources.jsonl.gz').read_bytes()).hexdigest())
    (BASE/'RESOURCE_MONITOR_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__=='__main__':main()
