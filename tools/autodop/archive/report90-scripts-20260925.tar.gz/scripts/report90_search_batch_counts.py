"""Count logical candidate scores and importance encodings outside timed search runs."""
import json
import os
from pathlib import Path
import random
from unittest.mock import patch
import torch
from autodop import graph,mcts
from autodop.model import load_cost_model
from report90_search_refinement import search
from report90_batched_cost import score_batch
from report90_neighborhood_prepare import RUN,sha
OUT=RUN/'search_batch_cost'


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1)
    result=json.loads((OUT/'RESULT.json').read_text());assert result['status']=='verified_search_batch_cost'
    protocol=json.loads((OUT/'PROTOCOL.json').read_text())
    for p,d in protocol['source_sha256'].items():assert sha(Path(p))==d
    dev=RUN/'search_refinement_development';source=json.loads((dev/'PROTOCOL.json').read_text());vectors=json.loads((dev/'vectors.json').read_text())
    model,ck=load_cost_model(source['model']);model.eval();metadata=ck['metadata']
    namespace=dict(vars(graph));code=RUN/'graph_construction_pilot/competition_staged.py';exec(compile(code.read_text(),str(code),'exec'),namespace)
    counts={}
    def encoded(module,args,output):
        counts['encoder_calls']+=1;counts['logical_graph_encodings']+=int(args[0].shape[0]) if args[0].ndim==3 else 1
    def scored(module,args,output):counts['scorer_calls']+=1;counts['logical_candidate_scores']+=output.numel()
    handles=[model.encoder.input.register_forward_hook(encoded),model.scorer.register_forward_hook(scored)];records=[]
    try:
        with patch.object(graph,'_competition',namespace['_competition']),torch.inference_mode():
            for query in protocol['queries']:
                sample=graph.sample_from_request(vectors['refined_full'][query]['request']);sample['dop_config']=[1 if f.get('is_gather_root') else 4 for f in sample['fragments']]
                for mode in protocol['modes']:
                    counts.clear();counts.update(encoder_calls=0,logical_graph_encodings=0,scorer_calls=0,logical_candidate_scores=0)
                    if mode=='original_mcts':mcts.search(sample,model,metadata,iterations=64,seed=17)
                    elif mode=='refined_full':search(sample,model,metadata,budget=64,seed=17)
                    else:
                        domains=[graph.supported_dops(f,metadata['dop_classes']) for f in sample['fragments']];rng=random.Random(17);configs=[[rng.choice(d) for d in domains] for _ in range(64)]
                        if mode.endswith('_scalar'):
                            for cfg in configs:model(graph.build_graph({**sample,'dop_config':cfg},metadata))
                        else:
                            for i in range(0,64,16):score_batch(model,[graph.build_graph({**sample,'dop_config':cfg},metadata) for cfg in configs[i:i+16]])
                    assert counts['logical_candidate_scores']==64
                    assert counts['logical_graph_encodings']==(65 if mode in ['original_mcts','refined_full'] else 64)
                    assert counts['scorer_calls']==(4 if mode.endswith('_batch') else 64)
                    records.append({'query':query,'mode':mode,**counts})
    finally:
        for handle in handles:handle.remove()
    output={'status':'verified_search_candidate_accounting','records':records,'scope':'Forward hooks counted logical graphs/candidate outputs, not only Python call counts. Untimed diagnostic: both MCTS variants score64candidates plus1importance encoding; random variants score64candidates, batching groups them into4calls. NoSQL or deployment.','source_sha256':{str(p):sha(p) for p in [Path(__file__),OUT/'RESULT.json',OUT/'PROTOCOL.json',Path(__file__).with_name('report90_batched_cost.py')]}}
    p=OUT/'SCORING_COUNTS.json';assert not p.exists();p.write_text(json.dumps(output,indent=2)+'\n');print('verified64candidate outputs for16searches; MCTS includes one additional importance encoding')

if __name__=='__main__':main()
