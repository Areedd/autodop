"""Freeze extended-training choices in the existing common candidate pool."""
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from report90_models import RUN
from autodop.graph import build_graph, sample_from_request
from autodop.model import load_cost_model


def main():
    out = RUN / 'convergence_execution_20260913'
    out.mkdir(exist_ok=False)
    torch.set_num_threads(1)
    selection = json.loads((RUN / 'convergence_20260913/SELECTED.json').read_text())
    path = Path(selection['model'])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == selection['sha256']
    model, ck = load_cost_model(path)
    model.eval()
    reference = RUN / 'teacher_extension_20260913'
    rows = json.loads((reference / 'CHOICES_v2.json').read_text())
    originals = json.loads((reference / 'vectors_v2.json').read_text())
    vectors = {'extended_transformer_pool': {}, 'cost_xgb_rank': originals['cost_xgb_rank']}
    sources = {name: json.loads((RUN / name / 'vectors.json').read_text()) for name in {r['source'] for r in rows}}
    records = []
    for row in rows:
        query = row['id']
        request = sources[row['source']]['cost_transformer_rank'][query]['request']
        sample = sample_from_request(request)
        with torch.no_grad():
            scores = [float(model(build_graph({**sample, 'dop_config': config}, ck['metadata']))) for config in row['configs']]
        config = row['configs'][int(np.argmax(scores))]
        entry = {'request': request, 'fragment_dops': dict(zip(sample['fragment_ids'], config))}
        if query in vectors['extended_transformer_pool']:
            vectors['extended_transformer_pool'][query].setdefault('alternatives', []).append(entry)
        else:
            vectors['extended_transformer_pool'][query] = entry
        records.append({'id': query, 'source': row['source'], 'configs': row['configs'], 'scores': scores, 'selected_dops': config})
    assert all(len(v) == 90 for v in vectors.values())
    identical = sum(v['fragment_dops'] == vectors['cost_xgb_rank'][q]['fragment_dops']
                    for q, v in vectors['extended_transformer_pool'].items())
    protocol = {'scope': 'Validation-selected extended Transformer versus unchanged XGBoost within exactly the earlier common candidate pools. No test runtimes accessed by this script.',
                'selection': selection, 'queries': 90, 'query_plan_variants': len(records),
                'same_initial_plan_choices_as_xgb': identical,
                'pilot': 'Same fixed2queries,2modes,1warmup+1measured; all executions independently verified before expansion.',
                'formal': 'All90queries,2modes,1warmup+2measured; run sequentially after queue extension and before any BE replacement.',
                'interpretation': 'Model and validation-selection budget diagnostic. More validation checkpoints than original30 baseline; disclose budget. Does not prove all methods are inferior.',
                'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__), path, reference / 'CHOICES_v2.json', reference / 'vectors_v2.json', RUN / 'manifest.json']}}
    for name, data in [('PROTOCOL.json', protocol), ('vectors.json', vectors), ('CHOICES.json', records)]:
        (out / name).write_text(json.dumps(data, indent=2) + '\n')
    print(json.dumps({'queries': 90, 'plan_variants': len(records), 'identical_initial_choices': identical}))


if __name__ == '__main__':
    main()
