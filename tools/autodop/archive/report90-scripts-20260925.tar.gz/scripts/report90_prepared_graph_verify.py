"""Exact graph replay for every retained train/validation configuration."""
import json
import os
from pathlib import Path
import torch
from autodop import graph
from autodop.data import load_dataset
from report90_prepared_graph import PreparedGraph
from report90_neighborhood_prepare import RUN,sha


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1)
    out=RUN/'prepared_graph_verification';out.mkdir(exist_ok=False)
    dataset=RUN/'structure_coverage20/merged_dataset'
    samples,_,metadata=load_dataset(dataset)
    code=RUN/'graph_construction_pilot/competition_staged.py'
    namespace=dict(vars(graph));exec(compile(code.read_text(),str(code),'exec'),namespace)
    competition=namespace['_competition']
    sources=[Path(__file__),Path(__file__).with_name('report90_prepared_graph.py'),Path(graph.__file__),code,dataset/'samples.jsonl',dataset/'metadata.json']
    protocol=dict(scope='Cache per exact fragment/edge context, not merely plan_key. Recompute all DOP-dependent competition tensors. Returned static tensors cloned. No production or SQL changes.',source_sha256={str(p):sha(p) for p in sources})
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    caches={};checks=0
    for i,sample in enumerate(samples):
        identity=json.dumps({k:sample.get(k,[]) for k in ['fragments','edges']},sort_keys=True)
        if identity not in caches:caches[identity]=PreparedGraph(sample,metadata,competition)
        prepared=caches[identity]
        for unknown in [False,True]:
            actual=prepared.build(sample['dop_config'],unknown_dop=unknown)
            expected=graph.build_graph(sample,metadata,unknown_dop=unknown)
            assert actual.keys()==expected.keys()
            for k,v in expected.items():
                assert torch.equal(actual[k],v) if isinstance(v,torch.Tensor) else actual[k]==v,(i,unknown,k)
                checks+=1
            # A consumer mutation must not poison cached tensors.
            actual['numerical'].fill_(123)
            assert torch.equal(prepared.build(sample['dop_config'],unknown_dop=unknown)['numerical'],expected['numerical'])
        if (i+1)%400==0:print(i+1,flush=True)
    for path,digest in protocol['source_sha256'].items():assert sha(Path(path))==digest
    result=dict(status='verified_exact_graph_cache',samples=len(samples),contexts=len(caches),modes=['known','unknown'],field_checks=checks,returned_tensor_isolation=True,protocol_sha256=sha(out/'PROTOCOL.json'),scope=protocol['scope'])
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    (out/'REPORT.md').write_text('# 查询静态图特征缓存核验\n\n'+f"覆盖{len(samples)}个训练/验证配置、{len(caches)}个精确fragment/edge上下文，已知及未知DOP两种模式全部字段与原构图函数逐值一致；共{checks}项字段检查。返回数值张量被修改后，再构图也不受影响。\n\n这是实验适配器的正确性核验，尚未测量搜索成本，也未接入生产。竞争矩阵仍逐候选重算；缓存不能按plan_key跨不同请求特征复用。\n\n[结果](RESULT.json)、[协议](PROTOCOL.json)。\n")
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
