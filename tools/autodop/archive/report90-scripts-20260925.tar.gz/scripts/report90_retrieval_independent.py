"""Development-gated full-workload retrieval timing with independent reference targets."""
import argparse
import hashlib
import json
import os
import random
import time
from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch

from autodop import graph, mcts
from autodop.model import load_cost_model
from report90_batched_cost import score_batch
from report90_prepared_graph import PreparedGraph
from report90_search_refinement import search

RUN = Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    os.sched_setaffinity(0, {34})
    torch.set_num_threads(1)
    parser = argparse.ArgumentParser()
    parser.add_argument('--scope', choices=['development','report90'], required=True)
    args = parser.parse_args()
    suffix = 'search_refinement_development' if args.scope == 'development' else 'search_refinement_report90'
    out = RUN/('retrieval_independent_' + args.scope)
    out.mkdir(exist_ok=False)
    prior_path = RUN/suffix/'PROTOCOL.json'
    prior = json.loads(prior_path.read_text())
    vp = prior_path.parent/'vectors.json'
    vectors = json.loads(vp.read_text())
    screen_path = RUN/'retrieval_timing_pilot/RESULT.json'
    assert json.loads(screen_path.read_text())['status'] == 'verified_timed_traces'
    # Reference distribution uses a separate fixed random seed and is prepared
    # before any timed search. Reference scoring cost is not algorithm cost.
    reference_seed = 2026091477
    reference_model, reference_ck = load_cost_model(prior['model'])
    reference_model.eval()
    reference_meta = reference_ck['metadata']
    reference_code = RUN/'graph_construction_pilot/competition_staged.py'
    reference_ns = dict(vars(graph))
    exec(compile(reference_code.read_text(),str(reference_code),'exec'),reference_ns)
    targets, pools, reference_rows = {}, {}, []
    (out/'REFERENCE_PROTOCOL.json').write_text(json.dumps(dict(
        queries=prior['queries'],seed=reference_seed,candidates=256,
        quantiles=[.9,.95,1.],scope='Independent random reference stream, fixed before timed search. Finite empirical score distribution, not global optimum.',
        source_sha256={str(p):sha(p) for p in [Path(__file__),prior_path,vp,Path(prior['model']),reference_code]}),indent=2)+'\n')
    with patch.object(graph,'_competition',reference_ns['_competition']),torch.inference_mode():
        for qi,q in enumerate(prior['queries']):
            rs = graph.sample_from_request(vectors['refined_full'][q]['request'])
            rs['dop_config'] = [1 if f.get('is_gather_root') else 4 for f in rs['fragments']]
            prepared = PreparedGraph(rs,reference_meta,reference_ns['_competition'])
            domains = [graph.supported_dops(f,reference_meta['dop_classes']) for f in rs['fragments']]
            rng = random.Random(reference_seed)
            configs = [[rng.choice(d) for d in domains] for _ in range(256)]
            scores=[]
            for i in range(0,256,16):
                scores.extend(score_batch(reference_model,[prepared.build(c) for c in configs[i:i+16]]).tolist())
            unique={tuple(c):float(v) for c,v in zip(configs,scores)}
            pools[q]=sorted(unique.values())
            targets[q]={str(t):float(np.quantile(pools[q],t,method='higher')) for t in [.9,.95,1.]}
            reference_rows.append(dict(query=q,configs=configs,scores=scores,unique=len(unique)))
            if (qi+1)%10==0: print('Reference queries',qi+1,flush=True)
    (out/'REFERENCE.json').write_text(json.dumps(reference_rows)+'\n')
    modes = ['original_mcts', 'refined', 'no_attention', 'no_equivalence', 'random_scalar', 'random_batch']
    code = RUN/'graph_construction_pilot/competition_staged.py'
    model_path = Path(prior['model'])
    sources = [Path(__file__), prior_path, vp, screen_path, out/'REFERENCE_PROTOCOL.json',out/'REFERENCE.json', code, model_path,
               Path(graph.__file__), Path(mcts.__file__),
               Path(__file__).with_name('report90_prepared_graph.py'),
               Path(__file__).with_name('report90_batched_cost.py'),
               Path(__file__).with_name('report90_search_refinement.py')]
    protocol = dict(queries=prior['queries'], seeds=[17,29,43], modes=modes,
        budget=64, warmups_per_query_mode=1, timed_rounds_per_seed=1, batch_size=16,
        targets=targets, reference_score_pools=pools,
        scope='All frozen queries for selected scope. Independent256-candidate random reference per query, prepared before timing; not a global optimum. Three search seeds, one timed run each, warmup once per query/method. All methods share optimized graph/cache; includes cache setup, importance and trace instrumentation. No SQL, model training, deployment, HTTP or FE timing. Batch results and charges available only after full batch.',
        source_sha256={str(p):sha(p) for p in sources})
    (out/'PROTOCOL.json').write_text(json.dumps(protocol, indent=2)+'\n')
    model, ck = load_cost_model(model_path)
    model.eval()
    meta = ck['metadata']
    namespace = dict(vars(graph))
    exec(compile(code.read_text(), str(code), 'exec'), namespace)
    optimized = namespace['_competition']
    original_bindings = (graph._competition, graph.build_graph, mcts.build_graph,
                         mcts.attention_guided_groups, mcts.equivalence_groups)

    def natural(s, mdl, metadata, candidates, device='cpu'):
        return mcts.equivalence_groups(s, candidates)

    def individual(s, candidates):
        return [(i,) for i in range(len(candidates))]

    results = []
    with patch.object(graph, '_competition', optimized), torch.inference_mode():
        for qi, q in enumerate(prior['queries']):
            sample = graph.sample_from_request(vectors['refined_full'][q]['request'])
            sample['dop_config'] = [1 if f.get('is_gather_root') else 4 for f in sample['fragments']]

            def run(mode, seed):
                start = time.perf_counter_ns()
                prepared = PreparedGraph(sample, meta, optimized)
                trace = []
                last_config = None
                importance_calls = 0

                def elapsed():
                    return (time.perf_counter_ns()-start)/1e6

                def build(s, metadata, unknown_dop=False, device='cpu'):
                    nonlocal last_config
                    assert metadata is meta and s['fragments'] is sample['fragments']
                    last_config = list(s['dop_config'])
                    return prepared.build(last_config, unknown_dop, device)

                class Counted:
                    def eval(self):
                        return self

                    def fragment_importance(self, g):
                        nonlocal importance_calls
                        importance_calls += 1
                        return model.fragment_importance(g)

                    def __call__(self, g):
                        value = model(g)
                        score = float(value)
                        trace.append(dict(config=list(last_config), score=score,
                                          available_ms=elapsed(), evaluations=len(trace)+1))
                        return value

                counted = Counted()
                with patch.object(graph, 'build_graph', build), patch.object(mcts, 'build_graph', build):
                    if mode == 'original_mcts':
                        config, score = mcts.search(sample, counted, meta, iterations=64, seed=seed)
                    elif mode.startswith('random'):
                        domains = [graph.supported_dops(f, meta['dop_classes']) for f in sample['fragments']]
                        rng = random.Random(seed)
                        configs = [[rng.choice(d) for d in domains] for _ in range(64)]
                        if mode == 'random_scalar':
                            for config in configs:
                                counted(build({**sample,'dop_config':config}, meta))
                        else:
                            for i in range(0,64,16):
                                gs = [build({**sample,'dop_config':c}, meta) for c in configs[i:i+16]]
                                scores = score_batch(model, gs).tolist()
                                now = elapsed()
                                trace.extend(dict(config=list(c), score=float(s), available_ms=now,
                                                  evaluations=i+16) for c,s in zip(configs[i:i+16], scores))
                        best = max(trace, key=lambda r:r['score'])
                        config, score = best['config'], best['score']
                    else:
                        if mode == 'no_attention':
                            with patch.object(mcts, 'attention_guided_groups', natural):
                                value = search(sample, counted, meta, budget=64, seed=seed)
                        elif mode == 'no_equivalence':
                            with patch.object(mcts, 'equivalence_groups', individual):
                                value = search(sample, counted, meta, budget=64, seed=seed)
                        else:
                            value = search(sample, counted, meta, budget=64, seed=seed)
                        config, score = value['config'], value['score']
                total_ms = elapsed()
                assert len(trace) == 64 and score == max(t['score'] for t in trace)
                assert config == next(t['config'] for t in trace if t['score'] == score)
                assert all(t['available_ms'] <= total_ms for t in trace)
                assert all(a['available_ms'] <= b['available_ms'] for a,b in zip(trace,trace[1:]))
                return dict(query=q, method=mode, seed=seed, config=config, score=score,
                            total_ms=total_ms, importance_calls=importance_calls, trace=trace)

            warm = {mode:run(mode,17) for mode in modes}
            references = {}
            for si, seed in enumerate(protocol['seeds']):
                for ri in range(1):
                    shift = (qi+si+ri) % len(modes)
                    order = modes[shift:]+modes[:shift]
                    if (qi+si) % 2:
                        order = order[::-1]
                    for position, mode in enumerate(order):
                        value = run(mode,seed)
                        sequence = [(t['config'],t['score']) for t in value['trace']]
                        key = (mode,seed)
                        if key in references:
                            assert sequence == references[key]
                        else:
                            references[key] = sequence
                        if seed == 17:
                            assert sequence == [(t['config'],t['score']) for t in warm[mode]['trace']]
                        value.update(round=ri,position=position)
                        results.append(value)
                scalar, batched = references[('random_scalar',seed)], references[('random_batch',seed)]
                assert [c for c,s in scalar] == [c for c,s in batched]
                np.testing.assert_allclose([s for c,s in scalar],[s for c,s in batched],rtol=1e-6,atol=1e-6)
            (out/'PARTIAL.json').write_text(json.dumps(results)+'\n')
            print(f'{q}: {len(results)}/{len(prior["queries"])*18} timed searches complete', flush=True)
    assert original_bindings == (graph._competition, graph.build_graph, mcts.build_graph,
                                 mcts.attention_guided_groups, mcts.equivalence_groups)
    for p,d in protocol['source_sha256'].items():
        assert sha(Path(p)) == d
    assert len(results) == len(prior['queries'])*18
    (out/'RESULT.json').write_text(json.dumps(dict(status='verified_timed_traces',
        timed_searches=len(results), warmup_searches=len(prior['queries'])*6, module_bindings_restored=True,
        rows=results, protocol_sha256=sha(out/'PROTOCOL.json')), indent=2)+'\n')
    print('Completed',len(results),'timed searches; warmup parity and scalar/batch scores verified; no SQL or production changes.')


if __name__ == '__main__':
    main()
