"""Organize verified report material into a readable main report, retaining appendices."""
from pathlib import Path
import hashlib,json

RUN=Path(__file__).resolve().parents[1]/'runs/report90_20260912'

def section(text,title):
    key='## '+title+'\n'
    assert text.count(key)==1,title
    body=text.split(key,1)[1]
    return body.split('\n## ',1)[0].strip()

def main():
    final=RUN/'FINAL_REPORT.md'
    closeout=RUN/'FINAL_DELIVERY.json'
    if final.exists() and closeout.exists():
        state=json.loads(closeout.read_text())
        if state.get('status')=='completed_current_report_experiment_scope':
            assert hashlib.sha256(final.read_bytes()).hexdigest()==state['report_sha256']
            out=RUN/'MAIN_REPORT.md'
            out.write_text(final.read_text())
            (RUN/'MAIN_REPORT.sources.json').write_text(json.dumps(dict(
                status='current_report_scope_complete',scope=state['scope'],
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),final,closeout]},
                output_sha256=hashlib.sha256(out.read_bytes()).hexdigest()),indent=2)+'\n')
            print(out)
            return
    source=RUN/'FULL_REPORT.md';text=source.read_text()
    lines=['# AutoDOP 异构查询实验报告（交付草稿）','',
           '状态：主要性能、模型/搜索对照及成本测量已有结果；并发机制诊断仍在进行，尚未完成最终交付验收。主体集中呈现实验结论，完整过程和未通过的诊断保留在附录，不以省略对照改变结论。','',
           '## 1. 目标与实验口径','',
           '验证异构 fragment DOP 相对查询级统一 DOP 的收益，评估成本模型、搜索和策略阶段的贡献，并测量并发性能及调优成本。整体方法的端到端收益与单个组件的增量收益分别判断。','',
           section(text,'实验范围与方法'),'','## 2. 查询集与结构覆盖','',section(text,'查询结构'),'',
           '90条查询来自历史200条中的优势筛选子集。它适合描述该异构查询集合上的效果，不代表无偏任意SQL测试。结构签名数量不等于独立业务场景或统计独立样本。','',
           '## 3. 端到端性能及结构分组','',section(text,'单查询性能'),'',section(text,'结构分组结果'),'',
           '## 4. 成本模型、搜索和策略对照','',section(text,'模型与搜索消融'),'',
           '### 多阶段模型和训练预算复核','',section(text,'原多阶段成本模型复核'),'',section(text,'延长训练预算后的同期模型对照'),'',
           '原部署多阶段模型、从头训练30轮模型和延长训练模型具有不同训练过程，不混成一个Transformer结果。已有策略阶段对照不等价于删除整个蒸馏过程。历史多阶段训练属于实现与训练来源说明，不作为论文核心方法，也不再要求逐历史阶段重训消融；实际初始化、数据和训练成本仍须披露。','',
           '## 5. 并发性能与资源预算','',
           '以下完整90查询对照使用修正后的BE及checkpoint隔离FE，与主串行实验的原BE结果分开解释。统一4预算代表并发资源预留基线，不是统一DOP4。','',
           section(text,'完整90查询的原生预算并发对照'),'',
           '### 并发度扩展与失败记录','',
           '不同并发度的完整指标、原始过载与重试记录见 [详细并发结果](FULL_REPORT.md#并发性能) 和 [补充实验](EXTENSION_SUMMARY.md)。不能用成功请求的延迟替代吞吐和失败率，也不能把不同容量设置的结果拼成同一扩展曲线。','',
           '### 机制诊断进度','',
           'FIFO和整数取整小测未显示一致改善；实际时序诊断已完成128次查询及387条事件。当前继续检验相反到达顺序，两种顺序全部保留。带日志诊断不替代正式性能结果。详见 [槽位取整](native_rounding_comparison/REPORT.md)、[时间分解](native_rounding_timing_diagnostic/REPORT.md)、[队列生命周期](native_queue_timeline_summary/REPORT.md)。','',
           '## 6. 调优和训练成本','',
           '| 范围 | 实测值 | 解释 |','|---|---:|---|',
           '| FE controller | 平均18.007 ms，p99 36.408 ms | 180次正式计时，含回退 |',
           '| FE controller / 查询总延迟 | 1.104% | 分母不是优化器时间 |',
           '| 完整教师搜索 | 平均921.862 ms | 原主实验270次；与离线配置回放延迟分开 |',
           '| 30个成本模型候选累计训练 | 631.45 s | 不代表单个模型成本 |',
           '| 训练进程峰值RSS | 921.63 MiB | 整个进程的高水位 |',
           '| 策略训练微测 | 平均0.4109 s/轮 | 130个历史训练计划，不能代替历史完整训练时长 |','',
           '特征构建、模型推理、HTTP调用、FE阶段等计时来自不同测量范围，不能直接相加。详细逐模型、逐阶段和内存口径见 [成本附录](FULL_REPORT.md#调优与训练成本)。','',
           '## 7. 正确性、复现与证据','',section(text,'复现与证据'),'',
           '查询多重集摘要、SQL哈希、模型版本、实际DOP安装、预算回调和槽位释放均按相应实验核验。修复、重试和服务恢复证据保留；一个阶段通过不代表其他阶段或所有历史结果已自动通过。','',
           '## 8. 结论、适用范围与剩余验收','',
           '在冻结的优势查询集合上，异构DOP相对最佳候选统一DOP的平均延迟降低23.83%，82/90条获益。完整并发对照也支持异构平均性能收益，但资源预测预算存在尾延迟代价。成本模型和完整搜索尚未证明全面优于替代方案。','',
           '最终收尾仍包括当前并发诊断、最终配置冻结及证据索引复核。若交付还要求合同标准验收，TP优化器开销、TPCH SF100优化器开销及streams 7–20标准throughput均需独立补测；现有90条实验不能替代这些要求。12小时目标已经超时，不据此改变验收口径。','',
           '附录入口：[完整实验记录](FULL_REPORT.md)、[交付范围审计](DELIVERY_SCOPE_AUDIT.md)、[复现说明](REPRODUCE.md)。','']
    arrival=RUN/'native_arrival_comparison/RESULT.json'
    if arrival.exists():
        r=json.loads(arrival.read_text());assert r['executions']==256
        lines=[s.replace('当前继续检验相反到达顺序，两种顺序全部保留。','相反到达顺序256次诊断已完成，实际入队顺序通过核验。小槽位查询先到时，预测预算使异构平均延迟降低11.78%；相反顺序下增加15.34%，未显示顺序无关的稳定收益。全程计划/DOP检查未通过，正式阶段按查询一致。详见 [顺序对照](native_arrival_comparison/REPORT.md)。') for s in lines]
    additions=[]
    for title in ['原生时长排序并发开发小测','有界时长排序并发开发小测']:
        if '## '+title+'\n' in text:
            additions += ['### '+title,'',section(text,title),'']
    index=lines.index('## 6. 调优和训练成本')
    lines[index:index]=additions
    title='策略最终训练阶段受控消融'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        body=section(text,title).replace('\n### ', '\n#### ')
        lines[index:index]=['### '+title,'',body,'']
        lines=[s.replace('并发机制诊断仍在进行', '策略最终训练阶段对照正在补齐，既有并发诊断已保留')
               .replace('最终收尾仍包括当前并发诊断、最终配置冻结及证据索引复核。',
                        '最终收尾仍包括策略训练阶段在线对照、最终配置冻结及证据索引复核。') for s in lines]
        if (RUN/'policy_final_stage_ablation/online_full/SUMMARY.json').exists():
            lines=[s.replace('策略最终训练阶段对照正在补齐，既有并发诊断已保留',
                             '策略最终训练阶段对照已完成，成本模型排序和搜索调优仍在进行')
                   .replace('最终收尾仍包括策略训练阶段在线对照、最终配置冻结及证据索引复核。',
                            '后续仍需完成按排序准确率选模的成本模型对照、搜索调优验证、最终配置冻结及证据索引复核。') for s in lines]
    title='搜索改进开发小测'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='八条开发查询的搜索汇总'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='按排序准确率选模的完整模型对照'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='准确率选模后在报告查询集上的复核'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='九十条查询的搜索开销'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='图构造开销优化验证'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='九十条查询的正式搜索对照'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='搜索评分与实际延迟的一致性'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='交互特征模型三种子复核'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='分数间距校准模型排序复核'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='匹配训练方式小测'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='错对强化与权重平均复核'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='固定三检查点分数平均诊断'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='固定特征残差结构小测'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='训练配置覆盖诊断'
    if '## '+title+'\n' in text:
        index=lines.index('## 5. 并发性能与资源预算')
        lines[index:index]=['### '+title,'',section(text,title),'']
    title='候选批量评分成本'
    if '## '+title+'\n' in text:
        index=lines.index('## 7. 正确性、复现与证据')
        lines[index:index]=['### '+title,'',section(text,title),'']
    for title in ['XGBoost输入特征诊断', '基础与增强输入对照', '基础特征对照三种子复核', 'MLP显式DOP交互项对照', 'MLP交互项同预算100轮复核', 'MLP交互项三种子复核', '树教师软排序蒸馏', '策略历史训练链可恢复性']:
        if '## '+title+'\n' in text:
            insert = lines.index('## 5. 并发性能与资源预算')
            lines[insert:insert] = ['### '+title, '', section(text,title), '']
    if '## 搜索候选预算筛查\n' in text:
        insert = lines.index('## 7. 正确性、复现与证据')
        lines[insert:insert] = ['### 搜索候选预算筛查', '', section(text,'搜索候选预算筛查'), '']
    if '## 搜索预算SQL小测\n' in text:
        insert = lines.index('## 7. 正确性、复现与证据')
        lines[insert:insert] = ['### 搜索预算SQL小测', '', section(text,'搜索预算SQL小测'), '']
    if '## 查询静态特征缓存成本\n' in text:
        insert = lines.index('## 7. 正确性、复现与证据')
        lines[insert:insert] = ['### 查询静态特征缓存成本', '', section(text,'查询静态特征缓存成本'), '']
    if '## 全部90查询搜索预算对照\n' in text:
        insert = lines.index('## 7. 正确性、复现与证据')
        lines[insert:insert] = ['### 全部90查询搜索预算对照', '', section(text,'全部90查询搜索预算对照'), '']
    if (RUN/'PAPER_EXPERIMENT_SCOPE.md').exists():
        lines[lines.index('## 2. 查询集与结构覆盖'):lines.index('## 2. 查询集与结构覆盖')] = ['实验模块与最新完成口径见 [论文实验范围](PAPER_EXPERIMENT_SCOPE.md)。历史训练链消融不列入必需补测。', '']
    if '## 全量搜索预算评分诊断\n' in text:
        insert = lines.index('## 7. 正确性、复现与证据')
        lines[insert:insert] = ['### 全量搜索预算评分诊断', '', section(text,'全量搜索预算评分诊断'), '']
        lines[2] = '状态：90条查询的端到端、模型与特征对照、搜索、并发和成本均已有测量；最新720次搜索预算执行已完成。搜索按最新要求以候选检索效率为主，平均SQL执行延迟不再作为硬性领先条件。历史多阶段训练不再作为必需消融，实际训练来源仍披露。'
        lines = [s.replace('后续仍需完成按排序准确率选模的成本模型对照、搜索调优验证、最终配置冻结及证据索引复核。',
                           '模型与特征对照及最新搜索预算验证已完成；搜索改为评价共同质量目标的命中率、评分次数及实际耗时。剩余工作按论文实验范围执行，最终配置和证据索引仍须冻结复核。') for s in lines]
    if (RUN/'retrieval_efficiency/REPORT.md').exists():
        insert = lines.index('## 5. 并发性能与资源预算')
        lines[insert:insert] = ['### 搜索检索效率（当前主要评价）', '', '共同经验候选池评分第95百分位目标下，64次评分内改进搜索命中11/12组开发测试，随机命中3/12；第90百分位分别12/12与4/12。此结果支持候选评分检索效率，不是全局最优或SQL延迟保证。达到目标的实际耗时尚待逐步计时，不能由评分次数推算。详见 [全部阈值与失败记录](retrieval_efficiency/REPORT.md)。', '']
    if '## 检索效率与实际命中耗时\n' in text:
        insert = lines.index('## 5. 并发性能与资源预算')
        lines[insert:insert] = ['### 检索效率与实际命中耗时', '', section(text,'检索效率与实际命中耗时'), '']
        lines = [s.replace('达到目标的实际耗时尚待逐步计时，不能由评分次数推算。',
                           '已补充包含构图及缓存初始化的逐步实际计时，见下文检索效率小测；未用评分次数推算耗时。') for s in lines]
    out=RUN/'MAIN_REPORT.md';out.write_text('\n'.join(lines))
    (RUN/'MAIN_REPORT.sources.json').write_text(json.dumps(dict(status='draft',scope='Editorial extraction; no new performance measurement or completion claim',source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),source]},output_sha256=hashlib.sha256(out.read_bytes()).hexdigest()),indent=2)+'\n')
    print(out)

if __name__=='__main__':main()
