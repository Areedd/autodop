"""Corroborate failed-query ID candidates against FE audit lines, with no data writes."""
import json
import os
import time
import uuid
from pathlib import Path
import pymysql
from autodop.training import file_sha256
from report90_execute import RUN
from report90_failure_capture import fetch_timed


def main():
    out = RUN / 'failure_capture_smoke'; assert not out.exists()
    os.sched_setaffinity(0, {34}); out.mkdir()
    audit = RUN.parents[3] / 'output/fe/log/fe.audit.log'
    offset = audit.stat().st_size
    connection = pymysql.connect(host='127.0.0.1', port=9030, user='root', autocommit=True,
                                 connect_timeout=10, read_timeout=20)
    events = []
    try:
        cursor = connection.cursor(); cursor.execute('SET enable_auto_dop=false')
        for _ in range(2):
            token = 'autodop_failure_capture_' + uuid.uuid4().hex
            event = {'token': token}
            statement = 'SELECT `' + token + '` FROM (SELECT 1 AS present_column) t'
            try:
                fetch_timed(cursor, statement, event)
                raise AssertionError('Expected missing-column SQL error')
            except pymysql.MySQLError as error:
                event['original_error'] = str(error)
            assert 'failed_query_id_candidate' in event and 'query_id' not in event
            events.append(event)
        assert len({e['failed_query_id_candidate'] for e in events}) == 2
    finally:
        connection.close()
    (out / 'EVENTS.json').write_text(json.dumps(events, indent=2) + '\n')
    matches = []
    for attempt in range(20):
        with audit.open() as stream:
            stream.seek(offset); lines = stream.readlines()
        matches = [line.rstrip() for line in lines if any(e['token'] in line for e in events)]
        if all(any(e['token'] in line and e['failed_query_id_candidate'] in line for line in matches) for e in events):
            break
        time.sleep(.25)
    else:
        raise AssertionError('Failed ID candidates not corroborated by FE audit; retain events')
    (out / 'AUDIT_LINES.json').write_text(json.dumps(matches, indent=2) + '\n')
    result = {'status': 'verified', 'expected_errors': 2, 'candidate_ids_corroborated': 2,
              'scope': 'Analyzer-error smoke only. Does not establish OOM/connection-loss capture; no workload timings or AutoDOP performance claim.',
              'source_sha256': {str(p): file_sha256(p) for p in [Path(__file__), Path(__file__).with_name('report90_failure_capture.py'), out / 'EVENTS.json', out / 'AUDIT_LINES.json']}}
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n'); print(json.dumps(result))


if __name__ == '__main__': main()
