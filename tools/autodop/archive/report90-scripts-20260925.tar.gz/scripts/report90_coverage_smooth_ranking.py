"""Compare smooth dynamic-margin ranking with hinge, unchanged graph Transformer."""
import argparse
import datetime
import os
from pathlib import Path
import subprocess
import sys
import torch
from autodop.training import file_sha256
from report90_coverage_choices import BASE, read
import report90_coverage_stability as common

OUT=BASE/'smooth_ranking'


def main(stage):
    os.sched_setaffinity(0,{35});torch.set_num_threads(1)
    if stage=='pilot':
        assert not OUT.exists()
        assert read(BASE/'margin_signal_audit/RESULT.json')['status']=='verified'
        OUT.mkdir()
        common.save(OUT/'PROTOCOL.json',{
            'at':datetime.datetime.now().astimezone().isoformat(),'seeds':[17,29,43],'epochs':100,'pilot_epochs':2,
            'loss':'Softplus(log(slow_latency/fast_latency)-fast_score+slow_score), fixed temperature1. Replace hinge only; retain dynamic margin and score direction.',
            'unchanged':'Original multistage weights, Transformer with competition edges, existing batch-specific training pairs, uniform cohort/plan/pair sampling624/epoch, batch16, zero preservation weight, cosine1e-4 to1e-5 over100 epochs, validation every10 epochs.',
            'primary_metric':'Per-cohort pairwise ranking accuracy averaged equally across historical and complex development cohorts. Existing metrics pair eligibility and tie handling unchanged. Report both cohorts separately. All model candidates use accuracy-first selection; regret is a secondary tie breaker.',
            'user_amendment':'Transformer acceptance prioritizes pairwise ranking accuracy, without required SQL timing. This development experiment does not itself establish independent test superiority or cover MLP/regression controls, which remain required.',
            'hypothesis':'Keep gradient beyond the hinge boundary and test candidate-choice generalization. Zero hinge gradients are expected behavior, not an implementation defect. Benefit remains unproven.',
            'scope':'Development smooth-ranking loss comparison. No report90 labels used in fitting, no seed selection, no automatic SQL expansion or model deployment.',
            'source_sha256':{str(p):file_sha256(p) for p in [Path(__file__),Path(common.__file__),common.SOURCE,
                BASE/'margin_signal_audit/RESULT.json',BASE/'cosine_decay/RESULT.json',BASE/'top_sampling/COMPARISON.json']}})
    protocol=read(OUT/'PROTOCOL.json')
    for p,h in protocol['source_sha256'].items():assert file_sha256(p)==h
    if stage=='full':assert read(OUT/'seed17_pilot/SCORE_REPLAY.json')['status']=='verified'
    common.OUT=OUT
    seeds=[17] if stage=='pilot' else protocol['seeds']
    for seed in seeds:
        name=f'seed{seed}'+('_pilot' if stage=='pilot' else '')
        folder=OUT/name;assert not folder.exists()
        source,changes=common.staged_source(seed,folder,stage=='pilot')
        replacements={
            '\ndef main():':'\ndef order(q):\n    return -q["weighted_rank_accuracy"],q["weighted_regret"]\n\ndef main():',
            'model,_=load_cost_model(warm);optimizer=torch.optim.Adam(model.parameters(),lr=lr)':
                'model,_=load_cost_model(warm);optimizer=torch.optim.Adam(model.parameters(),lr=lr)\n        scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=100,eta_min=1e-5)',
            "entry={'epoch':epoch,'loss':float(np.mean(losses))}":
                "entry={'epoch':epoch,'loss':float(np.mean(losses)),'learning_rate':optimizer.param_groups[0]['lr']}\n            scheduler.step()",
            "ranking.append(dynamic_margin_ranking_loss(a,b,pair['fast_latency_ms'],pair['slow_latency_ms']))":
                "target=a.new_tensor(np.log(pair['slow_latency_ms']/pair['fast_latency_ms']))\n                    ranking.append(torch.nn.functional.softplus(target-a+b))",
            "gate=all(t['weighted_regret']<=c['selected']['validation']['weighted_regret'] and\n             t['cohorts']['complex_new']['mean_regret']<=c['selected']['validation']['cohorts']['complex_new']['mean_regret']":
                "gate=all(t['weighted_rank_accuracy']>c['selected']['validation']['weighted_rank_accuracy']",
        }
        for old,new in replacements.items():
            assert source.count(old)==1,old
            source=source.replace(old,new);changes[old]={'replacement':new,'occurrences':1}
        script=OUT/(name+'_trainer.py');compile(source,str(script),'exec');script.write_text(source)
        common.save(OUT/(name+'_SOURCE_TRANSFORM.json'),{'original_sha256':file_sha256(common.SOURCE),
                    'generated_sha256':file_sha256(script),'literal_changes':changes})
        common.save(OUT/'STATUS.json',{'status':'running','stage':name,'pid':os.getpid()})
        with (OUT/(name+'.log')).open('w') as stream:
            subprocess.run([sys.executable,str(script)],stdout=stream,stderr=subprocess.STDOUT,check=True)
        common.replay(folder)
    if stage=='full':
        qualities={str(s):read(OUT/f'seed{s}/SCORE_REPLAY.json')['models'] for s in seeds}
        common.save(OUT/'RESULT.json',{'status':'verified','seeds':qualities,
                    'before_cosine':read(BASE/'cosine_decay/RESULT.json')['after_cosine'],
                    'protocol_sha256':file_sha256(OUT/'PROTOCOL.json')})
    common.save(OUT/'STATUS.json',{'status':'pilot_verified' if stage=='pilot' else 'complete'})


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['pilot','full'],required=True)
    args=parser.parse_args()
    try:main(args.stage)
    except BaseException as error:
        if OUT.exists():common.save(OUT/'STATUS.json',{'status':'failed','error':repr(error)})
        raise
