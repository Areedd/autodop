"""Posthoc score-versus-latency diagnostic; never change the measured query set."""
import hashlib
import itertools
import json
from pathlib import Path
import statistics

BASE = Path(__file__).resolve().parents[1] / 'runs/report90_20260912/search_refinement_report90'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    result_path = BASE / 'full/RESULT.json'
    result = json.loads(result_path.read_text())
    assert result['status'] == 'verified' and result['executions'] == 1440
    for path, digest in result['source_sha256'].items():
        assert sha(path) == digest
    choices_path = BASE / 'CHOICES.json'
    choices = json.loads(choices_path.read_text())
    measured = result['per_query_ms']
    queries = set(measured['refined_full'])
    assert len(queries) == 90
    groups = {q: {} for q in queries}
    mode_scores = {q: {} for q in queries}
    for row in choices:
        assert row['seed'] == 17
        q, mode = row['id'], row['mode']
        mode_scores[q][mode] = row['score']
        key = tuple(row['config'])
        entry = groups[q].setdefault(key, {'score': row['score'], 'latencies': [], 'modes': []})
        assert entry['score'] == row['score']
        entry['latencies'].append(measured[mode][q])
        entry['modes'].append(mode)
    correct = total = ties = 0
    regrets = []
    for q, configs in groups.items():
        entries = [{**v, 'latency': statistics.mean(v['latencies'])} for v in configs.values()]
        for a, b in itertools.combinations(entries, 2):
            fast, slow = sorted([a, b], key=lambda x: x['latency'])
            if slow['latency'] / fast['latency'] - 1 < .03:
                continue
            total += 1
            correct += fast['score'] > slow['score']
            ties += fast['score'] == slow['score']
        best_score = max(x['score'] for x in entries)
        top_latency = statistics.mean(x['latency'] for x in entries if x['score'] == best_score)
        regrets.append(top_latency / min(x['latency'] for x in entries) - 1)
    comparisons = {}
    for mode in measured:
        if mode == 'refined_full':
            continue
        counts = {'queries': 90, 'full_score_higher': 0, 'full_score_lower': 0, 'score_ties': 0,
                  'full_score_higher_but_at_least3pct_slower': 0, 'full_faster': 0}
        for q in queries:
            a, b = mode_scores[q]['refined_full'], mode_scores[q][mode]
            counts['full_score_higher'] += a > b
            counts['full_score_lower'] += a < b
            counts['score_ties'] += a == b
            counts['full_faster'] += measured['refined_full'][q] < measured[mode][q]
            counts['full_score_higher_but_at_least3pct_slower'] += a > b and measured['refined_full'][q] >= 1.03 * measured[mode][q]
        comparisons[mode] = counts
    output = {'status': 'verified_posthoc_diagnostic', 'queries': 90,
              'unique_configurations': sum(len(v) for v in groups.values()),
              'pairs': total, 'correct': correct, 'score_ties': ties, 'pair_accuracy': correct / total,
              'top_score_mean_relative_regret': statistics.mean(regrets), 'comparisons': comparisons,
              'scope': 'Posthoc on8 measured search winners per query only, not all64 candidates or an unbiased test. Identical DOP configurations use arithmetic mean of their measured mode latencies; one formal execution per mode.3% latency gap, prediction ties incorrect. Scores use frozen preparation inputs, not a new fit or proof of equality of every runtime feature. No observations dropped and no parameters selected by this script.',
              'source_sha256': {str(p): sha(p) for p in [Path(__file__), result_path, choices_path]}}
    out = BASE / 'SCORE_LATENCY_DIAGNOSTIC.json'
    assert not out.exists()
    out.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main()
