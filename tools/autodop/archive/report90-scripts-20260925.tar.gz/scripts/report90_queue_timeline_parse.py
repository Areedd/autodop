"""Validate complete diagnostic streams; incomplete captures fail closed."""
import re

PATTERN = re.compile(r'AUTODOP_QUEUE_TIMELINE seq=(\d+) ns=(\d+) warehouse=(\d+) event=(REQUIRE|ALLOCATE|RELEASE) query=([0-9a-f-]+) slots=(\d+) pending=(\d+) allocated=(\d+) running=(\d+)')


def validate(lines, capacity=None):
    trackers = {}
    rows = []
    for line in lines:
        if 'AUTODOP_QUEUE_TIMELINE' not in line:
            continue
        m=PATTERN.search(line)
        if not m:raise ValueError('Malformed queue timeline event')
        seq,ns,warehouse,event,query,slots,pending,allocated,running=m.groups()
        seq,ns,warehouse,slots,pending,allocated,running=map(int,(seq,ns,warehouse,slots,pending,allocated,running))
        t=trackers.setdefault(warehouse,dict(seq=0,ns=-1,pending={},allocated={}))
        if seq!=t['seq']+1 or ns<t['ns']:raise ValueError('Missing/reordered event or tracker restart')
        if slots<=0:raise ValueError('Invalid slot demand')
        if event=='REQUIRE':
            if query in t['pending'] or query in t['allocated']:raise ValueError('Duplicate require')
            t['pending'][query]=slots
        elif event=='ALLOCATE':
            if t['pending'].pop(query,None)!=slots:raise ValueError('Allocation without matching requirement')
            t['allocated'][query]=slots
        else:
            old=t['allocated'].pop(query,None)
            if old is None:old=t['pending'].pop(query,None)
            if old!=slots:raise ValueError('Release without matching lifecycle')
        if (len(t['pending']),sum(t['allocated'].values()),len(t['allocated']))!=(pending,allocated,running):
            raise ValueError('Recorded queue counters disagree with lifecycle')
        if capacity is not None and allocated>capacity:raise ValueError('Slot capacity exceeded')
        t.update(seq=seq,ns=ns)
        rows.append(dict(sequence=seq,ns=ns,warehouse=warehouse,event=event,query_id=query,slots=slots,
                         pending=pending,allocated=allocated,running=running))
    if not rows:raise ValueError('No queue timeline events')
    if any(t['pending'] or t['allocated'] for t in trackers.values()):raise ValueError('Unfinished lifecycle at end of capture')
    return rows
