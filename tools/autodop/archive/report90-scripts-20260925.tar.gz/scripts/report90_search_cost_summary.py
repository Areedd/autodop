"""Audit and summarize frozen search timings separately from SQL replay latency."""
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics

BASE = Path(__file__).resolve().parents[1] / 'runs/report90_20260912/search_refinement_report90'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def percentile(values, q):
    values = sorted(values)
    pos = (len(values) - 1) * q
    low = math.floor(pos)
    high = math.ceil(pos)
    return values[low] + (values[high] - values[low]) * (pos - low)


def main():
    status = json.loads((BASE / 'PREPARATION_STATUS.json').read_text())
    assert status['status'] == 'verified' and status['choices'] == 720
    sources = json.loads((BASE / 'PREPARATION_SOURCES.json').read_text())
    for path, expected in sources.items():
        assert sha(path) == expected, path
    protocol = json.loads((BASE / 'PROTOCOL.json').read_text())
    rows = json.loads((BASE / 'CHOICES.json').read_text())
    keys = [(r['id'], r['mode'], r['seed']) for r in rows]
    assert len(keys) == len(set(keys)) == 720
    assert set(keys) == set(itertools.product(protocol['queries'], protocol['modes'], protocol['seeds']))
    assert all(r['score_calls'] == 64 and math.isfinite(r['search_seconds']) and r['search_seconds'] > 0 for r in rows)
    stats = {}
    for mode in protocol['modes']:
        group = [r for r in rows if r['mode'] == mode]
        times = [r['search_seconds'] * 1000 for r in group]
        expected_importance = 0 if mode in ['original_independent_random', 'refined_no_attention'] else 1
        assert all(r['importance_calls'] == expected_importance for r in group)
        unique = []
        for r in group:
            if not r['details']:
                continue
            records = r['details']['records']
            assert len(records) == r['score_calls']
            count = len({tuple(v['config']) for v in records})
            assert count == r['details']['unique_evaluations']
            unique.append(count)
        stats[mode] = {'queries': len(group), 'mean_ms': statistics.mean(times),
                       'p50_ms': percentile(times, .5), 'p90_ms': percentile(times, .9), 'p99_ms': percentile(times, .99),
                       'score_calls_per_query': 64, 'importance_calls_per_query': expected_importance,
                       'unique_configurations_mean': statistics.mean(unique) if unique else None,
                       'unique_configuration_coverage': len(unique)}
    result = {'status': 'verified', 'modes': stats,
              'scope': 'One offline search per query/mode, same90 queries, seed17 and64 scoring calls. Includes code inside each search timer; excludes model loading, SQL execution and HTTP service latency. Timings were not measured in one end-to-end request with the replay SQL and must not be presented as such. Original variants do not log every candidate, so their unique counts are unknown.',
              'source_sha256': {str(p): sha(p) for p in [Path(__file__), BASE / 'CHOICES.json', BASE / 'PREPARATION_SOURCES.json', BASE / 'PREPARATION_STATUS.json', BASE / 'PROTOCOL.json']}}
    out = BASE / 'COST_SUMMARY.json'
    assert not out.exists()
    out.write_text(json.dumps(result, indent=2) + '\n')
    lines = ['# 搜索开销核验', '', result['scope'], '', '| 方案 | 平均 ms | p50 ms | p90 ms | p99 ms |', '|---|---:|---:|---:|---:|']
    for mode, s in stats.items():
        lines.append(f"| {mode} | {s['mean_ms']:.2f} | {s['p50_ms']:.2f} | {s['p90_ms']:.2f} | {s['p99_ms']:.2f} |")
    (BASE / 'COST_REPORT.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps(stats, indent=2))


if __name__ == '__main__':
    main()
