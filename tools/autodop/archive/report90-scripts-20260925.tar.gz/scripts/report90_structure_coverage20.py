"""Balanced root/ordered-shape development augmentation without latency selection."""
import argparse
from collections import Counter
from dataclasses import asdict
import datetime
import hashlib
import json
import os
from pathlib import Path
import random
import re
import time
from report90_execute import ROOT,RUN,check
from report90_complex_development import canonical
from generate_composable_branch_suite import Node,compile_sql,evaluate,from_dict,leaves

SOURCE=ROOT/'runs/preference_random200_20260911'
OUT=RUN/'structure_coverage20'
OPS=['inner','left','full','union']
SHAPES=[(((0,1),2),3),((0,(1,2)),3),((0,1),(2,3)),(0,((1,2),3)),(0,(1,(2,3)))]
SEED=2026091317

def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
    p=OUT/name;t=p.with_suffix('.tmp');t.write_text(json.dumps(value,indent=2,default=str)+'\n');t.replace(p)

def shape(n):return 'x' if n.op=='leaf' else '('+shape(n.left)+','+shape(n.right)+')'

def instantiate(form,ids,rng,root=None):
    if isinstance(form,int):return Node('leaf',ids[form])
    return Node(root or rng.choice(OPS),left=instantiate(form[0],ids,rng),right=instantiate(form[1],ids,rng))

def prepare():
    OUT.mkdir(exist_ok=False);(OUT/'sql').mkdir()
    banks=read(SOURCE/'banks.json');old=read(SOURCE/'random200/manifest.json')['queries']
    previous=read(RUN/'complex_development24/manifest.json')['queries']
    historical=Path(read(RUN/'PROTOCOL.json')['training_dataset'])/'samples.jsonl'
    historical_rows=[json.loads(l) for l in historical.open()]
    hashes={q['sql_sha256'] for q in old+previous+historical_rows}
    seen={canonical(from_dict(q['tree'])) for q in old+previous}
    before=Counter((from_dict(q['tree']).op,shape(from_dict(q['tree']))) for q in previous if q['split']=='train' and len(q['branch_ids'])==4)
    rng=random.Random(SEED);queries=[]
    for root_index,root in enumerate(OPS):
        for shape_index,form in enumerate(SHAPES):
            omitted=(root_index+shape_index)%5
            month=sorted(banks)[(root_index+shape_index)%len(banks)]
            for attempt in range(10000):
                ids=[i for i in range(5) if i!=omitted];rng.shuffle(ids)
                n=instantiate(form,ids,rng,root);signature=canonical(n);body=compile_sql(n,banks[month]);digest=hashlib.sha256(body.encode()).hexdigest()
                if signature not in seen and digest not in hashes:break
            else:raise RuntimeError('No unused canonical tree for fixed cell')
            seen.add(signature);hashes.add(digest)
            qid=f'coverage20_train_{len(queries):02d}_{root}_s{shape_index}_m{month}'
            path=OUT/'sql'/f'{qid}.sql';path.write_text(body);branch_ids=sorted(leaves(n))
            queries.append({'id':qid,'query_id':qid,'split':'train','database':'autodop_tpcds_sf100_paper_20260905',
                'template_family':'root_shape_coverage','tree':asdict(n),'tree_signature':signature,
                'ordered_shape':shape(n),'shape_index':shape_index,'branch_ids':branch_ids,
                'branch_types':[banks[month][i]['family'] for i in branch_ids],
                'parameters':{'start_month':int(month),'months':3},'sql_file':str(path),'sql_sha256':digest,
                'training_eligible':True,'evaluation_role':'training'})
    assert len(queries)==20 and len({q['sql_sha256'] for q in queries})==20
    assert Counter(q['tree']['op'] for q in queries)==dict.fromkeys(OPS,5)
    assert len({(q['tree']['op'],q['shape_index']) for q in queries})==20
    save('manifest.json',{'query_count':20,'queries':queries,'scope':'Training augmentation pilot; no latency filtering or independent-test claim.'})
    sources=[Path(__file__),ROOT/'scripts/report90_complex_development.py',ROOT/'generate_composable_branch_suite.py',SOURCE/'banks.json',SOURCE/'random200/manifest.json',RUN/'complex_development24/manifest.json',historical]
    save('PROTOCOL.json',{'status':'frozen_before_execution','frozen_at':datetime.datetime.now().astimezone().isoformat(),
        'seed':SEED,'queries':20,'train_queries':20,'valid_queries':0,'design':'4 root operators x 5 ordered four-leaf binary shapes; each omitted branch family appears once per root. Random leaf order and internal operators, fixed month rotation. No latency read or filtering.',
        'separation':'Exact SQL hashes excluded against original200, previous24, historical cost samples; canonical trees excluded against original200 and previous24. Raw graph exclusion against protected validation remains required before fitting.',
        'interpretation':'Five ordered shapes are not five logical equivalence classes. Existing validation has been used in development; new training cannot turn it into an untouched test.',
        'prior_four_branch_train_queries':8,'prior_root_ordered_shape_cells':len(before),
        'semantic_gate':'Independent source/materialized branch equality and composed bag semantics for every SQL. No replacements on failure.',
        'manifest_sha256':sha(OUT/'manifest.json'),'source_sha256':{str(p):sha(p) for p in sources}})
    save('COVERAGE.json',{'prior_four_branch_train_queries':8,'prior_root_ordered_shape_cells':{'/'.join(k):v for k,v in before.items()},'new_root_shape_cells':20,'new_queries':20})
    save('STATUS.json',{'status':'prepared','queries':20})
    print(json.dumps({'status':'prepared','queries':20,'prior_four_branch_root_shape_cells':len(before)}))

def validate():
    import pymysql
    from collect_trusted_dataset import result_digest
    assert read(OUT/'STATUS.json')['status']=='prepared'
    assert not (OUT/'SEMANTIC_AUDIT.json').exists(), 'Preserve previous validation'
    protocol=read(OUT/'PROTOCOL.json')
    assert sha(OUT/'manifest.json')==protocol['manifest_sha256']
    for name,expected in protocol['source_sha256'].items():assert sha(Path(name))==expected
    os.sched_setaffinity(0,set(range(27,35)))
    save('STATUS.json',{'status':'running','stage':'semantic_validation','pid':os.getpid()})
    for attempt in range(20):
        try:check(OUT/f'IDLE_{attempt}.json');break
        except RuntimeError:
            if attempt==19:raise
            time.sleep(15)
    from report90_cpu_observe import workers
    nodes=workers()
    assert all(n['image_id']=='sha256:73548ebadb50d11fec58e9937ebd5ee189205fd8f1acf8359fc63923132c476b' for n in nodes)
    save('DEPLOYMENT.json',nodes)
    queries=read(OUT/'manifest.json')['queries'];banks=read(SOURCE/'banks.json')
    audit={'status':'running','branches':[],'queries':[],'sql_executions':0}
    native=[];branch_rows={}
    with pymysql.connect(host='127.0.0.1',port=9030,user='root',database=queries[0]['database'],read_timeout=200,connect_timeout=5) as conn:
        with conn.cursor() as cur:
            for setting in ['enable_auto_dop=false','pipeline_dop=4','query_timeout=180','enable_profile=false',
                            'enable_spill=false','enable_query_cache=false','enable_runtime_adaptive_dop=false']:
                cur.execute('SET '+setting)
            for month in sorted({str(q['parameters']['start_month']) for q in queries}):
                branch_rows[month]=[]
                for branch in banks[month]:
                    cur.execute(branch['source_sql']);source_rows=cur.fetchall();audit['sql_executions']+=1
                    cur.execute(branch['sql']);rows=cur.fetchall();audit['sql_executions']+=1
                    assert result_digest(source_rows)==result_digest(rows),(month,branch['family'])
                    branch_rows[month].append(rows)
                    audit['branches'].append({'month':month,'family':branch['family'],'source_copy_equal':True,
                        'digest':result_digest(rows),'rows':len(rows)})
                    save('SEMANTIC_AUDIT.json',audit)
            for q in queries:
                body=Path(q['sql_file']).read_text();assert hashlib.sha256(body.encode()).hexdigest()==q['sql_sha256']
                cur.execute('EXPLAIN '+body);plan='\n'.join(str(x[0]) for x in cur.fetchall())
                cur.execute(body);actual=cur.fetchall();audit['sql_executions']+=1
                month=str(q['parameters']['start_month'])
                expected=evaluate(from_dict(q['tree']),banks[month],branch_rows[month])
                assert result_digest(actual)==result_digest(expected),q['id']
                digest=result_digest(actual)
                audit['queries'].append({'id':q['id'],'split':q['split'],'independent_assembly_equal':True,
                    'native_result_digest':digest,'result_rows':len(actual),'explain':plan,
                    'explain_fragment_count':len(re.findall(r'^PLAN FRAGMENT ',plan,re.MULTILINE))})
                native.append({'id':q['id'],'status':'accepted','database':q['database'],'sql_sha256':q['sql_sha256'],
                    'native_result_digest':digest,'provenance':'Independent branch bag assembly and actual native SQL, SEMANTIC_AUDIT.json; no configuration latency labels yet.'})
                save('SEMANTIC_AUDIT.json',audit)
                print(json.dumps({'verified_queries':len(audit['queries']),'total':len(queries),'fragments':audit['queries'][-1]['explain_fragment_count']}),flush=True)
    audit['status']='verified';save('SEMANTIC_AUDIT.json',audit)
    save('TRUSTED_NATIVE.json',{'status':'finished','queries':native,'source_sha256':{'manifest.json':sha(OUT/'manifest.json'),'SEMANTIC_AUDIT.json':sha(OUT/'SEMANTIC_AUDIT.json')},
        'scope':'Native result identity only; not a measured cost training dataset.'})
    save('STATUS.json',{'status':'semantic_verified','queries':len(queries),'sql_executions':audit['sql_executions'],
        'at':datetime.datetime.now().astimezone().isoformat()})


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['prepare','validate']);args=parser.parse_args()
    if args.stage=='prepare':prepare()
    else:
        try:validate()
        except BaseException as e:
            save('STATUS.json',{'status':'failed','stage':'semantic_validation','error':repr(e),'pid':os.getpid()});raise
