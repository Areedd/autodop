"""Run frozen 30-epoch distillation pilot after its readiness audit."""
import json
import os
from pathlib import Path
import subprocess
import sys
import torch
from autodop.training import file_sha256
import report90_coverage_stability as common

BASE = Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20'
OUT = BASE/'xgb_distillation_pilot'


def main():
    torch.set_num_threads(1);os.sched_setaffinity(0,{34})
    readiness = common.read(OUT/'READINESS_AUDIT.json')
    assert readiness['status']=='verified_ready_for_pilot'
    for path,digest in readiness['source_sha256'].items():assert file_sha256(path)==digest
    assert not (OUT/'pilot').exists()
    common.save(OUT/'STATUS.json',dict(status='running_pilot',pid=os.getpid()))
    with (OUT/'pilot.log').open('w') as stream:
        subprocess.run([sys.executable,str(OUT/'pilot_trainer.py')],stdout=stream,stderr=subprocess.STDOUT,check=True)
    models = common.replay(OUT/'pilot')
    reference = common.read(BASE/'hard_pair_ema_pilot/RESULT.json')['models']['transformer']['weighted_rank_accuracy']
    score = models['transformer']['weighted_rank_accuracy']
    # This is only a necessary gate. All-family controls and independent pair
    # auditing are required before any three-seed expansion.
    gate = score>reference and all(score>v['weighted_rank_accuracy'] for k,v in models.items() if k!='transformer')
    result = dict(status='replayed_pilot',models=models,reference_macro_accuracy=reference,
                  necessary_gate_passed=gate,expansion_authorized=False,
                  remaining='Independent pair audit and all-family gate before expansion; no report90 selection.',
                  source_sha256={str(p):file_sha256(p) for p in [Path(__file__),OUT/'PROTOCOL.json',OUT/'READINESS_AUDIT.json',OUT/'pilot/SCORE_REPLAY.json']})
    common.save(OUT/'RESULT.json',result)
    common.save(OUT/'STATUS.json',dict(status='pilot_complete_pending_independent_audit',necessary_gate_passed=gate))
    print(json.dumps({k:v for k,v in result.items() if k not in ('models','source_sha256')},indent=2),flush=True)


if __name__=='__main__':
    try:main()
    except BaseException as error:
        common.save(OUT/'STATUS.json',dict(status='failed',error=repr(error)))
        raise
