"""Replay frozen teacher scores; diagnose the completed budget experiment only.

No fitting, configuration selection, or SQL execution is performed here.
"""
import json
import os
from pathlib import Path

import numpy as np
import torch

from autodop import graph
from autodop.model import load_cost_model
from report90_neighborhood_prepare import RUN, sha
from report90_prepared_graph import PreparedGraph


def main():
    os.sched_setaffinity(0, {34})
    torch.set_num_threads(1)
    base = RUN / 'search_budget_report90'
    old = RUN / 'search_refinement_report90'
    result = json.loads((base / 'collection/RESULT.json').read_text())
    protocol = json.loads((base / 'PROTOCOL.json').read_text())
    assert result['status'] == 'verified' and result['executions'] == 720
    vectors = json.loads((base / 'vectors.json').read_text())
    prior = json.loads((old / 'PROTOCOL.json').read_text())
    model_path = Path(prior['model'])
    code = RUN / 'graph_construction_pilot/competition_staged.py'
    sources = [Path(__file__), base / 'collection/RESULT.json', base / 'vectors.json',
               base / 'PROTOCOL.json', old / 'PROTOCOL.json', model_path, code,
               Path(graph.__file__), Path(__file__).with_name('report90_prepared_graph.py')]
    hashes = {str(p): sha(p) for p in sources}
    for p, digest in protocol['source_sha256'].items():
        assert sha(Path(p)) == digest
    model, ck = load_cost_model(model_path)
    model.eval()
    namespace = dict(vars(graph))
    exec(compile(code.read_text(), str(code), 'exec'), namespace)
    scores = {m: {} for m in vectors}
    configs = {m: {} for m in vectors}
    with torch.inference_mode():
        for q in protocol['queries']:
            sample = graph.sample_from_request(vectors['refined_budget64'][q]['request'])
            sample['dop_config'] = [1 if f.get('is_gather_root') else 4 for f in sample['fragments']]
            prepared = PreparedGraph(sample, ck['metadata'], namespace['_competition'])
            for mode in vectors:
                entry = vectors[mode][q]
                assert entry['request'] == vectors['refined_budget64'][q]['request']
                config = [entry['fragment_dops'][f] for f in sample['fragment_ids']]
                configs[mode][q] = config
                scores[mode][q] = float(model(prepared.build(config)))
    comparisons = {}
    pairs = [('refined_budget64', 'random_budget64'),
             ('refined_budget32', 'random_budget32'),
             ('refined_budget64', 'refined_budget32'),
             ('random_budget64', 'random_budget32')]
    for a, b in pairs:
        rows = []
        for q in protocol['queries']:
            x, y = result['per_query_ms'][a][q], result['per_query_ms'][b][q]
            rows.append(dict(query=q, same_config=configs[a][q] == configs[b][q],
                             score_a=scores[a][q], score_b=scores[b][q],
                             latency_a_ms=x, latency_b_ms=y,
                             relative_latency_change_percent=100*(x/y-1)))
        different = [r for r in rows if not r['same_config']]
        valid = [r for r in different if max(r['latency_a_ms'], r['latency_b_ms']) /
                 min(r['latency_a_ms'], r['latency_b_ms']) >= 1.03]
        correct = sum((r['score_a']-r['score_b'])*(r['latency_a_ms']-r['latency_b_ms']) < 0 for r in valid)
        same = [abs(r['relative_latency_change_percent']) for r in rows if r['same_config']]
        comparisons[a+'_vs_'+b] = dict(
            different_config_queries=len(different), valid3percent_pairs=len(valid),
            correct_ordering=correct, accuracy=correct/len(valid) if valid else None,
            higher_a_score=sum(r['score_a'] > r['score_b'] for r in different),
            higher_a_score_but_at_least3percent_slower=sum(
                r['score_a'] > r['score_b'] and r['relative_latency_change_percent'] >= 3 for r in different),
            same_config_queries=len(same),
            same_config_absolute_change_median_percent=float(np.median(same)) if same else None,
            same_config_absolute_change_max_percent=max(same) if same else None,
            rows=rows)
    for p, digest in hashes.items():
        assert sha(Path(p)) == digest
    out = base / 'SCORE_DIAGNOSTIC.json'
    out.write_text(json.dumps(dict(status='completed_frozen_teacher_replay',
        scope='Post-hoc diagnosis on reused90; one observation/config. Not independent model evaluation or causal proof. Scores are higher-is-better; score ties count incorrect.',
        comparisons=comparisons, source_sha256=hashes), indent=2)+'\n')
    lines = ['# 搜索预算结果的教师评分诊断', '',
             '只重算已冻结模型和已执行配置，不训练、不换配置、不增加SQL。相同配置的时间差用于描述本批测量波动，不能归因于搜索算法。', '',
             '| 比较 | 不同配置 | ≥3%延迟差对数 | 教师排序正确 | 评分更高却慢≥3% | 相同配置数 | 相同配置绝对变化中位数 |',
             '|---|---:|---:|---:|---:|---:|---:|']
    for name, r in comparisons.items():
        noise = r['same_config_absolute_change_median_percent']
        lines.append(f"| {name} | {r['different_config_queries']} | {r['valid3percent_pairs']} | {r['correct_ordering']} | {r['higher_a_score_but_at_least3percent_slower']} | {r['same_config_queries']} | {noise:.2f}% |" if noise is not None else
                     f"| {name} | {r['different_config_queries']} | {r['valid3percent_pairs']} | {r['correct_ordering']} | {r['higher_a_score_but_at_least3percent_slower']} | 0 | — |")
    lines += ['', '3%阈值按较慢/较快≥1.03定义；评分并列算错。只比较这四个搜索输出，不能替代开发集920对准确率。该结果不能区分全部模型误差与测量噪声，也不能据此将报告查询加入训练。', '',
              '完整分数、延迟、配置一致性及来源：[SCORE_DIAGNOSTIC.json](SCORE_DIAGNOSTIC.json)。']
    (base / 'SCORE_DIAGNOSTIC.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k: {j:v for j,v in r.items() if j!='rows'} for k,r in comparisons.items()}, indent=2))


if __name__ == '__main__':
    main()
