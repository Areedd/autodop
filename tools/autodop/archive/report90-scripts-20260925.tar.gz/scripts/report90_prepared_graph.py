"""Experimental per-query immutable feature cache; not wired into production."""
import copy
import torch
from autodop import graph


class PreparedGraph:
    def __init__(self,sample,metadata,competition=None):
        self._sample=copy.deepcopy(sample)
        self._metadata=copy.deepcopy(metadata)
        self._competition=competition or graph._competition
        # Existing constructor retains validation/normalization behavior.
        template=graph.build_graph(self._sample,self._metadata,unknown_dop=True)
        dynamic={'dop_ids','competition','competition_overlap','worker_share','resource_pressure'}
        self._static={k:v for k,v in template.items() if k not in dynamic}
        self._ids={dop:i+1 for i,dop in enumerate(metadata['dop_classes'])}

    def build(self,dop_config,unknown_dop=False,device='cpu'):
        size=len(self._sample['fragments'])
        if len(dop_config)!=size:
            raise ValueError('dop_config size does not match fragment count')
        if unknown_dop:
            ids=[0]*size
        else:
            try:ids=[self._ids[int(dop)] for dop in dop_config]
            except KeyError as error:raise ValueError(f'unsupported DOP {error.args[0]}') from error
        result={k:v.clone() if isinstance(v,torch.Tensor) else v for k,v in self._static.items()}
        result.update(self._competition(self._sample['fragments'],self._sample.get('edges',[]),dop_config,unknown_dop))
        result['dop_ids']=torch.tensor(ids,dtype=torch.long)
        return {k:v.to(device) if isinstance(v,torch.Tensor) else v for k,v in result.items()}
