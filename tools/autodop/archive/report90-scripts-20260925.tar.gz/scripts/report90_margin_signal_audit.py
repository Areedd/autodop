"""Measure existing hinge-loss activity and calibration without fitting."""
import collections
import datetime
import json
import math
import os
from pathlib import Path
import numpy as np
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from autodop.training import file_sha256, select_partition
from report90_complex_retrain import key, validation
from report90_coverage_choices import BASE, read


def summarize(rows):
    assert rows
    return {'pairs':len(rows), 'active_hinge_fraction':float(np.mean([r['residual']>0 for r in rows])),
            'ranking_accuracy':float(np.mean([r['score_gap']>0 for r in rows])),
            'mean_hinge':float(np.mean([max(0,r['residual']) for r in rows])),
            'mean_absolute_gap_error':float(np.mean([abs(r['residual']) for r in rows])),
            'overshoot_fraction':float(np.mean([r['residual']<0 for r in rows]))}


def main():
    out=BASE/'margin_signal_audit';assert not out.exists();out.mkdir()
    torch.set_num_threads(1);os.sched_setaffinity(0,{35})
    dataset=BASE/'merged_dataset';samples,pairs,meta=load_dataset(dataset)
    contract=read(dataset/'CONTRACT.json')
    train,tp=select_partition(samples,pairs,contract,'train')
    valid,vp=select_partition(samples,pairs,contract,'valid')
    assert len(train)==1365 and len(valid)==212
    records={str(s):read(BASE/f'cosine_decay/seed{s}/RESULT.json')['selected']['transformer'] for s in [17,29,43]}
    sources=[Path(__file__),dataset/'samples.jsonl',dataset/'pairs.jsonl',dataset/'CONTRACT.json',dataset/'metadata.json']
    protocol={'at':datetime.datetime.now().astimezone().isoformat(), 'models':records,
              'scope':'Fixed cosine models; train and development validation only, no report90 data, no fitting or deployment.',
              'pair_definition':'Preserve existing batch-specific pairs including multiplicity. Residual=log(slow/fast)-(fast_score-slow_score). Hinge active iff residual>0. Top sets use canonical point latency within3% of minimum.',
              'source_sha256':{str(p):file_sha256(p) for p in sources}}
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    graphs={key(s):build_graph(s,meta) for s in samples};lookup={key(s):s for s in samples}
    groups=collections.defaultdict(list)
    for s in samples:groups[s['plan_key']].append(s)
    top={p:{s['config_key'] for s in ss if s['latency_ms']<=1.03*min(x['latency_ms'] for x in ss)} for p,ss in groups.items()}
    models={};all_scores={}
    for seed,record in records.items():
        assert file_sha256(record['model'])==record['model_sha256']
        model,ck=load_cost_model(record['model']);model.eval();assert ck['metadata']==meta
        with torch.no_grad():scores={k:float(model(g)) for k,g in graphs.items()}
        assert np.isfinite(list(scores.values())).all()
        assert validation(valid,[scores[key(s)] for s in valid])==record['selected']['validation']
        model_result={}
        for split,ss,pp in [('train',train,tp),('valid',valid,vp)]:
            buckets=collections.defaultdict(list)
            for pair in pp:
                plan=pair['plan_key'];fk=(plan,pair['fast_config_key']);sk=(plan,pair['slow_config_key'])
                assert lookup[fk]['split']==split and lookup[sk]['split']==split
                gap=scores[fk]-scores[sk];margin=math.log(pair['slow_latency_ms']/pair['fast_latency_ms'])
                row={'score_gap':gap,'residual':margin-gap}
                c=lookup[fk]['source_cohort'];buckets[(c,'all')].append(row)
                bucket='top' if fk[1] in top[plan] or sk[1] in top[plan] else 'non_top'
                buckets[(c,bucket)].append(row)
            model_result[split]={c:{bucket:summarize(rows) for (cohort,bucket),rows in buckets.items() if cohort==c}
                                 for c in ['historical','complex_new']}
        models[seed]=model_result
        all_scores[seed]=[scores[key(s)] for s in samples]
        print(seed,model_result,flush=True)
    (out/'SCORES.json').write_text(json.dumps(all_scores)+'\n')
    reloaded=read(out/'SCORES.json');assert reloaded==all_scores
    result={'status':'verified','models':models,'scores_serialization_exact':True,'scope':protocol['scope']}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 排序间隔学习信号诊断','',protocol['scope'],'',
           '| 种子 | 划分 | 群组 | 候选对 | 数量 | 有梯度比例 | 排序准确率 | 平均hinge损失 | 平均间隔绝对误差 |',
           '|---|---|---|---|---:|---:|---:|---:|---:|']
    for seed,splits in models.items():
        for split,cohorts in splits.items():
            for cohort,buckets in cohorts.items():
                for bucket,q in buckets.items():
                    lines.append(f"| {seed} | {split} | {cohort} | {bucket} | {q['pairs']} | {q['active_hinge_fraction']:.2%} | {q['ranking_accuracy']:.2%} | {q['mean_hinge']:.4f} | {q['mean_absolute_gap_error']:.4f} |")
    lines+=['','所有排序方向错误的正间隔训练对均有非零hinge梯度，不能称为错误被损失函数忽略。高比例无梯度也可能代表训练拟合充分，不能单独归因于优化停滞。间隔过大不受现有单侧损失惩罚；这属于目标性质，不直接证明它导致泛化误差。历史对标签保留批次差异，本表按候选对计权，与主报告按计划计权的选择损失不同。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')


if __name__=='__main__':main()
