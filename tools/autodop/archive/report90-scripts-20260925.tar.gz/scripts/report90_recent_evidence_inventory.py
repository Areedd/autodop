"""Inventory completed recent diagnostics without absorbing active run files."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'runs/report90_20260912'


def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def main():
    prefixes=['budget_rounding_analysis','integer_predictor_validation','integer_slot_estimator_validation',
              'report90_native_budget_rounding_power2','report90_native_budget_rounding_integer',
              'report90_native_budget_rounding_restart','native_rounding_comparison','native_rounding_control_audit',
              'native_rounding_phase_audit','native_rounding_wait_analysis','native_rounding_timing_diagnostic',
              'queue_timeline_validation','report90_native_budget_timeline_power2','report90_native_budget_timeline_restart',
              'native_queue_timeline_summary']
    for name in ['rounding','timeline']:
        restore=RUN/f'report90_native_budget_{name}_restart/RESTORATION.json'
        assert json.loads(restore.read_text())['restored']
    paths={Path(__file__),ROOT/'scripts/report90_delivery_main.py',RUN/'MAIN_REPORT.md',RUN/'MAIN_REPORT.sources.json',RUN/'FULL_REPORT.md',RUN/'DELIVERY_SCOPE_AUDIT.md'}
    for name in prefixes:
        root=RUN/name;assert root.is_dir()
        paths.update(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    # Include evidence-declared source files without interpreting hash inventories as tests.
    for p in list(paths):
        if p.suffix!='.json':continue
        try:r=json.loads(p.read_text())
        except (ValueError,UnicodeError):continue
        if isinstance(r,dict):
            for name in r.get('source_sha256',{}):paths.add(Path(name))
    missing=sorted(str(p) for p in paths if not p.exists())
    current={str(p.resolve()):digest(p) for p in sorted(paths) if p.is_file()}
    old=json.loads((RUN/'DELIVERY_EVIDENCE_CHECK.sources.json').read_text())['source_sha256']
    changed={p:dict(previous=old[p],current=h) for p,h in current.items() if p in old and old[p]!=h}
    result=dict(at=datetime.now(timezone.utc).isoformat(),scope='Supplementary current-state inventory of completed rounding and timeline diagnostics plus report draft. Active arrival-order experiment excluded. Differences from the previous inventory are explicitly retained; hashes alone do not verify experimental claims.',files=len(current),missing=missing,changed_since_previous_inventory=changed,source_sha256=current)
    (RUN/'RECENT_EVIDENCE.sources.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('source_sha256','changed_since_previous_inventory')},indent=2))
    print('Changed since previous inventory:',list(changed))
    if missing:raise RuntimeError('Missing evidence files')

if __name__=='__main__':main()
