"""Two additional fixed-seed30-epoch replications after the EMA pilot gate passes."""
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import torch
from autodop.model import load_cost_model
import report90_coverage_stability as common
from report90_neighborhood_prepare import RUN,sha

BASE=RUN/'structure_coverage20';PILOT=BASE/'hard_pair_ema_pilot';OUT=BASE/'hard_pair_ema_stability'
SOURCE=PILOT/'pilot_trainer.py'

def pair_audit(folder,seed):
    original=Path(__file__).with_name('report90_interaction_pair_audit.py')
    changes={
        "BASE = Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20'":'BASE = Path('+repr(str(BASE))+')',
        "BASE/f'interaction_ranking/seed{seed}'":'Path('+repr(str(folder))+')',
        "BASE/f'interaction_pair_audit_seed{seed}'":'Path('+repr(str(OUT/f'pair_audit_seed{seed}'))+')',
        'from report90_interaction_model import load_interaction_model as load_cost_model':'from autodop.model import load_cost_model',
        "Path(__file__).with_name('report90_interaction_model.py')":'Path('+repr(str(Path(__file__).resolve().parents[1]/'autodop/model.py'))+')',
        'sources = [Path(__file__),':'sources = [Path(__file__), Path('+repr(str(original))+'), Path('+repr(str(Path(__file__)))+'),',
        'Interaction-augmented Transformer; unchanged flat controls.':'Fixed0.99 EMA,30-epoch hard-pair training replication; unchanged flat controls.',
    }
    text=original.read_text()
    for old,new in changes.items():assert text.count(old)==1,old;text=text.replace(old,new)
    script=OUT/f'audit_seed{seed}.py';compile(text,str(script),'exec');script.write_text(text)
    common.save(OUT/f'audit_seed{seed}_TRANSFORM.json',{'original_sha256':sha(original),'generated_sha256':sha(script),'changes':changes})
    runpy.run_path(str(script),run_name='ema_stability_audit')['main'](seed)

def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1)
    assert not OUT.exists()
    result=common.read(PILOT/'RESULT.json');assert result['status']=='verified' and result['expansion_gate_passed']
    assert common.read(PILOT/'pair_audit/RESULT.json')['status']=='verified_independent_pair_replay'
    assert common.read(PILOT/'TRAJECTORY_AUDIT.json')['status']=='verified_exact'
    for path,digest in common.read(PILOT/'PROTOCOL.json')['source_sha256'].items():assert sha(Path(path))==digest
    OUT.mkdir()
    common.save(OUT/'PROTOCOL.json',{'seeds':[17,29,43],'epochs_per_seed':30,'reference_seed17':str(PILOT/'pilot'),
        'design':'Reuse completed seed17 pilot; independently train seeds29,43 with identical original initialization,data,loss,50% training-error sampling refreshed every10epochs,EMA0.99 each update,Adam1e-4,cosine100 horizon. No new hyperparameters or training-budget expansion.',
        'selection':'Checkpoint macro equal-cohort ranking accuracy then regret and earlier epoch; retain all three seeds, mean/range and every control. Development validation reused; not blind test.',
        'scope':'No SQL, report90 selection or deployment. Gate passage from a single seed is not stable superiority.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),SOURCE,PILOT/'RESULT.json',PILOT/'pair_audit/RESULT.json',PILOT/'PROTOCOL.json',PILOT/'TRAJECTORY_AUDIT.json',Path(__file__).with_name('report90_ema_weights.py'),Path(__file__).with_name('report90_hard_pair_sampler.py')]}})
    for seed in [29,43]:
        folder=OUT/f'seed{seed}'
        changes={repr(str(PILOT/'pilot')):repr(str(folder)),repr(str(PILOT/'PROTOCOL.json')):repr(str(OUT/'PROTOCOL.json')),
            'torch.manual_seed(17);rng=random.Random(17)':f'torch.manual_seed({seed});rng=random.Random({seed})',
            'random_state=17':f'random_state={seed}'}
        text=SOURCE.read_text();applied={}
        for old,new in changes.items():
            count=text.count(old);assert count==(2 if old==repr(str(PILOT/'PROTOCOL.json')) else 1),(old,count)
            text=text.replace(old,new);applied[old]={'replacement':new,'occurrences':count}
        script=OUT/f'seed{seed}_trainer.py';compile(text,str(script),'exec');script.write_text(text)
        common.save(OUT/f'seed{seed}_TRANSFORM.json',{'original_sha256':sha(SOURCE),'generated_sha256':sha(script),'changes':applied})
        common.save(OUT/'STATUS.json',{'status':'running','seed':seed,'stage':'train','pid':os.getpid()})
        with (OUT/f'seed{seed}.log').open('w') as stream:subprocess.run([sys.executable,str(script)],stdout=stream,stderr=subprocess.STDOUT,check=True)
        common.load_cost_model=load_cost_model;common.replay(folder)
        common.save(OUT/'STATUS.json',{'status':'running','seed':seed,'stage':'independent_pair_audit','pid':os.getpid()})
        pair_audit(folder,seed)
    audits=[common.read(PILOT/'pair_audit/RESULT.json')]+[common.read(OUT/f'pair_audit_seed{s}/RESULT.json') for s in [29,43]]
    audit_paths=[PILOT/'pair_audit/RESULT.json']+[OUT/f'pair_audit_seed{s}/RESULT.json' for s in [29,43]]
    assert all(a['status']=='verified_independent_pair_replay' for a in audits)
    assert len({sha(p.with_name('PAIR_POOL.json')) for p in audit_paths})==1
    models={kind:{metric:{'mean':sum(a['models'][kind][metric] for a in audits)/3,'minimum':min(a['models'][kind][metric] for a in audits),'maximum':max(a['models'][kind][metric] for a in audits)} for metric in ['macro_accuracy','pooled_accuracy']} for kind in audits[0]['models']}
    gate=all(a['models']['transformer']['macro_accuracy']>max(v['macro_accuracy'] for k,v in a['models'].items() if k!='transformer') for a in audits)
    common.save(OUT/'RESULT.json',{'status':'verified_three_seed_summary','seeds':[17,29,43],'models':models,'every_seed_macro_beats_all_controls':gate,'scope':'Reused development validation; not blind-test or statistical significance evidence. No seed selection or deployment.','protocol_sha256':sha(OUT/'PROTOCOL.json'),'source_sha256':{str(p):sha(p) for p in audit_paths},'pair_pool_sha256':sha(audit_paths[0].with_name('PAIR_POOL.json'))})
    common.save(OUT/'STATUS.json',{'status':'complete','every_seed_macro_beats_all_controls':gate})
    lines=['# 错对强化与权重平均的三种子复核','','| 模型 | 等权准确率均值 | 种子范围 | 汇总准确率均值 |','|---|---:|---:|---:|']
    for kind,v in models.items():
        m=v['macro_accuracy'];lines.append(f"| {kind} | {100*m['mean']:.3f}% | {100*m['minimum']:.3f}–{100*m['maximum']:.3f}% | {100*v['pooled_accuracy']['mean']:.3f}% |")
    lines+=['',f'全部种子均按等权指标超过所有对照：{gate}。','', '三个种子使用同一920对，不是2760个独立查询对。验证集已反复用于开发，不能称作盲测。全部种子与对照均保留，未执行SQL或部署。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');print('Three-seed replication complete',gate,flush=True)

if __name__=='__main__':
    try:main()
    except BaseException as error:
        if OUT.exists():common.save(OUT/'STATUS.json',{'status':'failed','error':repr(error)})
        raise
