"""Execute the frozen development search pilot after the active SQL run finishes."""
import collections
import json
import math
import subprocess
import sys
from pathlib import Path
from statistics import mean

from autodop.training import file_sha256
from report90_execute import check
from report90_wait_for_idle import wait_for_idle

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT/'runs/report90_20260912'
BASE = RUN/'search_refinement_development'
OUT = BASE/'pilot'


def read(path):
    return json.loads(path.read_text())


def save(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2)+'\n')


def percentile(values, fraction):
    values = sorted(values)
    index = (len(values)-1)*fraction
    return values[math.floor(index)] + (values[math.ceil(index)]-values[math.floor(index)])*(index-math.floor(index))


def main():
    prior = RUN/'policy_final_stage_ablation/online_full'
    assert read(prior/'STATUS.json')['status'] == 'verified', 'Finish existing SQL first'
    assert read(prior/'scored/independent_verification.json')['all_expected_executions_verified']
    assert read(BASE/'PREPARATION_STATUS.json')['status'] == 'verified'
    for path, expected in read(BASE/'PREPARATION_SOURCES.json').items():
        assert file_sha256(path) == expected
    protocol = read(BASE/'PROTOCOL.json')
    for path, expected in protocol['source_sha256'].items():
        assert file_sha256(path) == expected
    OUT.mkdir(exist_ok=False)
    command = [sys.executable, str(ROOT/'collect_paper_evaluations.py'),
               '--manifest', str(BASE/'manifest.json'),
               '--trusted-collection', str(RUN/'complex_development24/TRUSTED_NATIVE.json'),
               '--output-dir', str(OUT/'scored'), '--modes', ','.join(protocol['modes']),
               '--scenario', 'serial', '--query-timeout-s', '180', '--auto-dop-max-dop', '16',
               '--torch-threads', '1', '--decision-timeout-ms', '1000', '--warmup', '1',
               '--repetitions', '1', '--seed', '2026091321', '--decision-vectors', str(BASE/'vectors.json')]
    save('COMMAND.json', command)
    sources = [Path(__file__), ROOT/'collect_paper_evaluations.py', ROOT/'scripts/verify_paper_evaluations.py',
               BASE/'PROTOCOL.json', BASE/'PREPARATION_SOURCES.json', BASE/'PREPARATION_STATUS.json',
               BASE/'manifest.json', BASE/'vectors.json', BASE/'CHOICES.json']
    save('SOURCES.json', {str(p):file_sha256(p) for p in sources})
    save('STATUS.json', dict(status='waiting_idle', expected=64))
    try:
        wait_for_idle(check, OUT/'IDLE.json')
        save('STATUS.json', dict(status='executing', expected=64))
        subprocess.run(command, check=True)
        proof_path = OUT/'scored/independent_verification.json'
        subprocess.run([sys.executable, str(ROOT/'scripts/verify_paper_evaluations.py'),
                        '--collection-dir', str(OUT/'scored'), '--output', str(proof_path)], check=True)
        proof = read(proof_path)
        assert proof['all_expected_executions_verified'] and proof['expected_slots'] == 64
        assert read(OUT/'scored/frontend_settings.json')['restored']
        events = [json.loads(line) for line in (OUT/'scored/events.jsonl').read_text().splitlines()]
        assert len(events) == 64
        assert all(e['status'] == 'verified' and e['dop_validation']['applied'] for e in events)
        expected = {(m,q,p) for m in protocol['modes'] for q in protocol['queries'] for p in ['warmup','measured']}
        assert {(e['mode'],e['id'],e['phase']) for e in events} == expected
        measured = collections.defaultdict(dict)
        for event in events:
            if event['phase'] == 'measured':
                measured[event['mode']][event['id']] = event['client_latency_ms']
        stats = {mode:dict(mean_ms=mean(values.values()),
                           **{f'p{int(p*100)}_ms':percentile(values.values(),p) for p in [.5,.9,.99]})
                 for mode, values in measured.items()}
        full = stats['refined_full']
        differences = {mode:{k:100*(1-full[k]/values[k]) for k in full}
                       for mode,values in stats.items() if mode != 'refined_full'}
        for path, expected_hash in read(OUT/'SOURCES.json').items():
            assert file_sha256(path) == expected_hash
        result = dict(status='verified', executions=64, statistics=stats, full_reduction_percent=differences,
                      per_query_ms=measured, mean_better_than_all_controls=all(v['mean_ms']>0 for v in differences.values()),
                      scope='Four reused development queries, one measured execution per mode/query. '
                            'Fixed-vector replay excludes offline search; record search_seconds separately. '
                            'All configurations, queries and outcomes retained; no robustness or report90 superiority claim.',
                      source_sha256={str(p):file_sha256(p) for p in [proof_path, OUT/'SOURCES.json', OUT/'scored/events.jsonl']})
        save('RESULT.json', result)
        lines = ['# 搜索改进开发小测', '', result['scope'], '',
                 '| 配置 | 平均 ms | p50 | p90 | p99 |', '|---|---:|---:|---:|---:|']
        for mode in protocol['modes']:
            s = stats[mode]
            lines.append(f"| {mode} | {s['mean_ms']:.2f} | {s['p50_ms']:.2f} | {s['p90_ms']:.2f} | {s['p99_ms']:.2f} |")
        lines += ['', f"完整改进组平均延迟低于全部对照：{result['mean_better_than_all_controls']}。"
                  '该小测不是统计显著性证明，不自动扩大实验。全部原始记录及不利结果保留。']
        (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
        save('STATUS.json', dict(status='verified', restored=True))
        print('\n'.join(lines))
    except BaseException as error:
        save('STATUS.json', dict(status='failed', error=repr(error)))
        raise


if __name__ == '__main__':
    main()
