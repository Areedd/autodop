"""Read-only compact live status, distinguishing execution from final verification."""
import datetime
import json
from pathlib import Path

run=Path(__file__).resolve().parents[1]/'runs/report90_20260912'
state=json.loads((run/'PIPELINE_STATUS.json').read_text())
out={k:state.get(k) for k in ('status','stage','error') if state.get(k) is not None}
stage=state['stage']
if state['status']=='complete' and not (run/'CLOSEOUT.json').exists():
    timing=run/'fe_timing/STATUS.json'
    t=json.loads(timing.read_text()) if timing.exists() else {'stage':'pending'}
    stage='fe_timing_'+t['stage']
    out={'status':'failed' if t['stage']=='failed' else 'running','stage':stage,'primary_pipeline':'complete'}
    if t.get('error'):out['error']=t['error']
    if t['stage']=='full':stage='fe_timing_full'
    if t['stage']=='pilot':stage='fe_timing_pilot'

name='concurrent_attempt'+stage.removeprefix('concurrent_c') if stage.startswith('concurrent_c') else stage
p=run/name/'scored/collection.json'
if not p.exists() and stage=='concurrent_c2':
    p=run/'concurrent_pilot_attempt1/scored/collection.json'
    if p.exists():out['substage']='high_concurrency_pilot'
try:
    if p.exists():
        c=json.loads(p.read_text());rr=c.get('rounds',[])
        settings=c['settings'];nq=len(c['queries'])
        counts=[int(v) for v in settings['clients'].split(',')] if settings['scenario']=='concurrent' else [1]
        out['expected']=sum(nq*max(1,(n*settings['minimum_per_client']+nq-1)//nq) for n in counts)*len(settings['modes'].split(','))*(settings['warmup']+settings['repetitions'])
        out.update(rounds=len(rr),verified=sum(r['verified'] for r in rr),failed=sum(r['failed_or_missing'] for r in rr))
        n=0;last={};sql_errors=0
        with (p.parent/'sql_executions.jsonl').open() as f:
            for line in f:
                try:last=json.loads(line);n+=1;sql_errors+=int(last.get('status')!='verified')
                except json.JSONDecodeError:pass
        out.update(executed=n,sql_errors=sql_errors,mode=last.get('mode'),phase=last.get('phase'),last_finished=last.get('finished_at'))
except (FileNotFoundError, json.JSONDecodeError):
    out['monitor_note']='Stage files are being initialized or updated; retry next snapshot.'
out['checked_at']=datetime.datetime.now().astimezone().isoformat()
print(json.dumps(out,ensure_ascii=False))
