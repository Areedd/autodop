"""Offline real-request parity for worker-order canonical cache keys."""
import copy
import hashlib
import json
import os
from pathlib import Path
import statistics
import time
import torch
from autodop.engine import PolicyEngine


BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/distillation_concurrency_extension'


class CanonicalCache(PolicyEngine):
    def decide(self, request):
        # Model and load correction use worker membership, not list order.
        normalized=copy.deepcopy(request)
        for fragment in normalized['fragments']:fragment['worker_ids']=sorted(fragment.get('worker_ids',[]))
        return super().decide(normalized)


def main():
    os.sched_setaffinity(0,{37});torch.set_num_threads(1)
    policy=Path(json.loads((BASE.parent/'PROTOCOL.json').read_text())['model'])
    recorded=[json.loads(line) for line in (BASE/'streams_pilot/decisions.jsonl').read_text().splitlines()]
    events=[json.loads(line) for line in (BASE/'streams_pilot/events.jsonl').read_text().splitlines()]
    cells={e['query_id']:(e['mode'],e['streams']) for e in events}
    kwargs=dict(load_correction={'cpu_threshold':.4,'mem_threshold':.65,'floor':.1})
    baseline=PolicyEngine(policy,**kwargs);candidate=CanonicalCache(policy,cache_capacity=128,**kwargs)
    counts=[0,0]
    def hook(index):
        def record(*args):counts[index]+=1
        return record
    baseline.model.register_forward_hook(hook(0));candidate.model.register_forward_hook(hook(1))
    timings=[[],[]];last=None
    for row in recorded:
        cell=cells[row['query_id']]
        if cell!=last:candidate.clear_decision_cache();last=cell
        start=time.perf_counter();a=baseline.decide(row['request']);timings[0].append(1000*(time.perf_counter()-start))
        start=time.perf_counter();b=candidate.decide(row['request']);timings[1].append(1000*(time.perf_counter()-start))
        assert a==b,'Canonical worker order changed response'
    result=dict(status='verified_offline_canonical_cache_parity',requests=len(recorded),model_calls=counts,
        mean_ms=[statistics.mean(t) for t in timings],median_ms=[statistics.median(t) for t in timings],
        scope='Actual recorded pilot requests, cache reset at every mode/stream cell. Offline parity and descriptive timing only; candidate not deployed or included in the running stream curve.',
        source_sha256={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),policy,BASE/'streams_pilot/decisions.jsonl',BASE/'streams_pilot/events.jsonl',BASE.parents[2]/'autodop/engine.py']})
    with (BASE/'CANONICAL_CACHE_PILOT.json').open('x') as f:json.dump(result,f,indent=2)
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
