"""Four-mode native admission pilot; frozen predictor and common SQL collector."""
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

from collect_trusted_dataset import frontend_settings
from report90_execute import ROOT, RUN, check
from report90_native_predictor import NativePredictor
from report90_queue_extension import connect, settings_guard

OUT = RUN / 'native_budget_instrumented32'
SUPPORT = RUN / 'native_budget_pilot_support'
MODES = {'native':'fixed8', 'native_budget':'predicted',
         'policy_static':'fixed8', 'policy_budget':'predicted'}


def save(name, obj):
    (OUT/name).write_text(json.dumps(obj, indent=2)+'\n')


def main():
    OUT.mkdir(exist_ok=False)
    save('STATUS.json', dict(status='running', pid=os.getpid()))
    os.sched_setaffinity(0, set(range(27,35)))
    model_path = RUN/'native_predictor_service17/MODEL.json'
    predictor = NativePredictor.load(model_path)
    assert hashlib.sha256((ROOT.parents[1]/'output/fe/lib/starrocks-fe.jar').read_bytes()).hexdigest() == json.loads((RUN/'native_queue_instrumentation/BINARY_AUDIT.json').read_text())['instrumented_sha256']
    manifest = json.loads((SUPPORT/'manifest.json').read_text())
    assert len(manifest['queries']) == 2
    original = json.loads((RUN/'PROTOCOL.json').read_text())
    command = [sys.executable, str(SUPPORT/'collector.py'), '--manifest', str(SUPPORT/'manifest.json'),
               '--trusted-collection', str(RUN/'DEVELOPMENT17_TRUSTED.json'), '--output-dir', str(OUT/'scored'),
               '--policy-model', original['model'], '--policy-variants', str(SUPPORT/'policy_variants.json'),
               '--modes', ','.join(MODES), '--scenario','concurrent','--clients','4',
               '--minimum-per-client','1','--warmup','1','--repetitions','1','--seed',str(original['seed']),
               '--query-timeout-s','180','--auto-dop-max-dop','16','--torch-threads','1',
               '--decision-timeout-ms','1000','--metrics-urls',
               'http://127.0.0.1:8040/metrics,http://127.0.0.1:8041/metrics,http://127.0.0.1:8042/metrics,http://127.0.0.1:8030/metrics']
    sources = [Path(__file__), model_path, ROOT/'scripts/report90_native_predictor.py',
               ROOT/'scripts/verify_paper_evaluations.py', *[p for p in SUPPORT.iterdir() if p.is_file()]]
    save('PROTOCOL.json', dict(queries=2, clients=4, tasks_per_mode_per_phase=4, expected_executions=32,
         warmup=1, repetitions=1, modes=MODES, retries=0,
         scope='Instrumented queue-path diagnostic, not a performance comparison: frozen native predictor versus fixed8 reservation, crossed with native DOP and unchanged static AutoDOP. Native V2 MBE handles all admission. All waiting and prediction included in SQL client latency. No report90 or independent generalization claim.',
         gate='No automatic full run. Require all32 SQL results/identities/DOP verified and prediction/actual allocated/released slots matched. Report all modes and failures before expansion.',
         source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}))
    save('COMMAND.json', command)
    check(OUT/'IDLE.json')
    lock = threading.Lock()
    healthy = threading.Event()
    state = dict(mode='bootstrap', active=0)
    posts = []
    errors = []
    switches = []
    server = None

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args): pass

        def do_GET(self):
            try:
                if self.path == '/health_check':
                    self.send_response(200); self.end_headers(); self.wfile.write(b'OK'); self.wfile.flush()
                    healthy.set()
                    return
                mode = self.path.removeprefix('/mode/')
                assert self.path.startswith('/mode/') and mode in MODES
                with lock:
                    assert state['active'] == 0
                    state['mode'] = mode
                    switches.append(dict(mode=mode, at=time.time()))
                    save('MODE_SWITCHES.json', switches)
                self.send_response(200); self.end_headers(); self.wfile.write(b'OK')
            except Exception as error:
                errors.append(repr(error)); self.send_response(500); self.end_headers()

        def do_POST(self):
            entered = False
            try:
                assert self.path == '/predict_csv'
                size = int(self.headers['Content-Length']); assert 0<size<1000000
                body = self.rfile.read(size).decode()
                with lock:
                    mode = state['mode']; state['active'] += 1; entered = True
                start = time.perf_counter_ns()
                pred = predictor.predict_csv(body, MODES.get(mode, 'fixed8'))
                elapsed = time.perf_counter_ns()-start
                with lock:
                    posts.append(dict(mode=mode, csv=body, prediction=pred, prediction_ns=elapsed, at=time.time()))
                    save('PREDICTOR_REQUESTS.json', dict(records=posts, errors=errors))
                self.send_response(200); self.end_headers(); self.wfile.write(str(pred['encoded_cost_bytes']).encode())
            except Exception as error:
                errors.append(repr(error)); self.send_response(500); self.end_headers()
            finally:
                if entered:
                    with lock: state['active'] -= 1

    try:
        server = ThreadingHTTPServer(('127.0.0.1',18083), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        with settings_guard(OUT), connect() as control:
            with control.cursor() as q:
                q.execute("ADMIN SHOW FRONTEND CONFIG LIKE 'enable_query_queue_v2'")
                assert str(q.fetchone()[2]).lower() == 'true'
                updates = dict(query_queue_slots_estimator_strategy='MBE',query_queue_v2_concurrency_level='4',
                               max_query_queue_history_slots_number='256',
                               query_cost_prediction_service_address='http://127.0.0.1:18083',enable_query_cost_prediction='true')
                with frontend_settings(q, updates, OUT/'frontend_settings.json', restore_connection_factory=connect):
                    with connect() as c, c.cursor() as b:
                        first = manifest['queries'][0]
                        sql = Path(first['sql_file']).read_text()
                        assert hashlib.sha256(Path(first['sql_file']).read_bytes()).hexdigest()==first['sql_sha256']
                        b.execute('USE `'+first['database']+'`')
                        for setting in ['enable_auto_dop=false','pipeline_dop=0','enable_runtime_adaptive_dop=false','enable_query_cache=false','enable_spill=false']:
                            b.execute('SET '+setting)
                        b.execute('EXPLAIN SCHEDULER /* native_budget_bootstrap */ '+sql.strip().rstrip(';'))
                        save('BOOTSTRAP_PLAN.json', b.fetchall())
                    assert healthy.wait(45)
                    time.sleep(1)
                    subprocess.run(command, check=True)
                    q.execute('ADMIN SET FRONTEND CONFIG ("enable_query_cost_prediction" = "false")')
                    time.sleep(1)
                    q.execute('SELECT QUERY_ID, STATE, EST_COSTS_SLOTS, ALLOCATE_SLOTS, QUERY, EXTRA_MESSAGE FROM information_schema.warehouse_queries')
                    cols=[c[0].lower() for c in q.description]
                    save('SLOT_HISTORY.json', dict(rows=[dict(zip(cols,r)) for r in q.fetchall()]))
        assert not errors
        proof=OUT/'scored/independent_verification.json'
        subprocess.run([sys.executable,str(ROOT/'scripts/verify_paper_evaluations.py'),'--collection-dir',str(OUT/'scored'),'--output',str(proof)],check=True)
        verified=json.loads(proof.read_text())
        assert verified['all_expected_executions_verified'] and verified['expected_slots']==32
        save('STATUS.json',dict(status='captured',executions=32))
    except BaseException as error:
        save('STATUS.json',dict(status='failed',error=repr(error)));raise
    finally:
        save('PREDICTOR_REQUESTS.json',dict(records=posts,errors=errors))
        if server is not None: server.shutdown();server.server_close()


if __name__ == '__main__': main()
