"""Paired MLP input-feature intervention with identical parameter dimensions."""
import json
from pathlib import Path
import subprocess
import sys
from report90_interaction_pair_audit import BASE, sha


def main():
    out=BASE/'mlp_interaction_pilot';out.mkdir(exist_ok=False)
    source=Path(__file__).with_name('report90_accuracy_baselines.py')
    protocol=dict(seed=17,smoke_epochs=2,pilot_epochs=30,learning_rates=[3e-4,1e-3],
                  methods=['mlp_rank','mlp_smooth_rank','mlp_regression'],arms=['full','no_explicit_interaction'],
                  intervention='Zero only normalized explicit DOP*numeric and DOP*onehot columns. Keep1088input dimensions, identical initial weights and hidden64/64 architecture;556columns remain active. Structural/DOP statistics remain.',
                  scope='Both arms retrained on same1365train/212valid and equal sampling/update budgets. No report90 or SQL. Reused development validation; small30epoch test before any100epoch or3seed expansion.',
                  selection='Macro historical/complex pair accuracy, then regret, earlier epoch/lower learning-rate setting; validate each10epochs.',
                  source_sha256={str(p):sha(p) for p in [Path(__file__),source,BASE/'merged_dataset/samples.jsonl',BASE/'merged_dataset/pairs.jsonl']})
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    guard="""    if stage == 'full':
        pilot = read(BASE / f'accuracy_baselines_seed{SEED}_pilot/RESULT.json')
        assert pilot['status'] == 'verified' and pilot['source_sha256'][str(Path(__file__))] == file_sha256(__file__)
"""
    for stage in ['smoke','pilot']:
        for arm in protocol['arms']:
            folder=out/f'{stage}_{arm}'
            text=source.read_text()
            changes={"out = BASE / (f'accuracy_baselines_seed{SEED}_' + stage)":'out = Path('+repr(str(folder))+')',
                     guard:'',
                     'epochs = 2 if stage == \'pilot\' else 100':f'epochs = {2 if stage=="smoke" else 30}',
                     "settings = [0] if stage == 'pilot' else [0, 1]":"settings = [0, 1]",
                     "['mlp_rank', 'mlp_smooth_rank', 'mlp_regression', 'xgb_regression']":"['mlp_rank', 'mlp_smooth_rank', 'mlp_regression']",
                     "Path(__file__).with_name('report90_models.py')":'Path('+repr(str(source.with_name('report90_models.py')))+')',
                     "Path(__file__).with_name('report90_complex_retrain.py')":'Path('+repr(str(source.with_name('report90_complex_retrain.py')))+')',
                     'No new feature removal to weaken baselines.':f'Paired feature intervention arm={arm}; see parent protocol; full counterpart retained.',
                     "'epochs': epochs,":"'parent_protocol': "+repr(str(out/'PROTOCOL.json'))+", 'feature_arm': "+repr(arm)+", 'epochs': epochs,",
                     "sources = [Path(__file__),":"sources = [Path(__file__), Path("+repr(str(source))+"), Path("+repr(str(out/'PROTOCOL.json'))+"),",
            }
            if arm=='no_explicit_interaction':
                changes['    xx = torch.stack']= '''    n=len(meta['numeric_features']);c=sum(len(meta['category_vocab'][k]) for k in meta['category_features']);w=2*n+2*c+5
    masked=[pool*w+j for pool in range(4) for j in range(n+c+1,2*n+2*c+1)]
    assert len(masked)==532
    for value in flat.values():value[masked]=0
    save(out/'MASK.json',{'zeroed_normalized_columns':masked,'input_width':1088,'active_columns':556})
    xx = torch.stack'''
            for old,new in changes.items():
                assert text.count(old)==1,(old,text.count(old))
                text=text.replace(old,new)
            script=out/f'{stage}_{arm}_trainer.py';compile(text,str(script),'exec');script.write_text(text)
            (out/f'{stage}_{arm}_TRANSFORM.json').write_text(json.dumps(dict(original_sha256=sha(source),generated_sha256=sha(script),changes=changes),indent=2)+'\n')
            (out/'STATUS.json').write_text(json.dumps(dict(status='running',stage=stage,arm=arm))+'\n')
            with (out/f'{stage}_{arm}.log').open('w') as stream:
                subprocess.run([sys.executable,str(script),'--stage','pilot','--seed','17','--cpu','35'],stdout=stream,stderr=subprocess.STDOUT,check=True)
            assert json.loads((folder/'RESULT.json').read_text())['status']=='verified'
        # Both smoke arms must complete/reload before the30epoch paired pilot.
    records={arm:json.loads((out/f'pilot_{arm}/RESULT.json').read_text()) for arm in protocol['arms']}
    summary={kind:{arm:r['selected'][kind]['selected']['validation']['weighted_rank_accuracy'] for arm,r in records.items()} for kind in protocol['methods']}
    (out/'RESULT.json').write_text(json.dumps(dict(status='completed_reload_verified_pending_independent_audit',macro_accuracy=summary,source_sha256={str(out/f'pilot_{arm}/RESULT.json'):sha(out/f'pilot_{arm}/RESULT.json') for arm in protocol['arms']}),indent=2)+'\n')
    (out/'STATUS.json').write_text(json.dumps(dict(status='complete_pending_independent_audit'))+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
