"""Recompute policy-stage outputs by split; confidence is not measured execution quality."""
import argparse
import json
from pathlib import Path
from statistics import mean
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_policy_model
from autodop.training import file_sha256

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'runs/report90_20260912/policy_final_stage_ablation'


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--phase',choices=['smoke','full'],required=True)
    args=parser.parse_args()
    directory=BASE/args.phase
    completed=directory/'RESULT.json'
    result=json.loads(completed.read_text());assert result['status']=='verified'
    for path,digest in result['source_sha256'].items():assert file_sha256(path)==digest
    protocol=json.loads((BASE/'PROTOCOL.json').read_text())
    for path,digest in protocol['source_sha256'].items():assert file_sha256(path)==digest
    contract=json.loads(Path(protocol['training_contract']).read_text())
    train=set(contract['train_plan_keys']);valid=set(contract['valid_plan_keys'])
    assert len(train)==130 and len(valid)==14 and not train&valid
    torch.set_num_threads(1)
    initial,saved=load_policy_model(protocol['initial_policy']);initial.eval()
    samples,_,_=load_dataset(protocol['dataset']);by={s['plan_key']:s for s in samples}
    assert set(by)==train|valid
    graphs={k:build_graph(s,saved['metadata'],unknown_dop=True) for k,s in by.items()}
    classes=saved['metadata']['dop_classes']
    def predict(model):
        model.eval();outputs={}
        with torch.no_grad():
            for key,graph in graphs.items():
                p=model(graph).softmax(-1)
                outputs[key]=dict(dops=[classes[i] for i in p.argmax(-1).tolist()],confidence=float(p.max(-1).values.min()))
        return outputs
    reference=predict(initial)
    summaries={};sources=[Path(__file__),completed,BASE/'PROTOCOL.json',Path(protocol['initial_policy'])]
    for arm,record in result['arms'].items():
        checkpoint=Path(record['checkpoint']);assert file_sha256(checkpoint)==record['checkpoint_sha256'];sources.append(checkpoint)
        model,metadata=load_policy_model(checkpoint)
        assert metadata['metadata']==saved['metadata'] and metadata['model_config']==saved['model_config']
        recomputed=predict(model);stored={r['plan_key']:r for r in record['predictions']}
        assert set(stored)==set(recomputed)
        for key,row in recomputed.items():
            assert row['dops']==stored[key]['predicted_dops'] and row['confidence']==stored[key]['confidence']
            assert stored[key]['split']==('train' if key in train else 'valid')
        summary=dict(epochs=record['epochs'],training_seconds=record['training_seconds'])
        for partition,keys in [('train',train),('valid',valid)]:
            changed_plans=sum(recomputed[k]['dops']!=reference[k]['dops'] for k in keys)
            changed_nodes=sum(sum(a!=b for a,b in zip(recomputed[k]['dops'],reference[k]['dops'])) for k in keys)
            total_nodes=sum(len(reference[k]['dops']) for k in keys)
            summary[partition]=dict(plans=len(keys),changed_dop_plans=changed_plans,changed_nodes=changed_nodes,
                                    nodes=total_nodes,unchanged_node_fraction=1-changed_nodes/total_nodes,
                                    accepted_at_half=sum(recomputed[k]['confidence']>=.5 for k in keys),
                                    mean_min_confidence=mean(recomputed[k]['confidence'] for k in keys))
        summaries[arm]=summary
    audit=dict(status='verified_recomputed_training_outputs',phase=args.phase,arms=summaries,
               scope='DOP changes relative to initialization and confidence on 130 train/14 existing validation plans. These are preservation/threshold statistics, not optimal-DOP accuracy, calibrated uncertainty or SQL speed. No checkpoints selected using these results.',
               source_sha256={str(p):file_sha256(p) for p in sources})
    destination=directory/'TRAINING_AUDIT.json'
    with destination.open('x') as stream:json.dump(audit,stream,indent=2);stream.write('\n')
    lines=['# 最终策略训练阶段输出核验：'+args.phase,'',audit['scope'],'',
           '| 组别 | 轮数 | 训练循环秒 | 训练配置改变计划 | 训练达阈值计划 | 验证配置改变计划 | 验证达阈值计划 |',
           '|---|---:|---:|---:|---:|---:|---:|']
    for arm,s in summaries.items():
        lines.append(f"| {arm} | {s['epochs']} | {s['training_seconds']:.2f} | {s['train']['changed_dop_plans']}/130 | {s['train']['accepted_at_half']}/130 | {s['valid']['changed_dop_plans']}/14 | {s['valid']['accepted_at_half']}/14 |")
    (directory/'TRAINING_REPORT.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines))


if __name__=='__main__':main()
