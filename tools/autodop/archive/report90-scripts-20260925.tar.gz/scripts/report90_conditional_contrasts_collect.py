"""Collect frozen training-only one-group DOP endpoint contrasts; no fitting."""
import json
import os
from pathlib import Path
import subprocess
import sys

from autodop.data import sample_from_trace
from build_trusted_dataset import digest
from report90_execute import ROOT, RUN, check
from report90_wait_for_idle import wait_for_idle
from report90_conditional_contrasts_prepare import OUT as BASE
from report90_neighborhood_prepare import sha

OUT = BASE / 'collection'


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def main():
    os.sched_setaffinity(0, set(range(27, 35)))
    assert json.loads((RUN / 'search_refinement_report90/full/STATUS.json').read_text()) == {'status': 'verified', 'restored': True}
    assert json.loads((BASE / 'STATUS.json').read_text())['status'] == 'prepared'
    protocol = json.loads((BASE / 'PROTOCOL.json').read_text())
    for p, h in protocol['source_sha256'].items():
        assert sha(Path(p)) == h
    assert not OUT.exists()
    OUT.mkdir()
    sources = [Path(__file__), BASE / 'PROTOCOL.json', BASE / 'manifest.json', BASE / 'vectors.json', ROOT / 'collect_paper_evaluations.py', ROOT / 'scripts/verify_paper_evaluations.py']
    save('SOURCES.json', {str(p): sha(p) for p in sources})
    save('STATUS.json', {'status': 'waiting_idle', 'pid': os.getpid()})
    wait_for_idle(check, OUT / 'IDLE.json')
    command = [sys.executable, str(ROOT / 'collect_paper_evaluations.py'), '--manifest', str(BASE / 'manifest.json'),
        '--trusted-collection', str(RUN / 'complex_development24/TRUSTED_NATIVE.json'), '--output-dir', str(OUT / 'scored'),
        '--modes', ','.join(protocol['modes']), '--scenario', 'serial', '--query-timeout-s', '180', '--auto-dop-max-dop', '16',
        '--torch-threads', '1', '--decision-timeout-ms', '1000', '--warmup', '1', '--repetitions', '1', '--seed', '2026091422',
        '--decision-vectors', str(BASE / 'vectors.json')]
    save('COMMAND.json', command)
    save('STATUS.json', {'status': 'executing', 'pid': os.getpid(), 'expected': 56})
    with (OUT / 'collector.log').open('w') as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
    proof_path = OUT / 'scored/independent_verification.json'
    subprocess.run([sys.executable, str(ROOT / 'scripts/verify_paper_evaluations.py'), '--collection-dir', str(OUT / 'scored'), '--output', str(proof_path)], check=True)
    proof = json.loads(proof_path.read_text())
    assert proof['all_expected_executions_verified'] and proof['expected_slots'] == 56
    assert json.loads((OUT / 'scored/frontend_settings.json').read_text())['restored']
    events = [json.loads(line) for line in (OUT / 'scored/events.jsonl').open()]
    assert len(events) == 56 and all(e['status'] == 'verified' and e['dop_validation']['applied'] for e in events)
    assert {(e['id'], e['mode'], e['phase']) for e in events} == {(q, m, p) for q in protocol['queries'] for m in protocol['modes'] for p in ['warmup', 'measured']}
    manifest = {q['id']: q for q in json.loads((BASE / 'manifest.json').read_text())['queries']}
    proposals = json.loads((BASE / 'PROPOSALS.json').read_text())
    samples = []
    for event in events:
        if event['phase'] != 'measured':
            continue
        q = event['id']
        sample = sample_from_trace(event['trace'])
        sample['plan_key'] = digest({'sql_sha256': manifest[q]['sql_sha256'], 'plan': sample['plan_key']})
        assert sample['plan_key'] == proposals[q]['training_plan_key'], 'Plan changed: preserve observations without merging labels'
        sample.update(template_id=q, template_family=manifest[q]['template_family'], sql_sha256=manifest[q]['sql_sha256'],
                      database=manifest[q]['database'], split='train', source_cohort='complex_new')
        samples.append(sample)
    assert len(samples) == 28
    (OUT / 'training_samples.jsonl').write_text(''.join(json.dumps(s, sort_keys=True) + '\n' for s in samples))
    for p, h in json.loads((OUT / 'SOURCES.json').read_text()).items():
        assert sha(Path(p)) == h
    save('RESULT.json', {'status': 'verified', 'executions': 56, 'newly_measured_configs': 28,
        'scope': 'Four training-only queries: remeasured anchor with previous dominant group fixed atDOP1 and three other low/high contrasts,7 configurations each; one formal observation per configuration. Labels not merged into active data and no automatic training/expansion.',
        'source_sha256': {str(p): sha(p) for p in [proof_path, OUT / 'scored/events.jsonl', OUT / 'training_samples.jsonl', OUT / 'SOURCES.json']}})
    save('STATUS.json', {'status': 'verified', 'restored': True})
    print('56 executions independently verified;28 controlled training configurations retained', flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        if OUT.exists():
            save('STATUS.json', {'status': 'failed', 'error': repr(error)})
        raise
