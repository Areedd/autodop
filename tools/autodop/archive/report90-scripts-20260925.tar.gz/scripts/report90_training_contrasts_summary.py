"""Summarize frozen single-group DOP contrasts and label consistency; no training."""
import itertools
import json
from pathlib import Path
from autodop.data import sample_from_trace
from report90_training_contrasts_prepare_v2 import OUT as BASE
from report90_neighborhood_prepare import sha

def main():
    folder=BASE/'collection';result=json.loads((folder/'RESULT.json').read_text());assert result['status']=='verified' and result['executions']==72
    for p,d in result['source_sha256'].items():assert sha(Path(p))==d
    rows=[json.loads(x) for x in (folder/'scored/events.jsonl').read_text().splitlines()];assert len(rows)==72
    proposals=json.loads((BASE/'PROPOSALS.json').read_text());protocol=json.loads((BASE/'PROTOCOL.json').read_text())
    phases={};overlaps={}
    for row in rows:
        assert row['status']=='verified' and row['dop_validation']['applied']
        phases.setdefault(row['id'],{}).setdefault(row['phase'],{})[row['mode']]=float(row['trace']['latency_ms'])
        sample=sample_from_trace(row['trace']);workers=[set(f['worker_ids']) for f in sample['fragments']]
        signature=tuple(tuple(len(a&b) for b in workers) for a in workers)
        overlaps.setdefault(row['id'],set()).add(signature)
    summaries={};totals={'formal_eligible_pairs':0,'both_phase_eligible_pairs':0,'same_order_both_phase_pairs':0,'endpoint_contrasts':0,'endpoint_formal_gap_ge3pct':0,'endpoint_formal_gap_ge20pct':0,'endpoint_both_phase_ge3pct':0,'endpoint_same_order_both_phase':0}
    for query,values in sorted(phases.items()):
        warm,formal=values['warmup'],values['measured'];assert set(warm)==set(formal)==set(protocol['modes']);assert all(v>0 for v in [*warm.values(),*formal.values()])
        pairs={'formal_eligible_pairs':0,'both_phase_eligible_pairs':0,'same_order_both_phase_pairs':0}
        for a,b in itertools.combinations(sorted(formal),2):
            fw=max(formal[a],formal[b])/min(formal[a],formal[b])>=1.03;ww=max(warm[a],warm[b])/min(warm[a],warm[b])>=1.03
            pairs['formal_eligible_pairs']+=fw;pairs['both_phase_eligible_pairs']+=fw and ww;pairs['same_order_both_phase_pairs']+=fw and ww and ((formal[a]<formal[b])==(warm[a]<warm[b]))
        for key,value in pairs.items():totals[key]+=int(value)
        contrasts=[]
        for i,group in enumerate(proposals[query]['selected_groups']):
            lo,hi=f'group{i}_low',f'group{i}_high';ratio=max(formal[lo],formal[hi])/min(formal[lo],formal[hi]);wratio=max(warm[lo],warm[hi])/min(warm[lo],warm[hi]);both=ratio>=1.03 and wratio>=1.03;same=(formal[hi]<formal[lo])==(warm[hi]<warm[lo])
            contrasts.append({'group':i,'fragment_indices':group['indices'],'root_node':group['root_node'],'low_dop':group['low'],'high_dop':group['high'],'low_ms':formal[lo],'high_ms':formal[hi],'high_vs_low_reduction_percent':100*(1-formal[hi]/formal[lo]),'formal_gap_ge3pct':ratio>=1.03,'both_phase_gap_ge3pct':both,'same_order_in_both_phases':same})
            totals['endpoint_contrasts']+=1;totals['endpoint_formal_gap_ge3pct']+=ratio>=1.03;totals['endpoint_formal_gap_ge20pct']+=ratio>=1.2;totals['endpoint_both_phase_ge3pct']+=both;totals['endpoint_same_order_both_phase']+=both and same
        summaries[query]={'anchor_ms':formal['anchor4'],'best_observed_ms':min(formal.values()),'formal_ms':formal,'warmup_ms':warm,'contrasts':contrasts,'pair_counts':pairs,'distinct_worker_overlap_matrices':len(overlaps[query])}
    totals={k:int(v) for k,v in totals.items()};output={'status':'verified_controlled_contrast_summary','queries':summaries,'totals':totals,
        'scope':'All4 training queries,36 configurations and72 warm/formal executions retained. Each contrast changes one equivalence group between legal extrema with other groups fixed. One formal observation per configuration; warmup agreement is only a noise diagnostic, not an independent formal repetition. No significance, model superiority, new training or active-dataset mutation claim.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),folder/'RESULT.json',folder/'scored/events.jsonl',BASE/'PROPOSALS.json',BASE/'PROTOCOL.json']}}
    target=BASE/'SUMMARY.json';assert not target.exists();target.write_text(json.dumps(output,indent=2)+'\n')
    lines=['# 单等价组DOP高低对照采集','',output['scope'],'','| 训练查询 | 组 | 根算子 | DOP1延迟ms | DOP16延迟ms | 高DOP相对低DOP降低 | 两阶段均≥3%且方向一致 |','|---|---:|---|---:|---:|---:|---|']
    for q,v in summaries.items():
        for c in v['contrasts']:lines.append(f"| {q} | {c['group']} | {c['root_node']} | {c['low_ms']:.2f} | {c['high_ms']:.2f} | {c['high_vs_low_reduction_percent']:.2f}% | {c['both_phase_gap_ge3pct'] and c['same_order_in_both_phases']} |")
    lines+=['',f"16组端点对照中，正式阶段差距≥3%的有{totals['endpoint_formal_gap_ge3pct']}组，≥20%的有{totals['endpoint_formal_gap_ge20pct']}组；两阶段都≥3%的{totals['endpoint_both_phase_ge3pct']}组中，方向一致{totals['endpoint_same_order_both_phase']}组。",'',f"36个配置内部所有正式有效对共{totals['formal_eligible_pairs']}对；两阶段均满足3%的{totals['both_phase_eligible_pairs']}对中，方向一致{totals['same_order_both_phase_pairs']}对。",'', '每个查询的worker重叠矩阵种类数：'+str({q:v['distinct_worker_overlap_matrices'] for q,v in summaries.items()}),'', '所有原始数据保留，未将预热作为独立正式重复，也未将有限候选中的最快者称为全局最优。']
    (BASE/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps(totals))

if __name__=='__main__':main()
