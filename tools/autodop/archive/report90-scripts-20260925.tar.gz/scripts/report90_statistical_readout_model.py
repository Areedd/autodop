"""Experimental Transformer readout retaining graph-wide feature statistics."""
import math

import torch
from torch import nn
from autodop.model import CostModel, MODEL_FORMAT_VERSION, save_checkpoint


class StatisticalReadoutCostModel(CostModel):
    def __init__(self, metadata, model_config=None):
        super().__init__(metadata, model_config)
        width = self.encoder.config['hidden_dim']
        self.statistics_scorer = nn.Sequential(nn.Linear(4 * width + 1, width), nn.GELU(), nn.Linear(width, 1))
        nn.init.zeros_(self.statistics_scorer[-1].weight)
        nn.init.zeros_(self.statistics_scorer[-1].bias)

    def forward(self, graph):
        nodes = self.encoder(graph)
        pooled, _ = self.global_readout(nodes)
        count = nodes.shape[0]
        statistics = torch.cat([nodes.mean(0), nodes.sum(0) / math.sqrt(count), nodes.max(0).values,
                                (nodes.var(0, correction=0) + 1e-6).sqrt(), nodes.new_tensor([math.log1p(count)])])
        return (self.scorer(pooled) + self.statistics_scorer(statistics)).squeeze(-1)


def load_statistical_model(path, device='cpu'):
    checkpoint = torch.load(path, map_location=device, weights_only=False)
    if checkpoint.get('format_version') != MODEL_FORMAT_VERSION or checkpoint.get('kind') not in ['cost', 'cost_statistical_readout']:
        raise ValueError('Unsupported statistical-readout cost checkpoint')
    model = StatisticalReadoutCostModel(checkpoint['metadata'], checkpoint['model_config'])
    if checkpoint['kind'] == 'cost':
        missing, unexpected = model.load_state_dict(checkpoint['model_state'], strict=False)
        expected = {'statistics_scorer.0.weight', 'statistics_scorer.0.bias', 'statistics_scorer.2.weight', 'statistics_scorer.2.bias'}
        if set(missing) != expected or unexpected:
            raise ValueError('Warm start differs beyond the new readout')
    else:
        model.load_state_dict(checkpoint['model_state'], strict=True)
    return model.to(device), checkpoint


def save_statistical_checkpoint(path, kind, model, metadata, training=None):
    if kind != 'cost' or not isinstance(model, StatisticalReadoutCostModel):
        raise ValueError('Expected experimental statistical readout model')
    save_checkpoint(path, 'cost_statistical_readout', model, metadata, training)
