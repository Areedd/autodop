"""Controlled experiment BE replacement with original-image rollback on validation failure."""
import datetime
import json
from pathlib import Path
import subprocess
import sys
import time

from report90_cpu_deployment_check import COMPOSE, check as deployment_check, read_json
from report90_cpu_parity import main as parity
from report90_execute import RUN, check
from report90_queue_extension import connect

FIX = RUN / 'cpu_capacity_fix'


def main():
    target = FIX / 'DEPLOYMENT_RESULT.json'
    assert not target.exists(), 'Inspect previous deployment result before any retry'
    assert not (FIX / 'DEPLOYMENT_VALIDATION.json').exists()
    image = json.loads((FIX / 'CANDIDATE_IMAGE.json').read_text())
    assert image['status'] == 'smoke_passed_not_deployed'
    original = json.loads((FIX / 'PARITY_ORIGINAL.json').read_text())
    assert original['status'] == 'original_health_and_results_recorded'
    baseline = json.loads((FIX / 'DEPLOYMENT_BASELINE.json').read_text())
    live = deployment_check(image['original_image_id'])
    assert live['compose_sha256'] == original['deployment']['compose_sha256']
    assert {r['container']: r['config_sha256'] for r in live['containers']} == {
        r['container']: r['config_sha256'] for r in original['deployment']['containers']}
    for name in ('queue_extension_20260913_attempt3', 'convergence_execution_20260913', 'search_convergence_20260913'):
        assert json.loads((RUN / name / 'STATUS.json').read_text())['status'] == 'complete'
    base = ['docker', 'compose', '-p', 'starrocks_deploy', '-f', str(COMPOSE)]
    base_config = read_json([*base, 'config', '--format', 'json'])
    commands = {}
    for phase, tag in [('candidate', image['candidate_tag']), ('original', image['original_tag'])]:
        command = [*base, '-f', str(FIX / f'compose_{phase}.json')]
        resolved = read_json([*command, 'config', '--format', 'json'])
        assert set(resolved['services']) == set(base_config['services'])
        for name, service in resolved['services'].items():
            expected = dict(base_config['services'][name])
            expected['image'] = tag
            assert service == expected, f'Unexpected deployment change in {phase}/{name}'
        commands[phase] = command
    for attempt in range(12):
        try:
            check(FIX / f'DEPLOYMENT_IDLE_{time.time_ns()}.json')
            break
        except RuntimeError:
            if attempt == 11:
                raise
            print('Shared server busy; retrying the unchanged idle gate in15seconds', flush=True)
            time.sleep(15)
    record = {'status': 'starting', 'at': datetime.datetime.now().astimezone().isoformat(),
              'candidate_image_id': image['candidate_image_id'], 'original_image_id': image['original_image_id'],
              'actions': [], 'scope': 'Only be1/be2/be3 in starrocks_deploy; retain all mounts. Roll back original images on startup or two-query parity validation failure.'}

    def save():
        temp = target.with_suffix('.tmp')
        temp.write_text(json.dumps(record, indent=2) + '\n')
        temp.replace(target)

    def replace(node, phase):
        command = [*commands[phase], 'up', '-d', '--no-deps', '--pull', 'never', '--force-recreate', node['compose_service']]
        action = {'phase': phase, 'container': node['container'], 'command': command, 'status': 'started'}
        record['actions'].append(action)
        save()
        result = subprocess.run(command, text=True, capture_output=True, timeout=120)
        (FIX / f"deploy_{phase}_{node['compose_service']}.log").write_text(result.stdout + result.stderr)
        assert result.returncode == 0, f'Compose failed for {node["container"]}'
        expected_image = image[f'{phase}_image_id']
        for _ in range(30):
            container = read_json(['docker', 'inspect', node['container']])[0]
            assert container['Image'] == expected_image
            with connect() as connection:
                with connection.cursor() as cursor:
                    cursor.execute('SHOW BACKENDS')
                    rows = [dict(zip([c[0] for c in cursor.description], row)) for row in cursor.fetchall()]
            port = 9049 + int(node['compose_service'][-1])
            backend = next(r for r in rows if int(r['HeartbeatPort']) == port)
            # Require a heartbeat after container creation; stale Alive alone is insufficient.
            from datetime import datetime as dt
            started = dt.fromisoformat(container['State']['StartedAt'].replace('Z', '+00:00')).timestamp()
            heartbeat = dt.fromisoformat(str(backend['LastHeartbeat'])).timestamp()
            if container['State']['Running'] and str(backend['Alive']).lower() == 'true' and heartbeat >= started:
                action['status'] = 'healthy'
                save()
                return
            time.sleep(5)
        raise RuntimeError(f'No fresh healthy heartbeat: {node["container"]}')

    save()
    try:
        for node in baseline:
            replace(node, 'candidate')
        parity('candidate')
        record['status'] = 'deployed_health_and_pilot_parity_verified'
        save()
    except BaseException as error:
        record.update(status='validation_failed_rolling_back', error=repr(error))
        save()
        failures = []
        for node in baseline:
            try:
                replace(node, 'original')
            except BaseException as rollback_error:
                failures.append({'container': node['container'], 'error': repr(rollback_error)})
        record.update(status='rolled_back' if not failures else 'rollback_incomplete', rollback_errors=failures)
        save()
        raise
    print(json.dumps({'status': record['status'], 'output': str(target)}))


if __name__ == '__main__':
    main()
