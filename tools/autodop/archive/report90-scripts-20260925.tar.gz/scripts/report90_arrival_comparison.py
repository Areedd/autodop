"""Retain both mirrored arrival orders and all four modes in the report."""
from pathlib import Path
import hashlib,json,statistics

RUN=Path(__file__).resolve().parents[1]/'runs/report90_20260912'
KEYS=('batch_seconds','mean_ms','p50_ms','p90_ms','p99_ms')


def quantile(values,p):
    v=sorted(values);x=(len(v)-1)*p;i=int(x);j=min(i+1,len(v)-1)
    return v[i]+(v[j]-v[i])*(x-i)


def main():
    sources=[Path(__file__)];arms={};pooled={};gates={};protocols={}
    for order in ('low_first','high_first'):
        out=RUN/('report90_native_budget_arrival_'+order)
        audit=json.loads((out/'ALLOCATION_AUDIT.json').read_text())
        timeline=json.loads((out/'TIMELINE_AUDIT.json').read_text())
        assert audit['status']=='verified' and audit['executions']==128
        assert timeline['status']=='verified_diagnostic' and timeline['queries']==128
        for proof in (audit,timeline):
            for name,digest in proof['source_sha256'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
        protocols[order]=json.loads((out/'PROTOCOL.json').read_text())
        metrics=audit['metrics']
        effects={name:{k:100*(1-metrics[new][k]/metrics[base][k]) for k in KEYS}
                 for name,new,base in [('heterogeneous_fixed','policy_static','native'),('heterogeneous_predicted','policy_budget','native_budget'),('budget_native','native_budget','native'),('budget_heterogeneous','policy_budget','policy_static')]}
        arms[order]=dict(metrics=metrics,effects=effects)
        gates[order]=dict(passed=timeline['arrival_order_passed'],checks=timeline['arrival_checks'])
        events=[json.loads(s) for s in (out/'scored/events.jsonl').read_text().splitlines()]
        for e in events:
            if e['phase']=='measured':pooled.setdefault(e['mode'],[]).append(e['client_latency_ms'])
        sources += [out/'ALLOCATION_AUDIT.json',out/'TIMELINE_AUDIT.json',out/'scored/events.jsonl',out/'PROTOCOL.json']
    assert protocols['low_first']['source_sha256']==protocols['high_first']['source_sha256']
    assert protocols['low_first']['first_query']!=protocols['high_first']['first_query']
    assert len(pooled)==4 and all(len(v)==32 for v in pooled.values())
    combined={mode:dict(observations=len(v),mean_ms=statistics.mean(v),p50_ms=quantile(v,.5),p90_ms=quantile(v,.9),p99_ms=quantile(v,.99)) for mode,v in pooled.items()}
    control_path=RUN/'native_arrival_control_audit/RESULT.json'
    control=json.loads(control_path.read_text());sources.append(control_path)
    result=dict(plan_control_status=control['status'],status='measured_diagnostic',executions=256,arrival_order_passed=all(g['passed'] for g in gates.values()),arrival_gates=gates,arms=arms,pooled=combined,
                scope='Two frozen queries, mirrored grouped arrival orders with 250 ms planned spacing, 16 clients, one warmup and formal batch per mode/order. All modes/orders retained. SQL latency excludes planned pre-submit delay; batch time includes it. Logging enabled. Pooled quantiles summarize 32 formal jobs per mode, not independent queries or replicated batches. Arrival control must pass before discussing controlled enqueue order; this alone does not establish plan or environmental equivalence.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    out=RUN/'native_arrival_comparison';out.mkdir(exist_ok=True)
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 相反到达顺序诊断','',result['scope'],'',f"实际入队顺序控制通过：{result['arrival_order_passed']}；全程计划/DOP一致性：{result['plan_control_status']}。",'',
           '正值表示延迟降低；负值表示增加。两种顺序分别报告。','',
           '| 顺序 | 对比 | 整批降低 | 平均降低 | p50降低 | p90降低 | p99降低 |','|---|---|---:|---:|---:|---:|---:|']
    for order,arm in arms.items():
        for name,effect in arm['effects'].items():lines.append('| '+order+' | '+name+' | '+' | '.join(f'{effect[k]:.2f}%' for k in KEYS)+' |')
    if not result['arrival_order_passed']:lines+=['','实际入队顺序未全部符合计划，保留全部结果，但不作为成功控制入队顺序的实验。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))

if __name__=='__main__':main()
