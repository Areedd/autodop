"""Validate the gate on the two frozen mixed-budget queries, without SQL data execution."""
import hashlib
import json
from pathlib import Path
from report90_execute import RUN,check
from report90_queue_extension import connect
from report90_plan_stability_gate import verify_stable_plans


def main():
    out=RUN/'native_plan_stability_gate_probe';out.mkdir(exist_ok=False)
    manifest=RUN/'native_mixed_budget_pilot_support/manifest.json'
    queries=json.loads(manifest.read_text())['queries']
    check(out/'IDLE.json')
    observations=[]
    def fetch(q,dop):
        path=Path(q['sql_file']);assert hashlib.sha256(path.read_bytes()).hexdigest()==q['sql_sha256']
        with connect() as conn,conn.cursor() as c:
            c.execute('USE `'+q['database']+'`')
            for setting in ['enable_auto_dop=false',f'pipeline_dop={dop}','enable_runtime_adaptive_dop=false','enable_query_cache=false','enable_spill=false']:
                c.execute('SET '+setting)
            c.execute("SHOW VARIABLES LIKE 'new_planner_optimize_timeout'");timeout=c.fetchone()
            observations.append(dict(id=q['id'],dop=dop,optimizer_timeout=timeout))
            (out/'SESSION_OBSERVATIONS.json').write_text(json.dumps(observations,indent=2)+'\n')
            c.execute('EXPLAIN VERBOSE '+path.read_text().strip().rstrip(';'))
            return '\n'.join(str(x[0]) for x in c.fetchall())+'\n'
    result=verify_stable_plans(queries,fetch,out/'plans')
    (out/'PROTOCOL.json').write_text(json.dumps(dict(query_data_executions=0,fresh_connection_each_explain=True,
        source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path(__file__).with_name('report90_plan_stability_gate.py'),manifest]},
        gate_status=result['status']),indent=2)+'\n')
    print(json.dumps(dict(status=result['status'],explains=len(result['records']),accepted=result['accepted']),indent=2))


if __name__=='__main__':main()
