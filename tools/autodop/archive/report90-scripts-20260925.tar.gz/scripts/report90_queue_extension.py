"""Shared native admission guard for every baseline; preserve queueing in client latency."""
import json,os,sys,time,subprocess,datetime,hashlib,argparse
from pathlib import Path
from contextlib import contextmanager
import pymysql
from report90_execute import ROOT,RUN,check
OUT=RUN/'queue_extension_20260913'
SETTINGS={'enable_query_queue_select':'true','enable_query_queue':'true','query_queue_concurrency_limit':'8','query_queue_mem_used_pct_limit':'0','query_queue_cpu_used_permille_limit':'0','query_queue_driver_high_water':'-1','query_queue_driver_low_water':'-1','query_queue_max_queued_queries':'1024','query_queue_pending_timeout_second':'180'}
def save(name,value):
 p=OUT/name;tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(p)
def status(stage,**extra):save('STATUS.json',{'status':'running','stage':stage,'pid':os.getpid(),'at':datetime.datetime.now().astimezone().isoformat(),**extra})
def connect():return pymysql.connect(host='127.0.0.1',port=9030,user='root',connect_timeout=5,read_timeout=10,autocommit=True)
@contextmanager
def settings_guard(folder):
 original={};record={'original':original,'requested':SETTINGS,'restored':False};path=folder/'QUEUE_SETTINGS.json'
 def record_save():path.write_text(json.dumps(record,indent=2)+'\n')
 with connect() as c:
  with c.cursor() as q:
   for key in SETTINGS:q.execute('SELECT @@global.'+key);original[key]=str(q.fetchone()[0])
 try:
  record_save()
  with connect() as c:
   with c.cursor() as q:
    for key,val in SETTINGS.items():q.execute('SET GLOBAL '+key+' = %s',(val,))
    actual={}
    for key in SETTINGS:q.execute('SELECT @@global.'+key);actual[key]=str(q.fetchone()[0])
    record['applied']=actual;record_save()
    normalize=lambda value:float({'true':'1','false':'0'}.get(str(value).lower(),str(value)))
    assert all(normalize(actual[key])==normalize(val) for key,val in SETTINGS.items()),actual
  yield
 finally:
  errors=[]
  with connect() as c:
   with c.cursor() as q:
    for key,val in reversed(list(original.items())):
     try:q.execute('SET GLOBAL '+key+' = %s',(val,))
     except Exception as e:errors.append(str(e))
    for key,val in original.items():q.execute('SELECT @@global.'+key);assert str(q.fetchone()[0])==val,key
  record.update(restored=not errors,restore_errors=errors);record_save();assert not errors

def run_stage(name,clients,pilot=False):
 p=OUT/name;p.mkdir(exist_ok=False);status(name)
 for attempt in range(20):
  try:check(p/f'IDLE_{attempt}.json');break
  except RuntimeError:
   if attempt==19:raise
   time.sleep(15)
 with settings_guard(p):
  original=json.loads((RUN/'PROTOCOL.json').read_text());cmd=[sys.executable,str(ROOT/'collect_paper_evaluations.py'),'--manifest',str(RUN/('pilot.json' if pilot else 'manifest.json')),'--trusted-collection',str(ROOT/'runs/preference_random200_20260911/random200/trusted_merged.json'),'--output-dir',str(p/'scored'),'--policy-model',original['model'],'--modes','native,policy_static,policy_load','--scenario','concurrent','--clients',str(clients),'--minimum-per-client','2' if pilot else '1','--warmup','1','--repetitions','1','--seed',str(original['seed']),'--query-timeout-s','180','--auto-dop-max-dop','16','--torch-threads','1','--decision-timeout-ms','1000','--metrics-urls','http://127.0.0.1:8040/metrics,http://127.0.0.1:8041/metrics,http://127.0.0.1:8042/metrics,http://127.0.0.1:8030/metrics']
  (p/'COMMAND.json').write_text(json.dumps(cmd,indent=2)+'\n');subprocess.run(cmd,check=True)
  subprocess.run([sys.executable,str(ROOT/'scripts/verify_paper_evaluations.py'),'--collection-dir',str(p/'scored'),'--output',str(p/'scored/independent_verification.json')],check=True)
  v=json.loads((p/'scored/independent_verification.json').read_text());assert v['all_expected_executions_verified'],'Admission pilot/full has failures; investigate before expanding'
  pending=[]
  for line in (p/'scored/resources.jsonl').open():
   entry=json.loads(line)
   if entry.get('url')!='http://127.0.0.1:8030/metrics':continue
   for row in entry.get('prometheus_raw','').splitlines():
    if row.startswith('starrocks_fe_query_queue_pending'):
     pending.append(float(row.split()[-1]))
  audit={'samples':len(pending),'max_pending':max(pending,default=0),'clients':clients,'native_queue_shared_by_all_modes':True}
  (p/'QUEUE_ACTIVITY.json').write_text(json.dumps(audit,indent=2)+'\n')
  if clients>8:assert max(pending,default=0)>0,'Queue activation not observed; configuration alone is not proof'
 return p

def main():
 protocol={'scope':'Resolve observed overload using the same native admission guard for native/static/load baselines; do not attribute native admission to AutoDOP.','queue_settings':SETTINGS,'cap_reason':'8 concurrent executions passed prior complete90 batch and concentrated pilot. Fixed before this extension; no per-mode cap tuning.','pilot':'2fixedqueries,16clients,minimum2perclient,1warm1measure; strict success and observed queue activity before expansion','formal':'All90queries once per mode/round;1warm1measure;clients8,16,20. Finitebatch, not standardTPC-H or steady state.','latency':'Client wall time includes admission waiting; queue metrics retained.','restoration':'Global queue settings and AutoDOP FE settings restored per stage.','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 assert not (OUT/'PROTOCOL.json').exists();save('PROTOCOL.json',protocol);status('wait_teacher_extension')
 teacher=RUN/'teacher_extension_20260913'
 while not (teacher/'COMPLETE.json').exists():
  t=json.loads((teacher/'STATUS.json').read_text());assert t['status']!='failed',t
  os.kill(t['pid'],0)
  assert b'report90_teacher_extension.py' in Path(f"/proc/{t['pid']}/cmdline").read_bytes()
  time.sleep(20)
 run_stage('pilot_c16',16,True)
 for c in [8,16,20]:run_stage(f'full_c{c}',c)
 save('STATUS.json',{'status':'complete','at':datetime.datetime.now().astimezone().isoformat()})
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--attempt',type=int,default=1);args=parser.parse_args();assert args.attempt>=1
 if args.attempt>1:OUT=RUN/f'queue_extension_20260913_attempt{args.attempt}'
 OUT.mkdir(exist_ok=True)
 try:main()
 except BaseException as e:save('STATUS.json',{'status':'failed','error':repr(e),'pid':os.getpid()});raise
