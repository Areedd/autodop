"""Compare fixed native reservation encoding on all previously frozen LOO models."""
import hashlib,json
from pathlib import Path
import numpy as np
from report90_execute import RUN
from report90_native_predictor import NativePredictor

out=RUN/'native_memory_model_slot_compare17';out.mkdir(exist_ok=False)
source=RUN/'native_memory_prediction_loo17/RESULT.json'
model=RUN/'native_predictor_service17/MODEL.json'
d=json.loads(source.read_text());assert d['status']=='verified'
predictor=NativePredictor.load(model);rows=[]
for r in d['rows']:
 encoded=predictor.encode(int(r['reservation_bytes']))
 rows.append(dict(id=r['id'],model=r['model'],observed_peak_bytes=r['observed_peak_bytes'],raw_budget_bytes=r['reservation_bytes'],
                  raw_budget_below_observed=r['under_reserved'],**encoded,
                  nominal_below_observed=encoded['nominal_bytes_per_worker']<r['observed_peak_bytes'],
                  observed_fraction_of_nominal=r['observed_peak_bytes']/encoded['nominal_bytes_per_worker']))
summary={}
for name in sorted({r['model'] for r in rows}):
 rs=[r for r in rows if r['model']==name];assert len(rs)==17
 summary[name]=dict(raw_under=sum(r['raw_budget_below_observed'] for r in rs),nominal_under=sum(r['nominal_below_observed'] for r in rs),
                    slots_median=float(np.median([r['expected_physical_slots'] for r in rs])),slots_min=min(r['expected_physical_slots'] for r in rs),slots_max=max(r['expected_physical_slots'] for r in rs),
                    max_observed_fraction_of_nominal=max(r['observed_fraction_of_nominal'] for r in rs),saturated=sum(r['saturated'] for r in rs))
result=dict(status='verified',scope='Offline existing development LOO predictions, same fixed60% headroom and power-of-two slot encoding for all models. Nominal capacity coverage is not an actual memory guarantee. No model selection, parameter tuning, SQL execution or deployment.',summaries=summary,rows=rows,
 source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source,model,Path(__file__)]})
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# 既有内存模型的原生槽位换算对照','','| 模型 | 原预算低估/17 | 编码名义额度低于峰值/17 | 中位槽位 | 范围 |','|---|---:|---:|---:|---|']
for k,v in summary.items():lines.append(f"| {k} | {v['raw_under']} | {v['nominal_under']} | {v['slots_median']:.0f} | {v['slots_min']}–{v['slots_max']} |")
lines+=['',result['scope'],'','不能将槽位向上取整后的覆盖解释为原模型通过内存预测准确性筛查，或证明实际并发不会内存超限。']
(out/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps(summary))
