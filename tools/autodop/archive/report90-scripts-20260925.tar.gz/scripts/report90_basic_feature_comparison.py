"""Explicitly scoped basic/enhanced feature comparison on one shared pair pool."""
import json
from pathlib import Path
from report90_interaction_pair_audit import BASE, accuracy, sha


def main():
    paths = [BASE/'hard_pair_ema_pilot/pair_audit/RESULT.json',
             BASE/'hard_pair_ema_pilot/pair_audit/PAIR_POOL.json',
             BASE/'xgb_feature_ablation_pilot/RESULT.json',
             BASE/'xgb_feature_ablation_pilot/VALIDATION_ROWS.json']
    teacher,pool,features,rows=[json.loads(p.read_text()) for p in paths]
    assert teacher['status']=='verified_independent_pair_replay' and features['status']=='verified'
    key=lambda r:(r['plan_key'],r['config_key'])
    rowmap={key(r):i for i,r in enumerate(rows)}
    assert set(rowmap)=={key(r) for r in pool['samples']} and len(rowmap)==212
    for r in pool['samples']:
        other=rows[rowmap[key(r)]]
        assert r['latency_ms']==other['latency_ms'] and r['cohort']==other['source_cohort']
    results={'transformer_multistage_hard_ema_seed17':teacher['models']['transformer']['macro_accuracy']}
    for name,arm in [('xgboost_basic_no_explicit_interaction','no_explicit_dop_interaction'),('xgboost_enhanced_full','full')]:
        r=features['selected'][arm]
        scores=[r['scores'][rowmap[key(s)]] for s in pool['samples']]
        q=accuracy(pool['pairs'],scores)
        assert q['macro_accuracy']==r['quality']['weighted_rank_accuracy']
        results[name]=q['macro_accuracy']
    out=BASE/'basic_feature_comparison';out.mkdir(exist_ok=False)
    t=results['transformer_multistage_hard_ema_seed17']
    record=dict(status='verified_shared_pair_pool',seed=17,pairs=len(pool['pairs']),macro_accuracy=results,
                advantage_pp={name:100*(t-value) for name,value in results.items() if name.startswith('xgboost')},
                limitation='Single fixed seed, reused validation and different training histories/representations. Basic feature comparator selected after prior enhanced baseline results; not a prospective all-model superiority test.',
                source_sha256={str(p):sha(p) for p in paths+[Path(__file__)]})
    (out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
    lines=['# 基础与增强特征基线对照','',
           '固定seed17，在相同212验证配置、920有效对上重算；主指标为历史与复杂查询两组等权排序准确率。', '',
           '| 模型 | 输入处理 | 准确率 |','|---|---|---:|',
           f"| 多阶段Transformer＋错对采样＋EMA | 类别/DOP embedding与图结构，无显式DOP乘积 | {100*t:.4f}% |",
           f"| XGBoost基础特征版 | 556维，移除显式DOP乘积，保留图统计 | {100*results['xgboost_basic_no_explicit_interaction']:.4f}% |",
           f"| XGBoost增强特征版 | 1088维，包含显式DOP乘积及图统计 | {100*results['xgboost_enhanced_full']:.4f}% |", '',
           '该Transformer保留此前多阶段训练，两个XGBoost均200棵树、深度3/6按开发集选取；两类模型的训练预算及输入表示不相同。基础版本是在观察增强基线后新增的比较，必须公开这一分析范围。', '',
           '此表仅支持该固定种子与查询集合上的对照，不能推翻此前Transformer三种子结果不稳定的结论。完整增强基线继续保留；相对基础版本的优势不等价于全面领先。', '',
           '完整数据与哈希：[RESULT.json](RESULT.json)。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(record['advantage_pp'],indent=2))


if __name__=='__main__':main()
