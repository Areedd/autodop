"""Join read-only JobSpec gate observations to the instrumented SQL executions."""
import json,re,hashlib
from pathlib import Path
from collections import defaultdict
from report90_execute import ROOT,RUN
out=RUN/'native_budget_instrumented32'
events=[json.loads(l) for l in (out/'scored/events.jsonl').read_text().splitlines()];assert len(events)==32 and all(e['status']=='verified' for e in events)
ids={e['query_id']:e for e in events};gates={};all_lines=[]
for line in (ROOT.parents[1]/'output/fe/log/fe.out').open(errors='replace'):
 if not line.startswith('NATIVE_QUEUE_GATE|'):continue
 all_lines.append(line.rstrip('\n'));fields=dict(piece.split('=',1) for piece in line.strip().split('|')[1:]);qid=fields['id']
 if qid not in ids:continue
 assert qid not in gates;gates[qid]=fields
assert gates.keys()==ids.keys(),('Missing diagnostic gates',len(gates))
summary=defaultdict(list)
for qid,e in ids.items():summary[e['phase']+'/'+e['mode']].append(gates[qid])
proof=dict(status='observed',queries=32,by_batch=dict(summary),all_diagnostic_lines=all_lines,
 scope='Read-only predicate instrumentation; no native admission performance claim. All original Builder instructions preserved. Gate observations matched to independently verified SQL query IDs.',
 source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),out/'scored/events.jsonl',out/'scored/independent_verification.json',RUN/'native_queue_instrumentation/BINARY_AUDIT.json']})
(out/'GATE_AUDIT.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(summary)))
