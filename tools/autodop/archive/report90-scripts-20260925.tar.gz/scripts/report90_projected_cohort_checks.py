"""Reproducible gradient algebra tests and completed-run projection counters."""
import json
from pathlib import Path
import torch
from report90_projected_cohort_gradients import assign_gradients
from report90_neighborhood_prepare import RUN,sha
OUT=RUN/'structure_coverage20/projected_cohort_pilot'


def main():
    p=torch.nn.Parameter(torch.tensor([1.,2.],dtype=torch.float64));records=[]
    for name in ['conflict','agreement','single','zero']:
        groups={'historical':[2*p[0]],'complex_new':[-2*p[0]+2*p[1]]} if name=='conflict' else {'historical':[p.square().sum()],'complex_new':[2*p.square().sum()]} if name=='agreement' else {'historical':[p.square().sum()],'complex_new':[]} if name=='single' else {'historical':[0*p.sum()],'complex_new':[p.sum()]}
        expected=[.5,1.5] if name=='conflict' else [3.,6.] if name=='agreement' else [2.,4.] if name=='single' else [.5,.5]
        result=assign_gradients(groups,[p]);assert torch.equal(p.grad,torch.tensor(expected,dtype=torch.float64));assert result['projected']==(name=='conflict')
        records.append({'case':name,'gradient':p.grad.tolist(),**result})
    run=OUT/'pilot/transformer_h0/RESULT.json';r=json.loads(run.read_text());assert len(r['history'])==30
    history=r['history'];assert all(0<=h['projected_steps']<=h['optimizer_steps']==39 for h in history)
    result={'status':'verified_gradient_algebra_and_counters','checks':records,'optimizer_steps':sum(h['optimizer_steps'] for h in history),'projected_steps':sum(h['projected_steps'] for h in history),'projection_count_by_epoch':[h['projected_steps'] for h in history],
        'scope':'Exact synthetic float64 algebra checks. Real float32 grouping can differ from a single backward traversal by rounding even without projection. Counters show whether the intervention was applied, not causal accuracy benefits.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),Path(__file__).with_name('report90_projected_cohort_gradients.py'),run]}}
    target=OUT/'GRADIENT_CHECK.json';assert not target.exists();target.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

if __name__=='__main__':main()
