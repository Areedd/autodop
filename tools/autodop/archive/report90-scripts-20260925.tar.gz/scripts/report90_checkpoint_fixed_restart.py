"""Bounded native V2 pilot, with original FE file/runtime configuration recovery."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

import report90_fe_timing as fe
from report90_execute import ROOT, RUN, check
from report90_queue_extension import connect

OUT = RUN / 'checkpoint_fixed_restart'
CONF = ROOT.parents[1] / 'output/fe/conf/fe.conf'


def save(name, value):
    p = OUT / name
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2) + '\n')
    tmp.chmod(0o600)
    tmp.replace(p)


def configs():
    with connect() as c, c.cursor() as q:
        q.execute('ADMIN SHOW FRONTEND CONFIG')
        cols = [x[0].lower() for x in q.description]
        rows = [dict(zip(cols, r)) for r in q.fetchall()]
    return {r['key']: r for r in rows}


def restore_runtime():
    old = json.loads((OUT / 'RUNTIME_BEFORE.json').read_text())
    now = configs()
    changed = []
    with connect() as c, c.cursor() as q:
        for key, row in old.items():
            if str(row['ismutable']).lower() != 'true':
                continue
            if str(now[key]['value']) != str(row['value']):
                q.execute('ADMIN SET FRONTEND CONFIG (' + json.dumps(key) + ' = ' +
                          json.dumps(str(row['value'])) + ')')
                changed.append(key)
    final = configs()
    assert all(str(final[k]['value']) == str(r['value']) for k, r in old.items()
               if str(r['ismutable']).lower() == 'true')
    return changed


def verify_restoration():
    try:
        for _ in range(90):
            if fe.db_ready():
                break
            time.sleep(2)
        else:
            raise RuntimeError('Original FE readiness timeout')
        changed = restore_runtime()
        assert fe.sha(fe.JAR)=='fb2e974406e7291edd71df38d1826ac1610af043873e3ada93d9afeca8e53808'
        assert CONF.read_bytes() == (OUT / 'original-fe.conf').read_bytes()
        launch = json.loads((OUT / 'ORIGINAL_FE_LAUNCH.json').read_text())
        assert sorted(os.sched_getaffinity(fe.fe_pid())) == launch['affinity']
        assert str(configs()['enable_query_queue_v2']['value']).lower() == 'false'
        save('RESTORATION.json', dict(restored=True, pid=fe.fe_pid(), runtime_keys_restored=changed,
                                      configuration_sha256=fe.sha(CONF)))
        print('Original FE and runtime configuration restored', flush=True)
    except BaseException as error:
        save('RESTORATION.json', dict(restored=False, error=repr(error)))
        raise


def main():
    OUT.mkdir(exist_ok=False)
    save('STATUS.json', dict(stage='preflight', pid=os.getpid()))
    check(OUT / 'IDLE.json')
    current = RUN / 'native_predictor_service17/CURRENT_FE_LAUNCH.json'
    launch = json.loads(current.read_text())
    assert fe.fe_pid() == launch['pid']
    assert fe.sha(CONF) == launch['config_sha256']
    assert fe.sha(fe.JAR) == 'fb2e974406e7291edd71df38d1826ac1610af043873e3ada93d9afeca8e53808'
    save('ORIGINAL_FE_LAUNCH.json', launch)
    shutil.copy2(CONF, OUT / 'original-fe.conf')
    (OUT / 'original-fe.conf').chmod(0o600)
    original = configs()
    assert str(original['enable_query_queue_v2']['value']).lower() == 'false'
    assert str(original['enable_query_cost_prediction']['value']).lower() == 'false'
    save('RUNTIME_BEFORE.json', original)
    save('PROTOCOL.json', dict(scope='Validate checkpoint variable isolation through actual checkpoint; no data queries; restore original FE and mutable runtime settings. No automatic expansion.',
         sources={str(p): fe.sha(p) for p in [Path(__file__), ROOT/'scripts/report90_checkpoint_fixed_probe.py', ROOT/'scripts/report90_checkpoint_fixed_probe.py']}))
    fe.OUT = OUT
    stopped = False
    try:
        fe.stop_fe()
        stopped = True
        CONF.write_bytes((OUT / 'original-fe.conf').read_bytes())
        diagnostic_jar = RUN/'checkpoint_variable_regression/fixed-fe.jar'
        assert fe.sha(diagnostic_jar)==json.loads((diagnostic_jar.parent/'BINARY_AUDIT.json').read_text())['instrumented_sha256']
        tmp=fe.JAR.with_suffix('.queue-diagnostic-tmp');shutil.copy2(diagnostic_jar,tmp);tmp.replace(fe.JAR)
        fe.start_fe()
        restore_runtime()
        assert str(configs()['enable_query_queue_v2']['value']).lower() == 'false'
        save('STATUS.json', dict(stage='pilot', pid=os.getpid(), fe_pid=fe.fe_pid()))

        subprocess.run([sys.executable, str(ROOT/'scripts/report90_checkpoint_fixed_probe.py')], check=True)
        save('STATUS.json', dict(stage='pilot_verified', pid=os.getpid()))
    except BaseException as error:
        save('STATUS.json', dict(stage='failed', error=repr(error), pid=os.getpid()))
    finally:
        if stopped:
            pid = fe.fe_pid()
            proc = Path(f'/proc/{pid}/stat')
            if proc.exists() and not proc.read_text().split(') ')[1].startswith('Z'):
                fe.stop_fe()
            original_jar=RUN/'fe_timing/original-starrocks-fe.jar'
            assert fe.sha(original_jar)=='fb2e974406e7291edd71df38d1826ac1610af043873e3ada93d9afeca8e53808'
            tmp=fe.JAR.with_suffix('.queue-restore-tmp');shutil.copy2(original_jar,tmp);tmp.replace(fe.JAR)
            CONF.write_bytes((OUT / 'original-fe.conf').read_bytes())
            save('RESTORATION.json', dict(restored=False, configuration_restored=True, stage='starting_original'))
            # The restored FE remains this tool session's foreground process.
            # A child waits for readiness, restores mutable settings and writes proof.
            subprocess.Popen([sys.executable, str(Path(__file__)), '--verify-restoration'])
            fe.foreground_original_fe()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify-restoration', action='store_true')
    args = parser.parse_args()
    if args.verify_restoration:
        verify_restoration()
    else:
        main()
