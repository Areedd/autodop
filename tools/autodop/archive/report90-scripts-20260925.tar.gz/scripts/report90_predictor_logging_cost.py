"""CPU-only diagnostic of evidence serialization; no query rerun or service change."""
import hashlib,json,os,statistics,time
from pathlib import Path
from report90_execute import RUN

def main():
 os.sched_setaffinity(0,{35})
 source=RUN/'report90_native_budget_cap4_full/PREDICTOR_REQUESTS.json'
 body=source.read_bytes();data=json.loads(body);records=data['records'];assert records
 out=RUN/'predictor_logging_cost';out.mkdir(exist_ok=False)
 (out/'SNAPSHOT.json').write_bytes(body)
 rows=[]
 for n in sorted({1,min(16,len(records)),min(128,len(records)),len(records)}):
  obj=dict(records=records[:n],errors=data['errors'])
  samples=[];single=[]
  for _ in range(7):
   start=time.perf_counter_ns();encoded=json.dumps(obj,indent=2)+'\n';samples.append((time.perf_counter_ns()-start)/1e6)
   start=time.perf_counter_ns();json.dumps(records[n-1])+'\n';single.append((time.perf_counter_ns()-start)/1e6)
  rows.append(dict(records=n,bytes=len(encoded.encode()),full_snapshot_median_ms=statistics.median(samples),
                   single_record_median_ms=statistics.median(single),full_snapshot_samples_ms=samples))
 result=dict(status='measured',rows=rows,snapshot_sha256=hashlib.sha256(body).hexdigest(),
  scope='Seven CPU-only serializations on isolated CPU35; no file writes in timed region. Frozen mid-run snapshot, not actual server response timing. Excludes locks/disk/network; no causal latency correction or performance adjustment. Current experiment unchanged.')
 (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(rows)

if __name__=='__main__':main()
