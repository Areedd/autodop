"""Bounded Explain stability gate; preserve every observation and fail closed."""
import hashlib
import json
from pathlib import Path
import re
import time


def verify_stable_plans(queries, fetch_plan, output, dops=(0,4), consecutive=3, maximum=6):
    if not 2 <= consecutive <= maximum:
        raise ValueError('Invalid stability bounds')
    output=Path(output);output.mkdir(exist_ok=False)
    records=[];accepted=[]
    def save(status,error=None):
        result=dict(status=status,records=records,accepted=accepted,error=error,
                    consecutive=consecutive,maximum_per_query_dop=maximum,
                    scope='Exact Explain text including cost/cardinality; bounded pre-measurement gate. Passing does not guarantee future stability or establish execution-plan identity.')
        (output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
        return result
    try:
        for q in queries:
            for dop in dops:
                previous=None;streak=0
                for attempt in range(maximum):
                    start=time.perf_counter()
                    plan=fetch_plan(q,dop)
                    if not isinstance(plan,str) or 'PLAN FRAGMENT ' not in plan:
                        raise ValueError('Missing Explain plan')
                    digest=hashlib.sha256(plan.encode()).hexdigest()
                    filename=f'{len(records):03d}_dop{dop}.txt'
                    (output/filename).write_text(plan)
                    streak=streak+1 if digest==previous else 1
                    records.append(dict(id=q['id'],sql_sha256=q['sql_sha256'],dop=dop,attempt=attempt,
                                        sha256=digest,plan_file=filename,consecutive=streak,
                                        fragments=len(re.findall(r'^PLAN FRAGMENT ',plan,re.M)),
                                        elapsed_ms=(time.perf_counter()-start)*1000))
                    save('checking');previous=digest
                    if streak>=consecutive:
                        accepted.append(dict(id=q['id'],dop=dop,sha256=digest,observations=attempt+1))
                        break
                else:
                    raise RuntimeError(f"Plan did not stabilize: {q['id']} DOP {dop}")
        return save('stable')
    except BaseException as error:
        save('failed',repr(error))
        raise
