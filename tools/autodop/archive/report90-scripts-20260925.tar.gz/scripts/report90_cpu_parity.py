"""Capture original BE health/results or validate them after controlled replacement."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path

import pymysql
from collect_trusted_dataset import result_digest
from report90_cpu_deployment_check import check as deployment_check
from report90_execute import RUN, check

FIX = RUN / 'cpu_capacity_fix'


def main(phase):
    for name in ('queue_extension_20260913_attempt3', 'convergence_execution_20260913', 'search_convergence_20260913'):
        assert json.loads((RUN / name / 'STATUS.json').read_text())['status'] == 'complete'
    target = FIX / ('PARITY_ORIGINAL.json' if phase == 'original' else 'DEPLOYMENT_VALIDATION.json')
    assert not target.exists(), 'Preserve previous parity evidence'
    baseline = json.loads((FIX / 'DEPLOYMENT_BASELINE.json').read_text())
    image = baseline[0]['image_id'] if phase == 'original' else json.loads((FIX / 'CANDIDATE_IMAGE.json').read_text())['candidate_image_id']
    deployment = deployment_check(image, None if phase == 'original' else FIX / 'compose_candidate.json')
    preflight = json.loads((FIX / 'DEPLOYMENT_PREFLIGHT.json').read_text())
    assert deployment['compose_sha256'] == preflight['compose_sha256']
    assert {n['container']: n['config_sha256'] for n in deployment['containers']} == {
        n['container']: n['config_sha256'] for n in preflight['containers']}
    check(FIX / f'PARITY_IDLE_{phase}.json')
    queries = json.loads((RUN / 'pilot.json').read_text())['queries']
    records = []
    with pymysql.connect(host='127.0.0.1', port=9030, user='root', connect_timeout=5,
                         read_timeout=200, autocommit=True) as connection:
        with connection.cursor() as cursor:
            cursor.execute('SHOW BACKENDS')
            backends = [dict(zip([c[0] for c in cursor.description], row)) for row in cursor.fetchall()]
            expected = {9050, 9051, 9052}
            backends = [b for b in backends if int(b['HeartbeatPort']) in expected]
            assert len(backends) == 3
            assert all(str(b['Alive']).lower() == 'true' and int(b['CpuCores']) == 8 for b in backends)
            for key, value in [('enable_auto_dop', 'false'), ('pipeline_dop', '4'), ('query_timeout', '180')]:
                cursor.execute(f'SET {key} = {value}')
            for query in queries:
                sql = Path(query['sql_file']).read_text()
                assert hashlib.sha256(sql.encode()).hexdigest() == query['sql_sha256']
                cursor.execute('USE `' + query['database'].replace('`', '``') + '`')
                cursor.execute(sql)
                records.append({'id': query['id'], 'sql_sha256': query['sql_sha256'],
                                'digest': result_digest(cursor.fetchall())})
    if phase == 'candidate':
        original = json.loads((FIX / 'PARITY_ORIGINAL.json').read_text())
        assert records == original['queries'], 'Pilot results changed after BE replacement'
        assert {str(b['BackendId']) for b in backends} == {str(b['BackendId']) for b in original['backends']}
    result = {'status': 'original_health_and_results_recorded' if phase == 'original' else 'health_and_sql_parity_verified',
              'phase': phase, 'at': datetime.datetime.now().astimezone().isoformat(),
              'candidate_image_id': image if phase == 'candidate' else None,
              'deployment': deployment, 'backends': backends, 'queries': records,
              'scope': 'Three registered BEs alive with8cores; two frozen pilot queries have matching typed multiset digests at8 float significant digits. Not full correctness certification or load-correction validation.',
              'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    target.write_text(json.dumps(result, indent=2, default=str) + '\n')
    print(json.dumps({'status': result['status'], 'queries': len(records), 'output': str(target)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=['original', 'candidate'], required=True)
    main(parser.parse_args().phase)
