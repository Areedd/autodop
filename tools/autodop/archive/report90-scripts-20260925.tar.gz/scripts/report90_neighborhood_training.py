"""Small calibrated-ranking trial with isolated neighborhood training data."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

import torch
import report90_coverage_stability as common
from report90_interaction_model import load_interaction_model
from report90_neighborhood_prepare import OUT as BASE, RUN, sha

OUT = BASE / 'training_pilot'
DATASET = BASE / 'augmented_dataset'
SOURCE = RUN / 'structure_coverage20/pair_calibration_pilot/pilot_trainer.py'


def main(stage):
    os.sched_setaffinity(0, {34})
    torch.set_num_threads(1)
    assembly = common.read(DATASET / 'ASSEMBLY_AUDIT.json')
    assert assembly['status'] == 'verified_prepared_not_trained' and assembly['validation_unchanged']
    for p, digest in assembly['source_sha256'].items():
        assert sha(Path(p)) == digest
    if stage == 'smoke':
        assert not OUT.exists()
        OUT.mkdir()
        common.save(OUT / 'PROTOCOL.json', {'seed': 17, 'smoke_epochs': 2, 'pilot_epochs': 30, 'cpu': 34,
            'change': 'Add32 three-observation median configurations and40 batch-local pairs from4 existing training queries. No validation or report90 data added. All40 pairs used without reliability filtering or weighting.',
            'unchanged': 'Same calibrated ranking loss, multistage initialization, DOP interactions,624 sampled pairs/epoch,batch16,Adam1e-4,cosine100 horizon,accuracy-first validation selection. Refit flat-feature normalization on augmented training samples for all flat controls; graph feature metadata unchanged.',
            'scope': 'Two-epoch smoke then30-epoch seed17 pilot. No automatic full training, deployment or SQL. CPU34 differs from earlier CPU35; training wall times not a controlled performance comparison.',
            'source_sha256': {str(p): sha(p) for p in [Path(__file__), SOURCE, DATASET / 'ASSEMBLY_AUDIT.json',
                DATASET / 'samples.jsonl', DATASET / 'pairs.jsonl', DATASET / 'metadata.json', DATASET / 'CONTRACT.json',
                Path(common.__file__), Path(__file__).with_name('report90_interaction_model.py')]}})
    protocol = common.read(OUT / 'PROTOCOL.json')
    for p, digest in protocol['source_sha256'].items():
        assert sha(Path(p)) == digest
    if stage == 'pilot':
        assert common.read(OUT / 'smoke/SCORE_REPLAY.json')['status'] == 'verified'
    folder = OUT / stage
    assert not folder.exists()
    text = SOURCE.read_text()
    original_base = RUN / 'structure_coverage20/pair_calibration_pilot'
    changes = {
        repr(str(original_base / 'pilot')): repr(str(folder)),
        repr(str(original_base / 'PROTOCOL.json')): repr(str(OUT / 'PROTOCOL.json')),
        "dataset=BASE/'merged_dataset';warm=BASE/'prepared/cost.pt'": "dataset=Path(" + repr(str(DATASET)) + ");warm=BASE/'prepared/cost.pt'",
        'assert len(train)==1365 and len(valid)==212': 'assert len(train)==1397 and len(valid)==212',
        'os.sched_setaffinity(0,{35})': 'os.sched_setaffinity(0,{34})',
    }
    if stage == 'smoke':
        changes.update({'range(1,31)': 'range(1,3)', 'epoch%10==0': 'epoch%1==0', 'n_estimators=200': 'n_estimators=5'})
    record = {}
    for old, new in changes.items():
        count = text.count(old)
        assert count == (2 if old in [repr(str(original_base / 'PROTOCOL.json')), 'epoch%10==0'] else 1), (old, count)
        text = text.replace(old, new)
        record[old] = {'replacement': new, 'occurrences': count}
    script = OUT / f'{stage}_trainer.py'
    compile(text, str(script), 'exec')
    script.write_text(text)
    common.save(OUT / f'{stage}_SOURCE_TRANSFORM.json', {'original_sha256': sha(SOURCE), 'generated_sha256': sha(script), 'changes': record})
    common.save(OUT / 'STATUS.json', {'status': 'running', 'stage': stage, 'pid': os.getpid()})
    with (OUT / f'{stage}.log').open('w') as stream:
        subprocess.run([sys.executable, str(script)], stdout=stream, stderr=subprocess.STDOUT, check=True)
    original_load_dataset = common.load_dataset
    common.load_dataset = lambda path: original_load_dataset(DATASET)
    common.load_cost_model = load_interaction_model
    models = common.replay(folder)
    common.save(OUT / 'STATUS.json', {'status': stage + '_verified'})
    if stage == 'pilot':
        before = common.read(original_base / 'RESULT.json')['after']
        common.save(OUT / 'RESULT.json', {'status': 'verified', 'before': before, 'after': models,
            'protocol_sha256': sha(OUT / 'PROTOCOL.json'),
            'improves_reference': models['transformer']['weighted_rank_accuracy'] > before['transformer']['weighted_rank_accuracy']})
    print(stage, 'verified', models['transformer']['weighted_rank_accuracy'], flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['smoke', 'pilot'], required=True)
    args = parser.parse_args()
    try:
        main(args.stage)
    except BaseException as error:
        if OUT.exists():
            common.save(OUT / 'STATUS.json', {'status': 'failed', 'error': repr(error)})
        raise
