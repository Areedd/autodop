"""Replay all accuracy-selected models on one explicit, shared validation pair pool."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np
import torch
import xgboost as xgb
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from autodop.training import select_partition
from report90_models import MLP, flat_features

BASE = Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def make_pairs(samples):
    groups = {}
    for index, sample in enumerate(samples):
        groups.setdefault(sample['plan_key'], []).append(index)
    pairs = []
    for plan, indices in sorted(groups.items()):
        for i,j in itertools.combinations(indices,2):
            a,b = samples[i],samples[j]
            assert a['source_cohort'] == b['source_cohort']
            if abs(a['latency_ms']-b['latency_ms'])/min(a['latency_ms'],b['latency_ms']) < .03:
                continue
            fast,slow = (i,j) if a['latency_ms'] < b['latency_ms'] else (j,i)
            pairs.append(dict(plan_key=plan,cohort=a['source_cohort'],fast_index=fast,slow_index=slow))
    return pairs


def accuracy(pairs, scores):
    cohorts = {}
    for p in pairs:
        group = cohorts.setdefault(p['cohort'],dict(correct=0,total=0,score_ties=0))
        fast,slow = float(scores[p['fast_index']]),float(scores[p['slow_index']])
        group['correct'] += fast > slow
        group['score_ties'] += fast == slow
        group['total'] += 1
    for group in cohorts.values():
        group['accuracy'] = group['correct']/group['total']
    return dict(cohorts=cohorts,macro_accuracy=sum(v['accuracy'] for v in cohorts.values())/len(cohorts),
                pooled_accuracy=sum(v['correct'] for v in cohorts.values())/len(pairs))


def main(seed):
    torch.set_num_threads(1)
    neural = BASE/f'smooth_ranking/seed{seed}'
    controls = BASE/f'accuracy_baselines_seed{seed}_full'
    replay = json.loads((neural/'SCORE_REPLAY.json').read_text())
    assert replay['status'] == 'verified'
    primary = json.loads((neural/'RESULT.json').read_text())
    additional = json.loads((controls/'RESULT.json').read_text())
    assert primary['status'] == 'complete' and additional['status'] == 'verified'
    for path,digest in json.loads((neural/'EXECUTION_SOURCE_SHA256.json').read_text()).items():
        assert sha(path) == digest
    for path,digest in additional['source_sha256'].items():
        assert sha(path) == digest
    samples,pairs,metadata = load_dataset(BASE/'merged_dataset')
    contract = json.loads((neural/'CONTRACT.json').read_text())
    valid,_ = select_partition(samples,pairs,contract,'valid')
    valid = sorted(valid,key=lambda s:(s['plan_key'],s['config_key']))
    assert len(valid) == 212
    pool = make_pairs(valid)
    graphs = [build_graph(s,metadata) for s in valid]
    normal = np.load(BASE/'retrained/FEATURE_NORMALIZATION.npz')
    for name in ['mean','std']:
        assert np.array_equal(normal[name],np.load(neural/'FEATURE_NORMALIZATION.npz')[name])
    flat = np.stack([(flat_features(g,metadata)-normal['mean'])/normal['std'] for g in graphs])
    selection = {**primary['selected'], **additional['selected']}
    result = {}
    sources = [Path(__file__),neural/'SCORE_REPLAY.json',neural/'RESULT.json',controls/'RESULT.json',
               neural/'EXECUTION_SOURCE_SHA256.json',neural/'CONTRACT.json',
               BASE/'merged_dataset/samples.jsonl',BASE/'merged_dataset/metadata.json',
               BASE/'retrained/FEATURE_NORMALIZATION.npz']
    for kind,record in selection.items():
        model_path = Path(record['model'])
        assert sha(model_path) == record['model_sha256']
        sources.append(model_path)
        if kind == 'transformer':
            model,ck = load_cost_model(model_path)
            assert ck['metadata'] == metadata
            model.eval()
            with torch.no_grad(): scores = [float(model(g)) for g in graphs]
        elif kind.startswith('xg'):
            model = xgb.XGBRegressor() if kind.endswith('regression') else xgb.XGBRanker()
            model.load_model(model_path);model.set_params(n_jobs=1)
            scores = model.predict(flat).astype(float)
            if kind.endswith('regression'): scores = -scores
        else:
            ck = torch.load(model_path,weights_only=False,map_location='cpu')
            model = MLP(ck['width']);model.load_state_dict(ck['state']);model.eval()
            with torch.no_grad(): scores = model(torch.tensor(flat,dtype=torch.float32)).numpy().astype(float)
            if kind.endswith('regression'): scores = -scores
        assert np.isfinite(scores).all()
        measured = accuracy(pool,scores)
        expected = record['selected']['validation']
        assert measured['macro_accuracy'] == expected['weighted_rank_accuracy']
        for cohort,counts in measured['cohorts'].items():
            assert counts['accuracy'] == expected['cohorts'][cohort]['rank_accuracy']
            assert counts['total'] == expected['cohorts'][cohort]['ranking_pairs']
        assert {c:v['total'] for c,v in measured['cohorts'].items()} == {'historical':699,'complex_new':221}
        result[kind] = dict(**measured,scores=[float(s) for s in scores],model_sha256=sha(model_path))
    out = BASE/f'accuracy_pair_audit_seed{seed}'
    out.mkdir(exist_ok=False)
    manifest = [dict(plan_key=s['plan_key'],config_key=s['config_key'],latency_ms=s['latency_ms'],
                     cohort=s['source_cohort'],sql_sha256=s['sql_sha256']) for s in valid]
    (out/'PAIR_POOL.json').write_text(json.dumps(dict(samples=manifest,pairs=pool),indent=2)+'\n')
    sources.append(out/'PAIR_POOL.json')
    summary = dict(status='verified_independent_pair_replay',seed=seed,models=result,
                   scope='Same 920 within-plan validation pairs for all models; latency gap at least3%, score ties count as incorrect. '
                         'Primary macro averages historical and complex cohorts equally; pooled accuracy also reported. '
                         'Reused development validation selected checkpoints; not independent final-test evidence.',
                   source_sha256={str(p):sha(p) for p in sources})
    (out/'RESULT.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:{name:round(v[name]*100,4) for name in ['macro_accuracy','pooled_accuracy']}
                      for k,v in result.items()},indent=2))


if __name__ == '__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--seed',type=int,choices=[17,29,43],required=True)
    main(parser.parse_args().seed)
