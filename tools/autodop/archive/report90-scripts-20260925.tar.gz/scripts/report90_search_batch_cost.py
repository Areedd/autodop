"""Search-cost pilot with shared graph optimization and a batched random control."""
import json
import math
import os
from pathlib import Path
import random
import statistics
import time
from unittest.mock import patch
import torch
from autodop import graph,mcts
from autodop.model import load_cost_model
from report90_search_refinement import search
from report90_batched_cost import score_batch
from report90_neighborhood_prepare import RUN,sha
OUT=RUN/'search_batch_cost'


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1);assert not OUT.exists()
    development=RUN/'search_refinement_development';prior=json.loads((development/'PROTOCOL.json').read_text());vectors=json.loads((development/'vectors.json').read_text());queries=prior['queries'];assert len(queries)==4
    proof=json.loads((RUN/'graph_construction_verification/PROTOCOL.json').read_text())
    for p,d in proof['source_sha256'].items():assert sha(Path(p))==d
    assert json.loads((RUN/'candidate_pipeline_cost/RESULT.json').read_text())['status']=='verified_candidate_pipeline_cost'
    codepath=RUN/'graph_construction_pilot/competition_staged.py';namespace=dict(vars(graph));exec(compile(codepath.read_text(),str(codepath),'exec'),namespace);optimized=namespace['_competition'];original=graph._competition
    model_path=Path(prior['model']);model,ck=load_cost_model(model_path);model.eval();metadata=ck['metadata']
    modes=['original_mcts','refined_full','independent_random_scalar','independent_random_batch']
    OUT.mkdir();protocol={'queries':queries,'modes':modes,'candidate_budget':64,'seed':17,'batch_size':16,'warmups':1,'rounds':4,'order':'Rotate four modes across four timed rounds for each query.','scope':'All methods receive identical optimized graph construction. Complete local search from prepared sample, including domains, candidate generation, feature construction, scoring and search traversal. Excludes request parsing, HTTP,FE,SQL and model loading. MCTS methods remain sequential and perform their original importance pass; independent random can batch because candidate draws do not depend on scores. Shared hostCPU34/torch1thread; small development pilot, not end-to-end query speed or algorithm quality evidence.', 'source_sha256':{str(p):sha(p) for p in [Path(__file__),Path(graph.__file__),Path(mcts.__file__),Path(__file__).with_name('report90_search_refinement.py'),Path(__file__).with_name('report90_batched_cost.py'),development/'PROTOCOL.json',development/'vectors.json',model_path,codepath,RUN/'candidate_pipeline_cost/RESULT.json']}}
    (OUT/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n');results=[]
    with patch.object(graph,'_competition',optimized),torch.inference_mode():
        for query in queries:
            sample=graph.sample_from_request(vectors['refined_full'][query]['request']);sample['dop_config']=[1 if f.get('is_gather_root') else 4 for f in sample['fragments']]
            def run(mode):
                started=time.perf_counter_ns()
                if mode=='original_mcts':
                    config,score=mcts.search(sample,model,metadata,iterations=64,seed=17);scores=None;configs=None
                elif mode=='refined_full':
                    value=search(sample,model,metadata,budget=64,seed=17);config,score=value['config'],value['score'];scores=[r['score'] for r in value['records']];configs=[r['config'] for r in value['records']]
                else:
                    domains=[graph.supported_dops(f,metadata['dop_classes']) for f in sample['fragments']];rng=random.Random(17);configs=[[rng.choice(d) for d in domains] for _ in range(64)]
                    if mode.endswith('_scalar'):
                        scores=[float(model(graph.build_graph({**sample,'dop_config':cfg},metadata))) for cfg in configs]
                    else:
                        scores=[]
                        for i in range(0,64,16):
                            graphs=[graph.build_graph({**sample,'dop_config':cfg},metadata) for cfg in configs[i:i+16]];scores.extend(score_batch(model,graphs).tolist())
                    best=max(range(64),key=lambda i:scores[i]);config,score=configs[best],scores[best]
                elapsed=(time.perf_counter_ns()-started)/1e6
                assert math.isfinite(score)
                return {'config':list(config),'score':float(score),'scores':scores,'configs':configs,'total_ms':elapsed}
            warm={mode:run(mode) for mode in modes};assert warm['independent_random_scalar']['configs']==warm['independent_random_batch']['configs']
            scalar=warm['independent_random_scalar'];batch=warm['independent_random_batch']
            torch.testing.assert_close(torch.tensor(scalar['scores']),torch.tensor(batch['scores']),atol=1e-5,rtol=1e-5)
            assert scalar['config']==batch['config'],'Batching changed random-control winner; do not treat it as the same search'
            timings={m:[] for m in modes}
            for round_index in range(4):
                order=modes[round_index:]+modes[:round_index]
                for position,mode in enumerate(order):
                    measured=run(mode)
                    for k in ['config','score','scores','configs']:assert measured[k]==warm[mode][k],(query,mode,k)
                    timings[mode].append({'round':round_index,'position':position,'total_ms':measured['total_ms']})
            records={'query':query,'fragments':len(sample['fragments']),'outputs':warm,'timings':timings,'median_ms':{m:statistics.median(x['total_ms'] for x in timings[m]) for m in modes}}
            results.append(records);print(query,records['median_ms'],flush=True)
    assert graph._competition is original
    for p,d in protocol['source_sha256'].items():assert sha(Path(p))==d
    summary={m:statistics.mean(r['median_ms'][m] for r in results) for m in modes}
    result={'status':'verified_search_batch_cost','queries':results,'mean_of_query_medians_ms':summary,'random_winner_unchanged':True,'graph_module_restored':True,'scope':protocol['scope'],'protocol_sha256':sha(OUT/'PROTOCOL.json')}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 共享构图优化后的完整本地搜索成本','',protocol['scope'],'','| 查询 | 原MCTS ms | 改进搜索 ms | 随机逐条 ms | 随机批量 ms |','|---|---:|---:|---:|---:|']
    for r in results:
        m=r['median_ms'];lines.append(f"| {r['query']} | {m['original_mcts']:.3f} | {m['refined_full']:.3f} | {m['independent_random_scalar']:.3f} | {m['independent_random_batch']:.3f} |")
    lines+=['','四查询中位数的平均：'+str(summary),'','各随机版本使用完全相同的64个候选；逐条/批量分数容差通过、首选相同。每种搜索跨4轮输出严格复现。MCTS候选间存在顺序依赖，未强行改变其搜索轨迹以凑批。不能把这些时间与旧服务器状态下的测量直接混合，也不能从搜索开销推断SQL执行收益。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')

if __name__=='__main__':main()
