"""Freeze report90 model choices and search ablations without looking at test timings."""
import argparse,json,random,sys,time
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,'/tmp/autodop-report-deps')
import numpy as np
import torch
import xgboost as xgb
from autodop import mcts
from autodop.data import supported_dops
from autodop.graph import build_graph,sample_from_request
from autodop.model import CostModel,LatencyRegressionModel,load_cost_model
from autodop.engine import PolicyEngine
from report90_models import RUN,KINDS,MLP,flat_features
from measure_ablation_cost import save

def make(stage,attempt=0,request_overrides=None):
 torch.set_num_threads(1);pilot=stage=='pilot';out=RUN/(('choices_pilot' if pilot else 'choices')+(f'_attempt{attempt}' if attempt else ''));out.mkdir(exist_ok=False)
 train=RUN/('models_pilot' if pilot else 'models_full');meta=json.loads((train/'METADATA.json').read_text());chosen=json.loads((train/'SELECTED.json').read_text());normal=np.load(train/'FEATURE_NORMALIZATION.npz');loaded={}
 for key,name in chosen.items():
  kind=key.rsplit('_s',1)[0];folder=train/name
  if kind.startswith('xgb'):
   model=xgb.XGBRegressor() if kind.endswith('regression') else xgb.XGBRanker();model.load_model(folder/'model.ubj');model.set_params(n_jobs=1)
  else:
   ck=torch.load(folder/'model.pt',map_location='cpu',weights_only=False)
   if kind=='mlp_rank':model=MLP(ck['width']);model.load_state_dict(ck['state'])
   else:model=CostModel(meta,ck['model_config']) if kind.endswith('rank') else LatencyRegressionModel(meta,ck['model_config']);model.load_state_dict(ck['model_state'])
   model.eval()
  loaded[key]=(kind,model)
 manifest=json.loads((RUN/('pilot.json' if pilot else 'manifest.json')).read_text());proto=json.loads((RUN/'PROTOCOL.json').read_text());old=json.loads((ROOT/'runs/preference_random200_20260911/random200/vectors.json').read_text())['audit_dop4'];policy=PolicyEngine(proto['model']);teacher,tc=load_cost_model(ROOT/'runs/multi_structure_feedback_cost05_20260910/model/cost.pt');teacher.eval();seeds=[17] if pilot else proto['search_seeds'];budget=8 if pilot else proto['search_budget'];vectors={};rows=[]
 if request_overrides:
  replacements=json.loads(Path(request_overrides).read_text());manifest['queries']=[q for q in manifest['queries'] if q['id'] in replacements]
  for qid,req in replacements.items():old[qid]={'request':req,'fragment_dops':{str(f['fragment_id']):1 if f.get('is_gather_root') else 4 for f in req['fragments']}}
 def noeq(sample,candidates):return [(i,) for i in range(len(candidates))]
 def natural(sample,model,metadata,candidates,device='cpu'):return mcts.equivalence_groups(sample,candidates)
 def score_model(kind,model,graphs):
  if kind.startswith('xgb') or kind=='mlp_rank':xx=np.stack([(flat_features(g,meta)-normal['mean'])/normal['std'] for g in graphs])
  if kind.startswith('xgb'):scores=model.predict(xx)
  elif kind=='mlp_rank':
   with torch.no_grad():scores=model(torch.tensor(xx,dtype=torch.float32)).numpy()
  else:
   with torch.no_grad():scores=np.array([float(model(g)) for g in graphs])
  return -scores if kind.endswith('regression') else scores
 for q in manifest['queries']:
  qid=q['id'];req=old[qid]['request'];sample=sample_from_request(req);sample['dop_config']=[old[qid]['fragment_dops'][fid] for fid in sample['fragment_ids']];frags=sample['fragments'];candidates=[supported_dops(f,meta['dop_classes']) for f in frags]
  common=set.intersection(*(set(v) for f,v in zip(frags,candidates) if not f.get('is_gather_root')));uniform=[tuple(1 if f.get('is_gather_root') else d for f in frags) for d in sorted(common)];response=policy.decide(req);mapping={d['fragment_id']:d['dop'] for d in response['decisions']};policy_vec=tuple(mapping[fid] for fid in sample['fragment_ids']);pool=set(uniform+[policy_vec]);named={'policy_vector':policy_vec}
  for seed in seeds:
   order=['teacher_mcts','search_no_equivalence','search_no_attention','search_random'];random.Random(seed).shuffle(order)
   for mode in order:
    begin=time.perf_counter()
    if mode=='search_random':
     rng=random.Random(seed);best=-float('inf');config=None
     for _ in range(budget):
      proposal=[rng.choice(v) for v in candidates]
      with torch.no_grad():score=float(teacher(build_graph({**sample,'dop_config':proposal},tc['metadata'])))
      if score>best:best=score;config=proposal
    elif mode=='search_no_equivalence':
     with patch.object(mcts,'equivalence_groups',noeq):config,best=mcts.search(sample,teacher,tc['metadata'],iterations=budget,seed=seed)
    elif mode=='search_no_attention':
     with patch.object(mcts,'attention_guided_groups',natural):config,best=mcts.search(sample,teacher,tc['metadata'],iterations=budget,seed=seed)
    else:config,best=mcts.search(sample,teacher,tc['metadata'],iterations=budget,seed=seed)
    pool.add(tuple(config));rows.append(dict(id=qid,type='search',mode=mode,seed=seed,seconds=time.perf_counter()-begin,score=best,dops=config))
    if seed==17:named[mode]=tuple(config)
  # Fresh query-level baselines; uniform4 is already a native collector mode.
  for d in (1,2,8,16):
   config=tuple(1 if f.get('is_gather_root') else d for f in frags)
   assert config in uniform
   named[f'audit_dop{d}']=config
  configs=sorted(pool);graphs=[build_graph({**sample,'dop_config':list(c)},meta) for c in configs];ug=[build_graph({**sample,'dop_config':list(c)},meta) for c in uniform]
  for key,(kind,model) in loaded.items():
   begin=time.perf_counter();scores=score_model(kind,model,graphs);index=int(np.argmax(scores));uni=score_model(kind,model,ug);ui=int(np.argmax(uni));assert np.isfinite(scores).all() and np.isfinite(uni).all();rows.append(dict(id=qid,type='cost_model',mode=key,seconds=time.perf_counter()-begin,candidates=len(configs),selected_dops=configs[index],uniform_selected_dops=uniform[ui],uniform_scores=uni.tolist(),uniform_configs=uniform,scores=scores.tolist(),configs=configs))
   if key.endswith('_s17'):named['cost_'+kind]=configs[index]
  for mode,config in named.items():
   assert len(config)==len(frags) and all(d in vs for d,vs in zip(config,candidates));vectors.setdefault(mode,{})[qid]=dict(request=req,fragment_dops=dict(zip(sample['fragment_ids'],config)))
  save(out/'ROWS.json',rows);save(out/'vectors.json',vectors);save(out/'PROGRESS.json',dict(status='running',queries=len(vectors['policy_vector']),total=len(manifest['queries'])));print('choices',qid,flush=True)
 save(out/'PROGRESS.json',dict(status='complete',queries=len(manifest['queries']),modes=list(vectors),note='Primary seed17 used for actual execution; all3 seeds recorded offline. Common candidate pool fixed before scoring and uses no test latency.'))
 if not request_overrides:save(RUN/('CHOICES_PILOT_READY.json' if pilot else 'CHOICES_READY.json'),dict(directory=str(out.resolve()),queries=len(manifest['queries'])))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--stage',choices=['pilot','full'],required=True);p.add_argument('--attempt',type=int,default=0);p.add_argument('--request-overrides');a=p.parse_args();make(a.stage,a.attempt,a.request_overrides)
