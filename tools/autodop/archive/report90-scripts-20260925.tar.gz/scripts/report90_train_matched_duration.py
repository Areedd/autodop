"""Fixed-protocol native duration models on matched development observations."""
from collections import defaultdict
from pathlib import Path
import hashlib,json,time
import joblib
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import ExtraTreesRegressor

BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/matched_development_duration'


def predict(bundle,x):
    if bundle['kind']=='training_median':return np.full(len(x),bundle['value'])
    z=bundle['scaler'].transform(x)
    if bundle['kind']=='nearest3_log_mean':
        values=[]
        for row in z:
            nearest=np.argsort(np.linalg.norm(bundle['training']-row,axis=1),kind='stable')[:3]
            values.append(np.exp(bundle['log_targets'][nearest].mean()))
        return np.array(values)
    return np.exp(np.clip(bundle['estimator'].predict(z),-30,30))


def metrics(rows,pred):
    groups=defaultdict(list)
    for r,value in zip(rows,pred):groups[r['id']].append((r['client_latency_ms'],float(value)))
    means=[(q,float(np.mean([v[0] for v in pairs])),float(np.mean([v[1] for v in pairs]))) for q,pairs in sorted(groups.items())]
    y=np.array([r[1] for r in means]);z=np.array([r[2] for r in means]);error=np.maximum(y/z,z/y)
    pairs=[(i,j) for i in range(len(y)) for j in range(i+1,len(y)) if y[i]!=y[j]]
    accuracy=sum(.5 if z[i]==z[j] else float((z[i]-z[j])*(y[i]-y[j])>0) for i,j in pairs)/len(pairs)
    return dict(queries=len(means),observations=len(rows),median_qerror=float(np.median(error)),p90_qerror=float(np.quantile(error,.9)),max_qerror=float(max(error)),pair_accuracy=accuracy,query_means=means)


def main():
    proof=BASE/'full/INDEPENDENT_AUDIT.json';audit=json.loads(proof.read_text());assert audit['status']=='verified' and audit['queries']==61
    for name,h in audit['source_sha256'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h
    data_path=BASE/'full/RESULT.json';rows=json.loads(data_path.read_text())['executions']
    protocol_path=BASE/'DURATION_MODEL_PROTOCOL.json';protocol=json.loads(protocol_path.read_text())
    train=[r for r in rows if r['split']=='train'];valid=[r for r in rows if r['split']=='valid']
    assert len(train)==106 and len(valid)==16 and not {r['id'] for r in train}&{r['id'] for r in valid}
    header=rows[0]['feature_record']['header'];assert all(r['feature_record']['header']==header for r in rows)
    names=[n for n in header if n.startswith(('env_','operators_'))];indices=[header.index(n) for n in names]
    matrix=lambda items:np.array([[r['feature_record']['values'][i] for i in indices] for r in items],dtype=float)
    x=matrix(train);v=matrix(valid);y=np.array([r['client_latency_ms'] for r in train]);assert np.isfinite(x).all() and np.isfinite(v).all() and np.all(y>0)
    out=BASE/'models';out.mkdir(exist_ok=False);summaries={};predictions={}
    for name,params in protocol['models'].items():
        start=time.monotonic();bundle=dict(kind=name,feature_names=names)
        if name=='training_median':bundle['value']=float(np.median(y))
        else:
            scaler=StandardScaler().fit(x);z=scaler.transform(x);bundle['scaler']=scaler
            if name=='nearest3_log_mean':bundle.update(training=z,log_targets=np.log(y))
            else:
                estimator=Ridge(**params) if name=='ridge_log' else ExtraTreesRegressor(**params)
                estimator.fit(z,np.log(y));bundle['estimator']=estimator
        elapsed=time.monotonic()-start
        before=predict(bundle,v);path=out/(name+'.joblib');joblib.dump(bundle,path)
        loaded=joblib.load(path);after=predict(loaded,v);assert np.array_equal(before,after)
        summary=metrics(valid,after);summary['fit_seconds']=elapsed;summary['reloaded_exactly']=True
        summary['phases']={phase:metrics([r for r in valid if r['phase']==phase],after[[r['phase']==phase for r in valid]]) for phase in ('warmup','measured')}
        summaries[name]=summary;predictions[name]=after.tolist()
    baseline=summaries['training_median']['median_qerror'];gate=protocol['gate']
    for name,s in summaries.items():
        s['screen_passed']=name!='training_median' and s['median_qerror']<=gate['median_query_qerror_max'] and s['p90_qerror']<=gate['p90_query_qerror_max'] and s['pair_accuracy']>=gate['query_pair_accuracy_min'] and s['median_qerror']<baseline
    sources=[Path(__file__),proof,data_path,protocol_path,*out.glob('*.joblib')]
    result=dict(status='development_validation',training_queries=53,validation_queries=8,feature_count=len(names),summary=summaries,predictions=predictions,validation_query_ids=[r['id'] for r in valid],
                scope='Fixed original development split, two actual native executions per SQL. Query aggregate metrics plus separate phases. Validation reused in previous development; 28 pairs are not independent observations. Native duration only, callback overhead included. Passing permits further development checks, not deployment or report90 superiority claims.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 同批次计划特征与耗时模型验证','',result['scope'],'','| 模型 | 中位Q-error | p90 Q-error | 跨查询排序准确率 | 拟合秒数 | 门槛通过 |','|---|---:|---:|---:|---:|---|']
    for name,s in summaries.items():lines.append(f"| {name} | {s['median_qerror']:.3f} | {s['p90_qerror']:.3f} | {100*s['pair_accuracy']:.2f}% | {s['fit_seconds']:.3f} | {s['screen_passed']} |")
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))

if __name__=='__main__':main()
