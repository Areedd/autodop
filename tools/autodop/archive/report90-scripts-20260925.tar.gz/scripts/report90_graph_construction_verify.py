"""Check exact competition tensors on every existing model-data configuration."""
import json
import os
from pathlib import Path
import time

import torch
from autodop import graph
from autodop.data import load_dataset
from report90_graph_construction_pilot import RUN, sha, save


def main():
    os.sched_setaffinity(0, {35})
    torch.set_num_threads(1)
    parent = RUN / 'graph_construction_pilot'
    pilot = json.loads((parent / 'RESULT.json').read_text())
    assert pilot['status'] == 'verified' and pilot['graphs_exact'] == 64 and pilot['search_outputs_exact'] == 12
    protocol = json.loads((parent / 'PROTOCOL.json').read_text())
    for path, digest in protocol['source_sha256'].items():
        assert sha(path) == digest
    namespace = dict(vars(graph))
    code = (parent / 'competition_staged.py').read_text()
    exec(compile(code, '<verified_competition>', 'exec'), namespace)
    optimized = namespace['_competition']
    dataset = RUN / 'structure_coverage20/merged_dataset'
    samples, _, _ = load_dataset(dataset)
    assert len(samples) == 1577
    out = RUN / 'graph_construction_verification'
    assert not out.exists()
    out.mkdir()
    sources = [Path(__file__), Path(graph.__file__), parent / 'competition_staged.py', parent / 'PROTOCOL.json', parent / 'RESULT.json', dataset / 'samples.jsonl']
    save(out / 'PROTOCOL.json', {'samples': 1577, 'unknown_dop': [False, True],
        'scope': 'Every merged train/validation configuration; exact float32 competition, overlap, worker sharing and pressure tensors. Read-only, no model fitting or SQL. No claim of equivalence for untested future inputs.',
        'source_sha256': {str(p): sha(p) for p in sources}})
    started = time.perf_counter()
    checks = 0
    for index, sample in enumerate(samples):
        for unknown in [False, True]:
            args = sample['fragments'], sample.get('edges', []), sample['dop_config'], unknown
            baseline = graph._competition(*args)
            fast = optimized(*args)
            assert baseline.keys() == fast.keys()
            for key in baseline:
                assert torch.equal(baseline[key], fast[key]), (sample['plan_key'], sample['config_key'], unknown, key)
                checks += 1
        if (index + 1) % 100 == 0:
            save(out / 'STATUS.json', {'status': 'running', 'samples_verified': index + 1, 'tensor_checks': checks})
    result = {'status': 'verified', 'samples_verified': len(samples), 'tensor_checks': checks,
              'elapsed_seconds': time.perf_counter() - started, 'protocol_sha256': sha(out / 'PROTOCOL.json')}
    save(out / 'RESULT.json', result)
    save(out / 'STATUS.json', result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
