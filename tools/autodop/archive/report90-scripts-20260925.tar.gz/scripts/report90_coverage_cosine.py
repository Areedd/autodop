"""Single schedule change versus the completed fixed-LR three-seed experiment."""
import argparse
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import torch
from autodop.training import file_sha256
from report90_coverage_choices import BASE, read
import report90_coverage_stability as common

OUT = BASE / 'cosine_decay'


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main(stage):
    torch.set_num_threads(1); os.sched_setaffinity(0, {35})
    if stage == 'pilot':
        assert not OUT.exists(), 'Preserve existing schedule experiment'
        assert read(BASE / 'seed_stability/RESULT.json')['status'] == 'verified'
        assert read(BASE / 'parameter_average3/RESULT.json')['status'] == 'verified'
        OUT.mkdir()
        save(OUT / 'PROTOCOL.json', {'frozen_at': datetime.datetime.now().astimezone().isoformat(),
             'seeds': [17, 29, 43], 'epochs': 100, 'initial_lr': 1e-4, 'final_lr': 1e-5,
             'schedule': 'CosineAnnealingLR T_max=100, eta_min=1e-5; step once after each epoch, no restarts.',
             'pilot': 'Seed17 twoepochs, same100-epoch scheduler horizon and shortened XGBoost controls. Verify all reloaded models before full runs.',
             'hypothesis': 'Test whether decaying update size reduces observed fixed-LR training variability. Same initialization, data, loss, sampling, batch size and validation selection.',
             'aggregation': 'All three seeds compared to corresponding fixed-LR controls. No best-seed selection or automatic deployment/SQL expansion. Report all outcomes.',
             'scope': 'Development optimization experiment after observing fixed-LR seeds and unsuccessful equal-parameter averaging; not independent test evidence.',
             'source_sha256': {str(p): file_sha256(p) for p in [Path(__file__), Path(common.__file__), common.SOURCE,
                BASE / 'seed_stability/RESULT.json', BASE / 'parameter_average3/RESULT.json']}})
    protocol = read(OUT / 'PROTOCOL.json')
    for path, expected in protocol['source_sha256'].items(): assert file_sha256(path) == expected
    if stage == 'full': assert read(OUT / 'seed17_pilot/SCORE_REPLAY.json')['status'] == 'verified'
    seeds = [17] if stage == 'pilot' else protocol['seeds']
    names = [f'seed{s}' + ('_pilot' if stage == 'pilot' else '') for s in seeds]
    assert all(not (OUT / n).exists() for n in names)
    common.OUT = OUT  # Generated checkpoints cite this schedule protocol, not the prior one.
    for seed, name in zip(seeds, names):
        folder = OUT / name; source, changes = common.staged_source(seed, folder, stage == 'pilot')
        replacements = {
            'model,_=load_cost_model(warm);optimizer=torch.optim.Adam(model.parameters(),lr=lr)':
                'model,_=load_cost_model(warm);optimizer=torch.optim.Adam(model.parameters(),lr=lr)\n        scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=100,eta_min=1e-5)',
            "entry={'epoch':epoch,'loss':float(np.mean(losses))}":
                "entry={'epoch':epoch,'loss':float(np.mean(losses)),'learning_rate':optimizer.param_groups[0]['lr']}\n            scheduler.step()",
        }
        for old, new in replacements.items():
            assert source.count(old) == 1
            source = source.replace(old, new); changes[old] = {'replacement': new, 'occurrences': 1}
        script = OUT / (name + '_trainer.py'); compile(source, str(script), 'exec'); script.write_text(source)
        save(OUT / (name + '_SOURCE_TRANSFORM.json'), {'original_sha256': file_sha256(common.SOURCE),
             'generated_sha256': file_sha256(script), 'literal_changes': changes})
        save(OUT / 'STATUS.json', {'status': 'running', 'stage': name, 'pid': os.getpid()})
        with (OUT / (name + '.log')).open('w') as stream:
            subprocess.run([sys.executable, str(script)], stdout=stream, stderr=subprocess.STDOUT, check=True)
        common.replay(folder)
    if stage == 'full':
        after = {str(seed): read(OUT / f'seed{seed}/SCORE_REPLAY.json')['models'] for seed in seeds}
        before = read(BASE / 'seed_stability/RESULT.json')['seeds']
        save(OUT / 'RESULT.json', {'status': 'verified', 'before_fixed_lr': before, 'after_cosine': after,
                                 'protocol_sha256': file_sha256(OUT / 'PROTOCOL.json')})
        lines = ['# 学习率下降的开发对照', '', protocol['scope'], '',
                 '| 种子 | 流程 | 模型 | 综合选择损失 | 复杂选择损失 |', '|---|---|---|---:|---:|']
        for seed in map(str, seeds):
            for phase, qualities in [('固定学习率', before), ('余弦下降', after)]:
                for kind, q in qualities[seed].items():
                    lines.append(f"| {seed} | {phase} | {kind} | {100*q['weighted_regret']:.2f}% | {100*q['cohorts']['complex_new']['mean_regret']:.2f}% |")
        lines += ['', '固定学习率结果复用已完成的独立核验；新流程全部模型重新加载复算。唯一优化更新变化为预先固定的学习率日程，排序损失、历史保留项权重0、数据采样和初始化不变。XGBoost参数不变，重复训练用于核验。保留三个种子，不选择最好一次；不自动部署或启动SQL。']
        (OUT / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    save(OUT / 'STATUS.json', {'status': 'pilot_verified' if stage == 'pilot' else 'complete'})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--stage', choices=['pilot', 'full'], required=True)
    args = parser.parse_args()
    try:
        main(args.stage)
    except BaseException as error:
        if OUT.exists(): save(OUT / 'STATUS.json', {'status': 'failed', 'error': repr(error), 'pid': os.getpid()})
        raise
