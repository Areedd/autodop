"""Fixed arithmetic three-seed score ensemble for all model families, separate from single-model results."""
import argparse
import json
from pathlib import Path
import numpy as np
from report90_interaction_pair_audit import BASE,accuracy,sha

OUT=BASE/'hard_pair_ema_ensemble'

def main(stage):
    paths=[BASE/'hard_pair_ema_pilot/pair_audit/RESULT.json']+[BASE/f'hard_pair_ema_stability/pair_audit_seed{s}/RESULT.json' for s in [29,43]]
    if stage=='prepare':
        assert not OUT.exists();OUT.mkdir()
        (OUT/'PROTOCOL.json').write_text(json.dumps({'seeds':[17,29,43],
            'aggregation':'Unweighted arithmetic mean of configuration scores across all three fixed seeds, applied separately to every model family. No weight fitting, calibration, seed selection, report90 data, or changed pair threshold.',
            'scope':'Separate ensemble variant using three checkpoints; does not replace or repair failed single-model three-seed replication. Requires up to three model inferences and model storage per score; actual runtime not measured here. Previously reused development validation, not blind test.',
            'source_sha256':{str(p):sha(p) for p in [Path(__file__),BASE/'hard_pair_ema_stability/PROTOCOL.json']},
            'model_sources':[str(p) for p in paths]},indent=2)+'\n');return
    protocol=json.loads((OUT/'PROTOCOL.json').read_text())
    for p,d in protocol['source_sha256'].items():assert sha(Path(p))==d
    assert not (OUT/'RESULT.json').exists()
    pools=[json.loads(p.with_name('PAIR_POOL.json').read_text()) for p in paths];assert pools[0]==pools[1]==pools[2]
    audits=[json.loads(p.read_text()) for p in paths]
    for a in audits:
        assert a['status']=='verified_independent_pair_replay'
        for p,d in a['source_sha256'].items():assert sha(Path(p))==d
    result={}
    for kind in audits[0]['models']:
        values=np.array([a['models'][kind]['scores'] for a in audits],dtype=np.float64)
        assert values.shape==(3,212) and np.isfinite(values).all()
        averaged=values.mean(axis=0);counts=accuracy(pools[0]['pairs'],averaged)
        counts['scores']=averaged.tolist();result[kind]=counts
    t=result['transformer']['macro_accuracy'];gate=all(t>v['macro_accuracy'] for k,v in result.items() if k!='transformer')
    summary={'status':'verified_fixed_score_ensemble','models':result,'macro_beats_all_ensemble_controls':gate,
        'scope':protocol['scope'],'source_sha256':{str(p):sha(p) for p in [*paths,OUT/'PROTOCOL.json']}}
    (OUT/'RESULT.json').write_text(json.dumps(summary,indent=2)+'\n')
    lines=['# 固定三种子分数平均诊断','',protocol['aggregation'],'',protocol['scope'],'', '| 模型（三检查点平均） | 等权准确率 | 汇总准确率 |','|---|---:|---:|']
    for kind,v in result.items():lines.append(f"| {kind} | {100*v['macro_accuracy']:.3f}% | {100*v['pooled_accuracy']:.3f}% |")
    lines+=['',f'是否超过全部同样聚合的对照：{gate}。不能将三检查点模型表述为单个原模型的结果。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');print({k:v['macro_accuracy'] for k,v in result.items()})

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['prepare','evaluate'],required=True);main(parser.parse_args().stage)
