"""Reuse frozen summary and retrospective scoring logic for calibrated model seeds."""
import argparse
import json
from pathlib import Path
import runpy

from report90_interaction_pair_audit import BASE, sha


def main(stage):
    root = BASE / 'pair_calibration_full'
    if stage == 'summary':
        for seed in [17, 29, 43]:
            assert json.loads((BASE / f'calibration_pair_audit_seed{seed}/RESULT.json').read_text())['status'] == 'verified_independent_pair_replay'
        original = Path(__file__).with_name('report90_interaction_accuracy_summary.py')
        changes = {
            "BASE = Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20'": 'BASE = Path(' + repr(str(BASE)) + ')',
            'interaction_pair_audit_seed': 'calibration_pair_audit_seed',
            'interaction_accuracy_comparison': 'calibration_accuracy_comparison',
            'Interaction-augmented Transformer': 'Pair-calibrated Transformer',
            'DOP交互输入模型的三种子排序比较': '分数间距校准模型的三种子排序比较',
        }
    else:
        assert json.loads((BASE / 'calibration_accuracy_comparison/RESULT.json').read_text())['status'] == 'verified_three_seed_accuracy_summary'
        original = Path(__file__).with_name('report90_interaction_observed90.py')
        changes = {
            'interaction_observed90': 'calibration_observed90',
            'interaction_accuracy_comparison': 'calibration_accuracy_comparison',
            'interaction_ranking/seed': 'pair_calibration_full/seed',
            'interaction_pair_audit_seed': 'calibration_pair_audit_seed',
            "Path(__file__).with_name('report90_models.py')": 'Path(' + repr(str(original.with_name('report90_models.py'))) + ')',
            'DOP交互输入模型在90条已测候选子集上的排序复核': '分数间距校准模型在90条已测候选子集上的排序复核',
        }
    changes['[Path(__file__)'] = '[Path(__file__), Path(' + repr(str(original)) + '), Path(' + repr(str(Path(__file__))) + ')'
    text = original.read_text()
    replacements = {}
    for old, new in changes.items():
        count = text.count(old)
        assert count > 0, old
        text = text.replace(old, new)
        replacements[old] = {'replacement': new, 'occurrences': count}
    generated = root / f'{stage}_staged.py'
    assert not generated.exists()
    compile(text, str(generated), 'exec')
    generated.write_text(text)
    (root / f'{stage}_TRANSFORM.json').write_text(json.dumps({'original_sha256': sha(original),
        'generated_sha256': sha(generated), 'wrapper_sha256': sha(Path(__file__)), 'changes': replacements}, indent=2) + '\n')
    runpy.run_path(str(generated), run_name='calibration_results')['main']()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['summary', 'observed90'], required=True)
    main(parser.parse_args().stage)
