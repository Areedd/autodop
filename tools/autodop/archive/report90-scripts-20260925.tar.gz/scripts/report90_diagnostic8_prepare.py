"""Explicit diagnostic follow-up after an unmet gate; never rewrites its outcome."""
import datetime
import json
from pathlib import Path
import subprocess
import sys
from autodop.training import file_sha256
from report90_coverage_choices import BASE, read


def replace(source, old, new, count=1):
    assert source.count(old) == count, (old, source.count(old))
    return source.replace(old, new)


def main():
    support = BASE / 'diagnostic_execution8_support_attempt2'; assert not support.exists()
    result = read(BASE / 'cosine_decay/RESULT.json'); assert result['status'] == 'verified'
    selections = [result['after_cosine'][str(s)]['transformer']['cohorts']['complex_new']['choices'] for s in [17, 29, 43]]
    assert selections[0] == selections[1] == selections[2]
    xgb = result['after_cosine']['17']['xgboost_pairs']['cohorts']['complex_new']['choices']
    assert sum(selections[0][p] != xgb[p] for p in xgb) == 1
    original = read(BASE / 'retrained/SCORE_REPLAY.json'); assert not original['development_gate_passed']
    support.mkdir()
    reason = {'frozen_at': datetime.datetime.now().astimezone().isoformat(), 'diagnostic_only': True,
        'original_gate_passed': False, 'all_cosine_seed_complex_choices_equal': True,
        'different_choices_from_pair_xgb': 1,
        'reason': 'All three schedule seeds select identical configurations for all8complex queries; only one differs from pair-XGBoost. Rerun all8queries and both XGBoost organizations to examine execution/label uncertainty, not to declare the original gate passed.',
        'model_choice': 'Seed17, the original reference seed; all three seeds have identical decisions on these8queries. No best-seed selection.',
        'scope': 'New diagnostic protocol after observed development results. Original gate remains failed. No90-query expansion, deployment, independent-test claim, or statistical-superiority claim. All8queries, all5modes,1warm+1measured=80executions.',
        'source_sha256': {str(p): file_sha256(p) for p in [Path(__file__), BASE / 'cosine_decay/RESULT.json', BASE / 'retrained/SCORE_REPLAY.json']}}
    reason_path = support / 'RATIONALE.json'; reason_path.write_text(json.dumps(reason, indent=2) + '\n')
    source_path = Path(__file__).with_name('report90_coverage_choices.py'); source = source_path.read_text()
    source = replace(source, "OUT = BASE / 'execution8'", "OUT = BASE / 'diagnostic_execution8'")
    source = replace(source, "assert replay['status'] == 'verified' and replay['development_gate_passed']",
        "assert replay['status'] == 'verified' and not replay['development_gate_passed']\n    assert read(BASE / 'cosine_decay/RESULT.json')['status'] == 'verified'")
    source = replace(source, "result = read(BASE / 'retrained/RESULT.json')",
        "result = read(BASE / 'retrained/RESULT.json')\n    result['selected']['transformer'] = read(BASE / 'cosine_decay/seed17/RESULT.json')['selected']['transformer']")
    source = replace(source, "    for kind, selected in result['selected'].items():",
        "    sources += [BASE / 'cosine_decay/seed17/RESULT.json', BASE / 'cosine_decay/seed17/SCORE_REPLAY.json', Path(" + repr(str(reason_path)) + ")]\n    for kind, selected in result['selected'].items():")
    source = replace(source, "    OUT.mkdir()", "    protocol.update(read(Path(" + repr(str(reason_path)) + ")))\n    protocol['source_sha256'] = {str(p): file_sha256(p) for p in sources}\n    protocol['gate'] = 'Diagnostic verification only; original expansion gate remains failed. No automatic full run or deployment.'\n    OUT.mkdir()")
    choices_script = support / 'choices.py'; compile(source, str(choices_script), 'exec'); choices_script.write_text(source)
    executor_path = Path(__file__).with_name('report90_coverage_execute.py'); executor = executor_path.read_text()
    executor = replace(executor, 'from report90_coverage_choices import BASE, COM, OUT, read',
        "from report90_coverage_choices import BASE, COM, read\nOUT = BASE / 'diagnostic_execution8'")
    executor = replace(executor, "assert read(BASE / 'retrained/SCORE_REPLAY.json')['development_gate_passed']",
        "assert protocol['diagnostic_only'] and protocol['original_gate_passed'] is False\n    assert not read(BASE / 'retrained/SCORE_REPLAY.json')['development_gate_passed']")
    executor = replace(executor, "ROOT / 'collect_paper_evaluations.py'", "BASE.parent / 'failure_capture_smoke/collector.py'", 2)
    executor = executor.replace('execution_gate_passed', 'descriptive_mean_check').replace('扩大实验的执行门槛', '描述性均值条件（不授权扩大实验）')
    execute_script = support / 'execute.py'; compile(executor, str(execute_script), 'exec'); execute_script.write_text(executor)
    sources = [source_path, executor_path, choices_script, execute_script, reason_path,
               BASE.parent / 'failure_capture_smoke/collector.py', BASE.parent / 'failure_capture_smoke/report90_failure_capture.py']
    (support / 'SOURCE_SHA256.json').write_text(json.dumps({str(p): file_sha256(p) for p in sources}, indent=2) + '\n')
    subprocess.run([sys.executable, str(choices_script)], check=True)
    print('Prepared diagnostic choices; original expansion gate remains failed.')


if __name__ == '__main__': main()
