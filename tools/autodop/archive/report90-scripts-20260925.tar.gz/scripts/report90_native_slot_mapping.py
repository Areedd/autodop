"""Execute extracted Java MBE arithmetic; distinguish prediction from reservation."""
import hashlib
import json
import math
from pathlib import Path
import subprocess


def method_body(text, marker):
    start=text.index('{',text.index(marker));depth=1;end=start+1
    while depth:
        depth+=(text[end]=='{')-(text[end]=='}');end+=1
    return text[start:end]


def main():
    root=Path(__file__).resolve().parents[3];run=root/'tools/autodop/runs/report90_20260912'
    out=run/'native_slot_mapping17';assert not (out/'RESULT.json').exists()
    read=lambda p:json.loads(p.read_text())
    runtime=read(out/'RUNTIME.json');configs={r['Key']:r for r in runtime['configs']}
    nodes=runtime['backends'];assert len(nodes)==3 and all(int(n['CpuCores'])==8 for n in nodes)
    assert configs['query_queue_v2_concurrency_level']['Value']=='4'
    prior=run/'development17_memory_observed/DIRECT_MEMORY_ANALYSIS.json'
    limits={r['limit_bytes'] for r in read(prior)['rows']};assert len(limits)==1;limit=limits.pop()
    per_worker=8*4;workers=3;total_slots=per_worker*workers;slot_bytes=limit//per_worker
    utils=root/'fe/fe-core/src/main/java/com/starrocks/sql/optimizer/Utils.java'
    estimator=root/'fe/fe-core/src/main/java/com/starrocks/qe/scheduler/slot/SlotEstimatorFactory.java'
    options=root/'fe/fe-core/src/main/java/com/starrocks/qe/scheduler/slot/QueryQueueOptions.java'
    power_body=method_body(utils.read_text(),'public static int computeMinGEPower2(int num)')
    text=estimator.read_text();a=text.index('long numSlotsPerWorker = memCost / opts.v2().getMemBytesPerSlot();')
    b=text.index('return (int) numSlots;',a)+len('return (int) numSlots;')
    original=text[a:b];mapping=original.replace('opts.v2().getMemBytesPerSlot()','slotBytes').replace(
        'opts.v2().getNumWorkers()','workers').replace('opts.v2().getTotalSlots()','totalSlots')
    java='''import java.io.*;
public class NativeSlotArithmetic {
  static int computeMinGEPower2(int num) POWER
  static int map(long memCost,long slotBytes,int workers,int totalSlots) { MAPPING }
  public static void main(String[] args) throws Exception {
    try (BufferedReader r=new BufferedReader(new FileReader(args[0]))) {
      for(String line;(line=r.readLine())!=null;) {
        String[] f=line.split(",");
        System.out.println(map(Long.parseLong(f[0]),Long.parseLong(f[1]),Integer.parseInt(f[2]),Integer.parseInt(f[3])));
      }
    }
  }
}
'''.replace('POWER',power_body).replace('MAPPING',mapping)
    source=out/'NativeSlotArithmetic.java';source.write_text(java)
    boundary=[0,1,slot_bytes-1,slot_bytes,slot_bytes+1,3*slot_bytes//2,
              2*slot_bytes-1,2*slot_bytes,3*slot_bytes,limit,limit*2]
    model_path=run/'native_memory_prediction_loo17/RESULT.json';model=read(model_path);assert model['status']=='verified'
    predictions=[r for r in model['rows'] if r['model']=='neighbor_max3'];assert len(predictions)==17
    queries=[];costs=list(boundary)
    for r in predictions:
        budget=r['reservation_bytes']
        required=math.ceil(budget*5/(3*slot_bytes))  # budget / 0.60, exactly the prior headroom fraction
        rounded=1<<(max(required,1)-1).bit_length()
        modes={'direct_budget':budget,'headroom_scaled_budget':math.ceil(budget*5/3),
               'ceil_slot_encoded_budget':rounded*slot_bytes}
        for mode,cost in modes.items():
            queries.append(dict(id=r['id'],mode=mode,cost_bytes=cost,unencoded_budget_bytes=budget,
                                observed_peak_bytes=r['observed_peak_bytes'],index=len(costs)))
            costs.append(cost)
    input_path=out/'inputs.csv';input_path.write_text(''.join(f'{c},{slot_bytes},{workers},{total_slots}\n' for c in costs))
    subprocess.run(['javac',str(source)],check=True,capture_output=True,text=True)
    output=subprocess.check_output(['java','-cp',str(out),'NativeSlotArithmetic',str(input_path)],text=True)
    (out/'java_output.txt').write_text(output);mapped=list(map(int,output.splitlines()));assert len(mapped)==len(costs)
    def python_map(cost):
        count=cost//slot_bytes
        return min(total_slots,max(1,(1<<(max(count,1)-1).bit_length())*workers))
    assert mapped==[python_map(c) for c in costs]
    # Test the subtle floor-before-power-of-two case against source-extracted Java.
    assert mapped[5]==workers and mapped[5]//workers*slot_bytes<boundary[5]
    summaries={}
    for r in queries:
        n=mapped[r.pop('index')];assert n%workers==0
        nominal=n//workers*slot_bytes
        r.update(physical_slots=n,nominal_reserved_bytes_per_worker=nominal,
                 below_observed_peak=nominal<r['observed_peak_bytes'],
                 scaled_budget_covered=nominal*3>=r['unencoded_budget_bytes']*5,
                 at_total_slot_cap=n==total_slots)
    for mode in ['direct_budget','headroom_scaled_budget','ceil_slot_encoded_budget']:
        rs=[r for r in queries if r['mode']==mode]
        summaries[mode]=dict(queries=len(rs),below_observed_peak=sum(r['below_observed_peak'] for r in rs),
                             not_covering_headroom_scaled_budget=sum(not r['scaled_budget_covered'] for r in rs),
                             min_physical_slots=min(r['physical_slots'] for r in rs),
                             max_physical_slots=max(r['physical_slots'] for r in rs),
                             at_total_slot_cap=sum(r['at_total_slot_cap'] for r in rs))
    paths=[Path(__file__).resolve(),out/'RUNTIME.json',prior,model_path,utils,estimator,options,source,input_path]
    result=dict(status='verified',scope='Source-extracted arithmetic, not a live V2 allocation or physical memory guarantee. '
          'Model original prediction gate remains failed. Slot headroom does not prove unseen query coverage. '
          'MBE only; live strategy currently MAX and V2 disabled. Encoded cost is a reservation request, not raw predicted memory.',
          slot_bytes=slot_bytes,total_slots=total_slots,slots_per_worker=per_worker,
          java_python_parity=True,boundary_cases=len(boundary),summaries=summaries,rows=queries,
          source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 原生MBE槽位换算审计','',result['scope'],'',
           f'3个BE、每BE8核、concurrency_level=4：总槽位{total_slots}，每BE每槽{slot_bytes}字节。',
           '抽取Java原方法执行，与Python复算逐项相同。先整数除法再取不小于商的2次幂，可能小于原字节请求。', '',
           '| 字节请求方式 | 名义额度低于观测峰值 | 未覆盖含40%余量的预算 | 物理槽位范围 |', '|---|---:|---:|---:|']
    for mode,r in summaries.items():
        lines.append(f"| {mode} | {r['below_observed_peak']}/17 | {r['not_covering_headroom_scaled_budget']}/17 | {r['min_physical_slots']}–{r['max_physical_slots']} |")
    lines+=['','编码方案先将原预算除以0.60，再向上取整到槽位和2的幂，传回槽位对应字节数，避免原生前置整数除法损失预算。该方案使用已有60%预算规则，未按留出标签调整倍率。',
            '这仅检查17条已观测查询下的名义额度；V2当前关闭且不可热切换，尚未运行集成并发测试。正常槽位模型、调度公平性、预测外推及进程基线内存仍需实测。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps(summaries,indent=2))


if __name__=='__main__':main()
