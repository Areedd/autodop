"""Retrospective ranking of all90 frozen queries after the three-seed EMA audit."""
import json
from pathlib import Path
import runpy
from report90_interaction_pair_audit import BASE,sha

def main():
    root=BASE/'hard_pair_ema_stability'
    summary=json.loads((root/'RESULT.json').read_text());assert summary['status']=='verified_three_seed_summary'
    for path,digest in summary['source_sha256'].items():assert sha(Path(path))==digest
    original=Path(__file__).with_name('report90_interaction_observed90.py')
    changes={
        'from report90_interaction_model import load_interaction_model as load_cost_model':'from autodop.model import load_cost_model',
        'interaction_observed90':'hard_pair_ema_observed90',
        'interaction_accuracy_comparison':'hard_pair_ema_stability',
        'verified_three_seed_accuracy_summary':'verified_three_seed_summary',
        "BASE/f'interaction_ranking/seed{seed}/RESULT.json'":"(BASE/'hard_pair_ema_pilot/pilot/RESULT.json' if seed==17 else BASE/f'hard_pair_ema_stability/seed{seed}/RESULT.json')",
        "BASE/f'interaction_pair_audit_seed{seed}/RESULT.json'":"(BASE/'hard_pair_ema_pilot/pair_audit/RESULT.json' if seed==17 else BASE/f'hard_pair_ema_stability/pair_audit_seed{seed}/RESULT.json')",
        "Path(__file__).with_name('report90_models.py')":'Path('+repr(str(original.with_name('report90_models.py')))+')',
        'DOP交互输入模型在90条已测候选子集上的排序复核':'错对强化与权重平均模型在90条已测候选上的排序复核',
        '[Path(__file__),':'[Path(__file__), Path('+repr(str(original))+'), Path('+repr(str(Path(__file__)))+'),',
    }
    text=original.read_text();applied={}
    for old,new in changes.items():
        count=text.count(old);assert count>0,old
        text=text.replace(old,new);applied[old]={'replacement':new,'occurrences':count}
    generated=root/'observed90_staged.py';assert not generated.exists();compile(text,str(generated),'exec');generated.write_text(text)
    (root/'OBSERVED90_TRANSFORM.json').write_text(json.dumps({'original_sha256':sha(original),'generated_sha256':sha(generated),'wrapper_sha256':sha(Path(__file__)),'changes':applied},indent=2)+'\n')
    runpy.run_path(str(generated),run_name='ema_observed90')['main']()

if __name__=='__main__':main()
