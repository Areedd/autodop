"""Matched pair-gap ridge probes of frozen graph representations and raw statistics."""
import json
import os
from pathlib import Path
import numpy as np
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from autodop.training import select_partition
from report90_complex_retrain import pair_index,validation
from report90_neighborhood_prepare import RUN,sha
BASE=RUN/'structure_coverage20';OUT=BASE/'frozen_representation_probe'
ALPHAS=[.0001,.01,1.]


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1);assert not OUT.exists()
    data=BASE/'merged_dataset'
    checkpoints={'multistage':BASE/'prepared/cost.pt','hard_ema_seed17':BASE/'hard_pair_ema_pilot/pilot/transformer_h0/best.pt'}
    sources=[Path(__file__),data/'samples.jsonl',data/'pairs.jsonl',data/'metadata.json',data/'CONTRACT.json',*checkpoints.values(),Path(__file__).with_name('report90_complex_retrain.py'),Path(__file__).with_name('report90_models.py')]
    OUT.mkdir()
    protocol={'status':'frozen_before_probe','representations':['multistage64','hard_ema_seed17_64','raw_statistics1088'],'alphas':ALPHAS,
        'objective':'sum of cohort/plan/pair-normalized weighted squared errors of predicted within-batch score gap versus log(slow/fast) plusalpha*||w||²; no intercept needed for differences.',
        'normalization':'Each representation standardized on1365training configurations only;std<1e-6 replaced by1.',
        'selection':'Equal-cohort validation accuracy, regret, then earlier alpha in the fixed list. Same22plans/212configs and3%gap; no90queries or SQL.',
        'scope':'Diagnostic of frozen features, not full architecture superiority or a production replacement. Existing graph checkpoints already selected on reused development validation. No encoder updates; same three ridge settings for each representation.',
        'source_sha256':{str(p):sha(p) for p in sources}}
    (OUT/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    samples,pairs,metadata=load_dataset(data);contract=json.loads((data/'CONTRACT.json').read_text())
    train,tp=select_partition(samples,pairs,contract,'train');valid,_=select_partition(samples,pairs,contract,'valid')
    train=sorted(train,key=lambda s:(s['plan_key'],s['config_key']));valid=sorted(valid,key=lambda s:(s['plan_key'],s['config_key']))
    assert len(train)==1365 and len(valid)==212 and len(tp)==6702
    ordered=train+valid;graphs=[build_graph(s,metadata) for s in ordered]
    from report90_models import flat_features
    representations={'raw_statistics1088':np.stack([flat_features(g,metadata) for g in graphs]).astype(np.float64)}
    originals={}
    for name,path in checkpoints.items():
        model,ck=load_cost_model(path);model.eval();embeddings=[];scores=[]
        with torch.no_grad():
            for g in graphs:
                pooled,_=model.global_readout(model.encoder(g));embeddings.append(pooled.numpy().astype(np.float64));scores.append(float(model.scorer(pooled).squeeze(-1)))
        label='multistage64' if name=='multistage' else 'hard_ema_seed17_64'
        representations[label]=np.stack(embeddings)
        originals[name]=validation(valid,scores[len(train):])
    index={(s['plan_key'],s['config_key']):i for i,s in enumerate(train)};fi=[];si=[];targets=[];weights=[]
    by=pair_index(train,tp)
    for cohort,plans in by.items():
        for plan,pp in sorted(plans.items()):
            for p in pp:
                fi.append(index[plan,p['fast_config_key']]);si.append(index[plan,p['slow_config_key']]);targets.append(np.log(p['slow_latency_ms']/p['fast_latency_ms']));weights.append(.5/len(plans)/len(pp))
    y=np.array(targets);weight=np.array(weights);assert np.isclose(weight.sum(),1)
    results={};all_scores={}
    for name,features in representations.items():
        assert np.isfinite(features).all()
        mean=features[:len(train)].mean(0);std=features[:len(train)].std(0);std[std<1e-6]=1
        X=(features-mean)/std;D=X[fi]-X[si];gram=D.T@(weight[:,None]*D);rhs=D.T@(weight*y)
        candidates=[]
        for j,alpha in enumerate(ALPHAS):
            system=gram+alpha*np.eye(D.shape[1]);coef=np.linalg.solve(system,rhs)
            residual=np.linalg.norm(system@coef-rhs)/(np.linalg.norm(rhs)+1e-12);assert residual<1e-7
            predictions=X@coef;assert np.isfinite(predictions).all()
            q=validation(valid,predictions[len(train):]);assert sum(v['ranking_pairs'] for v in q['cohorts'].values())==920
            model_path=OUT/f'{name}_alpha{j}.npz';np.savez(model_path,coefficient=coef,mean=mean,std=std)
            saved=np.load(model_path);replayed=((features-saved['mean'])/saved['std'])@saved['coefficient'];assert np.array_equal(predictions,replayed)
            c={'alpha':alpha,'setting':j,'validation':q,'weighted_train_pair_mse':float(np.sum(weight*(D@coef-y)**2)),'stored_train_pair_accuracy':float(np.mean(D@coef>0)),'solve_relative_residual':float(residual),'model_sha256':sha(model_path)}
            candidates.append(c);all_scores[f'{name}_alpha{j}']=predictions[len(train):].tolist()
        winner=min(candidates,key=lambda c:(-c['validation']['weighted_rank_accuracy'],c['validation']['weighted_regret'],c['setting']))
        results[name]={'features':features.shape[1],'candidates':candidates,'selected':winner}
        print(name,winner['alpha'],winner['validation']['weighted_rank_accuracy'],flush=True)
    for p,d in protocol['source_sha256'].items():assert sha(Path(p))==d
    (OUT/'SCORES.json').write_text(json.dumps(all_scores)+'\n')
    result={'status':'verified_frozen_representation_probe','models':results,'original_scalar_models':originals,'training_samples':len(train),'training_pairs':len(tp),'validation_samples':len(valid),'validation_pairs':920,'scope':protocol['scope'],'protocol_sha256':sha(OUT/'PROTOCOL.json'),'scores_sha256':sha(OUT/'SCORES.json')}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 冻结图表示的成对线性读出诊断','',protocol['scope'],'','| 表示 | 维度 | 所选正则项 | 两组等权排序准确率 | 训练对MSE |','|---|---:|---:|---:|---:|']
    for name,r in results.items():
        c=r['selected'];lines.append(f"| {name} | {r['features']} | {c['alpha']} | {100*c['validation']['weighted_rank_accuracy']:.3f}% | {c['weighted_train_pair_mse']:.5f} |")
    lines += ['', '原读出准确率：'+str({k:100*v['weighted_rank_accuracy'] for k,v in originals.items()}),'', '全部设置、系数、训练归一化和验证分数保存；通过线性方程残差及保存后分数逐值重放检查。线性读出失败不能证明表示不包含非线性可用信息。训练对标签保留原批次口径；训练准确率与开发集等权准确率不可直接比较。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')

if __name__=='__main__':main()
