"""Evaluate the trained auxiliary head, separately from ranking acceptance."""
import json
import os
from pathlib import Path
import numpy as np
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from report90_models import flat_features
from report90_neighborhood_prepare import RUN,sha
BASE=RUN/'structure_coverage20';OUT=BASE/'feature_reconstruction_pilot'


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1)
    assert json.loads((OUT/'RESULT.json').read_text())['status']=='verified'
    folder=OUT/'pilot/transformer_h0';model,ck=load_cost_model(folder/'raw_final.pt');model.eval()
    auxiliary=torch.load(folder/'auxiliary_final.pt',map_location='cpu',weights_only=False)
    head=torch.nn.Linear(64,auxiliary['target_width']);head.load_state_dict(auxiliary['state']);head.eval()
    norm=np.load(OUT/'pilot/FEATURE_NORMALIZATION.npz')
    samples,pairs,metadata=load_dataset(BASE/'merged_dataset')
    totals={};forward_equal=0
    with torch.no_grad():
        for sample in samples:
            g=build_graph(sample,metadata);pooled,_=model.global_readout(model.encoder(g))
            target=torch.tensor((flat_features(g,metadata)-norm['mean'])/norm['std'],dtype=torch.float32)
            reconstruction=head(pooled)
            values=totals.setdefault(sample['split'],{'samples':0,'mse_sum':0.,'zero_predictor_mse_sum':0.})
            values['samples']+=1;values['mse_sum']+=float((reconstruction-target).square().mean());values['zero_predictor_mse_sum']+=float(target.square().mean())
            assert torch.equal(model.scorer(pooled).squeeze(-1),model(g));forward_equal+=1
    for values in totals.values():
        values['mean_mse']=values['mse_sum']/values['samples'];values['mean_zero_predictor_mse']=values['zero_predictor_mse_sum']/values['samples']
    assert len(model.state_dict())==83 and forward_equal==1577
    result={'status':'verified_auxiliary_diagnostic','partitions':totals,'forward_parity_samples':forward_equal,'auxiliary_parameters':sum(p.numel() for p in head.parameters()),'inference_state_tensors':len(model.state_dict()),
        'scope':'Final raw model with its final training-only head, not selected EMA checkpoint. Feature-only reconstruction diagnosis, no latency label scoring or selection here. Zero predictor means training feature mean under train-only normalization. Lower reconstruction MSE does not establish better ranking.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),folder/'raw_final.pt',folder/'auxiliary_final.pt',OUT/'pilot/FEATURE_NORMALIZATION.npz',OUT/'RESULT.json',BASE/'merged_dataset/samples.jsonl',BASE/'merged_dataset/metadata.json']}}
    p=OUT/'RECONSTRUCTION_DIAGNOSTIC.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(totals))

if __name__=='__main__':main()
