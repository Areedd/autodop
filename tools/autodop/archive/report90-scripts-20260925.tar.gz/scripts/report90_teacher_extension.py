"""Frozen original-teacher control, small pilot before contemporaneous fixed90 test."""
import json,hashlib,datetime,sys,subprocess,time,os
from pathlib import Path
import numpy as np
import torch
from autodop.model import load_cost_model
from autodop.graph import build_graph,sample_from_request
from report90_execute import ROOT,RUN,check
OUT=RUN/'teacher_extension_20260913';OUT.mkdir(exist_ok=True)
def save(name,value):
 p=OUT/name;tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(p)
def status(stage,**kw):save('STATUS.json',{'status':'running','stage':stage,'pid':os.getpid(),'at':datetime.datetime.now().astimezone().isoformat(),**kw})
def prepare(append=False):
 suffix='_v2' if append else ''
 assert not (OUT/f'vectors{suffix}.json').exists(),'Frozen inputs exist; do not overwrite'
 torch.set_num_threads(1);source=ROOT/'runs/multi_structure_feedback_cost05_20260910/model/cost.pt';teacher,ck=load_cost_model(source);teacher.eval()
 modes=['original_teacher_pool','cost_transformer_rank','cost_xgb_rank'];vectors=json.loads((OUT/'vectors.json').read_text()) if append else {m:{} for m in modes};records=json.loads((OUT/'CHOICES.json').read_text()) if append else []
 for folder in (['choices_attempt2'] if append else ['choices','choices_attempt1']):
  vv=json.loads((RUN/folder/'vectors.json').read_text());rows=json.loads((RUN/folder/'ROWS.json').read_text())
  for row in rows:
   if row['type']!='cost_model' or row['mode']!='transformer_rank_s17':continue
   q=row['id'];req=vv['cost_transformer_rank'][q]['request'];s=sample_from_request(req)
   with torch.no_grad():scores=[float(teacher(build_graph({**s,'dop_config':list(c)},ck['metadata']))) for c in row['configs']]
   selected=row['configs'][int(np.argmax(scores))]
   entries={'original_teacher_pool':{'request':req,'fragment_dops':dict(zip(s['fragment_ids'],selected))},**{m:vv[m][q] for m in modes[1:]}}
   for m,e in entries.items():
    if q in vectors[m]:vectors[m][q].setdefault('alternatives',[]).append(e)
    else:vectors[m][q]=e
   records.append({'id':q,'source':folder,'scores':scores,'configs':row['configs'],'selected_dops':selected})
 assert all(len(v)==90 for v in vectors.values());save(f'vectors{suffix}.json',vectors);save(f'CHOICES{suffix}.json',records)
 save(f'PROTOCOL{suffix}.json',{'scope':'Same frozen90, same prior candidate pool; original multistage teacher versus retrained30Transformer and XGBoost ranking. No runtime-based model selection.','modes':modes,'pilot_queries':2,'pilot_warmup':1,'pilot_repetitions':1,'full_queries':90,'full_warmup':1,'full_repetitions':2,'teacher_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),RUN/'manifest.json',RUN/'choices/ROWS.json',RUN/'choices_attempt1/ROWS.json',source]},'scope_limit':'Fixed posthoc positive90; result may contradict hypothesized superiority. Preserve all outcomes.'})
 print('Frozen choices ready',flush=True)
def stage(pilot,append=False):
 name=('pilot' if pilot else 'full')+('_v2' if append else '');p=OUT/name;p.mkdir(exist_ok=False);status(name)
 for retry in range(20):
  try:check(p/f'IDLE_{retry}.json');break
  except Exception:
   if retry==19:raise
   print('Idle/readiness gate not met, retry15s',flush=True);time.sleep(15)
 proto=json.loads((RUN/'PROTOCOL.json').read_text());cmd=[sys.executable,str(ROOT/'collect_paper_evaluations.py'),'--manifest',str(RUN/('pilot.json' if pilot else 'manifest.json')),'--trusted-collection',str(ROOT/'runs/preference_random200_20260911/random200/trusted_merged.json'),'--output-dir',str(p/'scored'),'--policy-model',proto['model'],'--modes','original_teacher_pool,cost_transformer_rank,cost_xgb_rank','--scenario','serial','--query-timeout-s','180','--auto-dop-max-dop','16','--torch-threads','1','--decision-timeout-ms','1000','--warmup','1','--repetitions','1' if pilot else '2','--seed',str(proto['seed']),'--decision-vectors',str(OUT/('vectors_v2.json' if append else 'vectors.json'))]
 (p/'COMMAND.json').write_text(json.dumps(cmd,indent=2)+'\n');subprocess.run(cmd,check=True)
 subprocess.run([sys.executable,str(ROOT/'scripts/verify_paper_evaluations.py'),'--collection-dir',str(p/'scored'),'--output',str(p/'scored/independent_verification.json')],check=True)
 proof=json.loads((p/'scored/independent_verification.json').read_text());assert proof['all_expected_executions_verified'],'Pilot/full evidence invalid; do not expand'
def main():
 append='--resume-new-plan' in sys.argv
 status('freeze_choices');prepare(append);stage(True,append);stage(False,append);status('complete',status_note='All slots verified');save('COMPLETE.json',{'completed_at':datetime.datetime.now().astimezone().isoformat()})
if __name__=='__main__':
 try:main()
 except BaseException as e:save('STATUS.json',{'status':'failed','error':repr(e),'pid':os.getpid()});raise
