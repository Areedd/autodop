"""Six serial EXPLAINs, interleaved optimizer budgets; never executes query data."""
import hashlib
import json
from pathlib import Path
import re
import time
from report90_queue_extension import connect
from report90_execute import RUN,check


def main():
    out=RUN/'native_plan_stability_probe';out.mkdir(exist_ok=False)
    check(out/'IDLE.json')
    manifest_path=RUN/'native_mixed_budget_pilot_support/manifest.json'
    q=json.loads(manifest_path.read_text())['queries'][0]
    sql=Path(q['sql_file']).read_text().strip().rstrip(';')
    assert hashlib.sha256(Path(q['sql_file']).read_bytes()).hexdigest()==q['sql_sha256']
    rows=[]
    with connect() as connection,connection.cursor() as c:
        c.execute('USE `'+q['database']+'`')
        for setting in ['enable_auto_dop=false','pipeline_dop=4','enable_runtime_adaptive_dop=false','enable_query_cache=false','enable_spill=false']:
            c.execute('SET '+setting)
        c.execute("SHOW VARIABLES LIKE 'new_planner_optimize_timeout'")
        original=c.fetchone();default=int(original[1])
        protocol=dict(query_id=q['id'],sql_sha256=q['sql_sha256'],default_timeout_ms=default,
                      raised_timeout_ms=max(default*10,30000),repetitions=3,
                      sequence=['default','raised']*3,query_data_executions=0,
                      scope='Serial Explain only, AutoDOP off, original serving FE. Planner variability diagnostic, not a performance comparison or FIFO causality test.')
        (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
        for index,label in enumerate(protocol['sequence']):
            timeout=default if label=='default' else protocol['raised_timeout_ms']
            c.execute('SET new_planner_optimize_timeout='+str(timeout))
            start=time.perf_counter();c.execute('EXPLAIN VERBOSE '+sql);plan='\n'.join(str(x[0]) for x in c.fetchall());elapsed=time.perf_counter()-start
            path=out/f'{index:02d}_{label}.txt';path.write_text(plan+'\n')
            lines=plan.splitlines();joins=[line.strip() for line in lines if 'join op:' in line.lower()]
            row=dict(index=index,label=label,optimizer_timeout_ms=timeout,elapsed_ms=elapsed*1000,
                     fragments=len(re.findall(r'^PLAN FRAGMENT ',plan,re.M)),joins=joins,
                     plan_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
            rows.append(row);print(json.dumps(row),flush=True)
        c.execute('SET new_planner_optimize_timeout='+str(default))
    (out/'RESULT.json').write_text(json.dumps(dict(status='complete',rows=rows,scope=protocol['scope']),indent=2)+'\n')


if __name__=='__main__':main()
