"""Audit formal-round stability without pooling measurement-batch labels."""
import itertools
import json
from pathlib import Path
from autodop.data import sample_from_trace
from report90_conditional_contrasts_prepare import OUT as BASE
from report90_neighborhood_prepare import sha


def load_batch(name):
    folder = BASE / name
    result = json.loads((folder / 'RESULT.json').read_text())
    assert result['status'] == 'verified' and result['executions'] == 56
    for p, digest in result['source_sha256'].items():
        assert sha(Path(p)) == digest
    rows = [json.loads(line) for line in (folder / 'scored/events.jsonl').read_text().splitlines()]
    assert len(rows) == 56
    formal = {}
    for row in rows:
        assert row['status'] == 'verified' and row['dop_validation']['applied']
        if row['phase'] == 'measured':
            key = (row['id'], row['mode'])
            assert key not in formal
            formal[key] = row
    assert len(formal) == 28
    return formal


def sign(value):
    return (value > 0) - (value < 0)


def main():
    original, repeat = load_batch('collection'), load_batch('repeat')
    assert original.keys() == repeat.keys()
    output = BASE / 'FORMAL_REPEAT_SUMMARY.json'
    assert not output.exists()
    protocol = json.loads((BASE / 'PROTOCOL.json').read_text())
    proposals = json.loads((BASE / 'PROPOSALS.json').read_text())
    latency = lambda row: float(row['trace']['latency_ms'])
    details, summaries = [], {}
    for key in original:
        a, b = original[key], repeat[key]
        ga, gb = sample_from_trace(a['trace']), sample_from_trace(b['trace'])
        assert ga['dop_config'] == gb['dop_config'] and ga['plan_key'] == gb['plan_key']
        assert a['sql_sha256'] == b['sql_sha256'] and a['result_digest'] == b['result_digest']
        wa = [set(f['worker_ids']) for f in ga['fragments']]
        wb = [set(f['worker_ids']) for f in gb['fragments']]
        overlap = lambda ws: [[len(x & y) / len(x | y) if x | y else 0 for y in ws] for x in ws]
        assert overlap(wa) == overlap(wb)
    for query in protocol['queries']:
        counts = dict(total_pairs=0, original_eligible=0, repeat_eligible=0, both_eligible=0, both_eligible_same_order=0)
        for a, b in itertools.combinations(sorted(protocol['modes']), 2):
            aa, ab = latency(original[query, a]), latency(original[query, b])
            ba, bb = latency(repeat[query, a]), latency(repeat[query, b])
            e1, e2 = max(aa, ab) / min(aa, ab) >= 1.03, max(ba, bb) / min(ba, bb) >= 1.03
            same = sign(aa-ab) == sign(ba-bb)
            counts['total_pairs'] += 1
            counts['original_eligible'] += e1
            counts['repeat_eligible'] += e2
            counts['both_eligible'] += e1 and e2
            counts['both_eligible_same_order'] += e1 and e2 and same
            details.append(dict(query=query, modes=[a,b], original_ms=[aa,ab], repeat_ms=[ba,bb], original_eligible=e1, repeat_eligible=e2, same_order=same))
        endpoints = []
        for i, group in enumerate(proposals[query]['selected_groups'], 1):
            a, b = f'group{i}_low', f'group{i}_high'
            aa, ab = latency(original[query,a]), latency(original[query,b])
            ba, bb = latency(repeat[query,a]), latency(repeat[query,b])
            endpoints.append(dict(group=i, root_node=group['root_node'], original_ms=[aa,ab], repeat_ms=[ba,bb],
                original_high_dop_reduction_percent=100*(1-ab/aa), repeat_high_dop_reduction_percent=100*(1-bb/ba),
                both_ge3pct_and_same_order=max(aa,ab)/min(aa,ab)>=1.03 and max(ba,bb)/min(ba,bb)>=1.03 and sign(aa-ab)==sign(ba-bb)))
        summaries[query] = dict(pair_counts=counts, endpoints=endpoints, anchor_ms=[latency(original[query,'anchor_low']), latency(repeat[query,'anchor_low'])])
    totals = {k:sum(q['pair_counts'][k] for q in summaries.values()) for k in counts}
    totals['endpoints_both_ge3pct_same_order'] = sum(e['both_ge3pct_and_same_order'] for q in summaries.values() for e in q['endpoints'])
    result = dict(status='verified_formal_repeat_consistency', queries=summaries, totals=totals, pairs=details,
        scope='All28 configurations and12 endpoints retained. Two separate formal rounds; warmups excluded. Agreement is descriptive, not significance. No cross-batch ranking labels, no training or test-query selection, no active model changes.',
        source_sha256={str(p):sha(p) for p in [Path(__file__),BASE/'PROTOCOL.json',BASE/'PROPOSALS.json',BASE/'REPEAT_PROTOCOL.json',BASE/'collection/RESULT.json',BASE/'repeat/RESULT.json',BASE/'collection/scored/events.jsonl',BASE/'repeat/scored/events.jsonl']})
    output.write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 条件分支对照的正式复测','',result['scope'],'','| 查询 | 分支组 | 首轮高DOP收益 | 复测高DOP收益 | 两轮均≥3%且方向一致 |','|---|---:|---:|---:|---|']
    for q, values in summaries.items():
        for e in values['endpoints']:
            lines.append(f"| {q} | {e['group']} | {e['original_high_dop_reduction_percent']:.2f}% | {e['repeat_high_dop_reduction_percent']:.2f}% | {e['both_ge3pct_and_same_order']} |")
    lines += ['',f"全部查询对：{totals['total_pairs']}；首轮有效{totals['original_eligible']}，复测有效{totals['repeat_eligible']}；两轮都有效{totals['both_eligible']}，其中方向一致{totals['both_eligible_same_order']}。",'',f"12组端点中，两轮均≥3%且同方向：{totals['endpoints_both_ge3pct_same_order']}。"]
    (BASE/'FORMAL_REPEAT_REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(totals),flush=True)


if __name__ == '__main__':
    main()
