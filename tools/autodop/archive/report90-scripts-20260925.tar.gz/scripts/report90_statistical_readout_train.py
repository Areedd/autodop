"""Matched small pilots for original and statistical Transformer readouts."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

import torch
from autodop.model import load_cost_model
from report90_statistical_readout_model import load_statistical_model
import report90_coverage_stability as common
from report90_neighborhood_prepare import RUN, sha

BASE = RUN / 'structure_coverage20'
OUT = BASE / 'statistical_readout_pilot'
SOURCE = BASE / 'pair_calibration_pilot/pilot_trainer.py'


def main(stage):
    torch.set_num_threads(1)
    os.sched_setaffinity(0, {34})
    if stage == 'smoke':
        assert not OUT.exists()
        proof = common.read(BASE / 'statistical_readout_smoke/RESULT.json')
        assert proof['status'] == 'verified' and proof['exact_warmstart_configurations'] == 1577
        for p, digest in proof['source_sha256'].items():
            assert sha(Path(p)) == digest
        OUT.mkdir()
        common.save(OUT / 'PROTOCOL.json', {'seed': 17, 'arms': ['original_readout', 'statistical_readout'],
            'smoke_epochs': 2, 'pilot_epochs': 30,
            'design': 'Both arms use original multi-stage Transformer encoder with competition edges, no explicit DOP interaction adapter. Only statistical arm adds a zero-output initialized residual MLP of node mean, sum/sqrt(count), max, stabilized std, and log1p(count). Original global attention retained.',
            'training': 'Same original1365 train/212 valid data; no neighborhood augmentation. Same softplus ranking +0.1 smooth_l1 pair-gap calibration,624 pairs/epoch,batch16,Adam1e-4,cosine100 horizon. Accuracy-first equal-cohort validation selection, regret/epoch tie breaks. Same XGBoost controls.',
            'scope': 'Matched two-arm small pilot, not a best-seed or report90 selection. No SQL or deployment. CPU34. Original attention importance excludes residual readout contribution; search impact remains untested.',
            'source_sha256': {str(p): sha(p) for p in [Path(__file__), SOURCE, Path(common.__file__),
                Path(__file__).with_name('report90_statistical_readout_model.py'), BASE / 'statistical_readout_smoke/RESULT.json']}})
    protocol = common.read(OUT / 'PROTOCOL.json')
    for p, digest in protocol['source_sha256'].items():
        assert sha(Path(p)) == digest
    if stage == 'pilot':
        assert common.read(OUT / 'STATUS.json')['status'] == 'smoke_verified'
    verified = {}
    for arm in protocol['arms']:
        folder = OUT / f'{stage}_{arm}'
        assert not folder.exists()
        replacement_import = ('from autodop.model import load_cost_model, save_checkpoint' if arm == 'original_readout' else
                              'from report90_statistical_readout_model import load_statistical_model as load_cost_model, save_statistical_checkpoint as save_checkpoint')
        changes = {
            repr(str(BASE / 'pair_calibration_pilot/pilot')): repr(str(folder)),
            repr(str(BASE / 'pair_calibration_pilot/PROTOCOL.json')): repr(str(OUT / 'PROTOCOL.json')),
            'from report90_interaction_model import load_interaction_model as load_cost_model,save_interaction_checkpoint as save_checkpoint': replacement_import,
            'os.sched_setaffinity(0,{35})': 'os.sched_setaffinity(0,{34})',
        }
        if stage == 'smoke':
            changes.update({'range(1,31)': 'range(1,3)', 'epoch%10==0': 'epoch%1==0', 'n_estimators=200': 'n_estimators=5'})
        text = SOURCE.read_text()
        audit = {}
        for old, new in changes.items():
            count = text.count(old)
            assert count == (2 if old in [repr(str(BASE / 'pair_calibration_pilot/PROTOCOL.json')), 'epoch%10==0'] else 1), (old, count)
            text = text.replace(old, new)
            audit[old] = {'replacement': new, 'occurrences': count}
        script = OUT / f'{stage}_{arm}_trainer.py'
        compile(text, str(script), 'exec')
        script.write_text(text)
        common.save(OUT / f'{stage}_{arm}_SOURCE_TRANSFORM.json', {'original_sha256': sha(SOURCE), 'generated_sha256': sha(script), 'changes': audit})
        common.save(OUT / 'STATUS.json', {'status': 'running', 'stage': stage, 'arm': arm, 'pid': os.getpid()})
        with (OUT / f'{stage}_{arm}.log').open('w') as stream:
            subprocess.run([sys.executable, str(script)], stdout=stream, stderr=subprocess.STDOUT, check=True)
        common.load_cost_model = load_cost_model if arm == 'original_readout' else load_statistical_model
        verified[arm] = common.replay(folder)
    if stage == 'pilot':
        common.save(OUT / 'RESULT.json', {'status': 'verified', 'arms': verified,
            'protocol_sha256': sha(OUT / 'PROTOCOL.json'),
            'statistical_improves_original': verified['statistical_readout']['transformer']['weighted_rank_accuracy'] > verified['original_readout']['transformer']['weighted_rank_accuracy']})
    common.save(OUT / 'STATUS.json', {'status': stage + '_verified'})
    print(stage, 'verified', {arm: models['transformer']['weighted_rank_accuracy'] for arm, models in verified.items()}, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['smoke', 'pilot'], required=True)
    args = parser.parse_args()
    try:
        main(args.stage)
    except BaseException as error:
        if OUT.exists():
            common.save(OUT / 'STATUS.json', {'status': 'failed', 'error': repr(error)})
        raise
