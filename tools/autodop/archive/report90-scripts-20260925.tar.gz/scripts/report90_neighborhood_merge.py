"""Aggregate exactly three formal observations without filtering configurations."""
import collections
import itertools
import json
from pathlib import Path
import statistics

from report90_neighborhood_prepare import OUT as BASE, sha


def placement(fragments):
    workers = [set(f['worker_ids']) for f in fragments]
    return [[len(a & b) / len(a | b) if a | b else 0.0 for b in workers] for a in workers]


def main():
    by_config = collections.defaultdict(list)
    sources = [Path(__file__)]
    for name, expected in [('collection', 64), ('repeat', 96)]:
        folder = BASE / name
        result = json.loads((folder / 'RESULT.json').read_text())
        assert result['status'] == 'verified' and result['executions'] == expected
        for p, digest in result['source_sha256'].items():
            assert sha(Path(p)) == digest
        path = folder / 'training_samples.jsonl'
        sources += [folder / 'RESULT.json', path]
        for line in path.open():
            sample = json.loads(line)
            assert sample['split'] == 'train' and sample['source_cohort'] == 'complex_new'
            by_config[(sample['template_id'], sample['plan_key'], sample['config_key'])].append(sample)
    assert len(by_config) == 32 and all(len(values) == 3 for values in by_config.values())
    out = BASE / 'verified_labels'
    assert not out.exists()
    out.mkdir()
    aggregated, evidence = [], []
    for key, values in sorted(by_config.items()):
        first = values[0]
        assert all(v['dop_config'] == first['dop_config'] and v['edges'] == first['edges'] for v in values)
        assert all(placement(v['fragments']) == placement(first['fragments']) for v in values), 'Worker overlap changed; do not merge'
        times = [v['latency_ms'] for v in values]
        median = statistics.median(times)
        aggregated.append({**first, 'latency_ms': median})
        evidence.append({'template_id': key[0], 'plan_key': key[1], 'config_key': key[2], 'latencies_ms': times,
                         'median_ms': median, 'relative_range': (max(times) - min(times)) / median})
    queries = collections.defaultdict(list)
    for entry in evidence:
        queries[entry['template_id']].append(entry)
    diagnostics = {}
    all_pairs = []
    for query, values in queries.items():
        assert len(values) == 8
        best = min(v['median_ms'] for v in values)
        counts = {'eligible_pairs': 0, 'both_within20pct': 0, 'same_sign_all3': 0, 'nonoverlapping_ranges': 0}
        for a, b in itertools.combinations(values, 2):
            fast, slow = sorted([a, b], key=lambda x: x['median_ms'])
            if slow['median_ms'] / fast['median_ms'] < 1.03:
                continue
            same_sign = all(x < y for x, y in zip(fast['latencies_ms'], slow['latencies_ms']))
            separated = max(fast['latencies_ms']) < min(slow['latencies_ms'])
            counts['eligible_pairs'] += 1
            counts['both_within20pct'] += slow['median_ms'] <= 1.2 * best
            counts['same_sign_all3'] += same_sign
            counts['nonoverlapping_ranges'] += separated
            all_pairs.append({'template_id': query, 'plan_key': fast['plan_key'], 'fast_config_key': fast['config_key'],
                              'slow_config_key': slow['config_key'], 'fast_latency_ms': fast['median_ms'],
                              'slow_latency_ms': slow['median_ms'], 'same_sign_all3': same_sign, 'nonoverlapping_ranges': separated})
        diagnostics[query] = counts
    for name, values in [('samples.jsonl', aggregated), ('sample_evidence.jsonl', evidence), ('pair_diagnostics.jsonl', all_pairs)]:
        (out / name).write_text(''.join(json.dumps(v, sort_keys=True) + '\n' for v in values))
    result = {'status': 'verified', 'queries': 4, 'configurations': 32, 'formal_observations': 96,
              'total_executions_including_warmup': 160, 'per_query': diagnostics,
              'median_relative_range': statistics.median(e['relative_range'] for e in evidence),
              'scope': 'Exactly3 formal observations per config, median latency labels; all32 configs retained. Roundwise ordering and range separation are descriptive reliability diagnostics, not statistical significance. No pairs discarded, no active dataset changed, no automatic fitting or expansion.',
              'source_sha256': {str(p): sha(p) for p in sources + [out / n for n in ['samples.jsonl', 'sample_evidence.jsonl', 'pair_diagnostics.jsonl']]}}
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
