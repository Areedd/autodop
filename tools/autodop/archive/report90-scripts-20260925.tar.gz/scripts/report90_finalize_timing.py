"""Finalize only after the original FE remains available in its foreground session."""
import json, os, sys, time, subprocess
from pathlib import Path
from report90_fe_timing import OUT,RUN,ROOT,JAR,sha,fe_pid,db_ready,save,state
import pymysql

def main():
 for _ in range(180):
  status=json.loads((OUT/'STATUS.json').read_text())
  if status['stage']=='failed':raise RuntimeError(status)
  if (OUT/'RESULT_PENDING.json').exists():break
  time.sleep(10)
 else:raise TimeoutError('No complete controller timing result')
 for _ in range(120):
  if db_ready():break
  time.sleep(2)
 else:raise TimeoutError('Original FE not ready')
 pid=fe_pid();launch=json.loads((OUT/'ORIGINAL_FE_LAUNCH.json').read_text());binary=json.loads((OUT/'BINARY_AUDIT.json').read_text())
 samples=[]
 for _ in range(7):
  assert fe_pid()==pid and db_ready()
  assert sha(JAR)==binary['original_sha256'] and sorted(os.sched_getaffinity(pid))==launch['affinity']
  samples.append({'monotonic':time.monotonic(),'pid':pid,'ready':True})
  if len(samples)<7:time.sleep(5)
 with pymysql.connect(host='127.0.0.1',port=9030,user='root',read_timeout=10) as c:
  with c.cursor() as q:
   q.execute("ADMIN SHOW FRONTEND CONFIG LIKE '%auto_dop%'")
   cols=[x[0].lower() for x in q.description];rows=[dict(zip(cols,r)) for r in q.fetchall()]
   settings={r['key']:str(r['value']) for r in rows}
 original=json.loads((RUN/'serial/scored/frontend_settings.json').read_text())['original']
 assert all(settings.get(k)==v for k,v in original.items()),str(settings)
 save('RESTORATION.json',{'restored':True,'binary_restored':True,'sha256':sha(JAR),'pid':pid,'foreground_service':True,
      'stable_observation_seconds':samples[-1]['monotonic']-samples[0]['monotonic'],'samples':samples,'frontend_settings':settings})
 result=json.loads((OUT/'RESULT_PENDING.json').read_text());result['status']='complete';save('RESULT.json',result)
 state('complete',restored_fe_pid=pid)
 subprocess.run([sys.executable,str(ROOT/'scripts/report90_summary.py')],check=True)
 print(json.dumps({'status':'complete','report':str(RUN/'FULL_REPORT.md'),'closeout':str(RUN/'CLOSEOUT.json')}))
if __name__=='__main__':main()
