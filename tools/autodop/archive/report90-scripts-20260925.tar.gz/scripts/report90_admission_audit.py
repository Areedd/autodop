"""Independent reservation accounting and timer checks for factorial prototype."""
import argparse
import hashlib
import json
from pathlib import Path
import statistics


def main(phase):
    root=Path(__file__).resolve().parents[1]
    out=root/f'runs/report90_20260912/development17_budget_{phase}'
    stage=out.with_name(out.name+'_support')
    read=lambda p:json.loads(p.read_text())
    assert read(out/'STATUS.json')['status']=='complete'
    assert read(out/'RESULT.json')['status']=='verified'
    spec=read(stage/'MEMORY_BUDGET.json')
    journal=[json.loads(s) for s in (out/'ADMISSION.jsonl').read_text().splitlines()]
    events=[json.loads(s) for s in (out/'scored/events.jsonl').read_text().splitlines()]
    tokens={};active={};used=0;peak=0
    for i,r in enumerate(journal):
        assert r['sequence']==i and r['capacity_bytes']==spec['capacity_bytes']
        token=r['token'];amount=r['bytes'];assert amount>0
        if r['action']=='reserve':
            assert token not in tokens and token not in active
            used+=amount;active[token]=r;tokens[token]={'reserve':r}
        else:
            assert r['action']=='release' and token in active
            previous=active.pop(token);assert amount==previous['bytes'] and r['monotonic']>=previous['monotonic']
            used-=amount;tokens[token]['release']=r
        assert used==r['used_bytes'] and 0<=used<=spec['capacity_bytes']
        peak=max(peak,used)
    assert used==0 and not active
    matched=set();waits={}
    for e in events:
        gate=e['mode'] in ['native_budget','policy_budget']
        assert ('admission' in e)==gate
        # Both native aliases must stay AutoDOP-disabled when they succeed.
        if e['status']=='verified':
            assert e['autodop_enabled']==(e['mode'] in ['policy_static','policy_budget'])
        if not gate:continue
        a=e['admission'];token=a['token'];assert token not in matched;matched.add(token)
        assert token=='|'.join(str(e[k]) for k in ('mode','clients','phase','round','client','sequence'))
        pair=tokens[token];reservation=spec['queries'][e['id']]
        assert reservation['sql_sha256']==e['sql_sha256']
        assert a['reservation_bytes']==pair['reserve']['bytes']==reservation['reservation_bytes']
        assert a['capacity_bytes']==spec['capacity_bytes']
        assert e['admission_timing_contract']=='wait_plus_all_attempts_and_retry_backoff_v1'
        assert e['admission_request_latency_ms']>=e['logical_request_latency_ms']+a['wait_ms']-.01
        for attempt in e['sql_attempts']:
            finish=attempt['sql_finished_monotonic'];start=finish-attempt['client_latency_ms']/1000
            assert pair['reserve']['monotonic']<=start+.001
            assert finish<=pair['release']['monotonic']+.001
        waits.setdefault((e['mode'],e['phase']),[]).append(a['wait_ms'])
    assert matched==tokens.keys()
    summaries=[dict(mode=k[0],phase=k[1],tasks=len(v),wait_over_1ms=sum(x>1 for x in v),
                    mean_wait_ms=statistics.mean(v),max_wait_ms=max(v)) for k,v in sorted(waits.items())]
    paths=[out/'ADMISSION.jsonl',out/'scored/events.jsonl',out/'RESULT.json',
           stage/'MEMORY_BUDGET.json',Path(__file__).resolve()]
    result=dict(status='verified',reservations=len(tokens),capacity_bytes=spec['capacity_bytes'],
                peak_reserved_bytes=peak,end_reserved_bytes=used,summaries=summaries,
                scope='Verifies experimental client accounting and waiting inclusion, not actual memory bounds, deployed FE admission, or prediction quality.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    destination=out/'ADMISSION_AUDIT.json';assert not destination.exists()
    destination.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['pilot','full'],required=True)
    main(p.parse_args().phase)
