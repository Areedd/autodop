"""Replay each completed readout pilot against the unchanged seven-model pair pool."""
import argparse
import json
from pathlib import Path
import runpy

from report90_interaction_pair_audit import BASE, sha


def main(arm):
    root = BASE / 'statistical_readout_pilot'
    folder = root / f'pilot_{arm}'
    assert json.loads((folder / 'SCORE_REPLAY.json').read_text())['status'] == 'verified'
    original = Path(__file__).with_name('report90_interaction_pair_audit.py')
    model_source = Path(__file__).with_name('report90_statistical_readout_model.py')
    text = original.read_text()
    loader = ('from autodop.model import load_cost_model' if arm == 'original_readout' else
              'from report90_statistical_readout_model import load_statistical_model as load_cost_model')
    changes = {
        "BASE = Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20'": 'BASE = Path(' + repr(str(BASE)) + ')',
        "BASE/f'interaction_ranking/seed{seed}'": 'Path(' + repr(str(folder)) + ')',
        "BASE/f'interaction_pair_audit_seed{seed}'": 'Path(' + repr(str(root / f'audit_{arm}')) + ')',
        'from report90_interaction_model import load_interaction_model as load_cost_model': loader,
        "Path(__file__).with_name('report90_interaction_model.py')": 'Path(' + repr(str(model_source)) + ')',
        'sources = [Path(__file__),': 'sources = [Path(__file__), Path(' + repr(str(original)) + '), Path(' + repr(str(Path(__file__))) + '),',
        'Interaction-augmented Transformer; unchanged flat controls.': f'{arm}:30-epoch seed17 pilot; unchanged full-budget flat controls. Not a three-seed or final superiority claim.',
    }
    for old, new in changes.items():
        assert text.count(old) == 1, old
        text = text.replace(old, new)
    generated = root / f'audit_{arm}_staged.py'
    assert not generated.exists()
    compile(text, str(generated), 'exec')
    generated.write_text(text)
    (root / f'audit_{arm}_TRANSFORM.json').write_text(json.dumps({'original_sha256': sha(original),
        'generated_sha256': sha(generated), 'wrapper_sha256': sha(Path(__file__)), 'changes': changes}, indent=2) + '\n')
    runpy.run_path(str(generated), run_name='readout_audit')['main'](17)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--arm', choices=['original_readout', 'statistical_readout'], required=True)
    main(parser.parse_args().arm)
