"""Re-measure every comparator for three changed plans; retain the failed original run."""
import argparse
import json
import subprocess
import sys
from pathlib import Path
from report90_execute import ROOT, RUN, SOURCE, check


def run(pilot):
    out = RUN / ('repair_pilot' if pilot else 'serial_repair')
    out.mkdir(exist_ok=False)
    check(out / 'IDLE.json')
    if not pilot:
        assert json.loads((RUN/'repair_pilot/scored/independent_verification.json').read_text())['all_expected_executions_verified']
    proto = json.loads((RUN/'PROTOCOL.json').read_text())
    modes = ['native','uniform1','uniform2','uniform4','uniform8','uniform16','policy_static','policy_before']
    modes += [m for m in json.loads((RUN/'repair_vectors.json').read_text()) if not m.startswith('audit_dop')]
    command = [sys.executable, str(ROOT/'collect_paper_evaluations.py'),
        '--manifest',str(RUN/'repair_manifest.json'),'--trusted-collection',str(SOURCE/'random200/trusted_merged.json'),
        '--output-dir',str(out/'scored'),'--policy-model',proto['model'],'--modes',','.join(modes),
        '--scenario','serial','--query-timeout-s','180','--auto-dop-max-dop','16','--torch-threads','1',
        '--decision-timeout-ms','1000','--warmup','1','--repetitions','1' if pilot else '3',
        '--seed',str(proto['seed']),'--decision-vectors',str(RUN/'repair_vectors.json'),
        '--policy-variants',str(RUN/'policy_variants.json')]
    (out/'COMMAND.json').write_text(json.dumps(command,indent=2)+'\n')
    subprocess.run(command,check=True)
    subprocess.run([sys.executable,str(ROOT/'scripts/verify_paper_evaluations.py'),
        '--collection-dir',str(out/'scored'),'--output',str(out/'scored/independent_verification.json')],check=True)
    assert json.loads((out/'scored/independent_verification.json').read_text())['all_expected_executions_verified']


if __name__ == '__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--pilot',action='store_true');run(parser.parse_args().pilot)
