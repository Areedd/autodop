"""Freeze novel complex development trees, then validate SQL against branch bag semantics."""
import argparse
from collections import Counter
from dataclasses import asdict
import datetime
import hashlib
import json
import os
from pathlib import Path
import random
import re
import sys
import time

from report90_execute import ROOT, RUN, check
from generate_composable_branch_suite import Node, compile_sql, evaluate, from_dict, leaves

SOURCE=ROOT/'runs/preference_random200_20260911'
OUT=RUN/'complex_development24'
SEED=2026091309
OPS=['inner','left','full','union']


def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
    p=OUT/name;tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2,default=str)+'\n');tmp.replace(p)


def canonical(n):
    if n.op=='leaf':return str(n.branch)
    children=[canonical(n.left),canonical(n.right)]
    if n.op in ('inner','full','union'):children.sort()
    return n.op+'('+','.join(children)+')'


def tree(rng,ids,root=None):
    if len(ids)==1:return Node('leaf',ids[0])
    cut=rng.randrange(1,len(ids))
    return Node(root or rng.choice(OPS),left=tree(rng,ids[:cut]),right=tree(rng,ids[cut:]))


def prepare():
    OUT.mkdir(exist_ok=False);(OUT/'sql').mkdir()
    banks=read(SOURCE/'banks.json');old=read(SOURCE/'random200/manifest.json')['queries']
    historical=Path(read(RUN/'PROTOCOL.json')['training_dataset'])/'samples.jsonl'
    historical_rows=[json.loads(l) for l in historical.open()]
    excluded_hashes={q['sql_sha256'] for q in old}|{q['sql_sha256'] for q in historical_rows}
    seen={canonical(from_dict(q['tree'])) for q in old}
    rng=random.Random(SEED);queries=[];strata=Counter()
    for split,counts in [('train',[3,3,4,4]),('valid',[4,4])]:
        for root in OPS:
            for count in counts:
                for attempt in range(10000):
                    n=tree(rng,rng.sample(range(5),count),root)
                    key=canonical(n);month=rng.choice(sorted(banks));body=compile_sql(n,banks[month])
                    digest=hashlib.sha256(body.encode()).hexdigest()
                    if key not in seen and digest not in excluded_hashes:break
                else:raise RuntimeError('No unused structure found')
                seen.add(key);excluded_hashes.add(digest)
                qid=f'complexdev_{split}_{len(queries):02d}_{root}_b{count}_m{month}'
                path=OUT/'sql'/f'{qid}.sql';path.write_text(body)
                ids=sorted(leaves(n));strata[(split,root,count)]+=1
                queries.append({'id':qid,'query_id':qid,'split':split,'database':'autodop_tpcds_sf100_paper_20260905',
                    'template_family':'complex_development_structure','tree':asdict(n),'tree_signature':key,
                    'branch_ids':ids,'branch_types':[banks[month][i]['family'] for i in ids],
                    'parameters':{'start_month':int(month),'months':3},'sql_file':str(path),'sql_sha256':digest,
                    'training_eligible':split=='train','evaluation_role':'training' if split=='train' else 'development_validation'})
    assert len(queries)==24 and len({q['sql_sha256'] for q in queries})==24
    assert len({q['tree_signature'] for q in queries})==24
    assert Counter(q['split'] for q in queries)=={'train':16,'valid':8}
    save('manifest.json',{'query_count':24,'queries':queries,'scope':'New development data; not an independent final test set. No composite latency filtering.'})
    sources=[Path(__file__),SOURCE/'banks.json',SOURCE/'random200/manifest.json',historical,
             ROOT/'generate_composable_branch_suite.py']
    save('PROTOCOL.json',{'status':'frozen_before_execution','frozen_at':datetime.datetime.now().astimezone().isoformat(),
        'seed':SEED,'queries':24,'train_queries':16,'valid_queries':8,
        'strata':{'/'.join(map(str,k)):v for k,v in strata.items()},
        'selection':'Random branch families and tree shapes, balanced root operators; train3/4 branches, valid4 branches. No branch or composite latency used for selection.',
        'separation':'Exact SQL distinct from all original200 and retained cost samples. Canonical binary tree signatures distinct from original200 and between new train/valid; commutative child swaps normalized, associativity not fully normalized.',
        'semantic_gate':'Execute source and materialized branch SQL, independently assemble bag results, compare native composite digest, record EXPLAIN. Preserve all failures, no query replacement.',
        'scope':'New validation avoids training on its labels, but shares tables and branch grammar. Existing90 used previously for diagnostics, not an untouched external test.',
        'manifest_sha256':sha(OUT/'manifest.json'),'source_sha256':{str(p):sha(p) for p in sources}})
    save('STATUS.json',{'status':'prepared','queries':24})
    print(json.dumps({'status':'prepared','queries':24,'splits':dict(Counter(q['split'] for q in queries))}),flush=True)


def validate():
    import pymysql
    from collect_trusted_dataset import result_digest
    assert read(OUT/'STATUS.json')['status']=='prepared'
    assert not (OUT/'SEMANTIC_AUDIT.json').exists(), 'Preserve previous validation'
    protocol=read(OUT/'PROTOCOL.json')
    assert sha(OUT/'manifest.json')==protocol['manifest_sha256']
    for name,expected in protocol['source_sha256'].items():assert sha(Path(name))==expected
    os.sched_setaffinity(0,set(range(27,35)))
    save('STATUS.json',{'status':'running','stage':'semantic_validation','pid':os.getpid()})
    for attempt in range(20):
        try:check(OUT/f'IDLE_{attempt}.json');break
        except RuntimeError:
            if attempt==19:raise
            time.sleep(15)
    from report90_cpu_observe import workers
    nodes=workers()
    assert all(n['image_id']=='sha256:73548ebadb50d11fec58e9937ebd5ee189205fd8f1acf8359fc63923132c476b' for n in nodes)
    save('DEPLOYMENT.json',nodes)
    queries=read(OUT/'manifest.json')['queries'];banks=read(SOURCE/'banks.json')
    audit={'status':'running','branches':[],'queries':[],'sql_executions':0}
    native=[];branch_rows={}
    with pymysql.connect(host='127.0.0.1',port=9030,user='root',database=queries[0]['database'],read_timeout=200,connect_timeout=5) as conn:
        with conn.cursor() as cur:
            for setting in ['enable_auto_dop=false','pipeline_dop=4','query_timeout=180','enable_profile=false',
                            'enable_spill=false','enable_query_cache=false','enable_runtime_adaptive_dop=false']:
                cur.execute('SET '+setting)
            for month in sorted({str(q['parameters']['start_month']) for q in queries}):
                branch_rows[month]=[]
                for branch in banks[month]:
                    cur.execute(branch['source_sql']);source_rows=cur.fetchall();audit['sql_executions']+=1
                    cur.execute(branch['sql']);rows=cur.fetchall();audit['sql_executions']+=1
                    assert result_digest(source_rows)==result_digest(rows),(month,branch['family'])
                    branch_rows[month].append(rows)
                    audit['branches'].append({'month':month,'family':branch['family'],'source_copy_equal':True,
                        'digest':result_digest(rows),'rows':len(rows)})
                    save('SEMANTIC_AUDIT.json',audit)
            for q in queries:
                body=Path(q['sql_file']).read_text();assert hashlib.sha256(body.encode()).hexdigest()==q['sql_sha256']
                cur.execute('EXPLAIN '+body);plan='\n'.join(str(x[0]) for x in cur.fetchall())
                cur.execute(body);actual=cur.fetchall();audit['sql_executions']+=1
                month=str(q['parameters']['start_month'])
                expected=evaluate(from_dict(q['tree']),banks[month],branch_rows[month])
                assert result_digest(actual)==result_digest(expected),q['id']
                digest=result_digest(actual)
                audit['queries'].append({'id':q['id'],'split':q['split'],'independent_assembly_equal':True,
                    'native_result_digest':digest,'result_rows':len(actual),'explain':plan,
                    'explain_fragment_count':len(re.findall(r'^PLAN FRAGMENT ',plan,re.MULTILINE))})
                native.append({'id':q['id'],'status':'accepted','database':q['database'],'sql_sha256':q['sql_sha256'],
                    'native_result_digest':digest,'provenance':'Independent branch bag assembly and actual native SQL, SEMANTIC_AUDIT.json; no configuration latency labels yet.'})
                save('SEMANTIC_AUDIT.json',audit)
                print(json.dumps({'verified_queries':len(audit['queries']),'total':24,'fragments':audit['queries'][-1]['explain_fragment_count']}),flush=True)
    audit['status']='verified';save('SEMANTIC_AUDIT.json',audit)
    save('TRUSTED_NATIVE.json',{'status':'finished','queries':native,'source_sha256':{'manifest.json':sha(OUT/'manifest.json'),'SEMANTIC_AUDIT.json':sha(OUT/'SEMANTIC_AUDIT.json')},
        'scope':'Native result identity only; not a measured cost training dataset.'})
    save('STATUS.json',{'status':'semantic_verified','queries':24,'sql_executions':audit['sql_executions'],
        'at':datetime.datetime.now().astimezone().isoformat()})


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['prepare','validate']);args=parser.parse_args()
    if args.stage=='prepare':prepare()
    else:
        try:validate()
        except BaseException as e:
            save('STATUS.json',{'status':'failed','stage':'semantic_validation','error':repr(e),'pid':os.getpid()});raise
