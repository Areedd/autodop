"""Freeze and smoke-test train-only XGBoost soft-pair distillation into CostModel."""
import json
from pathlib import Path
import subprocess
import sys
from autodop.training import file_sha256

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'runs/report90_20260912/structure_coverage20'
OUT = BASE/'xgb_distillation_pilot'


def main():
    OUT.mkdir(exist_ok=False)
    source = BASE/'hard_pair_ema_pilot/pilot_trainer.py'
    teacher = BASE/'retrained/xgboost_pairs_h1/model.ubj'
    protocol = dict(status='frozen_before_smoke',seed=17,smoke_epochs=2,pilot_epochs=30,
                    teacher=str(teacher),teacher_sha256=file_sha256(teacher),
                    loss='existing measured-label calibrated pair loss + 0.25*BCEWithLogits(student_gap, sigmoid(frozen_xgb_gap)); temperature 1',
                    design='Same warm multistage CostModel+competition, hard-pair mining every10epochs, EMA0.99, 624pairs/epoch, batch16, Adam1e-4, cosine100 horizon. No XGBoost needed at inference.',
                    data='Teacher fits existing1365train samples and6702training pairs; teacher targets evaluated on train only. Validation212 and report90 not used for targets or gradients.',
                    selection='Teacher depth6 follows existing development evidence, not a blind choice. Student selection macro pair accuracy, regret, earlier epoch, every10epochs. Reused validation.',
                    gate='After finite two-epoch smoke and exact replay, run30epoch pilot. Expand to3seeds only if exceeding matched hardEMA reference and all fixed baseline families.',
                    scope='Training-method change using a tree teacher, not isolated Transformer architecture superiority. Include teacher training cost. No SQL, no production replacement.',
                    source_sha256={str(p):file_sha256(p) for p in [Path(__file__),source,teacher,BASE/'merged_dataset/samples.jsonl',BASE/'merged_dataset/pairs.jsonl']})
    (OUT/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    for stage in ('smoke','pilot'):
        text = source.read_text()
        oldout = BASE/'hard_pair_ema_pilot/pilot'
        replacements = {
            repr(str(oldout)):repr(str(OUT/stage)),
            repr(str(BASE/'hard_pair_ema_pilot/PROTOCOL.json')):repr(str(OUT/'PROTOCOL.json')),
            '    candidates=[]': '''    import xgboost as xgb
    frozen_xgb=xgb.XGBRanker();frozen_xgb.load_model(read(OUT.parent/'PROTOCOL.json')['teacher'])
    teacher_values=frozen_xgb.predict(np.stack([flat[key(s)] for s in train]))
    soft_scores={key(s):float(v) for s,v in zip(train,teacher_values)}
    assert len(soft_scores)==len(train) and not set(soft_scores)&{key(s) for s in valid}
    save(OUT/'TEACHER_TARGETS.json',{'training_only':True,'rows':[{'plan_key':s['plan_key'],'config_key':s['config_key'],'score':soft_scores[key(s)]} for s in train]})
    candidates=[]''',
            'ranking.append(torch.nn.functional.softplus(target-a+b) + 0.1*torch.nn.functional.smooth_l1_loss(a-b,target))': '''teacher_gap=soft_scores[(plan,pair['fast_config_key'])]-soft_scores[(plan,pair['slow_config_key'])]
                    soft_target=torch.sigmoid(a.new_tensor(teacher_gap))
                    distillation=torch.nn.functional.binary_cross_entropy_with_logits(a-b,soft_target)
                    ranking.append(torch.nn.functional.softplus(target-a+b) + 0.1*torch.nn.functional.smooth_l1_loss(a-b,target) + 0.25*distillation)''',
            "{'purpose':'Verify unchanged gradient trajectory'}":"{'purpose':'Raw final model with soft-pair distillation; not expected to match previous trajectory'}",
        }
        if stage=='smoke':
            replacements.update({'range(1,31)':'range(1,3)','epoch%10==0':'epoch%1==0','n_estimators=200':'n_estimators=5'})
        changes = {}
        for old,new in replacements.items():
            count = text.count(old)
            assert count == (2 if old in (repr(str(BASE/'hard_pair_ema_pilot/PROTOCOL.json')),'epoch%10==0') else 1),(old,count)
            text = text.replace(old,new)
            changes[old] = dict(replacement=new,occurrences=count)
        path = OUT/f'{stage}_trainer.py'
        compile(text,str(path),'exec');path.write_text(text)
        (OUT/f'{stage}_TRANSFORM.json').write_text(json.dumps(dict(original_sha256=file_sha256(source),generated_sha256=file_sha256(path),changes=changes),indent=2)+'\n')
    (OUT/'STATUS.json').write_text(json.dumps(dict(status='running_smoke'))+'\n')
    with (OUT/'smoke.log').open('w') as stream:
        subprocess.run([sys.executable,str(OUT/'smoke_trainer.py')],stdout=stream,stderr=subprocess.STDOUT,check=True)
    import report90_coverage_stability as common
    scores = common.replay(OUT/'smoke')
    (OUT/'SMOKE_RESULT.json').write_text(json.dumps(dict(status='verified',scores=scores),indent=2)+'\n')
    (OUT/'STATUS.json').write_text(json.dumps(dict(status='smoke_complete_pilot_not_started'))+'\n')
    print(json.dumps(scores,indent=2))


if __name__=='__main__':main()
