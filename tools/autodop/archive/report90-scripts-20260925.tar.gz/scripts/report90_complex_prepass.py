"""Small native/policy pass for all24 development SQL after semantic validation."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from report90_execute import ROOT,RUN,check
from verify_paper_evaluations import request_plan_key

BASE=RUN/'complex_development24'
OUT=BASE/'prepass'


def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
    p=OUT/name;tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(p)


def main():
    OUT.mkdir(exist_ok=False)
    save('STATUS.json',{'status':'running','stage':'waiting_for_semantics','pid':os.getpid()})
    while True:
        state=read(BASE/'STATUS.json')
        if state['status']=='semantic_verified':break
        assert state['status']=='running' and state['stage']=='semantic_validation',state
        os.kill(state['pid'],0)
        assert b'report90_complex_development.py' in Path(f"/proc/{state['pid']}/cmdline").read_bytes()
        time.sleep(15)
    semantic=read(BASE/'SEMANTIC_AUDIT.json')
    assert semantic['status']=='verified' and len(semantic['queries'])==24
    model=read(RUN/'PROTOCOL.json');assert sha(Path(model['model']))==model['model_sha256']
    protocol={'frozen_at':datetime.datetime.now().astimezone().isoformat(),'queries':24,'modes':['native','policy_static'],
        'warmup':1,'repetitions':1,'expected_slots':96,'seed':2026091310,'manifest_sha256':sha(BASE/'manifest.json'),
        'purpose':'Verify native result and real policy trace for every newly generated development SQL before collecting configuration training labels.',
        'gate':'All96 executions independently verified; no replacement or latency-based filtering. No model training on validation labels.',
        'scope':'Discovery and correctness small pass only, not definitive ranking labels or report-query performance comparison.'}
    save('PROTOCOL.json',protocol)
    sources=[Path(__file__),ROOT/'collect_paper_evaluations.py',ROOT/'scripts/verify_paper_evaluations.py',
             BASE/'manifest.json',BASE/'TRUSTED_NATIVE.json',BASE/'SEMANTIC_AUDIT.json',Path(model['model'])]
    save('EXECUTION_SOURCE_SHA256.json',{str(p):sha(p) for p in sources})
    os.sched_setaffinity(0,set(range(27,35)))
    for attempt in range(20):
        try:check(OUT/f'IDLE_{attempt}.json');break
        except RuntimeError:
            if attempt==19:raise
            time.sleep(15)
    command=[sys.executable,str(ROOT/'collect_paper_evaluations.py'),'--manifest',str(BASE/'manifest.json'),
        '--trusted-collection',str(BASE/'TRUSTED_NATIVE.json'),'--output-dir',str(OUT/'scored'),
        '--policy-model',model['model'],'--modes','native,policy_static','--scenario','serial',
        '--warmup','1','--repetitions','1','--seed',str(protocol['seed']),'--query-timeout-s','180',
        '--auto-dop-max-dop','16','--torch-threads','1','--decision-timeout-ms','1000',
        '--metrics-urls','http://127.0.0.1:8040/metrics,http://127.0.0.1:8041/metrics,http://127.0.0.1:8042/metrics,http://127.0.0.1:8030/metrics']
    save('COMMAND.json',command);save('STATUS.json',{'status':'running','stage':'native_policy_small_pass','pid':os.getpid()})
    subprocess.run(command,check=True)
    proof_path=OUT/'scored/independent_verification.json'
    subprocess.run([sys.executable,str(ROOT/'scripts/verify_paper_evaluations.py'),'--collection-dir',str(OUT/'scored'),
                    '--output',str(proof_path)],check=True)
    proof=read(proof_path)
    assert proof['all_expected_executions_verified'] and proof['expected_slots']==96
    assert read(OUT/'scored/frontend_settings.json')['restored']
    requests={};seen={}
    decisions={d['query_id']:d for line in (OUT/'scored/decisions.jsonl').open() if (d:=json.loads(line))}
    for line in (OUT/'scored/events.jsonl').open():
        event=json.loads(line)
        if event['mode']!='policy_static':continue
        request=decisions[event['query_id']]['request'];key=request_plan_key(request);qid=event['id']
        seen.setdefault(qid,set())
        if key not in seen[qid]:
            seen[qid].add(key);requests.setdefault(qid,[]).append({'plan_key':key,'request':request})
    assert len(requests)==24
    save('REQUESTS.json',requests)
    sizes={q['id']:len(requests[q['id']][0]['request']['fragments']) for q in read(BASE/'manifest.json')['queries']}
    result={'status':'complete','verified_executions':96,'queries':24,'request_variants':sum(map(len,requests.values())),
            'fragment_counts':sizes,'verification_sha256':sha(proof_path),'scope':protocol['scope']}
    save('RESULT.json',result);save('STATUS.json',{'status':'complete','at':datetime.datetime.now().astimezone().isoformat()})
    print(json.dumps(result),flush=True)


if __name__=='__main__':
    if OUT.exists():raise SystemExit('Preserve previous prepass')
    try:main()
    except BaseException as e:
        if OUT.exists():save('STATUS.json',{'status':'failed','error':repr(e),'pid':os.getpid()})
        raise
