"""Bounded native V2 pilot, with original FE file/runtime configuration recovery."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

import report90_fe_timing as fe
from report90_execute import ROOT, RUN, check
from report90_queue_extension import connect

OUT = RUN / 'report90_native_budget_stable_restart'
CONF = ROOT.parents[1] / 'output/fe/conf/fe.conf'


def save(name, value):
    p = OUT / name
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2) + '\n')
    tmp.chmod(0o600)
    tmp.replace(p)


def configs():
    with connect() as c, c.cursor() as q:
        q.execute('ADMIN SHOW FRONTEND CONFIG')
        cols = [x[0].lower() for x in q.description]
        rows = [dict(zip(cols, r)) for r in q.fetchall()]
    return {r['key']: r for r in rows}


def restore_runtime():
    old = json.loads((OUT / 'RUNTIME_BEFORE.json').read_text())
    now = configs()
    changed = []
    with connect() as c, c.cursor() as q:
        for key, row in old.items():
            if str(row['ismutable']).lower() != 'true':
                continue
            if str(now[key]['value']) != str(row['value']):
                q.execute('ADMIN SET FRONTEND CONFIG (' + json.dumps(key) + ' = ' +
                          json.dumps(str(row['value'])) + ')')
                changed.append(key)
    final = configs()
    assert all(str(final[k]['value']) == str(r['value']) for k, r in old.items()
               if str(r['ismutable']).lower() == 'true')
    return changed


def verify_restoration():
    try:
        for _ in range(90):
            if fe.db_ready():
                break
            time.sleep(2)
        else:
            raise RuntimeError('Original FE readiness timeout')
        changed = restore_runtime()
        assert fe.sha(fe.JAR)=='fb2e974406e7291edd71df38d1826ac1610af043873e3ada93d9afeca8e53808'
        assert CONF.read_bytes() == (OUT / 'original-fe.conf').read_bytes()
        launch = json.loads((OUT / 'ORIGINAL_FE_LAUNCH.json').read_text())
        assert sorted(os.sched_getaffinity(fe.fe_pid())) == launch['affinity']
        assert str(configs()['enable_query_queue_v2']['value']).lower() == 'false'
        save('RESTORATION.json', dict(restored=True, pid=fe.fe_pid(), runtime_keys_restored=changed,
                                      configuration_sha256=fe.sha(CONF)))
        print('Original FE and runtime configuration restored', flush=True)
    except BaseException as error:
        save('RESTORATION.json', dict(restored=False, error=repr(error)))
        raise


def main():
    assert json.loads((RUN/'report90_native_budget_mixed_restart/RESTORATION.json').read_text())['restored']
    assert json.loads((RUN/'native_plan_stability_gate_probe/plans/RESULT.json').read_text())['status'] == 'stable'
    OUT.mkdir(exist_ok=False)
    save('STATUS.json', dict(stage='preflight', pid=os.getpid()))
    evaluation=json.loads((RUN/'report90_frozen_budget_evaluation/RESULT.json').read_text())
    assert evaluation['status']=='memory_evaluated' and evaluation['encoded_nominal_underestimates']==0
    assert all(not row['prediction']['saturated'] for row in evaluation['rows'])
    for schedule in ('swrr', 'fifo'):
        proof = json.loads((RUN/('report90_native_budget_journal_'+schedule)/'ALLOCATION_AUDIT.json').read_text())
        assert proof['status'] == 'verified'
    assert json.loads((RUN/'report90_native_budget_journal_fifo_wait_restart/RESTORATION.json').read_text())['restored']
    check(OUT / 'IDLE.json')
    current = RUN / 'native_predictor_service17/CURRENT_FE_LAUNCH.json'
    previous = json.loads(current.read_text())
    pid = fe.fe_pid()
    proc = Path('/proc')/str(pid)
    arguments = (proc/'cmdline').read_bytes().decode().strip('\0').split('\0')
    assert 'com.starrocks.StarRocksFE' in arguments
    assert (proc/'cwd').resolve() == ROOT.parents[1]
    environment = dict(part.split('=', 1) for part in (proc/'environ').read_bytes().decode().split('\0')
                       if '=' in part)
    launch = dict(pid=pid, executable=str((proc/'exe').resolve()), cwd=str((proc/'cwd').resolve()),
                  arguments=arguments, affinity=sorted(os.sched_getaffinity(pid)),
                  environment={key:environment[key] for key in previous['environment'] if key in environment},
                  config_sha256=fe.sha(CONF))
    assert fe.sha(fe.JAR) == 'fb2e974406e7291edd71df38d1826ac1610af043873e3ada93d9afeca8e53808'
    save('ORIGINAL_FE_LAUNCH.json', launch)
    shutil.copy2(CONF, OUT / 'original-fe.conf')
    (OUT / 'original-fe.conf').chmod(0o600)
    original = configs()
    assert str(original['enable_query_queue_v2']['value']).lower() == 'false'
    assert str(original['enable_query_cost_prediction']['value']).lower() == 'false'
    save('RUNTIME_BEFORE.json', original)
    save('PROTOCOL.json', dict(scope='256-query two-arm SWRR/FIFO pilot, same FE and append-only logging, each arm four DOP/budget modes; post-OOM calibrated fixed4; restore original FE and mutable runtime settings. No automatic expansion.',
         sources={str(p): fe.sha(p) for p in [Path(__file__), ROOT/'scripts/report90_native_report_stable_wait_pilot.py', ROOT/'scripts/report90_wait_for_idle.py', ROOT/'scripts/report90_native_report_stable_pilot.py', ROOT/'scripts/report90_native_report_stable_audit.py', ROOT/'scripts/report90_native_stable_control_audit.py', ROOT/'scripts/report90_plan_stability_gate.py']}))
    fe.OUT = OUT
    stopped = False
    try:
        fe.stop_fe()
        stopped = True
        CONF.write_bytes((OUT / 'original-fe.conf').read_bytes() + b'\nenable_query_queue_v2 = true\n')
        diagnostic_jar = RUN/'fifo_queue_validation/fifo-minimal-fe.jar'
        assert fe.sha(diagnostic_jar)==json.loads((diagnostic_jar.parent/'MINIMAL_BINARY_AUDIT.json').read_text())['fifo_sha256']
        tmp=fe.JAR.with_suffix('.queue-diagnostic-tmp');shutil.copy2(diagnostic_jar,tmp);tmp.replace(fe.JAR)
        fe.start_fe()
        restore_runtime()
        assert str(configs()['enable_query_queue_v2']['value']).lower() == 'true'
        save('STATUS.json', dict(stage='pilot', pid=os.getpid(), fe_pid=fe.fe_pid()))

        for schedule in ('SWRR', 'FIFO'):
            env = dict(os.environ, REPORT90_SCHEDULE=schedule)
            subprocess.run([sys.executable, str(ROOT/'scripts/report90_native_report_stable_wait_pilot.py')], check=True, env=env)
            subprocess.run([sys.executable, str(ROOT/'scripts/report90_native_report_stable_audit.py')], check=True, env=env)
        subprocess.run([sys.executable, str(ROOT/'scripts/report90_native_stable_control_audit.py')], check=True)
        save('STATUS.json', dict(stage='pilot_verified', pid=os.getpid()))
    except BaseException as error:
        save('STATUS.json', dict(stage='failed', error=repr(error), pid=os.getpid()))
    finally:
        if stopped:
            pid = fe.fe_pid()
            proc = Path(f'/proc/{pid}/stat')
            if proc.exists() and not proc.read_text().split(') ')[1].startswith('Z'):
                fe.stop_fe()
            original_jar=RUN/'fe_timing/original-starrocks-fe.jar'
            assert fe.sha(original_jar)=='fb2e974406e7291edd71df38d1826ac1610af043873e3ada93d9afeca8e53808'
            tmp=fe.JAR.with_suffix('.queue-restore-tmp');shutil.copy2(original_jar,tmp);tmp.replace(fe.JAR)
            CONF.write_bytes((OUT / 'original-fe.conf').read_bytes())
            save('RESTORATION.json', dict(restored=False, configuration_restored=True, stage='starting_original'))
            # The restored FE remains this tool session's foreground process.
            # A child waits for readiness, restores mutable settings and writes proof.
            subprocess.Popen([sys.executable, str(Path(__file__)), '--verify-restoration'])
            fe.foreground_original_fe()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify-restoration', action='store_true')
    args = parser.parse_args()
    if args.verify_restoration:
        verify_restoration()
    else:
        main()
