"""Check shadow predictions against frozen models and unchanged sentinel response."""
from pathlib import Path
import hashlib,json
import numpy as np
from report90_native_duration_predictor import DurationPredictor

BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/matched_development_duration'

def main():
    out=BASE/'shadow/pilot';source=out/'RESULT.json';r=json.loads(source.read_text());assert r['status']=='verified' and r['queries']==4
    for p,h in r['source_sha256'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
    assert json.loads((out/'frontend_settings.json').read_text())['restored']
    rows=r['executions'];assert len(rows)==8
    selection=BASE/'shadow/SELECTION.json';ids=set(json.loads(selection.read_text())['query_ids']);assert {e['id'] for e in rows}==ids
    assert len({e['query_id'] for e in rows})==8
    models=BASE/'models/RESULT.json';proof=json.loads(models.read_text());sources=[Path(__file__),source,selection,models,out/'frontend_settings.json']
    for name in ['ridge_log','extra_trees_log']:
        path=BASE/'models'/(name+'.joblib');sources.append(path)
        adapter=DurationPredictor.load(path,rows[0]['feature_record']['header'],proof['source_sha256'][str(path)])
        for e in rows:
            c=e['feature_record'];prediction=adapter.predict_csv(c['csv'])
            assert prediction==c['shadow_predictions_ms'][name]
            assert '|PredictMemBytes='+str(e['sentinel_bytes'])+'|' in e['audit_line']
    assert all({e['phase'] for e in rows if e['id']==i}=={'warmup','measured'} for i in ids)
    ms=[e['feature_record']['shadow_ns']/1e6 for e in rows]
    result=dict(status='verified_shadow',queries=4,executions=8,frozen_models_replayed=True,restored=True,
                combined_prediction_mean_ms=float(np.mean(ms)),combined_prediction_p99_ms=float(np.quantile(ms,.99)),
                scope='Two frozen native duration models ran in the live callback but neither prediction changed DOP, sentinel memory return or admission. Four previously used development validation queries, not independent accuracy or scheduling performance evidence. Combined timing covers model adapters, excludes HTTP and FE feature creation.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    (out/'SHADOW_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'},indent=2))

if __name__=='__main__':main()
