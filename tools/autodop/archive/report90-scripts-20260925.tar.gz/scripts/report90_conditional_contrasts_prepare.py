"""Freeze training-only conditional contrasts after observing the dominant low-DOP group."""
import json
from pathlib import Path
from autodop.data import supported_dops
from autodop.graph import sample_from_request
from collect_paper_evaluations import VectorEngine
from report90_neighborhood_prepare import RUN,sha

OUT=RUN/'training_conditional_contrasts'

def main():
    assert not OUT.exists();prior=RUN/'training_contrasts_pilot_v2';summary=json.loads((prior/'SUMMARY.json').read_text());assert summary['status']=='verified_controlled_contrast_summary'
    for path,digest in summary['source_sha256'].items():assert sha(Path(path))==digest
    manifest=json.loads((prior/'manifest.json').read_text());old=json.loads((prior/'PROPOSALS.json').read_text());previous=json.loads((prior/'vectors.json').read_text())
    modes=['anchor_low']+[f'group{i}_{side}' for i in [1,2,3] for side in ['low','high']];vectors={m:{} for m in modes};proposals={}
    for q in manifest['queries']:
        qid=q['id'];effect=summary['queries'][qid]['contrasts'][0]
        assert effect['high_vs_low_reduction_percent']<0 and effect['both_phase_gap_ge3pct'] and effect['same_order_in_both_phases']
        base=previous['group0_low'][qid];sample=sample_from_request(base['request']);ids=sample['fragment_ids'];anchor=[base['fragment_dops'][fid] for fid in ids];domains=[supported_dops(f,[1,2,4,8,16]) for f in sample['fragments']]
        groups=old[qid]['selected_groups'];fixed=set(groups[0]['indices']);assert all(anchor[i]==groups[0]['low'] for i in fixed)
        proposals[qid]={'training_plan_key':old[qid]['training_plan_key'],'fixed_group':groups[0],'selected_groups':groups[1:],'configs':[]}
        for mode in modes:
            dop=list(anchor);change=None
            if mode!='anchor_low':
                token,side=mode.split('_');index=int(token[5:]);group=groups[index];assert fixed.isdisjoint(group['indices'])
                for i in group['indices']:dop[i]=group[side]
                assert {i for i,(a,b) in enumerate(zip(dop,anchor)) if a!=b}==set(group['indices'])
                change={'group':group['indices'],'action':group[side]}
            assert all(d in domain for d,domain in zip(dop,domains));assert all(d==1 for d,f in zip(dop,sample['fragments']) if f.get('is_gather_root',False))
            vector={'request':base['request'],'fragment_dops':dict(zip(ids,dop))};VectorEngine({qid:vector}).decide(base['request']);vectors[mode][qid]=vector
            proposals[qid]['configs'].append({'mode':mode,'dop_config':dop,'change':change})
        assert len({tuple(x['dop_config']) for x in proposals[qid]['configs']})==7
    OUT.mkdir()
    def save(name,v):(OUT/name).write_text(json.dumps(v,indent=2)+'\n')
    save('manifest.json',manifest);save('vectors.json',vectors);save('PROPOSALS.json',proposals)
    save('PROTOCOL.json',{'status':'frozen_before_measurement','queries':sorted(proposals),'modes':modes,'warmup':1,'repetitions':1,'expected_executions':56,
        'design':'For the same four training queries, fix previous group0 atDOP1 because all four training contrasts showed same-direction low-DOP preference. Remeasure anchor; independently contrast each remaining group1/2/3 at legalDOP1/16. Other groups fixed. Same groups retained, no timing-based re-selection of groups or queries.',
        'scope':'Adaptive training-data acquisition, not validation/test selection.28configurations, one warmup and one formal each; no training or active-dataset mutation. Prior observations not mixed into this batch labels. Tests whether low-DOP group context masked other group effects; no guaranteed improvement.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),prior/'SUMMARY.json',prior/'manifest.json',prior/'PROPOSALS.json',prior/'vectors.json',prior/'PROTOCOL.json']}})
    save('STATUS.json',{'status':'prepared','queries':4,'configs':28});print('Frozen28conditional configurations,56executions.')

if __name__=='__main__':main()
