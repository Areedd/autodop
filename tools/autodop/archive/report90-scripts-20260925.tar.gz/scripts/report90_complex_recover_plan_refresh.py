"""One diagnostic recovery per excluded query; reconcile complete verified label shards."""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from report90_execute import ROOT,RUN,check
from autodop.data import _hash,load_dataset

BASE=RUN/'complex_development24'
ORIGINAL=BASE/'labels/collection'
OUT=BASE/'recovery_plan_refresh'


def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return [json.loads(l) for l in p.open()]
def save(name,value):
    p=OUT/name;tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(p)


def build_verify(collection,manifest,dataset):
    subprocess.run([sys.executable,str(ROOT/'scripts/build_trusted_dataset.py'),
        '--input',str(collection/'measured/accepted.jsonl'),'--manifest',str(manifest),
        '--collection',str(collection/'collection.json'),'--output',str(dataset)],check=True)
    subprocess.run([sys.executable,str(ROOT/'scripts/verify_paper_dataset.py'),'--collection-dir',str(collection),
        '--dataset-dir',str(dataset),'--output',str(dataset/'verification.json')],check=True)
    assert read(dataset/'verification.json')['status']=='verified'


def main():
    assert read(BASE/'recovery/PLAN_DRIFT_DIAGNOSIS.json')['status']=='diagnosed_actual_topology_change'
    assert read(BASE/'recovery/STATUS.json')['status']=='failed'
    OUT.mkdir(exist_ok=False)
    save('STATUS.json',{'status':'running','stage':'waiting_for_original','pid':os.getpid()})
    os.sched_setaffinity(0,set(range(27,35)))
    while True:
        state=read(BASE/'labels/STATUS.json')
        pid=state.get('pid')
        alive=False
        if pid:
            try:alive=b'report90_complex_collect.py' in Path(f'/proc/{pid}/cmdline').read_bytes()
            except FileNotFoundError:pass
        if not alive:
            break
        assert state['status'] in ['running','failed'],state
        time.sleep(15)
    original=read(ORIGINAL/'collection.json')
    assert original['status']=='finished' and len(original['queries'])==24
    assert read(ORIGINAL/'frontend_settings.json')['restored']
    selected=read(BASE/'manifest.json')['queries'];by_id={q['id']:q for q in selected}
    failed=[q for q in original['queries'] if q['status']=='excluded']
    assert all(q['status'] in ('accepted','excluded') for q in original['queries'])
    preparation=read(BASE/'diagnostic_support/PREPARATION.json')
    for name,expected in preparation['source_sha256'].items():assert sha(Path(name))==expected
    protocol={'frozen_at':datetime.datetime.now().astimezone().isoformat(),'failed_queries':[q['id'] for q in failed],
        'recovery_limit':'One complete diagnostic batch per excluded query; do not rerun original accepted queries or repeat until success.',
        'configuration_contract':'Regenerate five uniform and three random heterogeneous configurations from each fresh probe using original balanced design and original query seed. Preserve strict within-batch raw plan identity; no latency-based selection.',
        'gate':'All original accepted queries and recovered queries independently reconciled. Complete per-query batches only; preserve failed original attempts.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),BASE/'manifest.json',ORIGINAL/'collection.json',BASE/'diagnostic_support/collector.py']}}
    save('PROTOCOL.json',protocol)
    save('ORIGINAL_RUNNER_STATUS.json',state)
    build_verify(ORIGINAL,BASE/'manifest.json',OUT/'original_dataset')
    datasets=[OUT/'original_dataset']
    events=rows(ORIGINAL/'provenance/executions.jsonl')
    probe_ids={e['id']:e['query_id'] for e in events if e['phase']=='probe' and e['status']=='verified'}
    raw={t['query_id']:t for p in (ORIGINAL/'raw').glob('*.jsonl') for t in rows(p) if t['query_id'] in set(probe_ids.values())}
    for position,q in enumerate(failed):
        assert len(q['configs'])==8 and q.get('plan_key'), 'Need a separate probe diagnosis before freezing missing configurations'
        folder=OUT/f'query_{position:02d}';folder.mkdir()
        request=raw[probe_ids[q['id']]]['request']
        vectors=[{str(f['fragment_index']):config[str(f['fragment_id'])] for f in request['fragments']} for config in q['configs']]
        manifest={'query_count':1,'queries':[by_id[q['id']]]}
        (folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
        (folder/'original_incompatible_configurations.json').write_text(json.dumps({q['id']:vectors},indent=2)+'\n')
        save('STATUS.json',{'status':'running','stage':'diagnostic_recovery','query':q['id'],'pid':os.getpid()})
        for attempt in range(20):
            try:check(folder/f'IDLE_{attempt}.json');break
            except RuntimeError:
                if attempt==19:raise
                time.sleep(15)
        command=[sys.executable,str(BASE/'diagnostic_support/collector.py'),'--manifest',str(folder/'manifest.json'),
            '--output-dir',str(folder/'collection'),
            '--configs','8','--config-design','balanced','--dops','1,2,4,8,16','--audit',original['settings']['audit'],
            '--probe-timeout-s','180','--query-timeout-s','180','--warmup','1','--repetitions','3',
            '--seed',str(2026091311+next(i for i,v in enumerate(selected) if v['id']==q['id']))]
        (folder/'COMMAND.json').write_text(json.dumps(command,indent=2)+'\n')
        subprocess.run(command,check=True)
        recovered=read(folder/'collection/collection.json')
        assert recovered['status']=='finished' and len(recovered['queries'])==1
        result=recovered['queries'][0]
        assert result['status']=='accepted', 'Diagnostic failure retained; inspect request journal instead of retrying automatically'
        assert all(result[k]==q[k] for k in ['sql_sha256','database','split','native_result_digest'])
        build_verify(folder/'collection',folder/'manifest.json',folder/'dataset')
        datasets.append(folder/'dataset')
    samples=[];pairs=[];evidence=[];assignments={}
    for dataset in datasets:
        current=rows(dataset/'all/samples.jsonl')
        for qid in {s['template_id'] for s in current}:
            assert qid not in assignments, 'Never mix batches from the same SQL'
            assignments[qid]=str(dataset)
        samples+=current;pairs+=rows(dataset/'all/pairs.jsonl');evidence+=rows(dataset/'sample_evidence.jsonl')
    assert set(assignments)==set(by_id)
    assert len(samples)==192 and set(collections.Counter(s['template_id'] for s in samples).values())=={8}
    assert collections.Counter(s['split'] for s in samples)=={'train':128,'valid':64}
    assert len({(s['plan_key'],s['config_key']) for s in samples})==192
    plan_split={s['plan_key']:s['split'] for s in samples}
    assert all(plan_split[s['plan_key']]==s['split'] for s in samples)
    semantic={q['id']:q['native_result_digest'] for q in read(BASE/'SEMANTIC_AUDIT.json')['queries']}
    for dataset in datasets:
        collection=ORIGINAL if dataset==OUT/'original_dataset' else dataset.parent/'collection'
        assert all(q['native_result_digest']==semantic[q['id']] for q in read(collection/'collection.json')['queries'] if q['status']=='accepted')
    raw_plan=lambda s:_hash({'fragments':[{k:v for k,v in f.items() if k!='worker_ids'} for f in s['fragments']], 'edges':s['edges']})
    raw_train={raw_plan(s) for s in samples if s['split']=='train'}
    raw_valid={raw_plan(s) for s in samples if s['split']=='valid'}
    historical,_,_=load_dataset(Path(read(RUN/'PROTOCOL.json')['training_dataset']))
    assert not raw_train&raw_valid and not raw_valid&{raw_plan(s) for s in historical}, 'Raw graph overlap invalidates held-out development boundary'
    combined=BASE/'verified_labels';combined.mkdir(exist_ok=False)
    (combined/'metadata.json').write_text((BASE/'warmstart/METADATA.json').read_text())
    for name,values in [('samples.jsonl',samples),('pairs.jsonl',pairs),('sample_evidence.jsonl',evidence)]:
        (combined/name).write_text(''.join(json.dumps(v,sort_keys=True)+'\n' for v in values))
    (combined/'model_split.json').write_text(json.dumps({split:sorted({s['plan_key'] for s in samples if s['split']==split}) for split in ['train','valid','test']},indent=2)+'\n')
    audit={'status':'complete','queries':24,'samples':192,'train_samples':128,'valid_samples':64,
        'pairs':len(pairs),'raw_train_valid_overlap':0,'raw_valid_historical_overlap':0,'metadata_source':str(BASE/'warmstart/METADATA.json'),'plan_refresh_diagnosis':str(BASE/'recovery/PLAN_DRIFT_DIAGNOSIS.json'),'assignments':assignments,'original_exclusions':[q['id'] for q in failed],
        'failure_scope':'Original exclusions retained separately. Recovered complete batches replace only excluded queries, never blend observations or select faster results.',
        'source_sha256':{str(p):sha(p) for d in datasets for p in [d/'verification.json',d/'all/samples.jsonl',d/'all/pairs.jsonl',d/'sample_evidence.jsonl']}}
    (combined/'ASSEMBLY_AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
    save('RESULT.json',audit);save('STATUS.json',{'status':'complete','at':datetime.datetime.now().astimezone().isoformat()})


if __name__=='__main__':
    if OUT.exists():raise SystemExit('Preserve existing recovery')
    try:main()
    except BaseException as e:
        if OUT.exists():save('STATUS.json',{'status':'failed','error':repr(e),'pid':os.getpid()})
        raise
