"""Audit feature/configuration coverage and associate it with existing development errors."""
import collections
import json
from pathlib import Path
import re
import statistics
import numpy as np
from report90_interaction_pair_audit import BASE,sha
from autodop.data import transformed_numeric

OUT=BASE/'training_coverage_audit'

def summary(values):
    return {'minimum':min(values),'median':statistics.median(values),'maximum':max(values)}

def main():
    assert not OUT.exists()
    dataset=BASE/'merged_dataset';samples=[json.loads(x) for x in (dataset/'samples.jsonl').read_text().splitlines()]
    meta=json.loads((dataset/'metadata.json').read_text());grouped=collections.defaultdict(list)
    for s in samples:grouped[s['plan_key']].append(s)
    plans={k:sorted(v,key=lambda s:s['config_key'])[0] for k,v in grouped.items()}
    assert all(len({(s['split'],s['source_cohort'],s['sql_sha256']) for s in v})==1 for v in grouped.values())
    train=[s for s in plans.values() if s['split']=='train'];valid=[s for s in plans.values() if s['split']=='valid']
    report=json.loads((BASE.parent/'manifest.json').read_text());protected={q['sql_sha256'] for q in report['queries']}
    assert not protected&{s['sql_sha256'] for s in samples}
    cohorts={};numeric={};category={}
    for c in ['historical','complex_new']:
        tr=[s for s in train if s['source_cohort']==c];va=[s for s in valid if s['source_cohort']==c]
        assert tr and va
        cohorts[c]={}
        for split,ss in [('train',tr),('valid',va)]:
            configs=[s for p in ss for s in grouped[p['plan_key']]]
            cohorts[c][split]={'plans':len(ss),'configurations':len(configs),'configurations_per_plan':summary([len(grouped[s['plan_key']]) for s in ss]),
                'fragment_counts':summary([len(s['fragments']) for s in ss]),
                'dop_counts':dict(sorted(collections.Counter(d for s in configs for d in s['dop_config']).items())),
                'heterogeneous_configurations':sum(len(set(s['dop_config']))>1 for s in configs),
                'template_families':dict(collections.Counter(s['template_family'] for s in ss))}
        numeric[c]={};category[c]={}
        training_matrix=np.array([transformed_numeric(f) for s in tr for f in s['fragments']]);validation_matrix=np.array([transformed_numeric(f) for s in va for f in s['fragments']])
        for i,name in enumerate(meta['numeric_features']):
            lo,hi=training_matrix[:,i].min(),training_matrix[:,i].max()
            numeric[c][name]={'train_log1p_min':float(lo),'train_log1p_max':float(hi),'valid_fragments_outside_range':int(((validation_matrix[:,i]<lo)|(validation_matrix[:,i]>hi)).sum()),'valid_fragments':len(validation_matrix)}
        for feature in meta['category_features']:
            seen={str(f.get(feature,'')) for s in tr for f in s['fragments']}
            values=[str(f.get(feature,'')) for s in va for f in s['fragments']]
            category[c][feature]={'unseen_in_same_cohort_training':sum(x not in seen for x in values),'unknown_to_model_vocabulary':sum(x not in meta['category_vocab'][feature] for x in values),'valid_fragments':len(values),'unseen_values':sorted(set(values)-seen)}
    audit_paths=[BASE/'hard_pair_ema_pilot/pair_audit/RESULT.json']+[BASE/f'hard_pair_ema_stability/pair_audit_seed{s}/RESULT.json' for s in [29,43]]
    audits=[json.loads(p.read_text()) for p in audit_paths];pools=[json.loads(p.with_name('PAIR_POOL.json').read_text()) for p in audit_paths];assert pools[0]==pools[1]==pools[2]
    for audit in audits:
        assert audit['status']=='verified_independent_pair_replay'
        for path,digest in audit['source_sha256'].items():assert sha(Path(path))==digest
    pairs=pools[0]['pairs'];errors=[]
    for key in sorted({p['plan_key'] for p in pairs}):
        pp=[p for p in pairs if p['plan_key']==key];s=plans[key]
        accuracies={}
        for kind in ['transformer','xgboost_pairs']:
            accuracies[kind]=sum(sum(a['models'][kind]['scores'][p['fast_index']]>a['models'][kind]['scores'][p['slow_index']] for p in pp)/len(pp) for a in audits)/3
        match=re.search(r'_(inner|left|full|union)_',s['template_id'])
        errors.append({'plan_key':key,'template_id':s['template_id'],'cohort':s['source_cohort'],'template_family':s['template_family'],'root_family':match.group(1) if match else None,'fragments':len(s['fragments']),'validation_pairs':len(pp),'model_accuracy':accuracies,'transformer_minus_xgb_pp':100*(accuracies['transformer']-accuracies['xgboost_pairs'])})
    sources=[Path(__file__),dataset/'samples.jsonl',dataset/'metadata.json',BASE.parent/'manifest.json',*audit_paths,*[p.with_name('PAIR_POOL.json') for p in audit_paths]]
    result={'status':'verified_coverage_and_error_audit','cohorts':cohorts,'numeric_ranges':numeric,'categorical_coverage':category,'validation_plan_errors':errors,'report90_sql_overlap':0,
        'scope':'Read-only development diagnostic; all22 validation plans retained. Static fragment features use lexicographically first configuration per plan; configuration/DOP coverage uses all configurations. Range and category coverage do not prove distributional equivalence or a cause of ranking errors. Historical within-batch pair labels unchanged. No training, newSQL or report90 model selection.',
        'source_sha256':{str(p):sha(p) for p in sources}}
    OUT.mkdir();(OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 训练覆盖与验证错误核对','',result['scope'],'','| 数据组 | 划分 | 计划数 | 配置数 | 每计划配置中位数 | fragment范围 | 异构配置数 |','|---|---|---:|---:|---:|---:|---:|']
    for c,parts in cohorts.items():
        for split,v in parts.items():
            f=v['fragment_counts'];lines.append(f"| {c} | {split} | {v['plans']} | {v['configurations']} | {v['configurations_per_plan']['median']} | {f['minimum']}–{f['maximum']} | {v['heterogeneous_configurations']} |")
    lines+=['','| 验证查询 | 有效对数 | Transformer三种子均值 | XGBoost排序 | 差值（百分点） |','|---|---:|---:|---:|---:|']
    for row in errors:lines.append(f"| {row['template_id']} | {row['validation_pairs']} | {100*row['model_accuracy']['transformer']:.3f}% | {100*row['model_accuracy']['xgboost_pairs']:.3f}% | {row['transformer_minus_xgb_pp']:.3f} |")
    lines+=['','数值范围外和未见类别的明细保留在RESULT.json；这些是关联诊断，不是因果或性能达标证据。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'cohorts':cohorts,'complex_errors':[e for e in errors if e['cohort']=='complex_new']},indent=2))

if __name__=='__main__':main()
