"""Build the minimal FIFO intervention on the checkpoint-isolated FE."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

RUN = Path(__file__).resolve().parents[1]/'runs/report90_20260912'

def main():
    out = RUN/'fifo_queue_validation'
    base = RUN/'checkpoint_variable_regression/fixed-fe.jar'
    assert hashlib.sha256(base.read_bytes()).hexdigest() == json.loads((base.parent/'BINARY_AUDIT.json').read_text())['fixed_sha256']
    dest = out/'fifo-minimal-fe.jar'
    prefix = 'com/starrocks/qe/scheduler/slot/'
    names = [prefix+n for n in ['QueryQueueOptions$SchedulePolicy.class', 'SlotSelectionStrategyV2.class', 'FifoSlotQueue.class']]
    updates = {name:(out/'classes'/name).read_bytes() for name in names}
    with zipfile.ZipFile(base) as src, zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED) as dst:
        for info in src.infolist():
            dst.writestr(info, updates.get(info.filename, src.read(info.filename)))
        for name,data in updates.items():
            if name not in src.namelist():
                dst.writestr(name,data)
    with zipfile.ZipFile(base) as a, zipfile.ZipFile(dest) as b:
        changed = [n for n in a.namelist() if a.read(n)!=b.read(n)]
        added = sorted(set(b.namelist())-set(a.namelist()))
        assert set(changed+added) == set(names)
    cmd = json.loads((out/'JAR_JUNIT_COMMAND.json').read_text())
    i = cmd.index('-cp')+1
    cmd[i] = cmd[i].replace(str(out/'fifo-fe.jar'), str(dest))
    (out/'MINIMAL_JUNIT_COMMAND.json').write_text(json.dumps(cmd,indent=2)+'\n')
    p = subprocess.run(cmd,capture_output=True,text=True)
    (out/'MINIMAL_JUNIT.log').write_text(p.stdout+p.stderr)
    result = dict(status='verified_not_deployed' if p.returncode==0 else 'failed',
                  base_sha256=hashlib.sha256(base.read_bytes()).hexdigest(),
                  fifo_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),
                  changed_classes=changed, added_classes=added,
                  test_exit_code=p.returncode, checkpoint_fix_preserved=True,
                  swrr_class_bytes_unchanged=True, performance_tested=False)
    (out/'MINIMAL_BINARY_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if p.returncode:
        print((p.stdout+p.stderr)[-6000:])
        raise SystemExit(p.returncode)

if __name__ == '__main__':
    main()
