"""Replay frozen CSV inputs and measure adapter CPU cost; no database queries."""
from pathlib import Path
import csv,io,hashlib,json,time
import numpy as np
from report90_native_duration_predictor import DurationPredictor
from report90_train_matched_duration import predict

BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/matched_development_duration'

def main():
    out=BASE/'adapter_audit';out.mkdir(exist_ok=False)
    data_path=BASE/'full/RESULT.json';rows=json.loads(data_path.read_text())['executions'];header=rows[0]['feature_record']['header']
    model_result=BASE/'models/RESULT.json';proof=json.loads(model_result.read_text())
    for name,h in proof['source_sha256'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h
    sources=[Path(__file__),Path(__file__).with_name('report90_native_duration_predictor.py'),data_path,model_result]
    summaries={}
    for name in ['ridge_log','extra_trees_log']:
        assert proof['summary'][name]['screen_passed']
        path=BASE/'models'/(name+'.joblib');sources.append(path)
        adapter=DurationPredictor.load(path,header,hashlib.sha256(path.read_bytes()).hexdigest())
        x=np.array([[r['feature_record']['values'][i] for i in adapter.indices] for r in rows],dtype=float)
        expected=predict(adapter.bundle,x)
        adapter.predict_csv(rows[0]['feature_record']['csv'])
        timings=[];observed=[]
        for r in rows:
            start=time.perf_counter_ns();observed.append(adapter.predict_csv(r['feature_record']['csv']));timings.append((time.perf_counter_ns()-start)/1e6)
        np.testing.assert_allclose(observed,expected,rtol=1e-12,atol=1e-9)
        valid=[value for r,value in zip(rows,observed) if r['split']=='valid']
        np.testing.assert_allclose(valid,proof['predictions'][name],rtol=1e-12,atol=1e-9)
        values=list(rows[0]['feature_record']['values'])
        encode=lambda h,v:','.join(h)+'\n'+','.join(map(str,v))+'\n'
        changed=list(values)
        for key in ['tables_0','tables_1','tables_2']:changed[header.index(key)]+=1000000
        assert adapter.predict_csv(encode(header,changed))==observed[0]
        rejected=[]
        for case,body in [('wrong_header',encode(list(reversed(header)),values)),('missing_row',','.join(header)),('extra_row',encode(header,values)+','.join(map(str,values))+'\n')]:
            try:adapter.predict_csv(body)
            except ValueError:rejected.append(case)
            else:raise AssertionError(case)
        for key,value in [('var_0',4),('env_1',16)]:
            changed=list(values);changed[header.index(key)]=value
            try:adapter.predict_csv(encode(header,changed))
            except ValueError:rejected.append(key)
            else:raise AssertionError(key)
        summaries[name]=dict(replayed=len(rows),mean_ms=float(np.mean(timings)),p50_ms=float(np.median(timings)),p99_ms=float(np.quantile(timings,.99)),identity_invariant=True,rejected_cases=rejected,predictions=observed,timings_ms=timings)
    result=dict(status='verified_offline',summary=summaries,
                scope='122 stored inputs per model, one untimed warm call. Scalar adapter and saved batch predictions agree within 1e-12 relative/1e-9 ms absolute tolerance. Timing includes CSV parsing, validation, transform and model inference, excludes HTTP, FE feature creation, locks and logging. Replay is not independent accuracy or SQL performance evidence.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 原生时长预测适配与成本核验','',result['scope'],'','| 模型 | 输入数 | 平均 ms | p50 ms | p99 ms |','|---|---:|---:|---:|---:|']
    for name,s in summaries.items():lines.append(f"| {name} | {s['replayed']} | {s['mean_ms']:.4f} | {s['p50_ms']:.4f} | {s['p99_ms']:.4f} |")
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))

if __name__=='__main__':main()
