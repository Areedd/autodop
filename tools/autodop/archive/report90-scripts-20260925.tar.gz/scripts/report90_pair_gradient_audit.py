"""Training-only score-gap derivatives under existing and sharper smooth losses."""
import json
import math
import os
from pathlib import Path
import numpy as np
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from autodop.training import select_partition
from report90_complex_retrain import pair_index
from report90_neighborhood_prepare import RUN, sha
BASE=RUN/'structure_coverage20'
OUT=BASE/'pair_gradient_audit'


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1)
    assert not OUT.exists()
    source=BASE/'merged_dataset'
    samples,pairs,metadata=load_dataset(source)
    contract=json.loads((source/'CONTRACT.json').read_text())
    train,tp=select_partition(samples,pairs,contract,'train')
    assert len(train)==1365 and len(tp)==6702
    by=pair_index(train,tp)
    graphs={(s['plan_key'],s['config_key']):build_graph(s,metadata) for s in train}
    paths={'warm':BASE/'prepared/cost.pt','raw_final':BASE/'hard_pair_ema_pilot/pilot/transformer_h0/raw_final.pt','ema_selected':BASE/'hard_pair_ema_pilot/pilot/transformer_h0/best.pt'}
    results={}
    for name,path in paths.items():
        model,_=load_cost_model(path);model.eval()
        with torch.no_grad():scores={k:float(model(g)) for k,g in graphs.items()}
        records=[]
        for cohort,plans in by.items():
            for plan,pp in plans.items():
                gaps=[scores[plan,p['fast_config_key']]-scores[plan,p['slow_config_key']] for p in pp]
                wrong=sum(g<=0 for g in gaps)
                for p,gap in zip(pp,gaps):
                    target=math.log(p['slow_latency_ms']/p['fast_latency_ms'])
                    base_weight=.5/len(plans)
                    # Expected refreshed hard sampler; actual pools stay fixed for10epochs.
                    weight=base_weight*((.5/len(pp)+(.5/wrong if gap<=0 else 0)) if wrong else 1/len(pp))
                    records.append((gap,target,weight,cohort))
        outcome={}
        for temperature in [1.,.1]:
            buckets={k:{'pairs':0,'expected_sampling_mass':0.,'absolute_score_gap_derivative_mass':0.} for k in ['wrong_or_tied','correct_below_margin','correct_at_or_above_margin']}
            for gap,target,weight,cohort in records:
                r=(gap-target)/temperature
                sigmoid=1/(1+math.exp(min(700,max(-700,r))))
                derivative=-sigmoid+.1*max(-1,min(1,gap-target))
                k='wrong_or_tied' if gap<=0 else ('correct_below_margin' if gap<target else 'correct_at_or_above_margin')
                v=buckets[k];v['pairs']+=1;v['expected_sampling_mass']+=weight;v['absolute_score_gap_derivative_mass']+=weight*abs(derivative)
            assert abs(sum(v['expected_sampling_mass'] for v in buckets.values())-1)<1e-10
            total=sum(v['absolute_score_gap_derivative_mass'] for v in buckets.values())
            for v in buckets.values():v['derivative_mass_fraction']=v['absolute_score_gap_derivative_mass']/total
            outcome[str(temperature)]=buckets
        results[name]=outcome
    OUT.mkdir()
    result={'status':'verified_training_score_gap_derivatives','models':results,'training_pairs':len(tp),
        'scope':'No validation or report90 labels read. Uses stored batch-specific pair labels. Score-gap derivatives are not parameter gradients; cancellation and Jacobians differ. Hard sampler weights are expected weights if refreshed at each inspected checkpoint, not exact historical sampled jobs. Sharper loss is T*softplus((target-gap)/T)+0.1*smooth_l1(gap,target). No fit, SQL or superiority claim.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),source/'samples.jsonl',source/'pairs.jsonl',source/'metadata.json',source/'CONTRACT.json',*paths.values()]}}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(results,indent=2))

if __name__=='__main__':main()
