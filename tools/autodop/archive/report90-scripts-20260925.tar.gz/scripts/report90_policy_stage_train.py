"""Controlled final policy-stage retraining; identical inputs and budget for all arms."""
import argparse
import json
import math
from pathlib import Path
import random
import time
import torch
from torch.nn import functional as F
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_policy_model, save_checkpoint
from autodop.training import file_sha256, select_partition

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'runs/report90_20260912/policy_final_stage_ablation'


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--phase',choices=['smoke','full'],required=True)
    args=parser.parse_args()
    protocol=json.loads((BASE/'PROTOCOL.json').read_text())
    for path,digest in protocol['source_sha256'].items(): assert file_sha256(path)==digest
    assert json.loads((BASE/'INPUT_AUDIT.json').read_text())['status']=='verified_inputs_current_code'
    if args.phase=='full':
        assert json.loads((BASE/'smoke/RESULT.json').read_text())['status']=='verified'
    out=BASE/args.phase;out.mkdir(exist_ok=False)
    def save(name,value): (out/name).write_text(json.dumps(value,indent=2)+'\n')
    save('STATUS.json',dict(status='loading',phase=args.phase))
    torch.set_num_threads(1)
    samples,pairs,_=load_dataset(protocol['dataset'])
    contract=json.loads(Path(protocol['training_contract']).read_text())
    training,_=select_partition(samples,pairs,contract,'train')
    by={s['plan_key']:s for s in samples};keys=sorted({s['plan_key'] for s in training})
    assert len(keys)==130
    incumbent,saved=load_policy_model(protocol['initial_policy']);incumbent.eval()
    graphs={k:build_graph(by[k],saved['metadata'],unknown_dop=True) for k in keys}
    classes=saved['metadata']['dop_classes'];index={dop:i for i,dop in enumerate(classes)}
    records=json.loads(Path(protocol['targets']).read_text())['plans']
    targets={r['plan_key']:torch.tensor([index[d] for d in r['target_dops']]) for r in records if r['margin_eligible']}
    assert len(targets)==125 and set(targets)<=set(keys)
    with torch.no_grad(): anchors={k:incumbent(g).softmax(-1) for k,g in graphs.items()}
    epochs=1 if args.phase=='smoke' else protocol['epochs']
    results={}
    try:
        for arm,weights in protocol['arms'].items():
            torch.manual_seed(protocol['seed']);rng=random.Random(protocol['seed'])
            model,_=load_policy_model(protocol['initial_policy']);model.train()
            assert all(torch.equal(value,incumbent.state_dict()[key]) for key,value in model.state_dict().items())
            optimizer=torch.optim.Adam([dict(params=model.encoder.parameters(),lr=protocol['encoder_lr']),
                                        dict(params=model.classifier.parameters(),lr=protocol['classifier_lr'])])
            history=[];start=time.monotonic();steps=0
            for epoch in range(1,epochs+1):
                order=keys.copy();rng.shuffle(order);values=[]
                for offset in range(0,len(order),protocol['batch_size']):
                    batch=order[offset:offset+protocol['batch_size']];optimizer.zero_grad()
                    outputs={k:model(graphs[k]) for k in batch}
                    kl=torch.stack([F.kl_div(outputs[k].log_softmax(-1),anchors[k],reduction='batchmean') for k in batch]).mean()
                    maxkl=torch.stack([F.kl_div(outputs[k].log_softmax(-1),anchors[k],reduction='none').sum(-1).max() for k in batch]).mean()
                    margin=torch.stack([F.relu(math.log(protocol['margin_probability'])-outputs[k].log_softmax(-1).gather(1,targets[k][:,None]).squeeze(1)).max()
                                        if k in targets else torch.zeros(()) for k in batch]).mean()
                    loss=weights['kl_weight']*kl+weights['max_kl_weight']*maxkl+weights['margin_weight']*margin
                    assert torch.isfinite(loss);loss.backward()
                    assert all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters())
                    optimizer.step();steps+=1
                    values.append([float(x.detach()) for x in [loss,kl,maxkl,margin]])
                if epoch==1 or epoch%100==0 or epoch==epochs:
                    row=dict(epoch=epoch,**{name:sum(v[i] for v in values)/len(values) for i,name in enumerate(['loss','kl','max_kl','margin'])})
                    history.append(row);save('STATUS.json',dict(status='running',arm=arm,epoch=epoch,epochs=epochs,steps=steps))
                    print(json.dumps(dict(arm=arm,**row)),flush=True)
            training_seconds=time.monotonic()-start
            model.eval();checkpoint=out/(arm+'.pt')
            save_checkpoint(checkpoint,'policy',model,saved['metadata'],training=dict(contract,adaptation=dict(
                protocol_sha256=file_sha256(BASE/'PROTOCOL.json'),initial_policy_sha256=file_sha256(protocol['initial_policy']),
                arm=arm,weights=weights,epochs=epochs,seed=protocol['seed'],selection='fixed_final_epoch',gradient_plan_keys=keys)))
            restored,_=load_policy_model(checkpoint);restored.eval();predictions=[]
            with torch.no_grad():
                for key in sorted(by):
                    graph=graphs[key] if key in graphs else build_graph(by[key],saved['metadata'],unknown_dop=True)
                    logits=model(graph);assert torch.equal(logits,restored(graph))
                    probs=logits.softmax(-1);chosen=logits.argmax(-1)
                    predictions.append(dict(plan_key=key,split='train' if key in graphs else 'valid',
                                            confidence=float(probs.max(-1).values.min()),
                                            predicted_dops=[classes[i] for i in chosen.tolist()]))
            results[arm]=dict(checkpoint=str(checkpoint),checkpoint_sha256=file_sha256(checkpoint),
                              epochs=epochs,steps=steps,training_seconds=training_seconds,history=history,
                              exact_reload=True,predictions=predictions)
            save(arm+'.json',results[arm])
        save('RESULT.json',dict(status='verified',phase=args.phase,arms=results,train_plans=len(keys),
                              validation_used_for_gradients=False,report90_used=False,
                              source_sha256={str(p):file_sha256(p) for p in [Path(__file__),BASE/'PROTOCOL.json',BASE/'INPUT_AUDIT.json']},
                              scope=protocol['scope']))
        save('STATUS.json',dict(status='verified',phase=args.phase,arms=list(results)))
    except BaseException as error:
        save('STATUS.json',dict(status='failed',error=repr(error),completed_arms=list(results)))
        raise


if __name__=='__main__':main()
