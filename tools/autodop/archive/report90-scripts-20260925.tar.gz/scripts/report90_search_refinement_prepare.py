"""Freeze search proposals on development requests without reading their latency labels."""
import json
import math
import random
import time
from pathlib import Path
from unittest.mock import patch

import torch
from autodop import mcts
from autodop.data import supported_dops
from autodop.graph import build_graph, sample_from_request
from autodop.model import load_cost_model
from autodop.training import file_sha256
from collect_paper_evaluations import VectorEngine, request_identity
from build_trusted_dataset import digest
from report90_search_refinement import search as refined_search

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT/'runs/report90_20260912'
OUT = RUN/'search_refinement_development'
COM = RUN/'complex_development24'


def save(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2)+'\n')
    temp.replace(path)


class CountedModel:
    def __init__(self, model):
        self.model = model
        self.score_calls = 0
        self.importance_calls = 0

    def eval(self):
        self.model.eval()
        return self

    def __call__(self, graph):
        self.score_calls += 1
        return self.model(graph)

    def fragment_importance(self, graph):
        self.importance_calls += 1
        return self.model.fragment_importance(graph)


def main():
    torch.set_num_threads(1)
    protocol = json.loads((OUT/'PROTOCOL.json').read_text())
    for path, expected in protocol['source_sha256'].items():
        assert file_sha256(path) == expected
    assert not (OUT/'PREPARATION_STATUS.json').exists(), 'Preserve earlier preparation'
    model, checkpoint = load_cost_model(protocol['model'])
    model.eval()
    metadata = checkpoint['metadata']
    manifest = json.loads((COM/'manifest.json').read_text())
    queries = {q['id']: q for q in manifest['queries'] if q['id'] in protocol['queries']}
    assert len(queries) == 4 and all(q['split'] == 'valid' for q in queries.values())
    evidence_path = COM/'verified_labels/sample_evidence.jsonl'
    evidence = [json.loads(line) for line in evidence_path.read_text().splitlines()]
    wanted = {e['query_ids'][0]: e['template_id'] for e in evidence if e['template_id'] in queries}
    trace_path = COM/'labels/collection/measured/accepted.jsonl'
    requests = {}
    for line in trace_path.open():
        trace = json.loads(line)
        if trace['query_id'] in wanted:
            q = wanted[trace['query_id']]
            request = trace['request']
            if q in requests:
                assert request_identity(requests[q]) == request_identity(request)
            requests.setdefault(q, request)
    assert set(requests) == set(queries)
    manifest['queries'] = [queries[q] for q in protocol['queries']]
    manifest['query_count'] = len(queries)
    sources = [Path(__file__), Path(mcts.__file__), Path(__file__).with_name('report90_search_refinement.py'),
               OUT/'PROTOCOL.json', Path(protocol['model']), evidence_path, trace_path,
               COM/'manifest.json', COM/'TRUSTED_NATIVE.json']
    save(OUT/'PREPARATION_SOURCES.json', {str(p):file_sha256(p) for p in sources})
    save(OUT/'PREPARATION_STATUS.json', dict(status='running'))
    rows = []
    vectors = {mode:{} for mode in protocol['modes']}

    def natural(sample, model, metadata, candidates, device='cpu'):
        return mcts.equivalence_groups(sample, candidates)

    def individual(sample, candidates):
        return [(i,) for i in range(len(candidates))]

    for q in protocol['queries']:
        request = requests[q]
        sample = sample_from_request(request)
        sample['dop_config'] = [1 if f.get('is_gather_root') else 4 for f in sample['fragments']]
        candidates = [supported_dops(f, metadata['dop_classes']) for f in sample['fragments']]
        assert all(d in values for d, values in zip(sample['dop_config'], candidates))
        for seed in protocol['seeds']:
            modes = list(protocol['modes'])
            random.Random(seed).shuffle(modes)
            for mode in modes:
                counted = CountedModel(model)
                begin = time.perf_counter()
                extra = {}
                if mode == 'original_mcts':
                    config, score = mcts.search(sample, counted, metadata, iterations=protocol['score_evaluations'], seed=seed)
                elif mode == 'original_independent_random':
                    rng = random.Random(seed)
                    config, score = None, -math.inf
                    for _ in range(protocol['score_evaluations']):
                        proposal = [rng.choice(values) for values in candidates]
                        with torch.no_grad():
                            value = float(counted(build_graph({**sample,'dop_config':proposal}, metadata)))
                        assert math.isfinite(value)
                        if value > score:
                            config, score = proposal, value
                else:
                    options = dict(budget=protocol['score_evaluations'], seed=seed)
                    if mode == 'refined_no_normalization': options['normalized'] = False
                    if mode == 'refined_random_completion': options['random_completion_probability'] = 1.
                    if mode == 'seeded_grouped_random': options['random_only'] = True
                    if mode == 'refined_no_attention':
                        with patch.object(mcts, 'attention_guided_groups', natural):
                            extra = refined_search(sample, counted, metadata, **options)
                    elif mode == 'refined_no_equivalence':
                        with patch.object(mcts, 'equivalence_groups', individual):
                            extra = refined_search(sample, counted, metadata, **options)
                    else:
                        extra = refined_search(sample, counted, metadata, **options)
                    # Patching away attention changes this count; use instrumentation.
                    extra['importance_forward_passes'] = counted.importance_calls
                    config, score = extra['config'], extra['score']
                elapsed = time.perf_counter()-begin
                assert counted.score_calls == protocol['score_evaluations']
                assert math.isfinite(score) and all(d in values for d, values in zip(config, candidates))
                with torch.no_grad():
                    replay = float(model(build_graph({**sample,'dop_config':config}, metadata)))
                assert replay == score
                rows.append(dict(id=q, mode=mode, seed=seed, config=config, score=score,
                                 score_calls=counted.score_calls, importance_calls=counted.importance_calls,
                                 search_seconds=elapsed, details=extra,
                                 plan_key=digest({'sql_sha256':queries[q]['sql_sha256'],'plan':request_identity(request)})))
                if seed == protocol['online_seed']:
                    vectors[mode][q] = dict(request=request, fragment_dops=dict(zip(sample['fragment_ids'], config)))
                save(OUT/'CHOICES.json', rows)
        save(OUT/'PREPARATION_STATUS.json', dict(status='running', completed_queries=len(vectors['original_mcts'])))
    for mode in vectors:
        assert set(vectors[mode]) == set(queries)
        engine = VectorEngine(vectors[mode])
        for request in requests.values():
            engine.decide(request)
    assert len(rows) == len(queries)*len(protocol['modes'])*len(protocol['seeds'])
    for path, expected in json.loads((OUT/'PREPARATION_SOURCES.json').read_text()).items():
        assert file_sha256(path) == expected
    save(OUT/'vectors.json', vectors)
    save(OUT/'manifest.json', manifest)
    save(OUT/'PREPARATION_STATUS.json', dict(status='verified', choices=len(rows), queries=len(queries),
         source_sha256=file_sha256(OUT/'PREPARATION_SOURCES.json'),
         scope='Development proposals only; no execution-latency selection or SQL performance claim.'))


if __name__ == '__main__':
    main()
