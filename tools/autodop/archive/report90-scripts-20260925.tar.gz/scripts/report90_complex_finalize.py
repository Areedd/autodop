"""Wait for the frozen training run, independently replay scores, publish its local report."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from report90_execute import ROOT,RUN

BASE=RUN/'complex_development24'
OUT=BASE/'training_finalize'


def read(p):return json.loads(p.read_text())
def status(value):
    p=OUT/'STATUS.json';tmp=p.with_suffix('.tmp')
    tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(p)


def main():
    OUT.mkdir(exist_ok=False)
    status({'status':'running','stage':'waiting_training','pid':os.getpid()})
    while True:
        state=read(BASE/'retrained/STATUS.json')
        if state['status']=='complete':break
        assert state['status']=='running',state
        pid=state['pid'];os.kill(pid,0)
        assert b'report90_complex_retrain.py' in Path(f'/proc/{pid}/cmdline').read_bytes()
        time.sleep(15)
    os.sched_setaffinity(0,{35})
    status({'status':'running','stage':'independent_score_replay','pid':os.getpid()})
    subprocess.run([sys.executable,str(ROOT/'scripts/report90_complex_training_report.py')],check=True)
    audit=read(BASE/'retrained/SCORE_REPLAY.json')
    assert audit['status']=='verified_selected_model_replay'
    report=BASE/'REPORT.md';original=report.read_text();(OUT/'REPORT.before.md').write_text(original)
    addition='\n\n## 接续训练与监督对照\n\n复杂开发集标签现已完整校验并完成接续训练。模型选择结果、独立分数回放及本轮训练成本见 [训练报告](retrained/REPORT.md)。训练数据来源和补测处理见 [采集说明](RECOVERY_NOTE.md)。这些是已参与模型选择的开发验证结果，不代表独立测试集或报告 90 条查询上的新性能结论。\n'
    assert '## 接续训练与监督对照' not in original
    report.write_text(original+addition)
    status({'status':'complete','at':datetime.datetime.now().astimezone().isoformat(),
            'development_gate_passed':audit['development_gate_passed'],
            'scope':'Local report and independent score replay only; no SQL expansion or model deployment.'})


if __name__=='__main__':
    if OUT.exists():raise SystemExit('Preserve existing finalization')
    try:main()
    except BaseException as error:
        if OUT.exists():status({'status':'failed','error':repr(error),'pid':os.getpid()})
        raise
