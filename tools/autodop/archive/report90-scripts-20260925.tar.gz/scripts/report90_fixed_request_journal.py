"""Diagnostic request logging around unchanged offline FixedEngine behavior."""
import datetime
import json
from pathlib import Path
from autodop.fixed_engine import FixedEngine


class JournalFixedEngine(FixedEngine):
    def __init__(self, fragment_dops, journal):
        super().__init__(fragment_dops)
        self.journal = Path(journal)

    def decide(self, request):
        record = {'at': datetime.datetime.now().astimezone().isoformat(),
                  'request': request, 'requested_fragment_dops': self.fragment_dops}
        try:
            response = super().decide(request)
            record['response'] = response
            return response
        except Exception as error:
            record['error'] = {'type': type(error).__name__, 'message': str(error)}
            raise
        finally:
            with self.journal.open('a') as stream:
                stream.write(json.dumps(record, sort_keys=True) + '\n')
