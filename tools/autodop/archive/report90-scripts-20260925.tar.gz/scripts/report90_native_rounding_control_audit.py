"""Fail a scheduler-isolation gate if captured heterogeneous plans/DOPs change."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
from report90_native_mixed_plan_audit import FIELDS

RUN=Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def main():
    plans=defaultdict(set);vectors=defaultdict(set);rows=[];sources=[Path(__file__)]
    for arm in ('power2','integer'):
        out=RUN/('report90_native_budget_rounding_'+arm)
        audit=json.loads((out/'ALLOCATION_AUDIT.json').read_text());assert audit['status']=='verified' and audit['executions']==128
        gate=json.loads((out/'PLAN_STABILITY/RESULT.json').read_text());assert gate['status']=='stable'
        for event in map(json.loads,(out/'scored/events.jsonl').read_text().splitlines()):
            if not event['mode'].startswith('policy'):continue
            request=event['trace']['request'];labels={f['fragment_id']:json.dumps({k:f.get(k) for k in FIELDS},sort_keys=True) for f in request['fragments']}
            descriptor=dict(fragments=sorted(labels.values()),edges=sorted((labels[e['source_fragment_id']],labels[e['dest_fragment_id']],e['partition_type']) for e in request['edges']))
            plan=hashlib.sha256(json.dumps(descriptor,sort_keys=True).encode()).hexdigest()
            validation=event['dop_validation'];assert validation['applied']
            vector=hashlib.sha256(json.dumps(validation['installed_dop'],sort_keys=True).encode()).hexdigest()
            plans[event['id']].add(plan);vectors[event['id']].add(vector)
            rows.append(dict(arm=arm,query_id=event['query_id'],id=event['id'],mode=event['mode'],phase=event['phase'],plan=plan,vector=vector))
        sources += [out/'ALLOCATION_AUDIT.json',out/'scored/events.jsonl',out/'PLAN_STABILITY/RESULT.json']
    assert len(rows)==128
    passed=all(len(values)==1 for values in plans.values()) and all(len(values)==1 for values in vectors.values())
    result=dict(status='passed' if passed else 'plan_or_dop_changed',heterogeneous_executions=len(rows),
                plan_variants={k:len(v) for k,v in plans.items()},dop_variants={k:len(v) for k,v in vectors.items()},rows=rows,
                scope='Checks captured model-request descriptors and installed vectors in all heterogeneous executions. Native AutoDOP-off executions lack these traces; descriptor equality is not full physical-plan equivalence. All SQL results remain archived even if this gate fails.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    out=RUN/'native_rounding_control_audit';out.mkdir(exist_ok=True);(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
    if not passed:raise RuntimeError('Captured plan/DOP changed; scheduler-isolation claim rejected')


if __name__=='__main__':main()
