"""Summarize all development memory profiles without selecting favorable queries."""
import hashlib
import json
from pathlib import Path
import statistics


def main():
    out=Path(__file__).resolve().parents[1]/'runs/report90_20260912/development17_memory_profiles_full'
    p=out/'MEMORY_PROFILE_CHECK.json';d=json.loads(p.read_text());assert d['status']=='verified'
    for path,expected in d['source_sha256'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==expected,path
    summaries={};pairs={}
    for mode in ['native','policy_static']:
        rows=[r for r in d['rows'] if r['mode']==mode and r['phase']=='measured'];assert len(rows)==17
        values=[r['peak_per_node']['approx_bytes']/1024**2 for r in rows]
        summaries[mode]=dict(min_mib=min(values),max_mib=max(values),median_mib=statistics.median(values),
                             max_min_ratio=max(values)/min(values))
        for r in rows:
            pairs.setdefault(r['id'],{})[mode]=r['peak_per_node']
    # Conservative comparison treats overlap in display rounding as unresolved.
    smaller=sum(v['policy_static']['upper_bytes']<v['native']['lower_bytes'] for v in pairs.values())
    larger=sum(v['policy_static']['lower_bytes']>v['native']['upper_bytes'] for v in pairs.values())
    result=dict(status='verified',summaries=summaries,paired_peaks=pairs,
                static_smaller_peak_queries=smaller,static_larger_peak_queries=larger,
                rounded_overlap_queries=17-smaller-larger,
                scope='17 development queries, profile-enabled isolated execution, one formal observation per mode. '
                      'Warmup remains archived. Neither a future memory bound nor a generalization test.',
                source_sha256={str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in [p,Path(__file__).resolve()]})
    target=out/'MEMORY_SUMMARY.json';assert not target.exists()
    target.write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 开发查询的内存需求差异','',result['scope'],'',
           '| 模式 | 最小 MiB | 中位数 MiB | 最大 MiB | 最大/最小 |','|---|---:|---:|---:|---:|']
    for mode,v in summaries.items():
        lines.append(f"| {mode} | {v['min_mib']:.2f} | {v['median_mib']:.2f} | {v['max_mib']:.2f} | {v['max_min_ratio']:.2f} |")
    lines+=['',f'静态异构策略的每BE峰值低于原生：{smaller}/17；高于原生：{larger}/17。显示舍入区间重叠：{17-smaller-larger}/17。',
            '', '上述差异支持验证按需求加权的准入机制，但不证明它一定提高吞吐。历史profile预算只能作为开发原型，不能冒充已训练的未见查询内存预测模型。',
            '单查询内存峰值与执行延迟是不同指标；不能因执行更快就推断内存更低，也不能将各查询峰值直接相加视为实际并发峰值。']
    (out/'MEMORY_SUMMARY.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(summaries,indent=2))


if __name__=='__main__':main()
