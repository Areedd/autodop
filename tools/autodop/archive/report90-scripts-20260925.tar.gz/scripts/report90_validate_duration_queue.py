"""Recompile and test the experimental queue, without replacing the deployed FE."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'tools/autodop/runs/report90_20260912/duration_queue_validation'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    out = BASE / ('audit_' + str(time.time_ns()))
    out.mkdir()
    deployed = ROOT / 'output/fe/lib/starrocks-fe.jar'
    before = digest(deployed)
    classes = out / 'classes'
    classes.mkdir()
    compile_cmd = json.loads((BASE / 'COMPILE_COMMAND.json').read_text())
    compile_cmd[compile_cmd.index('-d') + 1] = str(classes)
    compile_cmd = [arg for arg in compile_cmd if not arg.endswith('.java')]
    compile_cmd.extend(str(path) for path in sorted((BASE / 'src').rglob('*.java')))
    junit_cmd = json.loads((BASE / 'JUNIT_COMMAND.json').read_text())
    cp_index = junit_cmd.index('-cp') + 1
    junit_cmd[cp_index] = str(classes) + ':' + junit_cmd[cp_index].split(':', 1)[1]
    result = dict(status='running', deployed_sha256_before=before,
                  scope='Experimental queue lifecycle only; no SQL execution, FE deployment, or performance claim.')
    try:
        for name, cmd in [('COMPILE', compile_cmd), ('JUNIT', junit_cmd)]:
            (out / (name + '_COMMAND.json')).write_text(json.dumps(cmd, indent=2) + '\n')
            with (out / (name + '.log')).open('w') as log:
                process = subprocess.run(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=120)
            result[name.lower() + '_returncode'] = process.returncode
            if process.returncode:
                raise RuntimeError(name + ' failed; inspect ' + str(out))
        log = (out / 'JUNIT.log').read_text()
        assert '15 tests successful' in log and '0 tests failed' in log, log
        result.update(status='verified_unit_only', tests=15, randomized_operations=10000, random_seed=17,
                      registry_concurrent_threads=16, registry_request_lifecycles=16000)
    finally:
        result['deployed_sha256_after'] = digest(deployed)
        result['deployed_unchanged'] = before == result['deployed_sha256_after']
        sources = [Path(__file__), *sorted((BASE / 'src').rglob('*.java')),
                   out / 'COMPILE_COMMAND.json', out / 'JUNIT_COMMAND.json']
        result['source_sha256'] = {str(p): digest(p) for p in sources if p.exists()}
        (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    assert result['deployed_unchanged']
    print(json.dumps(dict(output=str(out), **result), indent=2))


if __name__ == '__main__':
    main()
