"""Refine coverage counts using actual supported domains, excluding fixed gather roots."""
import collections
import json
from pathlib import Path
import numpy as np
from autodop.data import supported_dops
from autodop.mcts import equivalence_groups
from report90_interaction_pair_audit import BASE,sha

OUT=BASE/'training_coverage_audit/EFFECTIVE_DOMAINS.json'

def main():
    assert not OUT.exists()
    source=BASE/'merged_dataset/samples.jsonl';samples=[json.loads(x) for x in source.read_text().splitlines()];plans=collections.defaultdict(list)
    for s in samples:plans[s['plan_key']].append(s)
    counts={};design=[]
    for (cohort,split) in sorted({(s['source_cohort'],s['split']) for s in samples}):
        selected=[s for s in samples if (s['source_cohort'],s['split'])==(cohort,split)];nonuniform=0
        for s in selected:
            domains=[supported_dops(f,[1,2,4,8,16]) for f in s['fragments']]
            assert all(d in domain for d,domain in zip(s['dop_config'],domains))
            nonuniform+=len({d for d,domain in zip(s['dop_config'],domains) if len(domain)>1})>1
        counts[f'{cohort}/{split}']={'configs':len(selected),'nonuniform_on_supported_movable_fragments':nonuniform,'uniform_on_supported_movable_fragments':len(selected)-nonuniform}
    for key,rows in sorted(plans.items()):
        s=rows[0]
        if s['source_cohort']!='complex_new' or s['split']!='train':continue
        domains=[supported_dops(f,[1,2,4,8,16]) for f in s['fragments']];groups=equivalence_groups(s,domains);movable=[i for i,d in enumerate(domains) if len(d)>1]
        X=np.log2(np.array([[r['dop_config'][i] for i in movable] for r in rows],dtype=float))
        design.append({'template_id':s['template_id'],'configs':len(rows),'movable_fragments':len(movable),'movable_equivalence_groups':sum(len(domains[g[0]])>1 for g in groups),'centered_full_fragment_log_dop_rank':int(np.linalg.matrix_rank(X-X.mean(0))),
            'nonuniform_configs':sum(len({r['dop_config'][i] for i in movable})>1 for r in rows),'stored_vectors_respect_equivalence':all(len({r['dop_config'][i] for i in g})==1 for r in rows for g in groups)})
    result={'status':'verified_effective_domain_audit','counts':counts,'complex_training_design':design,
        'scope':'Refinement of raw DOP-diversity counts. Gather-rootDOP1 is mandatory even when raw FE candidate list is broader. Query-uniform configurations may therefore contain raw1 and another DOP. Linear design rank is a within-query diagnostic, not proof that a shared nonlinear model cannot learn.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),source,Path(__file__).resolve().parents[1]/'autodop/data.py',Path(__file__).resolve().parents[1]/'autodop/mcts.py']}}
    OUT.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(counts));print('design',collections.Counter((r['configs'],r['nonuniform_configs'],r['centered_full_fragment_log_dop_rank']) for r in design))

if __name__=='__main__':main()
