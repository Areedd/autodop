"""Isolated FE controller timing, after primary tests; restore original binary in finally."""
import datetime, hashlib, json, os, shutil, signal, subprocess, sys, time, zipfile
from pathlib import Path
import pymysql
ROOT=Path(__file__).resolve().parents[1]; REPO=ROOT.parents[1]
RUN=ROOT/'runs/report90_20260912'; OUT=RUN/'fe_timing'; JAR=REPO/'output/fe/lib/starrocks-fe.jar'
sys.path.insert(0,str(ROOT/'runs/preference_random200_20260911'))
from preflight import check

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
 p=OUT/name;tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(p)
def state(stage,**extra):save('STATUS.json',{'stage':stage,'at':datetime.datetime.now().astimezone().isoformat(),**extra})
def db_ready():
 try:
  with pymysql.connect(host='127.0.0.1',port=9030,user='root',connect_timeout=3,read_timeout=5) as c:
   with c.cursor() as q:
    q.execute('SHOW BACKENDS');cols=[x[0].lower() for x in q.description]
    rows=[dict(zip(cols,r)) for r in q.fetchall()]
    return len(rows)==3 and all(str(r['alive']).lower()=='true' for r in rows)
 except Exception:return False

def fe_pid():return int((REPO/'output/fe/bin/fe.pid').read_text().strip())
def stop_fe():
 pid=fe_pid();cmd=Path(f'/proc/{pid}/cmdline').read_bytes()
 assert b'com.starrocks.StarRocksFE' in cmd and os.readlink(f'/proc/{pid}/cwd')==str(REPO), 'Unexpected FE process'
 os.kill(pid,signal.SIGTERM)
 for _ in range(120):
  p=Path(f'/proc/{pid}/stat')
  if not p.exists() or p.read_text().split(') ')[1].startswith('Z'):return
  time.sleep(1)
 raise RuntimeError('FE did not stop gracefully; no force kill issued')

def start_fe():
 launch=json.loads((OUT/'ORIGINAL_FE_LAUNCH.json').read_text());env=os.environ.copy();env.update(launch['environment'])
 affinity=','.join(map(str,launch['affinity']))
 subprocess.run(['taskset','-c',affinity,'bash',str(REPO/'output/fe/bin/start_fe.sh'),'--daemon'],env=env,cwd=REPO,check=True)
 for _ in range(120):
  if db_ready():
   assert sorted(os.sched_getaffinity(fe_pid()))==launch['affinity'];return
  time.sleep(2)
 raise RuntimeError('FE readiness timeout')

def foreground_original_fe():
 # Keep the restored FE itself as the tool's foreground process. A daemon child
 # can be cleaned up after its experiment launcher exits in this environment.
 launch=json.loads((OUT/'ORIGINAL_FE_LAUNCH.json').read_text());env=os.environ.copy();env.update(launch['environment']);os.chdir(REPO)
 args=['taskset','-c',','.join(map(str,launch['affinity'])),'bash',str(REPO/'output/fe/bin/start_fe.sh')]
 os.execvpe('taskset',args,env)

def prepare():
 assert 'Successful and fallback timing transfer verified' in (OUT/'merged_smoke_test.log').read_text()
 backup=OUT/'original-starrocks-fe.jar'
 if not backup.exists():shutil.copy2(JAR,backup)
 assert sha(backup)=='fb2e974406e7291edd71df38d1826ac1610af043873e3ada93d9afeca8e53808'
 replacements={str(p.relative_to(OUT/'merged')):p.read_bytes() for p in (OUT/'merged').rglob('*.class')}
 assert len(replacements)==4
 patched=OUT/'timed-starrocks-fe.jar'
 with zipfile.ZipFile(backup) as src,zipfile.ZipFile(patched,'w') as dst:
  for info in src.infolist():dst.writestr(info,replacements.get(info.filename,src.read(info.filename)))
 with zipfile.ZipFile(backup) as a,zipfile.ZipFile(patched) as b:
  assert a.namelist()==b.namelist()
  changed=[n for n in a.namelist() if a.read(n)!=b.read(n)]
  assert set(changed)==set(replacements)
 save('BINARY_AUDIT.json',{'original_sha256':sha(backup),'timed_sha256':sha(patched),'changed_classes':changed,
  'method_scope':'Original bytecode preserved except Controller.decideAndInstall and TraceManager.register; timing fields/getters added. Original isSupported, decide, and all policy behavior preserved.',
  'merged_smoke_test':'passed'})
 return backup,patched

def wait_idle(path):
 for retry in range(20):
  try:check(path.with_name(path.stem+f'_{retry}'+path.suffix));return
  except RuntimeError:
   if retry==19:raise
   print('Server busy; preserve threshold and retry after15s',flush=True);time.sleep(15)

def collect(pilot):
 name='fe_timing_pilot' if pilot else 'fe_timing_full';out=RUN/name;out.mkdir(exist_ok=False)
 wait_idle(out/'IDLE.json')
 protocol=json.loads((RUN/'PROTOCOL.json').read_text())
 command=[sys.executable,str(ROOT/'collect_paper_evaluations.py'),'--manifest',str(RUN/('pilot.json' if pilot else 'manifest.json')),
 '--trusted-collection',str(ROOT/'runs/preference_random200_20260911/random200/trusted_merged.json'),'--output-dir',str(out/'scored'),
 '--policy-model',protocol['model'],'--modes','policy_static','--scenario','serial','--query-timeout-s','180','--auto-dop-max-dop','16',
 '--torch-threads','1','--decision-timeout-ms','1000','--warmup','1','--repetitions','1' if pilot else '2','--seed',str(protocol['seed'])]
 (out/'COMMAND.json').write_text(json.dumps(command,indent=2)+'\n');subprocess.run(command,check=True)
 subprocess.run([sys.executable,str(ROOT/'scripts/verify_paper_evaluations.py'),'--collection-dir',str(out/'scored'),'--output',str(out/'scored/independent_verification.json')],check=True)
 proof=json.loads((out/'scored/independent_verification.json').read_text());assert proof['all_expected_executions_verified']
 settings=json.loads((out/'scored/frontend_settings.json').read_text());assert settings['restored'] and not settings['restore_errors']
 rows=[]
 for line in (out/'scored/events.jsonl').open():
  e=json.loads(line);t=e['trace']['auto_dop'];keys=['feature_extraction_ns','decision_and_validation_ns','installation_ns','controller_ns'];values=[t[k] for k in keys]
  assert values[0]>0 and values[1]>0 and values[2]>=0 and values[3]>=sum(values[:3]),str(values)
  assert values[3]-sum(values[:3])<1000000,'Unexpected unaccounted controller interval'
  skip=e['trace'].get('skip_reason');assert (values[2]==0) if skip else (values[2]>0)
  if e['phase']!='warmup':rows.append({'id':e['id'],'query_id':e['query_id'],'round':e['round'],'fallback':bool(skip),'latency_ms':e['client_latency_ms'],**dict(zip(keys,values))})
 return rows

def main():
 backup,patched=prepare();state('waiting_for_primary')
 while True:
  s=json.loads((RUN/'PIPELINE_STATUS.json').read_text())
  if s['status']=='complete':break
  if s['status']!='running':raise RuntimeError('Primary pipeline needs investigation: '+str(s))
  time.sleep(15)
 assert sha(JAR)==sha(backup)
 original_pid=fe_pid()
 if db_ready():
  wait_idle(OUT/'IDLE_BEFORE_RESTART.json');state('restarting_for_timing',original_pid=original_pid);stop_fe()
 else:
  assert not Path(f'/proc/{original_pid}').exists(),'Unexpected live but unavailable FE requires inspection'
  state('starting_from_stopped_fe',previous_pid=original_pid)
 swapped=False
 try:
  tmp=JAR.with_suffix('.timing-tmp');shutil.copy2(patched,tmp);tmp.replace(JAR);swapped=True
  start_fe();state('pilot',pid=fe_pid());pilot=collect(True)
  save('PILOT_TIMINGS.json',pilot);state('full',pid=fe_pid());rows=collect(False)
  expected={q['id'] for q in json.loads((RUN/'manifest.json').read_text())['queries']}
  assert len(rows)==180 and {r['id'] for r in rows}==expected
  save('ROWS.json',rows)
 finally:
  state('restoring_original_fe')
  if swapped:
   try:
    pid=fe_pid()
    if Path(f'/proc/{pid}').exists():stop_fe()
   except FileNotFoundError:pass
  tmp=JAR.with_suffix('.restore-tmp');shutil.copy2(backup,tmp);tmp.replace(JAR)
  assert sha(JAR)==sha(backup)
  save('RESTORATION.json',{'restored':False,'binary_restored':True,'sha256':sha(JAR),'service_restart':'pending_foreground_start'})
 from report90_summary import distribution
 result={'status':'complete','measured':len(rows),'queries':len(expected),'fallbacks':sum(r['fallback'] for r in rows),
  'stage_ms':{k.removesuffix('_ns'):distribution([r[k]/1e6 for r in rows]) for k in ('feature_extraction_ns','decision_and_validation_ns','installation_ns','controller_ns')},
  'controller_fraction_of_query_mean_percent':sum(r['controller_ns']/1e6 for r in rows)/sum(r['latency_ms'] for r in rows)*100,
  'scope':'Controller feature extraction including original DOP capture; decision HTTP and validation; DOP installation and installed DOP capture. Excludes optimizer, placement and trace persistence.',
  'binary_restored':True,'primary_latency_data_unchanged':True}
 result['status']='awaiting_service_verification';save('RESULT_PENDING.json',result);state('starting_original_fe');foreground_original_fe()
if __name__=='__main__':
 try:main()
 except BaseException as e:
  state('failed',error=repr(e))
  import traceback;traceback.print_exc()
  if sha(JAR)==sha(OUT/'original-starrocks-fe.jar') and not db_ready():foreground_original_fe()
  raise
