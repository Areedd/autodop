"""Build a concise evidence-backed report for the current90-query scope.

The historical experiment log remains intact. Completion here means coverage
of this report's experiments, not universal superiority or contract acceptance.
"""
import hashlib
import json
import re
import statistics
from pathlib import Path

RUN = Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    sources = []

    def read(name):
        p = RUN/name
        sources.append(p)
        return json.loads(p.read_text())

    def body(name):
        p = RUN/name
        sources.append(p)
        return p.read_text()

    def section(title):
        text = body('FULL_REPORT.md')
        key = '## '+title+'\n'
        assert text.count(key) == 1
        return text.split(key,1)[1].split('\n## ',1)[0].strip()

    main_result = read('SUMMARY.json')
    xgb = read('structure_coverage20/basic_feature_stability/RESULT.json')
    mlp = read('structure_coverage20/mlp_interaction_stability/RESULT.json')
    teacher = read('structure_coverage20/hard_pair_ema_stability/RESULT.json')
    search = read('retrieval_independent_report90/SUMMARY.json')
    search_raw = read('retrieval_independent_report90/RESULT.json')
    retrieval_audit = read('retrieval_independent_report90/FINAL_AUDIT.json')
    search_protocol = read('retrieval_independent_report90/PROTOCOL.json')
    env = read('ENVIRONMENT.json')
    runtime = read('RUNTIME_ENVIRONMENT.json')
    stage = read('policy_final_stage_ablation/online_full/SUMMARY.json')
    deployment = read('PROTOCOL.json')
    cost_protocol = read('search_refinement_report90/PROTOCOL.json')
    assert xgb['status']=='verified_three_seed_shared_pairs'
    assert mlp['status']=='verified_three_seeds'
    assert teacher['status']=='verified_three_seed_summary'
    assert stage['status']=='verified_complete_paired_summary'
    assert search['status']=='verified_first_hit_summary'
    assert search_raw['status']=='verified_timed_traces' and search_raw['timed_searches']==1620
    assert retrieval_audit['status']=='verified_independent_full_retrieval_audit'
    assert len(search_protocol['queries'])==90 and len(set(search_protocol['queries']))==90
    # New full-search sources are immutable and checked directly, not inferred
    # from an old report closeout marker.
    for result in [search, search_protocol, retrieval_audit]:
        for name,digest in result['source_sha256'].items():
            assert sha(Path(name))==digest, name
    n=270
    lines=['# AutoDOP 异构查询实验测试报告','',
        '本报告汇总冻结90条查询上的端到端性能、成本模型对照、搜索检索效率、策略阶段消融、并发性能及调优成本。对应实验已完成；结论按实际证据限定，不以“所有组件全面领先”作为完成声明。完整探索记录保留在附录。','',
        '## 1. 实验目标与评价口径','',
        '核心问题是异构fragment DOP能否优于查询级统一DOP；模型以成对排序准确率评价，搜索以相同评分质量目标下的检索命中率、评分次数和实际搜索时间评价。SQL执行延迟作为搜索输出质量参考，不再要求改进搜索平均执行延迟领先。并发同时报告平均、尾延迟、批次耗时及失败情况。','',
        'Transformer与竞争边作为整体建模方案，不单独删除竞争边。历史多阶段训练作为实际训练来源披露，不作为论文新增核心方法，不要求历史每阶段重训消融。已有最后策略阶段消融作为补充，不冒充删除整个蒸馏。','',
        '## 2. 环境、查询与数据','',
        f"历史SQL实测服务器CPU为{runtime['cpu_model']}，主串行实验BE版本为{runtime['backends'][0]['Version']}；同机3个BE，各绑定8 CPU、容器16GiB内存，上报MemLimit11.520GB。基础数据为TPC-DS SF100，实验SQL为结构化构造查询，非标准TPC-DS或TPC-H查询集。并发预算实验采用修正BE与checkpoint隔离FE，其环境与主串行分开解释。",'',
        f"离线环境：Python3.12.2、PyTorch{env['packages']['torch']}、NumPy{env['packages']['numpy']}、XGBoost{env['packages']['xgboost-cpu']}。本次新增检索计时绑定CPU34、单线程。服务器并非排他独占；SQL采集采用既有空闲门槛及分组控制。部署二进制摘要以各阶段记录为准，仓库HEAD不替代实际版本。",'',
        '90条查询在本轮前由历史200条按优势筛选并冻结，本轮没有再次筛选。2/3/4分支分别9/31/50条；根运算INNER/FULL/UNION/LEFT分别25/22/20/23条。带分支标记有序结构90种，去标记70种；结构签名数量不等于独立语义或业务场景。', '',
        '当前模型开发集含114训练计划、1365配置及6702条存储训练对；验证集22计划、212配置，统一有效排序对920条（历史699、复杂221）。训练对保留批次内测量，不直接用聚合时延改写。归一化仅使用训练数据；90条报告查询不参与梯度或检查点选择，但验证集和报告查询已反复分析，不能称独立盲测。', '',
        '主串行每配置预热1轮、正式3轮，先按查询平均，再对90条计算mean/p50/p90/p99。原生对照关闭AutoDOP、pipeline_dop=0；固定4直接设DOP4；最佳统一DOP为同批DOP1/2/4/8/16中各查询三轮均值最小者。所有配置共同关闭runtime adaptive DOP、query cache、spill，故“原生”是受控配置而非产品默认设置。AutoDOP采集调用超时1000ms，采集后恢复50ms。', '',
        '实验模型身份分别固定：端到端使用原部署策略；搜索使用冻结原教师及已验证词表扩展；新增920对排序比较使用错对强化/EMA的三个开发检查点。后者未部署，不能把其排序结果和原策略SQL延迟拼成同一新模型的端到端验证。', '',
        '| 实验角色 | 身份依据 |','|---|---|',
        f"| 在线策略 | SHA256 `{deployment['model_sha256']}` |",
        f"| 搜索教师 | `{Path(cost_protocol['model']).relative_to(RUN)}`；SHA256 `{sha(Path(cost_protocol['model']))}` |",
        '| 排序比较Transformer | hard_pair_ema_pilot与hard_pair_ema_stability的17/29/43检查点；逐模型来源见对应RESULT.json |', '',
        '## 3. 异构DOP端到端性能','',section('单查询性能'),'',
        section('结构分组结果'),'',
        '## 4. 成本模型与显式DOP交互项','',
        '主指标固定为历史/复杂两组排序准确率等权平均；真实延迟差小于3%的对统一排除，预测并列算错。固定17/29/43全部保留，不挑最佳种子。下表为同一920对上的模型及输入表示整体比较，非相同初始化、相同训练历史的纯架构干预。', '',
        '| 模型 | 三种子等权准确率均值 | 说明 |','|---|---:|---|',
        f"| Transformer＋竞争边 | {100*xgb['means']['transformer']:.3f}% | 历史初始化后错对强化与EMA；实际训练方式披露 |",
        f"| 基本XGBoost排序 | {100*xgb['means']['no_explicit_dop_interaction']:.3f}% | 明确移除显式DOP乘积项 |"]
    for kind,label in [('mlp_rank','MLP排序'),('mlp_smooth_rank','MLP平滑排序'),('mlp_regression','MLP直接回归')]:
        row=teacher['models'][kind]['macro_accuracy']
        lines.append(f"| {label} | {100*row['mean']:.3f}% | 完整显式交互特征，100轮 |")
    lines += [f"| 增强XGBoost排序 | {100*xgb['means']['full']:.3f}% | 保留DOP乘积项；结果保留 |", '',
        'Transformer均值优于基本XGBoost和上述MLP，但低于增强XGBoost，且不是每个种子均优于所有MLP。基本特征对照范围是在观察过旧结果后确定，应明确披露。XGBoost全行全列采样下三个种子结果相同，不代表三份独立数据。', '',
        'MLP/XGBoost完整输入为每fragment271维统计特征，经四种池化及全局统计得到1088维；基础XGBoost移除DOP乘积列后为556维。MLP消融保留1088维与相同初始化，将532个归一化乘积列置零，以隔离特征作用。Transformer使用图拓扑、DOP嵌入与竞争边，不直接输入这些手工乘积项。', '',
        '当前Transformer开发训练使用历史教师初始化，接续30轮、每轮624对、batch16、Adam学习率1e-4，每10轮刷新训练错对池并使用0.99参数EMA；这些是实际训练设置，不宣称为论文原有独立贡献。XGBoost为200棵树、深度3/6两档。MLP为64/64隐藏层、100轮、两档学习率。不同模型训练预算及初始化不同，不能据此将全部性能差异归因于架构。', '',
        '| MLP方法 | 完整交互 | 无显式交互 | 差值（百分点） |','|---|---:|---:|---:|']
    for kind,row in mlp['aggregate'].items():
        a,b=row['full_mean'],row['no_interaction_mean']
        lines.append(f'| {kind} | {100*a:.3f}% | {100*b:.3f}% | {100*(a-b):.3f} |')
    lines += ['', '三种子、两组学习率、固定100轮，按相同验证指标选设置和检查点；全部MLP方法在三个种子上均因交互项获益。详见 [模型与基本树对照](structure_coverage20/basic_feature_stability/REPORT.md)、[MLP特征消融](structure_coverage20/mlp_interaction_stability/REPORT.md)。', '',
        '![模型与显式DOP交互项对照](FINAL_MODEL_COMPARISON.png)', '',
        '### 同图结构的排序与直接回归补充','',
        '以下为较早的独立匹配实验：历史78训练/14验证计划、1077/148配置、699验证对，两个学习率、三种子、从头30轮，按候选选择损失选模。两组保留图和竞争边，比较动态间隔排序与log1p时延直接回归；两种目标每步所需前向次数不同。不能把这组准确率与上表920对接续训练的准确率直接相减。', '',
        '| 训练目标 | 三种子排序准确率 | 平均候选选择损失 | 单个所选模型训练秒均值 |','|---|---:|---:|---:|']
    for kind in ['transformer_rank','transformer_regression']:
        rows=[main_result['costs']['selected_training'][f'{kind}_s{s}'] for s in [17,29,43]]
        lines.append(f"| {kind} | {100*statistics.mean(r['validation']['rank_accuracy'] for r in rows):.3f}% | {100*statistics.mean(r['validation']['mean_regret'] for r in rows):.3f}% | {statistics.mean(r['seconds'] for r in rows):.2f} |")
    lines += ['', '该预算下排序目标的成对准确率及配置选择更好；没有由此证明所有训练预算下排序都优于回归。原始设置与逐种子值见 [模型训练结果](models_full/RESULT.json)。', '',
        '## 5. 搜索检索效率与结构消融','',
        '先完成4开发查询的小测，再对全部90条统一离线计时。六方法、3种子、每种子1次正式计时，共1620次正式搜索、540次预热；每次64候选评分。模型、竞争边实现、静态缓存和合法候选域相同。等价分组将组内DOP绑定，移除分组及独立随机搜索不作绑定，搜索空间差异是该消融的一部分。', '',
        '原MCTS已有注意力排序与等价分组；改进组在此基础上加入合法统一DOP锚点、按锚点评分尺度归一化回报，并以25%随机/75%当前最好配置补全未决变量。锚点评分及重复评分都计入64次预算。去注意力和去等价类组分别在改进组上删除相应机制，其他改进保留。因此不能把改进组对原MCTS的全部收益仅归因于注意力或等价类；这些搜索实现细节须与论文方法描述同步。', '',
        '每查询在搜索计时前，用独立固定随机种子2026091477生成256个参考候选、评分并去重，冻结其评分90/95/100百分位目标。参考候选不输入搜索；评估准备额外需要23040次评分，不计入任何方法搜索耗时。该分布不是全空间最优，也不是SQL延迟最优；不能将最高参考分称为全局最优。', '',
        '| 方法 | 16次内命中/270 | 32次内命中/270 | 64次内命中/270 | 100ms内命中/270 | 200ms内命中/270 | 完整64次耗时ms |','|---|---:|---:|---:|---:|---:|---:|']
    primary={r['method']:r for r in search['summary'] if r['target']=='0.95'}
    for method in search_protocol['modes']:
        r=primary[method];assert r['trials']==n
        lines.append(f"| {method} | {r['hit_by_evaluations']['16']} | {r['hit_by_evaluations']['32']} | {r['hits']} | {r['hit_by_median_time_ms']['100']} | {r['hit_by_median_time_ms']['200']} | {r['mean_trial_median_full_search_ms']:.2f} |")
    lines += ['', '表中主展示第95百分位；其他预定阈值完整保留。命中率同时包含未命中试验，不仅比较成功者平均耗时。时间从每次缓存初始化前开始，包含重要性编码、构图、评分、搜索和轨迹记录；不含模型加载、HTTP、FE、SQL。批量随机的16个分数一起可用，整批评分次数与耗时均计入。每种子仅1次计时，不能证明计时重复稳定性。', '',
        '![90查询的检索收敛曲线](retrieval_independent_report90/CONVERGENCE.png)', '',
        '实际优势应逐预算、目标和消融判断，不要求每个组件都获益；跑满64次的总成本与达到目标的效率是不同指标。详细数字与完整90/95/100目标见 [全量检索效率](retrieval_independent_report90/REPORT.md)。旧4查询经验池与新独立参考池目标不同，不能合并命中率或用新口径改写旧结果。', '',
        '已有720次配置回放中，64预算改进搜索平均SQL延迟比随机高2.00%、p99低12.50%；该项保留为输出质量参考。检索到更高教师分数不保证实际SQL更快，详见 [查询执行质量](search_budget_report90/collection/PAIRED_REPORT.md)。', '',
        '## 6. 在线策略及最后训练阶段消融','',
        '在线策略将离线搜索转为单次预测，主串行结果已覆盖服务调用与回退。四个最终阶段重训组从同一检查点开始，使用130训练计划、固定种子和1000轮，14验证计划及90条报告查询不参与梯度；固定最终检查点，不按SQL结果选模。每组训练循环约429.64–431.72s，不含初始化、构图、保存等。', '',
        body('policy_final_stage_ablation/online_full/REPORT.md').split('\n',1)[1].strip().replace(
            'One measured execution per query/arm; all frozen queries and fallbacks retained. Descriptive final-policy-stage ablation, not whole distillation or statistical robustness.',
            '每查询每组正式执行一次，保留全部冻结查询和回退；这是最后策略阶段的描述性消融，不代表完整蒸馏消融或重复稳定性。'), '',
        '这一补充支持最后阶段保留约束等的局部贡献，不等价于删除整个知识蒸馏。历史训练链可恢复性与数据来源见 [策略来源审计](policy_lineage_audit/REPORT.md)。', '',
        '## 7. 并发性能与资源预算','',section('完整90查询的原生预算并发对照'),'',
        '统一4预算是准入并发校准，不能写成DOP4。完整异构预测预算相对同预算原生平均请求延迟降低25.69%、整批耗时降低24.98%；在异构内部，预算相对静态平均降低11.49%，但p90、p99分别增加约18.70%、24.95%。这支持平均性能改善，同时存在尾延迟取舍。', '',
        '并发档位1/2/4/8/16及高负载失败记录见 [全部并发档位](FULL_REPORT.md#并发性能)；共同原生队列8/16/20客户端补充见 [队列实验](EXTENSION_SUMMARY.md)。原始OOM、重试、计划变化与环境修复保留，未用成功请求子集替代完整工作负载结果。不同BE版本和调度参数的曲线不拼接为同一扩展曲线。', '',
        '## 8. 调优与训练成本','',
        '| 测量范围 | 实测结果 | 解释 |','|---|---|---|',
        '| FE controller | 平均18.007ms，p9936.408ms | 180次正式计时，包含回退 |',
        '| controller占查询总延迟 | 1.104% | 不是占优化器时间，不能证明优化器开销<5% |',
        '| 缓存前/后改进搜索 | 303.30/240.95ms | 4开发查询，每次重新初始化缓存，4轮计时 |',
        '| 缓存前/后批量随机 | 225.64/172.83ms | 对照获得相同缓存优化，非改进搜索独占收益 |',
        '| 最后策略阶段训练循环 | 429.64–431.72s/组 | 1000轮；不含初始化和保存 |',
        '| 原始30候选训练累计 | 631.45s | 累计调参成本，不是单个模型成本 |',
        '| 原训练进程峰值RSS | 921.63MiB | 进程高水位，不是单模型净内存 |', '',
        '最新全90搜索成本见第5节。历史完整预训练墙钟成本因早期检查点/日志不完整而不能精确补造，实际接续训练与原始模型来源均保留。不同阶段、不同运行批次的计时不能直接相加冒充端到端实测。详见 [成本明细](FULL_REPORT.md#调优与训练成本)、[缓存成本](prepared_search_cost/REPORT.md)。', '',
        '## 9. 正确性、复现与交付范围','',
        'SQL结果多重集摘要、实际DOP安装和计划匹配按各采集阶段独立核验。主串行3条计划变化查询对全部配置整组补测，原失败记录保留；未仅补有利配置。离线检索预热/正式seed17轨迹一致，三种子随机逐条/批量候选相同且评分容差通过，运行时模块绑定已恢复。', '',
        '当前90查询报告范围的实验已完成，未新增生产代码或替换线上模型。合同要求的TP基准、TPC-H SF100优化器开销和streams7–20标准throughput未纳入本次完成声明。历史优势筛选、反复开发、增强树结果、消融不获益和并发尾延迟代价均属于解释结论所必需的实验限制。', '',
        '复现入口：[命令与阶段协议](REPRODUCE.md)、[查询清单](manifest.json)、[完整实验附录](FULL_REPORT.md)、[当前实验覆盖与产物摘要](FINAL_DELIVERY.json)。报告由 scripts/report90_final_delivery.py 从已完成产物生成，不执行SQL。', '']
    out=RUN/'FINAL_REPORT.md'
    out.write_text('\n'.join(lines)+'\n')
    sources += [Path(__file__),RUN/'manifest.json',RUN/'retrieval_independent_report90/CONVERGENCE.png',
                RUN/'FINAL_MODEL_COMPARISON.png',RUN/'FINAL_MODEL_COMPARISON.sources.json',
                RUN/'REPRODUCE.md',RUN/'PAPER_EXPERIMENT_SCOPE.md']
    coverage = dict(serial='completed90_queries',models='completed_shared_pairs_three_seeds',
        feature_ablation='completed_mlp_and_disclosed_xgb',ranking_regression='completed_matching30epoch_historical_cohort',
        retrieval='completed90_queries_six_methods_three_seeds',policy='completed_final_stage_only',
        concurrency='completed_finite_batch_comparisons',costs='completed_measured_scopes',
        historical_full_training_ablation='not_required_current_scope',contract='not_covered')
    (RUN/'FINAL_DELIVERY.json').write_text(json.dumps(dict(status='completed_current_report_experiment_scope',
        scope='90-query report with disclosed evidence limits; not all-method superiority, blind generalization or contract acceptance.',
        coverage=coverage,source_sha256={str(p):sha(p) for p in dict.fromkeys(sources)},
        report_sha256=sha(out)),indent=2)+'\n')
    print(out)


if __name__=='__main__':
    main()
