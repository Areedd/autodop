"""Freeze an eight-query development execution comparison after the model gate."""
import collections
import datetime
import json
from pathlib import Path

import numpy as np
import torch
import xgboost as xgb

from autodop.data import load_dataset
from autodop.graph import build_graph, sample_from_request
from autodop.model import load_cost_model
from autodop.training import file_sha256, select_partition
from report90_execute import RUN
from report90_models import flat_features
from collect_paper_evaluations import request_identity, VectorEngine
from build_trusted_dataset import digest

BASE = RUN / 'structure_coverage20'
COM = RUN / 'complex_development24'
OUT = BASE / 'execution8'


def read(path):
    return json.loads(path.read_text())


def main():
    assert not OUT.exists(), 'Preserve previous choices'
    replay = read(BASE / 'retrained/SCORE_REPLAY.json')
    assert replay['status'] == 'verified' and replay['development_gate_passed']
    result = read(BASE / 'retrained/RESULT.json')
    samples, pairs, metadata = load_dataset(BASE / 'merged_dataset')
    valid, _ = select_partition(samples, pairs, read(BASE / 'retrained/CONTRACT.json'), 'valid')
    groups = collections.defaultdict(list)
    for sample in valid:
        if sample['source_cohort'] == 'complex_new':
            groups[sample['template_id']].append(sample)
    assert len(groups) == 8 and all(len(v) == 8 for v in groups.values())
    evidence = [json.loads(l) for l in (COM / 'verified_labels/sample_evidence.jsonl').open()]
    wanted = {e['query_ids'][0]: e['template_id'] for e in evidence if e['split'] == 'valid'}
    requests = {}
    trace_path = COM / 'labels/collection/measured/accepted.jsonl'
    for line in trace_path.open():
        trace = json.loads(line)
        if trace['query_id'] in wanted:
            qid = wanted[trace['query_id']]
            request = trace['request']
            assert digest({'sql_sha256': groups[qid][0]['sql_sha256'],
                           'plan': request_identity(request)}) == groups[qid][0]['plan_key']
            requests.setdefault(qid, request)
    assert set(requests) == set(groups)
    torch.set_num_threads(1)
    norm = np.load(BASE / 'retrained/FEATURE_NORMALIZATION.npz')
    vectors, choices = {}, []
    sources = [Path(__file__), BASE / 'retrained/SCORE_REPLAY.json', BASE / 'retrained/RESULT.json',
               BASE / 'merged_dataset/samples.jsonl', BASE / 'retrained/FEATURE_NORMALIZATION.npz',
               COM / 'verified_labels/sample_evidence.jsonl', trace_path, COM / 'manifest.json', COM / 'TRUSTED_NATIVE.json']
    for kind, selected in result['selected'].items():
        path = Path(selected['model'])
        assert file_sha256(path) == selected['model_sha256']
        sources.append(path)
        if kind == 'transformer':
            model, checkpoint = load_cost_model(path)
            model.eval()
            assert checkpoint['metadata'] == metadata
        else:
            model = xgb.XGBRanker()
            model.load_model(path)
            model.set_params(n_jobs=1)
        mode = 'coverage_' + kind
        vectors[mode] = {}
        for qid, candidates in sorted(groups.items()):
            # Match validation.metrics: maximum score, then lexical config_key.
            candidates = sorted(candidates, key=lambda s: s['config_key'])
            graphs = [build_graph(s, metadata) for s in candidates]
            for candidate, graph in zip(candidates, graphs):
                live = build_graph({**sample_from_request(requests[qid]), 'dop_config': candidate['dop_config']}, metadata)
                assert graph.keys() == live.keys()
                for field in graph:
                    assert (torch.equal(graph[field], live[field]) if isinstance(graph[field], torch.Tensor)
                            else graph[field] == live[field]), (qid, field, 'request encoding differs')
            if kind == 'transformer':
                with torch.no_grad():
                    scores = [float(model(g)) for g in graphs]
            else:
                features = np.stack([(flat_features(g, metadata) - norm['mean']) / norm['std'] for g in graphs])
                scores = model.predict(features).astype(float).tolist()
            assert np.isfinite(scores).all()
            chosen = candidates[int(np.argmax(scores))]
            request = requests[qid]
            fragment_ids = sample_from_request(request)['fragment_ids']
            assert len(fragment_ids) == len(chosen['dop_config'])
            vectors[mode][qid] = {'request': request, 'fragment_dops': dict(zip(fragment_ids, chosen['dop_config']))}
            choices.append({'mode': mode, 'id': qid, 'plan_key': chosen['plan_key'],
                            'config_keys': [s['config_key'] for s in candidates], 'scores': scores,
                            'selected_config_key': chosen['config_key'], 'selected_dops': chosen['dop_config']})
        engine = VectorEngine(vectors[mode])
        for request in requests.values():
            engine.decide(request)
    manifest = read(COM / 'manifest.json')
    manifest['queries'] = [q for q in manifest['queries'] if q['id'] in groups]
    manifest['query_count'] = 8
    protocol = {'frozen_at': datetime.datetime.now().astimezone().isoformat(),
                'scope': 'Development pilot, all eight previously used validation queries. Same eight collected candidates per query. Not an independent test, online search, or report90 performance claim.',
                'modes': ['native', 'uniform4', *vectors], 'warmup': 1, 'repetitions': 1,
                'expected_executions': 80, 'seed': 2026091321,
                'gate': 'All executions independently verified, frontend settings restored, and Transformer measured mean latency no greater than either XGBoost before considering expansion. No automatic full run or deployment.',
                'failure_policy': 'Preserve any plan mismatch and all failures; do not discard queries or pick faster reruns.',
                'source_sha256': {str(p): file_sha256(p) for p in sources}}
    OUT.mkdir()
    for name, data in [('manifest.json', manifest), ('vectors.json', vectors), ('CHOICES.json', choices), ('PROTOCOL.json', protocol)]:
        (OUT / name).write_text(json.dumps(data, indent=2) + '\n')
    print(json.dumps({'queries': 8, 'model_choices': len(choices), 'expected_executions': 80}))


if __name__ == '__main__':
    main()
