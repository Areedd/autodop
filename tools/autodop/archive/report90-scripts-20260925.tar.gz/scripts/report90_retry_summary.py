"""Verify logical task coverage and retained retry chains separately from SQL traces."""
import json
from pathlib import Path
import numpy as np


def summarize(out):
    read=lambda p:json.loads(p.read_text())
    scored=out/'scored';proof=read(scored/'independent_verification.json')
    assert proof['evidence_valid'] and not proof['missing_slots']
    assert proof['expected_slots']==proof['recorded_sql_slots']==204
    events=[json.loads(s) for s in (scored/'events.jsonl').read_text().splitlines()]
    assert len(events)==204
    for e in events:
        attempts=e['sql_attempts'];assert len(attempts)==e['sql_attempt_count'] and 1<=len(attempts)<=4
        assert [a['attempt_index'] for a in attempts]==list(range(len(attempts)))
        assert e['retry_backoff_seconds']==[1.,2.,4.][:len(attempts)-1]
        assert e['logical_request_latency_ms']>=sum(a['client_latency_ms'] for a in attempts)
        assert e['client_latency_ms']==attempts[-1]['client_latency_ms']
        for a in attempts[:-1]:
            assert a['status']=='failed' and 'Memory of process exceed limit' in a['error']
        if e['status']=='verified':
            assert attempts[-1]['status']=='sql_succeeded_pending_digest_and_trace_verification'
        else:
            assert e['status']=='failed' and 'Memory of process exceed limit' in e['error']
            assert len(attempts)==4 and attempts[-1]['status']=='failed'
    rounds=read(scored/'collection.json')['rounds'];metrics={}
    for mode in ['native','policy_static','policy_load']:
        formal=[e for e in events if e['phase']=='measured' and e['mode']==mode]
        rr=[r for r in rounds if r['phase']=='measured' and r['mode']==mode]
        assert len(formal)==34 and len(rr)==1
        success=sum(e['status']=='verified' for e in formal);assert success==rr[0]['verified']
        logical=[e['logical_request_latency_ms'] for e in formal]
        metrics[mode]={'logical_tasks':34,'completed_tasks':success,'physical_sql_attempts':sum(e['sql_attempt_count'] for e in formal),
                       'failed_physical_attempts':sum(a['status']=='failed' for e in formal for a in e['sql_attempts']),
                       'batch_seconds':rr[0]['workload_wall_seconds'],
                       'verified_tasks_per_second':success/rr[0]['workload_wall_seconds'],
                       'time_to_all_tasks_seconds':rr[0]['workload_wall_seconds'] if success==34 else None,
                       'logical_latency_ms':dict(zip(['mean','p50','p90','p99'],[float(np.mean(logical)),*map(float,np.percentile(logical,[50,90,99]))]))}
    assert read(out/'QUEUE_SETTINGS.json')['restored'] and read(scored/'frontend_settings.json')['restored']
    result={'status':'verified','metrics':metrics,'logical_tasks_all_phases':204,
            'physical_attempts_all_phases':sum(e['sql_attempt_count'] for e in events),
            'scope':'17 historical development queries, bounded client retry policy identical for all modes. Final successful SQL independently traced; failed attempts retained as client errors and identity candidates, not claimed trace-linked. Finite batch, no report90 or contractual/steady-state claim.'}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 相同任务集合的有限重试并发小测','',result['scope'],'',
           '| 模式 | 正式任务完成 | SQL尝试 | 失败尝试 | 整批秒数 | 已核验任务/秒 | 全部任务完成秒数 |',
           '|---|---:|---:|---:|---:|---:|---:|']
    for mode,m in metrics.items():
        complete='未全部完成' if m['time_to_all_tasks_seconds'] is None else f"{m['time_to_all_tasks_seconds']:.2f}"
        lines.append(f"| {mode} | {m['completed_tasks']}/34 | {m['physical_sql_attempts']} | {m['failed_physical_attempts']} | {m['batch_seconds']:.2f} | {m['verified_tasks_per_second']:.4f} | {complete} |")
    lines+=['','最多4次SQL尝试，仅对实际BE进程内存超限错误重试，等待1/2/4秒。等待与失败耗时包含在整批和逻辑请求计时中。原client_latency_ms仍表示最后一次SQL执行及取数耗时，不能当作包含重试的请求延迟。客户端重试不是AutoDOP贡献，各模式共用；本实验不覆盖或替换原无重试结果。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    return result
