"""Offline decomposition; hypothetical integer rounding is not deployed or tuned."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics

RUN=Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def describe(rows):
    def median(key):return statistics.median(r[key] for r in rows)
    return dict(count=len(rows),raw_budget_under=sum(r['raw_budget_bytes']<r['observed_bytes'] for r in rows),
                legacy_nominal_under=sum(r['legacy_bytes']<r['observed_bytes'] for r in rows),
                hypothetical_integer_nominal_under=sum(r['integer_bytes']<r['observed_bytes'] for r in rows),
                integer_scaled_budget_failures=sum(r['integer_bytes']*3<r['raw_budget_bytes']*5 for r in rows),
                median_legacy_observed_ratio=median('legacy_observed_ratio'),
                median_integer_observed_ratio=median('integer_observed_ratio'),
                median_power2_over_integer_ratio=median('rounding_ratio'),
                total_nominal_reduction_percent=100*(1-sum(r['integer_bytes'] for r in rows)/sum(r['legacy_bytes'] for r in rows)),
                legacy_slot_counts=dict(Counter(str(r['legacy_slots']) for r in rows)),
                hypothetical_integer_slot_counts=dict(Counter(str(r['integer_slots']) for r in rows)))


def main():
    model_path=RUN/'native_predictor_service17/MODEL.json';m=json.loads(model_path.read_text())
    slot=int(m['slot_bytes']);workers=int(m['workers']);cap=int(m['slots_per_worker'])
    dev_path=RUN/'native_memory_prediction_loo17/RESULT.json';dev=json.loads(dev_path.read_text())
    report_path=RUN/'report90_frozen_budget_evaluation/RESULT.json';report=json.loads(report_path.read_text())
    populations={}
    for label,inputs in [('development_loo17',[r for r in dev['rows'] if r['model']=='neighbor_max3']),('frozen_report180',report['rows'])]:
        rows=[]
        for r in inputs:
            if label=='development_loo17':
                assert r['id'] not in r['train_ids'] and len(r['train_ids'])==16
                predicted=int(r['predicted_bytes']);observed=int(r['observed_peak_bytes'])
                budget=max(64*1024**2,(5*predicted+3)//4)
            else:
                predicted=r['prediction']['predicted_peak_bytes'];observed=r['observed_peak_upper_bytes'];budget=r['prediction']['budget_bytes']
            needed=(budget*5+3*slot-1)//(3*slot)
            rounded=1<<(max(needed,1)-1).bit_length()
            integer=min(needed,cap);legacy=min(rounded,cap)
            if label=='frozen_report180':assert legacy*slot==r['prediction']['nominal_bytes_per_worker']
            rows.append(dict(id=r['id'],pipeline_dop=r.get('pipeline_dop'),predicted_bytes=predicted,observed_bytes=observed,
                             raw_budget_bytes=budget,legacy_bytes=legacy*slot,integer_bytes=integer*slot,
                             legacy_slots=legacy*workers,integer_slots=integer*workers,
                             legacy_observed_ratio=legacy*slot/observed,integer_observed_ratio=integer*slot/observed,
                             rounding_ratio=legacy/integer))
        populations[label]=dict(summary=describe(rows),rows=rows)
    sources=[Path(__file__),model_path,dev_path,report_path,Path('fe/fe-core/src/main/java/com/starrocks/qe/scheduler/slot/SlotEstimatorFactory.java')]
    result=dict(status='offline_diagnostic',budget_multiplier=1.25,headroom_multiplier=5/3,
                combined_before_rounding=25/12,populations=populations,
                scope='No fitting, parameter search, SQL execution or deployment. Development OOF and selected-report observations kept separate. Integer rounding preserves existing model and safety multipliers; comparison is hypothetical and does not prove throughput, tail latency or OOM safety. Current FE independently rounds to powers of two, so predictor-only changes cannot realize integer slots.',
                source_sha256={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    out=RUN/'budget_rounding_analysis';out.mkdir(exist_ok=True);(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 预算预留与槽位取整离线诊断','',result['scope'],'',
           '当前链路：峰值预测 × 1.25 安全系数 ÷ 0.6 资源余量系数，再向上取整到槽位并取 2 的幂。仅前两个系数已将预测放大约 2.0833 倍。', '',
           '| 数据范围 | 数量 | 当前名义容量不足 | 假设整数槽位容量不足 | 当前预留/观测中位 | 整数槽位预留/观测中位 | 名义预留总量降低 |','|---|---:|---:|---:|---:|---:|---:|']
    for name,p in populations.items():
        s=p['summary'];lines.append(f"| {name} | {s['count']} | {s['legacy_nominal_under']} | {s['hypothetical_integer_nominal_under']} | {s['median_legacy_observed_ratio']:.3f} | {s['median_integer_observed_ratio']:.3f} | {s['total_nominal_reduction_percent']:.2f}% |")
    lines+=['','容量不足指单查询观测峰值高于分配名义容量，不等于已经发生 OOM；反之观测覆盖也不是未来安全保证。保留低估样本，不能将预留减少比例当成延迟或吞吐收益。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:v['summary'] for k,v in populations.items()},indent=2))


if __name__=='__main__':main()
