"""Report both scheduler arms without selecting favorable modes or queries."""
import hashlib
import json
from pathlib import Path

RUN = Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def main():
    out = RUN/'native_mixed_scheduler_comparison'
    arms = {}
    sources = [Path(__file__)]
    for name in ('swrr', 'fifo'):
        directory = RUN/('report90_native_budget_mixed_'+name)
        path = directory/'ALLOCATION_AUDIT.json'
        audit = json.loads(path.read_text())
        assert audit['status']=='verified' and audit['executions']==128
        protocol = json.loads((directory/'PROTOCOL.json').read_text())
        assert protocol['schedule'].lower()==name
        arms[name] = dict(metrics=audit['metrics'], protocol=protocol)
        sources.extend([path, directory/'PROTOCOL.json', directory/'SCHEDULE.json'])
    # Same frozen model/SQL/collector; only schedule and per-arm output differ.
    assert arms['swrr']['protocol']['source_sha256']==arms['fifo']['protocol']['source_sha256']
    reductions = {mode:{key:100*(1-arms['fifo']['metrics'][mode][key]/base[key])
                           for key in ('batch_seconds','mean_ms','p50_ms','p90_ms','p99_ms')}
                  for mode,base in arms['swrr']['metrics'].items()}
    plan_path = RUN/'native_mixed_plan_audit/RESULT.json'
    wait_path = RUN/'native_mixed_scheduler_wait_analysis/RESULT.json'
    plan = json.loads(plan_path.read_text())
    paired = json.loads(wait_path.read_text())
    sources += [plan_path, wait_path]
    out.mkdir(exist_ok=True)
    result = dict(status='verified_pilot', executions=256, fifo_reduction_percent=reductions,
                  metrics={k:v['metrics'] for k,v in arms.items()},
                  plan_variants_per_query=plan['variants_per_query'],
                  paired_installed_vector_changes=paired['vector_changes'],
                  decision='Do not expand FIFO performance trials from this pilot; first diagnose plan variation.',
                  scope='First frozen query from each 24/48-slot class repeated across 16 clients, one warmup and one measured batch per mode per arm. SWRR then FIFO in the same FE process, not randomized or causal proof. One query has 38/39-fragment plan variants and 24 of 64 heterogeneous pairs change installed DOP vectors; scheduler effects are not isolated. All four modes retained. No automatic expansion or significance/generalization claim.',
                  source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# SWRR/FIFO 同日志小测','','正值表示 FIFO 延迟降低，负值表示恶化。','','| 模式 | 整批时间 | 平均 | p50 | p90 | p99 |','|---|---:|---:|---:|---:|---:|']
    for mode,row in reductions.items():
        lines.append('| '+mode+' | '+' | '.join(f'{v:.2f}%' for v in row.values())+' |')
    lines+=['',result['scope'], '', '本轮不支持 FIFO 改善异构预测预算模式：平均延迟增加 6.47%，p90/p99 分别增加 3.95%/3.30%。同时存在计划结构和 DOP 向量变化，不能把差异归因于调度器本身；先定位计划变化，不扩大 FIFO 全量实验。', '', '[配对等待分析](../native_mixed_scheduler_wait_analysis/REPORT.md)；[计划描述审计](../native_mixed_plan_audit/RESULT.json)。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
