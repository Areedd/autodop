"""Plot all frozen continuation candidates from completed training records."""
import json
from pathlib import Path


def render(result,output):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    output=Path(output)
    fig,axes=plt.subplots(1,3,figsize=(14,4),constrained_layout=True)
    export={}
    for candidate in result['candidates']:
        if candidate['kind']!='transformer':continue
        history=candidate['history'];assert [x['epoch'] for x in history]==list(range(1,101))
        label=f"Transformer lr={candidate['learning_rate']:g}"
        checks=[x for x in history if 'validation' in x]
        axes[0].plot([x['epoch'] for x in history],[x['loss'] for x in history],label=label)
        axes[1].plot([x['epoch'] for x in checks],[100*x['validation']['weighted_regret'] for x in checks],marker='o',label=label)
        axes[2].plot([x['epoch'] for x in checks],[100*x['validation']['cohorts']['complex_new']['mean_regret'] for x in checks],marker='o',label=label)
        export[label]={'history':history,'selected_epoch':candidate['selected']['epoch']}
    for kind in ['xgboost_points','xgboost_pairs']:
        q=result['selected'][kind]['selected']['validation']
        axes[1].axhline(100*q['weighted_regret'],linestyle='--',label=kind)
        axes[2].axhline(100*q['cohorts']['complex_new']['mean_regret'],linestyle='--',label=kind)
    for axis,title,ylabel in zip(axes,['Training objective','Validation: equal cohort weight','Validation: complex cohort'],['Ranking + preservation loss','Configuration regret (%)','Configuration regret (%)']):
        axis.set(title=title,xlabel='Continuation epoch',ylabel=ylabel)
        axis.grid(alpha=.2);axis.legend(fontsize=7)
    fig.savefig(output/'LEARNING_CURVES.png',dpi=180)
    fig.savefig(output/'LEARNING_CURVES.svg')
    plt.close(fig)
    (output/'LEARNING_CURVES.json').write_text(json.dumps({'scope':'All declared Transformer candidates/checkpoints; horizontal lines are selected XGBoost validation results, not their learning curves. Validation is used for selection.','curves':export},indent=2)+'\n')
