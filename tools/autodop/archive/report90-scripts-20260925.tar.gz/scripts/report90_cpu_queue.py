"""Run the frozen corrected-BE pilot before expanding to the complete workload."""
from concurrent.futures import ThreadPoolExecutor
import datetime
import hashlib
import json
import os
from pathlib import Path
import statistics
import threading

import report90_queue_extension as queue
from report90_cpu_deployment_check import check as check_deployment
from report90_cpu_observe import observe
from report90_extension_summary import summarize

RUN = queue.RUN
FIX = RUN / 'cpu_capacity_fix'
OUT = RUN / 'queue_cpu_corrected_20260913'


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def cpu_gate(stage, observation):
    result = summarize(stage)
    assert result['status'] == 'verified', result['status']
    assert read(stage / 'scored/frontend_settings.json')['restored']
    samples = [json.loads(line) for line in observation.read_text().splitlines()]
    samples = [r for r in samples if r['type'] == 'sample']
    capacity = {}
    for name in ('starrocks-be1', 'starrocks-be2', 'starrocks-be3'):
        busy = [n for r in samples for n in r['workers']
                if n['container'] == name and n['process_fraction_of_capacity'] >= .5]
        assert len(busy) >= 3, f'Insufficient busy CPU samples: {name}'
        assert all(int(n['fe_reported_cores']) == 8 and str(n['alive']).lower() == 'true' for n in busy)
        actual = statistics.median(n['process_fraction_of_capacity'] for n in busy)
        reported = statistics.median(n['fe_reported_fraction'] for n in busy)
        capacity[name] = {'busy_samples': len(busy), 'median_actual': actual, 'median_reported': reported}
        # Coarse capacity gate, not pointwise equality: process and FE windows differ.
        assert abs(actual - reported) <= .2, f'CPU normalization still inconsistent: {capacity[name]}'
    applied = {r['query_id'] for line in (stage / 'scored/events.jsonl').open()
               if (r := json.loads(line)).get('phase') == 'measured'
               and r.get('mode') == 'policy_load' and r.get('dop_validation', {}).get('applied')}
    cpu_only = []
    for line in (stage / 'scored/decisions.jsonl').open():
        row = json.loads(line)
        if row['query_id'] not in applied:
            continue
        fragments = {f['fragment_id']: f for f in row['request']['fragments']}
        loads = row['request'].get('worker_loads', {})
        for decision in row['response']['decisions']:
            if 'load_corrected' not in decision.get('reason', ''):
                continue
            ids = [str(w) for w in fragments[decision['fragment_id']].get('worker_ids', [])]
            values = [loads.get(w, {}) for w in ids]
            if (values and all(v.get('fresh') and v['mem_used_pct'] <= .65 for v in values)
                    and any(v['cpu_used'] > .4 for v in values)):
                cpu_only.append({'query_id': row['query_id'], 'fragment_id': decision['fragment_id'],
                                 'installed_dop': decision['dop'], 'worker_ids': ids, 'loads': values})
    audit = {'status': 'passed' if cpu_only else 'cpu_only_correction_not_observed',
             'capacity': capacity, 'cpu_only_applied_fragments': cpu_only,
             'query_summary': result,
             'observer_sha256': hashlib.sha256(observation.read_bytes()).hexdigest()}
    save(stage / 'CPU_GATE.json', audit)
    assert cpu_only, 'No installed CPU-only correction; do not expand'


def main():
    assert not OUT.exists(), 'Preserve existing corrected-BE experiment'
    for name in ('queue_extension_20260913_attempt3', 'convergence_execution_20260913', 'search_convergence_20260913'):
        assert read(RUN / name / 'STATUS.json')['status'] == 'complete', name
    validation = read(FIX / 'DEPLOYMENT_VALIDATION.json')
    assert validation['status'] == 'health_and_sql_parity_verified'
    image = read(FIX / 'CANDIDATE_IMAGE.json')
    assert validation['candidate_image_id'] == image['candidate_image_id']
    check_deployment(image['candidate_image_id'], FIX / 'compose_candidate.json')
    protocol = read(FIX / 'LOAD_CORRECTION_PROTOCOL.json')
    for path, expected in [(Path(protocol['model']), protocol['model_sha256']),
                           (Path(protocol['workload']['manifest']), protocol['workload']['sha256'])]:
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
    assert read(RUN / 'PROTOCOL.json')['model'] == protocol['model']
    OUT.mkdir()
    queue.OUT = OUT
    save(OUT / 'PROTOCOL.json', {**protocol,
         'additional_cpu_gate': 'At least3 busy samples per BE (actual>=.5), median FE and actual capacity fractions differ by<=.2; at least1 installed formal load-corrected fragment with all fresh target workers below memory threshold and CPU above threshold.',
         'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in
                           [Path(__file__), Path(queue.__file__)]}})
    try:
        for name, clients, pilot in [('pilot_c16', 16, True), ('full_c8', 8, False),
                                      ('full_c16', 16, False), ('full_c20', 20, False)]:
            stop = threading.Event()
            observer = OUT / (name + '_CPU.jsonl')
            with ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(observe, observer, 10000, 3, stop)
                try:
                    stage = queue.run_stage(name, clients, pilot)
                finally:
                    stop.set()
                    future.result(timeout=30)
            cpu_gate(stage, observer)
        save(OUT / 'STATUS.json', {'status': 'complete', 'at': datetime.datetime.now().astimezone().isoformat()})
    except BaseException as error:
        save(OUT / 'STATUS.json', {'status': 'failed', 'error': repr(error), 'pid': os.getpid()})
        raise


if __name__ == '__main__':
    main()
