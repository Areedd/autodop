"""Wait for the existing idle gate without changing its threshold or restarting FE."""
import json
from pathlib import Path
import time


def wait_for_idle(check, output, attempts=6, pause_seconds=10, sleep=time.sleep):
    output = Path(output)
    history = []
    for attempt in range(attempts):
        path = output.with_name(output.stem+f'.attempt{attempt+1}'+output.suffix)
        try:
            check(path)
        except RuntimeError:
            # Only retry a confirmed busy measurement; other failures propagate.
            if not path.exists() or json.loads(path.read_text()).get('status') != 'busy':
                raise
            history.append(json.loads(path.read_text()))
            output.write_text(json.dumps(dict(status='waiting', attempts=history),indent=2)+'\n')
            if attempt+1 == attempts:
                raise RuntimeError('Idle gate stayed busy; no measurements started')
            sleep(pause_seconds)
        else:
            history.append(json.loads(path.read_text()))
            output.write_text(json.dumps(dict(history[-1], attempts=history),indent=2)+'\n')
            return
