"""Replicate the explicitly labelled basic-feature comparator at fixed seeds."""
import json
from pathlib import Path
import subprocess
import sys
from report90_interaction_pair_audit import BASE, sha, accuracy


def main():
    out=BASE/'basic_feature_stability';out.mkdir(exist_ok=False)
    source=Path(__file__).with_name('report90_xgb_feature_ablation.py')
    def save(name,value): (out/name).write_text(json.dumps(value,indent=2)+'\n')
    save('PROTOCOL.json',dict(seeds=[17,29,43],reuse_seed17=str(BASE/'xgb_feature_ablation_pilot'),
         design='Replicate full and no-explicit-DOP-interaction XGBoost at seeds29,43; same200trees, depths3/6, training weights and macro-first selection. Reuse all three already audited hardEMA Transformers.',
         scope='Development diagnostic selected after prior enhanced-baseline results. Does not replace all-model acceptance or blind-test evaluation. No SQL or deployment.',
         source_sha256={str(p):sha(p) for p in [Path(__file__),source,BASE/'xgb_feature_ablation_pilot/RESULT.json']}))
    for seed in [29,43]:
        text=source.read_text()
        changes={"BASE = ROOT/'runs/report90_20260912/structure_coverage20'":'BASE = Path('+repr(str(BASE))+')',
                 "ROOT = Path(__file__).resolve().parents[1]":'ROOT = Path('+repr(str(Path(__file__).resolve().parents[1]))+')',
                 "out = BASE/'xgb_feature_ablation_pilot'":'out = Path('+repr(str(out/f'seed{seed}'))+')',
                 'seed=17':f'seed={seed}', 'random_state=17':f'random_state={seed}',
                 '    protocol = dict(':"    masks = {k:v for k,v in masks.items() if k in ('full','no_explicit_dop_interaction')}\n    protocol = dict(",
                 'One-seed pilot, no stability claim.':f'Seed{seed} replication; aggregate all three seeds in parent report.',
                 '全部8个模型':'本轮全部4个模型'}
        # The Chinese source currently says 每个模型, so retain only actual edits.
        changes.pop('全部8个模型')
        for old,new in changes.items():
            assert text.count(old)==1,(old,text.count(old))
            text=text.replace(old,new)
        script=out/f'seed{seed}_trainer.py';compile(text,str(script),'exec');script.write_text(text)
        save(f'seed{seed}_TRANSFORM.json',dict(original_sha256=sha(source),generated_sha256=sha(script),changes=changes))
        save('STATUS.json',dict(status='running',seed=seed))
        with (out/f'seed{seed}.log').open('w') as log:
            subprocess.run([sys.executable,str(script)],stdout=log,stderr=subprocess.STDOUT,check=True)
    records=[];sources=[]
    for seed in [17,29,43]:
        xfolder=BASE/'xgb_feature_ablation_pilot' if seed==17 else out/f'seed{seed}'
        tfolder=BASE/'hard_pair_ema_pilot/pair_audit' if seed==17 else BASE/f'hard_pair_ema_stability/pair_audit_seed{seed}'
        xr=json.loads((xfolder/'RESULT.json').read_text());tr=json.loads((tfolder/'RESULT.json').read_text())
        pool=json.loads((tfolder/'PAIR_POOL.json').read_text());rows=json.loads((xfolder/'VALIDATION_ROWS.json').read_text())
        assert xr['status']=='verified' and tr['status']=='verified_independent_pair_replay'
        key=lambda s:(s['plan_key'],s['config_key'])
        ix={key(s):i for i,s in enumerate(rows)}
        assert set(ix)=={key(s) for s in pool['samples']}
        for s in pool['samples']:
            assert rows[ix[key(s)]]['latency_ms']==s['latency_ms']
        r=dict(seed=seed,transformer=tr['models']['transformer']['macro_accuracy'])
        for arm in ['full','no_explicit_dop_interaction']:
            selected=xr['selected'][arm]
            scores=[selected['scores'][ix[key(s)]] for s in pool['samples']]
            q=accuracy(pool['pairs'],scores)
            assert q['macro_accuracy']==selected['quality']['weighted_rank_accuracy']
            r[arm]=q['macro_accuracy']
        records.append(r)
        sources.extend([xfolder/'RESULT.json',xfolder/'VALIDATION_ROWS.json',tfolder/'RESULT.json',tfolder/'PAIR_POOL.json'])
    means={k:sum(r[k] for r in records)/3 for k in ['transformer','full','no_explicit_dop_interaction']}
    save('RESULT.json',dict(status='verified_three_seed_shared_pairs',records=records,means=means,
          all_seeds_above_basic=all(r['transformer']>r['no_explicit_dop_interaction'] for r in records),
          all_seeds_above_enhanced=all(r['transformer']>r['full'] for r in records),
          source_sha256={str(p):sha(p) for p in sources+[Path(__file__),out/'PROTOCOL.json']}))
    lines=['# 基础特征基线三种子复核','',
           '| seed | Transformer | XGBoost基础特征 | XGBoost增强特征 |','|---:|---:|---:|---:|']
    for r in records+[dict(seed='均值',**means)]:
        lines.append(f"| {r['seed']} | {100*r['transformer']:.4f}% | {100*r['no_explicit_dop_interaction']:.4f}% | {100*r['full']:.4f}% |")
    lines += ['', '主指标：两类查询等权排序准确率。固定三个种子全部报告，不选最佳种子。相同212配置及920排序对已对齐并重新计数。', '',
              '基础特征明确移除DOP乘积项；增强特征完整保留。两类模型训练历史与输入表示不同，且验证集反复使用。本次对照范围在观察已有结果后确定，不能当作预注册盲测或独立结构泛化结论。', '',
              'XGBoost使用全样本和全特征采样时，不同随机种子可能得到相同模型；相同结果不代表三次独立数据实验。', '',
              '完整记录：[RESULT.json](RESULT.json)、[协议](PROTOCOL.json)。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    save('STATUS.json',dict(status='verified_complete'))
    print(json.dumps(means,indent=2))


if __name__=='__main__':main()
