"""Small development trial: constrain pair-score gaps with measured log latency ratios."""
import argparse
import datetime
import os
from pathlib import Path
import subprocess
import sys

import torch
from autodop.training import file_sha256
import report90_coverage_stability as common
from report90_interaction_model import load_interaction_model

BASE = common.BASE
OUT = BASE / 'pair_calibration_pilot'
SOURCE = BASE / 'interaction_ranking/seed17_trainer.py'


def main(stage):
    os.sched_setaffinity(0, {35})
    torch.set_num_threads(1)
    common.load_cost_model = load_interaction_model
    if stage == 'smoke':
        assert not OUT.exists()
        OUT.mkdir()
        common.save(OUT / 'PROTOCOL.json', {
            'at': datetime.datetime.now().astimezone().isoformat(),
            'seed': 17, 'smoke_epochs': 2, 'pilot_epochs': 30,
            'loss': 'softplus(log(slow/fast)-a+b) + 0.1*smooth_l1(a-b, log(slow/fast))',
            'hypothesis': 'Limit unbounded score separation encouraged by pure ranking loss while retaining its ordering objective. Compare to the identical original first30-epoch schedule.',
            'unchanged': 'Same original multistage initialization plus zero-initialized DOP interactions, training partition, pair sampling, Adam1e-4, cosine100-epoch horizon, batch16, historical preservation0, and accuracy-first selection.',
            'selection': 'Equal-weight historical/complex validation pair accuracy, then regret, then earlier epoch. No report90 labels or best-seed selection.',
            'scope': 'Two-epoch smoke then one-seed30-epoch development pilot. No automatic full training, SQL or deployment. Reused development validation is not an independent test.',
            'source_sha256': {str(p): file_sha256(p) for p in [Path(__file__), SOURCE,
                Path(common.__file__), Path(__file__).with_name('report90_interaction_model.py'),
                BASE / 'interaction_fit_audit_seed17.json', BASE / 'interaction_error_diagnostic_seed17.json']}})
    protocol = common.read(OUT / 'PROTOCOL.json')
    for p, digest in protocol['source_sha256'].items():
        assert file_sha256(p) == digest
    if stage == 'pilot':
        assert common.read(OUT / 'smoke/SCORE_REPLAY.json')['status'] == 'verified'
    folder = OUT / stage
    assert not folder.exists()
    text = SOURCE.read_text()
    substitutions = {
        repr(str(BASE / 'interaction_ranking/seed17')): repr(str(folder)),
        repr(str(BASE / 'interaction_ranking/PROTOCOL.json')): repr(str(OUT / 'PROTOCOL.json')),
        'range(1,101)': 'range(1,3)' if stage == 'smoke' else 'range(1,31)',
        'ranking.append(torch.nn.functional.softplus(target-a+b))':
            'ranking.append(torch.nn.functional.softplus(target-a+b) + 0.1*torch.nn.functional.smooth_l1_loss(a-b,target))',
    }
    if stage == 'smoke':
        substitutions.update({'epoch%10==0': 'epoch%1==0', 'n_estimators=200': 'n_estimators=5'})
    changes = {}
    for old, new in substitutions.items():
        count = text.count(old)
        assert count == (2 if old in ['epoch%10==0', repr(str(BASE / 'interaction_ranking/PROTOCOL.json'))] else 1), (old, count)
        text = text.replace(old, new)
        changes[old] = {'replacement': new, 'occurrences': count}
    script = OUT / f'{stage}_trainer.py'
    compile(text, str(script), 'exec')
    script.write_text(text)
    common.save(OUT / f'{stage}_SOURCE_TRANSFORM.json', {
        'original_sha256': file_sha256(SOURCE), 'generated_sha256': file_sha256(script), 'changes': changes})
    common.save(OUT / 'STATUS.json', {'status': 'running', 'stage': stage, 'pid': os.getpid()})
    with (OUT / f'{stage}.log').open('w') as stream:
        subprocess.run([sys.executable, str(script)], stdout=stream, stderr=subprocess.STDOUT, check=True)
    verified = common.replay(folder)
    common.save(OUT / 'STATUS.json', {'status': stage + '_verified', 'stage': stage})
    if stage == 'pilot':
        reference = common.read(BASE / 'interaction_ranking/seed17/transformer_h0/RESULT.json')
        eligible = [h for h in reference['history'] if h['epoch'] <= 30 and 'validation' in h]
        before = min(eligible, key=lambda h: (-h['validation']['weighted_rank_accuracy'], h['validation']['weighted_regret'], h['epoch']))
        after = verified['transformer']
        common.save(OUT / 'RESULT.json', {
            'status': 'verified', 'before_first30': before, 'after': verified,
            'improves_matched_reference': after['weighted_rank_accuracy'] > before['validation']['weighted_rank_accuracy'],
            'scope': protocol['scope'], 'protocol_sha256': file_sha256(OUT / 'PROTOCOL.json')})
    print(stage, 'verified', verified['transformer']['weighted_rank_accuracy'], flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['smoke', 'pilot'], required=True)
    args = parser.parse_args()
    try:
        main(args.stage)
    except BaseException as error:
        if OUT.exists():
            common.save(OUT / 'STATUS.json', {'status': 'failed', 'error': repr(error)})
        raise
