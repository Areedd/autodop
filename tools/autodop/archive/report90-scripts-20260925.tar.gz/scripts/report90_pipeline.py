"""Run the authorized report90 stages sequentially; stop on failed evidence gates."""
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'runs/report90_20260912'


def save(path, value):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    tmp.replace(path)


def main(resume=False,resume_completed=False):
    lock = (RUN / 'PIPELINE.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    state = {'status': 'running', 'pid': os.getpid(), 'completed': []}

    def update(stage, **extra):
        state.update(stage=stage, updated_at=datetime.datetime.now().astimezone().isoformat(), **extra)
        save(RUN / 'PIPELINE_STATUS.json', state)
        print(json.dumps(state, ensure_ascii=False), flush=True)

    def wait_for(path, seconds):
        deadline = time.monotonic() + seconds
        while not path.exists():
            if time.monotonic() > deadline:
                raise TimeoutError(f'No completion evidence: {path}')
            time.sleep(10)
        return json.loads(path.read_text())

    def launch(label, script, *args):
        update(label)
        command = [sys.executable, str(ROOT / 'scripts' / script), *args]
        logfile=RUN/f'{label}.log'
        if logfile.exists() and resume_completed:logfile=RUN/f'{label}_resume_{time.time_ns()}.log'
        with logfile.open('x') as log:
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
        state['completed'].append(label)
        update(label)

    try:
        save(RUN / (f'RESUME_SOURCE_SHA256_{time.time_ns()}.json' if resume or resume_completed else 'EXECUTION_SOURCE_SHA256.json'), {
            str(p): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((ROOT / 'scripts').glob('report90_*.py'))
        })
        if resume_completed:
            assert json.loads((RUN/'serial_repair/scored/independent_verification.json').read_text())['all_expected_executions_verified']
            state['completed'].append('serial_repair')
        elif resume:
            update('wait_repair_pilot')
            assert wait_for(RUN/'repair_pilot/scored/independent_verification.json',1800)['all_expected_executions_verified']
            launch('serial_repair', 'report90_repair.py')
        else:
            update('wait_existing_serial_pilot')
            proof = wait_for(RUN / 'serial_pilot/scored/independent_verification.json', 1800)
            assert proof['all_expected_executions_verified'], 'Initial serial pilot failed'
            launch('choices_pilot_extended', 'report90_choices.py', '--stage', 'pilot', '--attempt', '3')
            launch('serial_pilot_extended', 'report90_execute.py', '--stage', 'serial_pilot', '--attempt', '1')
            update('wait_full_training')
            result = wait_for(RUN / 'models_full/RESULT.json', 7200)
            assert result['status'] == 'complete', 'Training did not complete'
            state['completed'].append('full_training')
            launch('choices_full', 'report90_choices.py', '--stage', 'full')
            launch('serial_full', 'report90_execute.py', '--stage', 'serial')
        launch('summary_after_serial', 'report90_summary.py')
        # Keep all 90 queries together. Separate concurrency levels to verify
        # completion before increasing load; never silently omit failed runs.
        for clients in (1, 2, 4, 8, 16):
            proof=RUN/f'concurrent_attempt{clients}/scored/independent_verification.json'
            if resume_completed and proof.exists():
                from report90_execute import accept_concurrent_evidence
                accept_concurrent_evidence(proof)
                state['completed'].append(f'concurrent_c{clients}')
                continue
            launch(f'concurrent_c{clients}', 'report90_execute.py', '--stage', 'concurrent',
                   '--attempt', str(clients), '--clients', str(clients))
            launch(f'summary_after_c{clients}', 'report90_summary.py')
        update('complete', status='complete')
    except BaseException as exc:
        update(state.get('stage', 'initialization'), status='failed', error=repr(exc),
               traceback=traceback.format_exc())
        raise


if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--resume-repair',action='store_true');parser.add_argument('--resume-completed',action='store_true')
    args=parser.parse_args();main(args.resume_repair,args.resume_completed)
