"""Freeze validation-selected extended model, then audit existing observed configurations."""
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from report90_models import RUN, prepare_data, metrics
from autodop.graph import build_graph, sample_from_request
from autodop.model import load_cost_model


def main():
    torch.set_num_threads(1)
    out = RUN / 'convergence_20260913'
    trained = json.loads((out / 'full/RESULT.json').read_text())
    assert trained['status'] == 'complete'
    winner = min(trained['results'], key=lambda r: (
        r['selected']['validation']['mean_regret'],
        -r['selected']['validation']['rank_accuracy'], r['setting']))
    model_path = out / f"full/h{winner['setting']}/best.pt"
    selected = {'setting': winner['setting'], 'epoch': winner['selected']['epoch'],
                'model': str(model_path), 'sha256': hashlib.sha256(model_path.read_bytes()).hexdigest(),
                'criterion': 'Historical validation mean regret, then ranking accuracy, then setting index. Fixed before reading any90-query scores or labels.'}
    selection_path = out / 'SELECTED.json'
    if selection_path.exists():
        assert json.loads(selection_path.read_text()) == selected
    else:
        selection_path.write_text(json.dumps(selected, indent=2) + '\n')
    model, ck = load_cost_model(model_path)
    model.eval()
    _, _, valid, _, _, _ = prepare_data()
    def score(sample):
        with torch.no_grad():
            return float(model(build_graph(sample, ck['metadata'])))
    validation = metrics(valid, [score(s) for s in valid])
    assert validation == winner['selected']['validation']
    # Now access observed90 data for descriptive evaluation, never selection.
    original = json.loads((RUN / 'original_teacher_audit/RESULT.json').read_text())
    observed_path = RUN / 'original_teacher_audit/POOL_SCORES.json'
    observed = json.loads(observed_path.read_text())
    summary = json.loads((RUN / 'SUMMARY.json').read_text())
    repaired = set(summary['serial_repair']['replaced_queries'])
    vectors = {name: json.loads((RUN / name / 'vectors.json').read_text()) for name in ['choices', 'choices_attempt1']}
    samples = {}
    for q in sorted({r['id'] for r in observed}):
        folder = 'choices_attempt1' if q in repaired else 'choices'
        samples[q] = sample_from_request(vectors[folder]['policy_vector'][q]['request'])
    assert len(samples) == 90
    scores, labels, detail = [], [], []
    for row in observed:
        q = row['id']
        assert len(row['dops']) == len(samples[q]['fragment_ids'])
        value = score({**samples[q], 'dop_config': row['dops']})
        scores.append(value)
        labels.append({'plan_key': q, 'config_key': str(tuple(row['dops'])),
                       'latency_ms': float(np.mean(row['mode_mean_latencies_ms']))})
        detail.append({'id': q, 'dops': row['dops'], 'score': value})
    evaluated = metrics(labels, scores)
    result = {'selected': selected, 'validation': validation,
              'fixed90_observed_pool': evaluated,
              'original_comparisons': original['evaluations']['fixed90_observed_pool'],
              'scope': 'Posthoc diagnostic on unchanged measured candidate subset, not newSQL or whole candidate pool. Fixed90 labels never used to select checkpoint. Expanded validation budget disclosed; no claim of untouched external test or online gain.',
              'observed_source_sha256': hashlib.sha256(observed_path.read_bytes()).hexdigest()}
    (out / 'OFFLINE_AUDIT.json').write_text(json.dumps(result, indent=2) + '\n')
    (out / 'OFFLINE_SCORES.json').write_text(json.dumps(detail, indent=2) + '\n')
    lines = ['# Transformer 训练预算检查', '',
             '保持原训练/验证划分、模型结构、两组学习率及每轮采样方式，分别从头训练 200 轮。每 10 轮评估历史验证集，按候选选择损失选检查点；90 查询的耗时不参与选模。', '',
             f"最终选择 h{selected['setting']} 的第 {selected['epoch']} 轮。两个学习率总训练及验证计时 {sum(r['seconds'] for r in trained['results']):.2f} 秒，单 CPU 35；期间共享主机上另有 SQL 实验，不能当作独占训练成本。", '',
             '| 口径 | 模型 | 排序准确率 | 平均候选选择损失 |', '|---|---|---:|---:|']
    groups = [('历史验证集重新枚举', {**original['evaluations']['validation'], 'extended_transformer': validation}),
              ('90查询已测候选子集', {**result['original_comparisons'], 'extended_transformer': evaluated})]
    for label, models in groups:
        for name, quality in models.items():
            lines.append(f"| {label} | {name} | {quality['rank_accuracy']:.2%} | {quality['mean_regret']:.2%} |")
    lines += ['', '排序准确率仅统计实测差异至少 3% 的配置对，分数相等计错。选择损失按计划平均所选配置耗时/已测最快耗时−1。当前 90 查询部分复用历史实测耗时，仅为同一候选子集上的诊断，不替代重新执行所选配置的结果。', '',
              '增加训练轮数及验证选择机会是本诊断的变量，未给其他模型增加相同搜索预算。此处不能据较好的单一验证点宣称已经收敛或已证明全面领先。']
    (out / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({'selected': selected, 'validation_rank': validation['rank_accuracy'],
                      'observed90_rank': evaluated['rank_accuracy'], 'observed90_regret': evaluated['mean_regret']}, indent=2))


if __name__ == '__main__':
    main()
