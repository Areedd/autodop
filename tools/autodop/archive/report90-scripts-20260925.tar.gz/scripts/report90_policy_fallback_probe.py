"""Exercise the response verifier on a real historical fallback and corrupted copies."""
import copy
import json
from pathlib import Path
import torch
from autodop.engine import PolicyEngine
from report90_policy_response_audit import sha, verify_response

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'runs/report90_20260912'


def find(path, predicate):
    with path.open() as stream:
        for line in stream:
            if line.strip():
                row=json.loads(line)
                if predicate(row): return row
    raise AssertionError('Required existing case missing')


def main():
    directory=RUN/'serial/scored'
    verification=json.loads((directory/'independent_verification.json').read_text())
    assert verification['evidence_valid']
    sources=[directory/'events.jsonl',directory/'decisions.jsonl',directory/'policy_variants.json']
    for path in sources: assert sha(path)==verification['source_sha256'][str(path)]
    event=find(sources[0],lambda r:r.get('status')=='verified' and r.get('mode')=='policy_before'
               and r.get('dop_validation',{}).get('fallback_category')=='low_confidence')
    decision=find(sources[1],lambda r:r['query_id']==event['query_id'])
    variant=json.loads(sources[2].read_text())['policy_before']
    checkpoint=Path(variant['checkpoint']);assert sha(checkpoint)==variant['checkpoint_sha256']
    torch.set_num_threads(1);engine=PolicyEngine(checkpoint)
    difference,applied=verify_response(event,decision,engine)
    assert not applied
    cases=[]
    for name in ['wrong_query_id','wrong_mode','altered_confidence','invalid_response_category','false_installation']:
        e,d=copy.deepcopy(event),copy.deepcopy(decision)
        if name=='wrong_query_id': d['query_id']='unrelated-query'
        elif name=='wrong_mode': d['mode']='unrelated-model'
        elif name=='altered_confidence': d['response']['confidence']=.99
        elif name=='invalid_response_category': e['dop_validation']['fallback_category']='invalid_response'
        else: e['dop_validation']['applied']=True
        try: verify_response(e,d,engine)
        except AssertionError: cases.append(name)
        else: raise AssertionError('Corrupted fixture accepted: '+name)
    result=dict(status='verified_fallback_verifier_case',query_id=event['query_id'],
                confidence=decision['response']['confidence'],confidence_difference=difference,rejected_corruptions=cases,
                historical_collection_fully_successful=verification['all_expected_executions_verified'],
                scope='One recorded successful SQL with legitimate low-confidence fallback selected for functional coverage; five altered copies are verifier tests, not experiment data. The historical collection includes other failures and is not relabeled successful. No new SQL, training or performance inference.',
                source_sha256={str(p):sha(p) for p in [Path(__file__),Path(__file__).with_name('report90_policy_response_audit.py'),
                                directory/'independent_verification.json',*sources,checkpoint]})
    path=RUN/'policy_final_stage_ablation/fallback_verifier_probe.json'
    with path.open('x') as stream: json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'},indent=2))


if __name__=='__main__':main()
