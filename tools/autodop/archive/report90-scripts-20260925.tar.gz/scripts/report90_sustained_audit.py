"""Recompute sustained-window throughput and verify complete scheduling/evidence."""
import argparse
from collections import Counter
import hashlib
import json
import random
import statistics
from pathlib import Path
from collect_paper_evaluations import load_queries,validate_execution_trace


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser();parser.add_argument('folder');args=parser.parse_args()
    out=Path(args.folder).resolve();protocol=json.loads((out/'PROTOCOL.json').read_text())
    result=json.loads((out/'RESULT.json').read_text());settings=protocol['settings']
    assert result['status']=='completed_sustained_collection' and result['frontend_restored'] and result['queue_restored']
    assert not result.get('monitor_errors',[])
    assert result['protocol_sha256']==sha(out/'PROTOCOL.json')
    for p,digest in protocol['source_sha256'].items():assert sha(Path(p))==digest,p
    queries=load_queries(Path(settings['manifest']),Path(settings['trusted']))
    by={q['id']:q for q in queries};jobs=list(queries);random.Random(settings['seed']).shuffle(jobs)
    events=[json.loads(line) for line in (out/'events.jsonl').read_text().splitlines()]
    expected={(m,int(n)) for m in settings['modes'].split(',') for n in settings['streams'].split(',')}
    assert {(r['mode'],r['streams']) for r in result['rounds']}==expected
    assert len(result['rounds'])==len(expected)
    seen=set();summaries=[]
    samples=[json.loads(line) for line in (out/'slot_samples.jsonl').read_text().splitlines()] if (out/'slot_samples.jsonl').exists() else []
    for e in events:
        key=(e['mode'],e['streams'],e['ticket']);assert key not in seen;seen.add(key)
        assert e['status']=='verified'
        q=by[e['id']];assert e['sql_sha256']==q['sql_sha256'] and e['result_digest']==q['native_result_digest']
        assert e['id']==jobs[e['ticket']%len(jobs)]['id']
        if e['mode']!='native':
            assert validate_execution_trace(e['trace'],e['query_id'])==e['dop_validation']
    for row in result['rounds']:
        es=[e for e in events if (e['mode'],e['streams'])==(row['mode'],row['streams'])]
        assert len(es)==row['total_executions'] and sorted(e['ticket'] for e in es)==list(range(len(es)))
        window=[e for e in es if row['window_start']<=e['completion_monotonic']<row['window_end']]
        assert len(window)==row['window_verified'] and row['window_failed']==row['total_failures']==0
        assert len(window)/row['window_seconds']==row['verified_qps']
        slots=[s for s in samples if (s['mode'],s['streams'])==(row['mode'],row['streams']) and row['window_start']<=s['monotonic']<row['window_end']]
        allocated=[sum(q['state']=='ALLOCATED' for q in s['rows']) for s in slots]
        pending=[sum(q['state']=='REQUIRING' for q in s['rows']) for s in slots]
        assert all(n<=settings['queue_cap'] for n in allocated),'Observed FE admission above configured cap'
        subwindows=[]
        start=row['window_start']
        while start<row['window_end']:
            end=min(start+60,row['window_end'])
            count=sum(start<=e['completion_monotonic']<end for e in window)
            subwindows.append(dict(seconds=end-start,completed=count,qps=count/(end-start)))
            start=end
        summaries.append(dict(mode=row['mode'],streams=row['streams'],qps=row['verified_qps'],
            window_verified=len(window),total_executions=len(es),window_query_counts=dict(Counter(e['id'] for e in window)),
            window_unique_queries=len({e['id'] for e in window}),total_unique_queries=len({e['id'] for e in es}),
            workload_size=len(queries),subwindows=subwindows,
            window_mean_client_ms=statistics.mean(e['client_latency_ms'] for e in window) if window else None,
            admission_samples=len(slots),max_observed_running=max(allocated,default=None),max_observed_pending=max(pending,default=None),
            applied=sum(e.get('dop_validation',{}).get('applied',False) for e in window),
            fallbacks=sum(e['mode']!='native' and not e.get('dop_validation',{}).get('applied',False) for e in window)))
    by_mode={}
    for mode in settings['modes'].split(','):
        rows=sorted([r for r in summaries if r['mode']==mode],key=lambda r:r['streams'])
        peak=max(r['qps'] for r in rows)
        by_mode[mode]=dict(strictly_nondecreasing_observed=all(b['qps']>=a['qps'] for a,b in zip(rows,rows[1:])),
            peak_qps=peak,largest_stream_qps=rows[-1]['qps'],largest_to_peak_ratio=rows[-1]['qps']/peak if peak else None,
            scope='One short window/cell; not repeated stability or a formal acceptance decision.')
    audit=dict(status='verified_sustained_windows_and_slots',executions=len(events),summaries=summaries,by_mode=by_mode,
        source_sha256={str(p):sha(p) for p in [Path(__file__),out/'PROTOCOL.json',out/'RESULT.json',out/'events.jsonl']+([out/'slot_samples.jsonl'] if samples else [])})
    (out/'AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
    lines=['# 持续stream测量核验','',
        '固定完成时间窗口，稳定期和排空另计；所有SQL结果、DOP（含回退）、全局查询分配序列及窗口计数已复算。60秒分段和查询覆盖数保存在AUDIT.json；分段并非独立重复实验。', '',
        '| 模式 | streams | 窗口QPS | 完成数 | 实测最大运行/等待 | 安装/回退 |', '|---|---:|---:|---:|---|---|']
    for row in summaries:
        lines.append(f"| {row['mode']} | {row['streams']} | {row['qps']:.4f} | {row['window_verified']} | {row['max_observed_running']}/{row['max_observed_pending']} | {row['applied']}/{row['fallbacks']} |")
    lines+=['', '采样只证明观测时点的准入上限，不是连续时刻资源保证。每格仅一个窗口，不以此证明噪声区间、长期稳态或合同验收；所有下降点保留。', '', '[逐查询计数与来源](AUDIT.json)。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps(by_mode,indent=2))


if __name__=='__main__':main()
