"""One plan-refresh batch for the diagnosed excluded coverage SQL; preserve all accepted batches."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from report90_execute import ROOT,RUN,check
from report90_complex_recover import build_verify
from report90_structure_coverage_collect import raw_plan
from autodop.data import load_dataset,write_jsonl
from autodop.training import file_sha256

BASE=RUN/'structure_coverage20';OUT=BASE/'labels_recovery';ORIGINAL=BASE/'labels/collection'
SUPPORT=RUN/'complex_development24/diagnostic_support'
def read(p):return json.loads(p.read_text())
def rows(p):return [json.loads(l) for l in p.open()]
def save(name,v):
    p=OUT/name;t=p.with_suffix('.tmp');t.write_text(json.dumps(v,indent=2)+'\n');t.replace(p)

def main():
    assert read(BASE/'labels/STATUS.json')['status']=='failed'
    original=read(ORIGINAL/'collection.json');assert original['status']=='finished' and len(original['queries'])==20
    assert read(ORIGINAL/'frontend_settings.json')['restored']
    failed=[q for q in original['queries'] if q['status']=='excluded'];assert len(failed)==1
    diagnosis=read(BASE/'PLAN_DRIFT_DIAGNOSIS.json');assert diagnosis['status']=='directly_verified_plan_mapping_mismatch' and diagnosis['query']==failed[0]['id']
    for path,expected in read(SUPPORT/'PREPARATION.json')['source_sha256'].items():assert file_sha256(path)==expected
    OUT.mkdir(exist_ok=False);os.sched_setaffinity(0,set(range(27,35)))
    save('STATUS.json',{'status':'running','stage':'verify_original_subset','pid':os.getpid()})
    save('PROTOCOL.json',{'frozen_at':datetime.datetime.now().astimezone().isoformat(),'failed_query':failed[0]['id'],
        'design':'One complete new batch on fresh native probe, same balanced8 design and original query seed; strict within-batch plan and result equality. No latency selection, no accepted query reruns, no automatic retries.',
        'source_sha256':{str(p):file_sha256(p) for p in [Path(__file__),BASE/'PLAN_DRIFT_DIAGNOSIS.json',BASE/'manifest.json',ORIGINAL/'collection.json',SUPPORT/'collector.py']}})
    build_verify(ORIGINAL,BASE/'manifest.json',OUT/'original_dataset')
    manifest=read(BASE/'manifest.json')['queries'];query=next(q for q in manifest if q['id']==failed[0]['id'])
    save('recovery_manifest.json',{'query_count':1,'queries':[query]})
    for attempt in range(20):
        try:check(OUT/f'IDLE_{attempt}.json');break
        except RuntimeError:
            if attempt==19:raise
            time.sleep(15)
    seed=read(BASE/'labels/PROTOCOL.json')['seed']+next(i for i,q in enumerate(manifest) if q['id']==query['id'])
    command=[sys.executable,str(SUPPORT/'collector.py'),'--manifest',str(OUT/'recovery_manifest.json'),'--output-dir',str(OUT/'collection'),
        '--configs','8','--config-design','balanced','--dops','1,2,4,8,16','--audit',original['settings']['audit'],
        '--probe-timeout-s','180','--query-timeout-s','180','--repetitions','3','--warmup','1','--seed',str(seed)]
    save('COMMAND.json',command);save('STATUS.json',{'status':'running','stage':'plan_refresh_collection','pid':os.getpid()})
    subprocess.run(command,check=True)
    recovered=read(OUT/'collection/collection.json');assert recovered['status']=='finished' and len(recovered['queries'])==1
    q=recovered['queries'][0];assert q['status']=='accepted' and len(q['configs'])==8,'Preserve diagnostic failure; no automatic retries'
    assert all(q[k]==failed[0][k] for k in ['sql_sha256','database','split','native_result_digest'])
    build_verify(OUT/'collection',OUT/'recovery_manifest.json',OUT/'recovered_dataset')
    parts=[OUT/'original_dataset',OUT/'recovered_dataset'];samples=[];pairs=[];evidence=[];assignments={}
    for part in parts:
        current=rows(part/'all/samples.jsonl')
        for qid in {s['template_id'] for s in current}:assert qid not in assignments;assignments[qid]=str(part)
        samples+=current;pairs+=rows(part/'all/pairs.jsonl');evidence+=rows(part/'sample_evidence.jsonl')
    assert set(assignments)=={q['id'] for q in manifest} and len(samples)==160
    assert all(s['split']=='train' for s in samples) and len({(s['plan_key'],s['config_key']) for s in samples})==160
    semantic={q['id']:q['native_result_digest'] for q in read(BASE/'SEMANTIC_AUDIT.json')['queries']}
    assert all(q['native_result_digest']==semantic[q['id']] for q in original['queries'] if q['status']=='accepted')
    assert q['native_result_digest']==semantic[q['id']]
    protected,_,_=load_dataset(RUN/'complex_development24/merged_dataset')
    assert not {raw_plan(s) for s in samples}&{raw_plan(s) for s in protected if s['split']=='valid'}
    dataset=OUT/'dataset';(dataset/'all').mkdir(parents=True)
    write_jsonl(dataset/'all/samples.jsonl',samples);write_jsonl(dataset/'all/pairs.jsonl',pairs);write_jsonl(dataset/'sample_evidence.jsonl',evidence)
    (dataset/'all/metadata.json').write_text((RUN/'complex_development24/warmstart/METADATA.json').read_text())
    sources=[p for part in parts for p in [part/'verification.json',part/'all/samples.jsonl',part/'all/pairs.jsonl',part/'sample_evidence.jsonl']]
    sources += [dataset/'all/samples.jsonl',dataset/'all/pairs.jsonl',RUN/'complex_development24/merged_dataset/samples.jsonl']
    save('RESULT.json',{'status':'complete','queries':20,'samples':160,'formal_executions':480,'protected_validation_raw_graph_overlap':0,
        'assignments':assignments,'excluded_original_query':query['id'],'scope':'Complete query batches only; failed original batch preserved, no cross-batch averaging or faster-result selection.',
        'source_sha256':{str(p):file_sha256(p) for p in sources}})
    save('STATUS.json',{'status':'complete','at':datetime.datetime.now().astimezone().isoformat()})

if __name__=='__main__':
    if OUT.exists():raise SystemExit('Preserve existing recovery')
    try:main()
    except BaseException as error:
        if OUT.exists():save('STATUS.json',{'status':'failed','error':repr(error),'pid':os.getpid()})
        raise
