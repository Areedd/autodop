"""Reproduce the extended-model search diagnosis from verified frozen execution data."""
import collections
import hashlib
import json
from pathlib import Path
import statistics

from report90_extension_summary import RUN, summarize


def main():
    folder = RUN / 'search_convergence_20260913'
    assert json.loads((folder / 'STATUS.json').read_text())['status'] == 'complete'
    stage = summarize(folder / 'full')
    assert stage['status'] == 'verified'
    choices_path = folder / 'CHOICES.json'
    choices = json.loads(choices_path.read_text())
    by = collections.defaultdict(dict)
    for choice in choices:
        by[choice['id']].setdefault(choice['mode'], []).append(choice)
    rows = []
    for query, modes in by.items():
        if any(len(values) != 1 for values in modes.values()):
            continue
        full, random = modes['search_extended_full'][0], modes['search_extended_random'][0]
        actual = stage['per_query_mean_latency_ms']
        rows.append({'id': query, 'full_predicted_score': full['score'], 'random_predicted_score': random['score'],
                     'full_latency_ms': actual['search_extended_full'][query],
                     'random_latency_ms': actual['search_extended_random'][query]})
    higher = [r for r in rows if r['full_predicted_score'] > r['random_predicted_score']]
    reversals = [r for r in higher if r['full_latency_ms'] >= 1.03*r['random_latency_ms']]
    sources = [choices_path, folder / 'full/scored/independent_verification.json',
               folder / 'full/scored/sql_executions.jsonl', Path(__file__)]
    result = {'status': 'completed_posthoc_diagnostic', 'all90_primary_results_retained': True,
              'scope': 'Single frozen-plan query IDs only for score attribution; one formal repetition. No causal or generalization claim.',
              'stable_queries': len(rows), 'excluded_multivariant_queries': sorted(set(by)-{r['id'] for r in rows}),
              'full_higher_predicted_score': len(higher), 'of_these_full_at_least3pct_slower': len(reversals),
              'search_ms_across94_plan_variants': {mode: statistics.mean(c['search_seconds']*1000 for c in choices if c['mode'] == mode)
                                                 for mode in sorted(stage['modes'])},
              'rows': rows, 'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}}
    (folder / 'SCORE_DIAGNOSTIC.json').write_text(json.dumps(result, indent=2) + '\n')
    lines = ['# 延长训练预算后的搜索消融', '',
             '全量 90 查询、4 配置、1 轮预热和 1 轮正式测量，共 720 次执行全部通过独立核验。', '',
             '| 配置 | 平均查询延迟 ms | 平均离线搜索 ms（94 个计划版本） |', '|---|---:|---:|']
    for mode, values in stage['modes'].items():
        lines.append(f"| {mode} | {values['query_mean_latency_ms']:.2f} | {result['search_ms_across94_plan_variants'][mode]:.2f} |")
    lines += ['', f'具有单一冻结计划版本的 {len(rows)} 条查询中，完整搜索在 {len(higher)} 条上预测评分高于随机搜索，其中 {len(reversals)} 条实际延迟反而至少高 3%。主结果保留全部 90 条；排除多版本查询仅用于避免评分版本匹配歧义。', '',
              '训练预算扩展后仍存在预测评分与实际收益不一致。该诊断不能独立排除探索预算、搜索顺序等因素，也不能用单轮测量证明微小差异的显著性。', '',
              '查询回放不包含离线搜索开销；上表搜索耗时单列，不将两种不同样本口径的均值直接相加作为端到端耗时。当前在线策略权重保持原样。', '',
              '复现：report90_search_audit.py，只读冻结评分与通过独立核验的执行记录，不执行 SQL。']
    (folder / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({key: result[key] for key in ['stable_queries', 'full_higher_predicted_score', 'of_these_full_at_least3pct_slower']}))


if __name__ == '__main__':
    main()
