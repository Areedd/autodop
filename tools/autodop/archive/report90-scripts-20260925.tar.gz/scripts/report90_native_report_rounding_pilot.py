"""Four-mode native admission pilot; frozen predictor and common SQL collector."""
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

from collect_trusted_dataset import frontend_settings
from report90_execute import ROOT, RUN, SOURCE, check
from report90_native_predictor_fixed4 import NativePredictor as Power2Predictor
from report90_native_predictor_integer import NativePredictor as IntegerPredictor
from report90_request_journal import RequestJournal
from report90_queue_extension import connect, settings_guard

ROUNDING = os.environ.get('REPORT90_ROUNDING', 'power2')
assert ROUNDING in ('power2', 'integer')
SCHEDULE = 'SWRR'
ESTIMATOR = 'MBE' if ROUNDING == 'power2' else 'MBE_CEIL'
NativePredictor = Power2Predictor if ROUNDING == 'power2' else IntegerPredictor
OUT = RUN / ('report90_native_budget_rounding_' + ROUNDING)
SUPPORT = RUN / 'native_mixed_budget_pilot_support'
MODES = {'native':'fixed4', 'native_budget':'predicted',
         'policy_static':'fixed4', 'policy_budget':'predicted'}


def save(name, obj):
    (OUT/name).write_text(json.dumps(obj, indent=2)+'\n')


def main():
    assert json.loads((RUN/'native_budget_fixed17/ALLOCATION_AUDIT.json').read_text())['status']=='verified'
    assert json.loads((RUN/'native_budget_fixed17_restart/RESTORATION.json').read_text())['restored']
    evaluation=json.loads((RUN/'report90_frozen_budget_evaluation/RESULT.json').read_text())
    assert evaluation['status']=='memory_evaluated'
    assert evaluation['encoded_nominal_underestimates']==0, 'Observed nominal coverage required before concurrency'
    assert all(not row['prediction']['saturated'] for row in evaluation['rows'])
    OUT.mkdir(exist_ok=False)
    save('STATUS.json', dict(status='running', pid=os.getpid()))
    os.sched_setaffinity(0, set(range(27,35)))
    model_path = RUN/'native_predictor_service17/MODEL.json'
    predictor = NativePredictor.load(model_path)
    assert hashlib.sha256((ROOT.parents[1]/'output/fe/lib/starrocks-fe.jar').read_bytes()).hexdigest() == json.loads((RUN/'integer_slot_estimator_validation/BINARY_AUDIT.json').read_text())['integer_sha256']
    manifest = json.loads((SUPPORT/'manifest.json').read_text())
    assert len(manifest['queries']) == 2
    original = json.loads((RUN/'PROTOCOL.json').read_text())
    command = [sys.executable, str(SUPPORT/'collector.py'), '--manifest', str(SUPPORT/'manifest.json'),
               '--trusted-collection', str(SOURCE/'random200/trusted_merged.json'), '--output-dir', str(OUT/'scored'),
               '--policy-model', original['model'], '--policy-variants', str(SUPPORT/'policy_variants.json'),
               '--modes', ','.join(MODES), '--scenario','concurrent','--clients','16',
               '--minimum-per-client','1','--warmup','1','--repetitions','1','--seed',str(original['seed']),
               '--query-timeout-s','180','--auto-dop-max-dop','16','--torch-threads','1',
               '--decision-timeout-ms','1000','--metrics-urls',
               'http://127.0.0.1:8040/metrics,http://127.0.0.1:8041/metrics,http://127.0.0.1:8042/metrics,http://127.0.0.1:8030/metrics']
    sources = [Path(__file__), model_path, ROOT/'scripts/report90_native_predictor.py', ROOT/'scripts/report90_native_predictor_fixed4.py', ROOT/'scripts/report90_native_predictor_integer.py', ROOT/'scripts/report90_request_journal.py',
               ROOT/'scripts/verify_paper_evaluations.py', *[p for p in SUPPORT.iterdir() if p.is_file()]]
    save('PROTOCOL.json', dict(queries=2, clients=16, tasks_per_mode_per_phase=16, expected_executions=128,
         warmup=1, repetitions=1, modes=MODES, retries=0, schedule=SCHEDULE, rounding=ROUNDING, estimator=ESTIMATOR,
         logging='Append-only flushed JSONL, final JSON export after handlers stop; flush is not fsync. No historical latency adjustment.',
         scope='Checkpoint-isolated FE with optional MBE_CEIL estimator (same package in both rounding arms, SWRR unchanged), bounded performance pilot: frozen native predictor versus fixed4 reservation, crossed with native DOP and unchanged static AutoDOP. Native V2 handles admission using the selected MBE/MBE_CEIL estimator. Slot-size changes can also change SWRR priority categories. All waiting and prediction included in SQL client latency. Post-OOM calibrated fixed4 baseline, first manifest query in each frozen 24/48-slot category, mixed-budget integration pilot; no independent arbitrary-query generalization claim.',
         gate='No automatic full run. Require all128 SQL results/identities/DOP verified and prediction/actual allocated/released slots matched. Report all modes and failures before expansion.',
         source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}))
    save('COMMAND.json', command)
    check(OUT/'IDLE.json')
    lock = threading.Lock()
    healthy = threading.Event()
    state = dict(mode='bootstrap', active=0)
    journal = RequestJournal(OUT/'PREDICTOR_REQUESTS.jsonl')
    errors = []
    switches = []
    server = None

    def record_error(error):
        with lock:
            errors.append(repr(error))
            journal.append('error', repr(error))

    class EvidenceServer(ThreadingHTTPServer):
        # server_close must join handlers before journal close/export.
        daemon_threads = False
        block_on_close = True

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args): pass

        def do_GET(self):
            try:
                if self.path == '/health_check':
                    self.send_response(200); self.end_headers(); self.wfile.write(b'OK'); self.wfile.flush()
                    healthy.set()
                    return
                mode = self.path.removeprefix('/mode/')
                assert self.path.startswith('/mode/') and mode in MODES
                with lock:
                    assert state['active'] == 0
                    state['mode'] = mode
                    switches.append(dict(mode=mode, at=time.time()))
                    save('MODE_SWITCHES.json', switches)
                self.send_response(200); self.end_headers(); self.wfile.write(b'OK')
            except Exception as error:
                record_error(error); self.send_response(500); self.end_headers()

        def do_POST(self):
            entered = False
            try:
                assert self.path == '/predict_csv'
                size = int(self.headers['Content-Length']); assert 0<size<1000000
                body = self.rfile.read(size).decode()
                with lock:
                    mode = state['mode']; state['active'] += 1; entered = True
                start = time.perf_counter_ns()
                pred = predictor.predict_csv(body, MODES.get(mode, 'fixed4'))
                elapsed = time.perf_counter_ns()-start
                with lock:
                    journal.append('record', dict(mode=mode, csv=body, prediction=pred, prediction_ns=elapsed, at=time.time()))
                self.send_response(200); self.end_headers(); self.wfile.write(str(pred['encoded_cost_bytes']).encode())
            except Exception as error:
                record_error(error); self.send_response(500); self.end_headers()
            finally:
                if entered:
                    with lock: state['active'] -= 1

    try:
        server = EvidenceServer(('127.0.0.1',18083), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        with settings_guard(OUT), connect() as control:
            with control.cursor() as q:
                q.execute("ADMIN SHOW FRONTEND CONFIG LIKE 'enable_query_queue_v2'")
                assert str(q.fetchone()[2]).lower() == 'true'
                updates = dict(query_queue_v2_schedule_strategy=SCHEDULE,query_queue_slots_estimator_strategy=ESTIMATOR,query_queue_v2_concurrency_level='4',
                               max_query_queue_history_slots_number='256',
                               query_cost_prediction_service_address='http://127.0.0.1:18083',enable_query_cost_prediction='true')
                with frontend_settings(q, updates, OUT/'frontend_settings.json', restore_connection_factory=connect):
                    q.execute("ADMIN SHOW FRONTEND CONFIG LIKE 'query_queue_v2_schedule_strategy'")
                    actual_schedule = q.fetchone()
                    assert str(actual_schedule[2]).upper() == SCHEDULE
                    save('SCHEDULE.json', dict(expected=SCHEDULE, actual=actual_schedule))
                    q.execute("ADMIN SHOW FRONTEND CONFIG LIKE 'query_queue_slots_estimator_strategy'")
                    actual_estimator = q.fetchone()
                    assert str(actual_estimator[2]).upper() == ESTIMATOR
                    save('ESTIMATOR.json', dict(expected=ESTIMATOR, actual=actual_estimator, rounding=ROUNDING))
                    with connect() as c, c.cursor() as b:
                        first = manifest['queries'][0]
                        sql = Path(first['sql_file']).read_text()
                        assert hashlib.sha256(Path(first['sql_file']).read_bytes()).hexdigest()==first['sql_sha256']
                        b.execute('USE `'+first['database']+'`')
                        for setting in ['enable_auto_dop=false','pipeline_dop=0','enable_runtime_adaptive_dop=false','enable_query_cache=false','enable_spill=false']:
                            b.execute('SET '+setting)
                        b.execute('EXPLAIN SCHEDULER /* native_budget_bootstrap */ '+sql.strip().rstrip(';'))
                        save('BOOTSTRAP_PLAN.json', b.fetchall())
                    assert healthy.wait(45)
                    time.sleep(1)
                    subprocess.run(command, check=True)
                    q.execute('ADMIN SET FRONTEND CONFIG ("enable_query_cost_prediction" = "false")')
                    time.sleep(1)
                    q.execute('SELECT QUERY_ID, STATE, EST_COSTS_SLOTS, ALLOCATE_SLOTS, QUERY, EXTRA_MESSAGE FROM information_schema.warehouse_queries')
                    cols=[c[0].lower() for c in q.description]
                    save('SLOT_HISTORY.json', dict(rows=[dict(zip(cols,r)) for r in q.fetchall()]))
        assert not errors
        proof=OUT/'scored/independent_verification.json'
        subprocess.run([sys.executable,str(ROOT/'scripts/verify_paper_evaluations.py'),'--collection-dir',str(OUT/'scored'),'--output',str(proof)],check=True)
        verified=json.loads(proof.read_text())
        assert verified['all_expected_executions_verified'] and verified['expected_slots']==128
        save('STATUS.json',dict(status='captured',executions=128))
    except BaseException as error:
        save('STATUS.json',dict(status='failed',error=repr(error)));raise
    finally:
        if server is not None: server.shutdown();server.server_close()
        journal.close()
        snapshot = journal.export(OUT/'PREDICTOR_REQUESTS.json')
        assert snapshot['errors'] == errors


if __name__ == '__main__': main()
