"""Score frozen models on controlled training probes, preserving measurement batches."""
import json
import os
from pathlib import Path
import numpy as np
import torch
import xgboost as xgb
from autodop.graph import build_graph
from autodop.model import load_cost_model
from report90_models import MLP,flat_features,metrics
from report90_interaction_pair_audit import BASE,sha

RUN=BASE.parent;OUT=RUN/'training_probe_model_diagnostic'

def read(p):return json.loads(p.read_text())

def main():
    os.sched_setaffinity(0,{33});torch.set_num_threads(1);assert not OUT.exists()
    batches=['training_contrasts_pilot_v2','training_conditional_contrasts'];samples=[];labels=[];descriptors=[];endpoints=[];sources=[Path(__file__)]
    for batch in batches:
        root=RUN/batch;proof=read(root/'collection/RESULT.json');assert proof['status']=='verified'
        for path,digest in proof['source_sha256'].items():assert sha(Path(path))==digest
        rows=[json.loads(x) for x in (root/'collection/training_samples.jsonl').read_text().splitlines()];assert all(s['split']=='train' for s in rows)
        proposals=read(root/'PROPOSALS.json');summary=read(root/'SUMMARY.json');assert summary['status']=='verified_controlled_contrast_summary'
        indices={}
        for s in sorted(rows,key=lambda s:(s['template_id'],s['config_key'])):
            q=s['template_id'];mode=next(c['mode'] for c in proposals[q]['configs'] if c['dop_config']==s['dop_config']);indices[(q,mode)]=len(samples)
            samples.append(s);labels.append({'plan_key':batch+':'+s['plan_key'],'config_key':s['config_key'],'latency_ms':s['latency_ms']});descriptors.append({'batch':batch,'query':q,'mode':mode,'latency_ms':s['latency_ms']})
        for q,v in summary['queries'].items():
            for c in v['contrasts']:
                i=c['group'];a,b=indices[(q,f'group{i}_low')],indices[(q,f'group{i}_high')]
                endpoints.append({'batch':batch,'query':q,'group':i,'low_index':a,'high_index':b,'low_ms':labels[a]['latency_ms'],'high_ms':labels[b]['latency_ms'],'eligible':c['formal_gap_ge3pct'],'phase_consistent':c['both_phase_gap_ge3pct'] and c['same_order_in_both_phases']})
        sources += [root/'collection/RESULT.json',root/'collection/training_samples.jsonl',root/'PROPOSALS.json',root/'SUMMARY.json']
    assert len(samples)==64 and len(endpoints)==28 and len({s['sql_sha256'] for s in samples})==4
    metadata=read(BASE/'retrained/METADATA.json');norm=np.load(BASE/'retrained/FEATURE_NORMALIZATION.npz')
    graphs=[build_graph(s,metadata) for s in samples];X=np.stack([(flat_features(g,metadata)-norm['mean'])/norm['std'] for g in graphs]);assert np.isfinite(X).all()
    scores={};selected={}
    for seed in [17,29,43]:
        primary=BASE/('hard_pair_ema_pilot/pilot' if seed==17 else f'hard_pair_ema_stability/seed{seed}')
        auditpath=BASE/('hard_pair_ema_pilot/pair_audit/RESULT.json' if seed==17 else f'hard_pair_ema_stability/pair_audit_seed{seed}/RESULT.json')
        audit=read(auditpath);assert audit['status']=='verified_independent_pair_replay'
        for path,digest in audit['source_sha256'].items():assert sha(Path(path))==digest
        extra=BASE/f'accuracy_baselines_seed{seed}_full/RESULT.json';records={**read(primary/'RESULT.json')['selected'],**read(extra)['selected']};sources += [primary/'RESULT.json',extra,auditpath]
        for kind,record in records.items():
            path=Path(record['model']);assert sha(path)==record['model_sha256'];sources.append(path);name=f'{kind}_seed{seed}';selected[name]=record
            if kind=='transformer':
                model,ck=load_cost_model(path);assert ck['metadata']==metadata;model.eval()
                with torch.no_grad():pred=np.array([float(model(g)) for g in graphs])
            elif kind.startswith('mlp'):
                ck=torch.load(path,weights_only=False,map_location='cpu');model=MLP(ck['width']);model.load_state_dict(ck['state']);model.eval()
                with torch.no_grad():pred=model(torch.tensor(X,dtype=torch.float32)).numpy().astype(float)
                if kind.endswith('regression'):pred=-pred
            else:
                model=xgb.XGBRegressor() if kind.endswith('regression') else xgb.XGBRanker();model.load_model(path);model.set_params(n_jobs=1);pred=model.predict(X).astype(float)
                if kind.endswith('regression'):pred=-pred
            assert np.isfinite(pred).all();scores[name]=pred.tolist()
    teacher=BASE/'prepared/cost.pt';model,ck=load_cost_model(teacher);assert ck['metadata']==metadata;model.eval();sources.append(teacher)
    with torch.no_grad():scores['original_multistage_teacher']=[float(model(g)) for g in graphs]
    families=sorted({k.rsplit('_seed',1)[0] for k in selected})
    for kind in families:scores[kind+'_ensemble']=np.mean([scores[f'{kind}_seed{s}'] for s in [17,29,43]],axis=0).tolist()
    quality={}
    for name,pred in scores.items():
        q=metrics(labels,pred);assert q['ranking_pairs']==139
        checks=[]
        for e in endpoints:
            a,b=e['low_index'],e['high_index'];checks.append({**e,'predicted_low_score':pred[a],'predicted_high_score':pred[b],'correct':(pred[a]-pred[b])*(e['high_ms']-e['low_ms'])>0})
        eligible=[x for x in checks if x['eligible']];phase=[x for x in checks if x['phase_consistent']]
        assert len(eligible)==15 and len(phase)==6
        quality[name]={'all_within_batch_pairs':q,'endpoint_eligible_correct':sum(x['correct'] for x in eligible),'endpoint_eligible_count':len(eligible),'phase_consistent_endpoint_correct':sum(x['correct'] for x in phase),'phase_consistent_endpoint_count':len(phase),'endpoints':checks}
    OUT.mkdir();(OUT/'SCORES.json').write_text(json.dumps(scores)+'\n')
    restored=read(OUT/'SCORES.json');assert all(metrics(labels,restored[k])==q['all_within_batch_pairs'] for k,q in quality.items())
    sources += [BASE/'retrained/METADATA.json',BASE/'retrained/FEATURE_NORMALIZATION.npz',OUT/'SCORES.json']
    result={'status':'verified_frozen_model_probe_diagnostic','config_observations':64,'measurement_batches':2,'queries':4,'models':quality,'observations':descriptors,
        'scope':'New controlled configurations of known training queries; not held-out-query or report90 superiority evidence. Models fixed before collection, no fitting. Batch-specific plan keys prevent cross-batch pair construction. All139 formal3% pairs retained; endpoints and warm/formal-consistent subsets are secondary diagnostics, not replacement metrics. Ensemble uses fixed arithmetic mean of all3seeds for every family.',
        'source_sha256':{str(p):sha(p) for p in sources}}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 已冻结模型对受控训练配置的预测核对','',result['scope'],'','| 模型 | 全139对准确率 | 15个有效端点正确数 | 6个两阶段一致端点正确数 |','|---|---:|---:|---:|']
    for name,q in quality.items():lines.append(f"| {name} | {100*q['all_within_batch_pairs']['rank_accuracy']:.3f}% | {q['endpoint_eligible_correct']}/15 | {q['phase_consistent_endpoint_correct']}/6 |")
    lines+=['','所有标签和分数保留。原训练查询已有部分配置进入训练，故这里仅检验新增干预的预测行为；不能替代开发集或90条查询结论。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');print({k:(v['all_within_batch_pairs']['rank_accuracy'],v['phase_consistent_endpoint_correct']) for k,v in quality.items()})

if __name__=='__main__':main()
