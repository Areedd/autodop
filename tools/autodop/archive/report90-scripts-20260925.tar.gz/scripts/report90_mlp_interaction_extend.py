"""Equal100epoch extension after the paired30epoch MLP feature pilot."""
import json
from pathlib import Path
import subprocess
import sys
import torch
from report90_interaction_pair_audit import BASE,sha


def main():
    prior=BASE/'mlp_interaction_pilot';out=BASE/'mlp_interaction100'
    assert json.loads((prior/'PAIR_AUDIT.json').read_text())['status']=='verified_independent_pair_replay'
    out.mkdir(exist_ok=False)
    protocol=json.loads((prior/'PROTOCOL.json').read_text())
    protocol.update(pilot_epochs=100,scope='Equal100epoch feature comparison after completed30epoch pilot; seed17. No SQL or report90 selection.',
                    source_sha256={str(p):sha(p) for p in [Path(__file__),prior/'PROTOCOL.json',prior/'PAIR_AUDIT.json']})
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    for arm in protocol['arms']:
        source=prior/f'pilot_{arm}_trainer.py';text=source.read_text()
        assert text.count('epochs = 30')==1 and text.count(str(prior))==3
        text=text.replace('epochs = 30','epochs = 100').replace(str(prior),str(out))
        path=out/f'pilot_{arm}_trainer.py';compile(text,str(path),'exec');path.write_text(text)
        (out/f'{arm}_TRANSFORM.json').write_text(json.dumps(dict(source_sha256=sha(source),generated_sha256=sha(path),changes='Output/protocol paths and30->100epochs only'),indent=2)+'\n')
        (out/'STATUS.json').write_text(json.dumps(dict(status='running',arm=arm))+'\n')
        with (out/f'{arm}.log').open('w') as stream:
            subprocess.run([sys.executable,str(path),'--stage','pilot','--seed','17','--cpu','35'],stdout=stream,stderr=subprocess.STDOUT,check=True)
    records={arm:json.loads((out/f'pilot_{arm}/RESULT.json').read_text()) for arm in protocol['arms']}
    summary={kind:{arm:r['selected'][kind]['selected']['validation']['weighted_rank_accuracy'] for arm,r in records.items()} for kind in protocol['methods']}
    (out/'RESULT.json').write_text(json.dumps(dict(status='completed_reload_verified_pending_independent_audit',macro_accuracy=summary,source_sha256={str(out/f'pilot_{arm}/RESULT.json'):sha(out/f'pilot_{arm}/RESULT.json') for arm in protocol['arms']}),indent=2)+'\n')
    # Reuse the independent pair auditor with explicitly recorded relocation.
    audit=Path(__file__).with_name('report90_mlp_interaction_audit.py')
    text=audit.read_text();assert text.count("BASE/'mlp_interaction_pilot'")==1
    text=text.replace("BASE/'mlp_interaction_pilot'","BASE/'mlp_interaction100'").replace('30轮','100轮')
    path=out/'audit.py';path.write_text(text)
    (out/'AUDIT_TRANSFORM.json').write_text(json.dumps(dict(source_sha256=sha(audit),generated_sha256=sha(path),changes='Output relocation and report epoch label'),indent=2)+'\n')
    subprocess.run([sys.executable,str(path)],check=True)
    parity=[]
    for candidate in records['full']['candidates']:
        kind,setting=candidate['kind'],candidate['setting']
        old=BASE/f'accuracy_baselines_seed17_full/{kind}_h{setting}/model.pt'
        new=Path(candidate['model'])
        a=torch.load(old,map_location='cpu',weights_only=False);b=torch.load(new,map_location='cpu',weights_only=False)
        same=a['state'].keys()==b['state'].keys() and all(torch.equal(a['state'][k],b['state'][k]) for k in a['state'])
        parity.append(dict(kind=kind,setting=setting,exact_state_equal=same,old_sha256=sha(old),new_sha256=sha(new)))
    (out/'BASELINE_PARITY.json').write_text(json.dumps(dict(records=parity,all_exact=all(r['exact_state_equal'] for r in parity)),indent=2)+'\n')
    (out/'STATUS.json').write_text(json.dumps(dict(status='complete_verified'))+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
