"""Independently rebuild every training-only tree-teacher target."""
import json
import os
from pathlib import Path
import numpy as np
import torch
import xgboost as xgb
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.training import file_sha256, select_partition
from report90_models import flat_features

BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20'
OUT=BASE/'xgb_distillation_pilot'


def main():
    torch.set_num_threads(1);os.sched_setaffinity(0,{35})
    p=json.loads((OUT/'PROTOCOL.json').read_text())
    assert file_sha256(p['teacher'])==p['teacher_sha256']
    samples,pairs,meta=load_dataset(BASE/'merged_dataset')
    contract=json.loads((BASE/'merged_dataset/CONTRACT.json').read_text())
    train,tp=select_partition(samples,pairs,contract,'train')
    valid,_=select_partition(samples,pairs,contract,'valid')
    key=lambda s:(s['plan_key'],s['config_key'])
    assert not {key(s) for s in train}&{key(s) for s in valid}
    matrix=np.stack([flat_features(build_graph(s,meta),meta) for s in train])
    mean,std=matrix.mean(0),matrix.std(0);std[std<1e-6]=1
    norm=np.load(OUT/'smoke/FEATURE_NORMALIZATION.npz')
    assert np.array_equal(mean,norm['mean']) and np.array_equal(std,norm['std'])
    teacher=xgb.XGBRanker();teacher.load_model(p['teacher']);teacher.set_params(n_jobs=1)
    scores=teacher.predict((matrix-mean)/std)
    stored=json.loads((OUT/'smoke/TEACHER_TARGETS.json').read_text())['rows']
    assert len(stored)==len(train)==1365
    assert [key(s) for s in stored]==[key(s) for s in train]
    assert np.array_equal(scores,np.array([r['score'] for r in stored]))
    lookup={key(s):float(score) for s,score in zip(train,scores)}
    cohorts={s['plan_key']:s['source_cohort'] for s in train}
    stats={}
    for cohort in sorted(set(cohorts.values())):
        rows=[r for r in tp if cohorts[r['plan_key']]==cohort]
        gaps=np.array([lookup[(r['plan_key'],r['fast_config_key'])]-lookup[(r['plan_key'],r['slow_config_key'])] for r in rows])
        probability=1/(1+np.exp(-gaps))
        stats[cohort]=dict(pairs=len(rows),teacher_agrees=int((gaps>0).sum()),teacher_ties=int((gaps==0).sum()),
                           teacher_disagrees=int((gaps<0).sum()),
                           soft_target_quantiles=dict(zip(['min','p10','p50','p90','max'],np.quantile(probability,[0,.1,.5,.9,1]).tolist())))
    sources=[Path(__file__),Path(p['teacher']),OUT/'PROTOCOL.json',OUT/'smoke/TEACHER_TARGETS.json',OUT/'smoke/FEATURE_NORMALIZATION.npz',BASE/'merged_dataset/samples.jsonl',BASE/'merged_dataset/pairs.jsonl',BASE/'merged_dataset/metadata.json',BASE/'merged_dataset/CONTRACT.json',Path(__file__).with_name('report90_models.py'),BASE.parents[1]/'autodop/graph.py']
    # The package root is two levels above the report run.
    sources[-1]=Path(__file__).resolve().parents[1]/'autodop/graph.py'
    result=dict(status='verified_exact_training_targets',rows=len(train),train_pairs=len(tp),
                normalization_recomputed_exact=True,scores_recomputed_exact=True,validation_target_overlap=0,
                cohorts=stats,source_sha256={str(s):file_sha256(s) for s in sources},
                scope='Teacher in-sample fit and target replay only, not held-out teacher accuracy or proof of student improvement. Teacher errors retained, never filtered by report90.')
    (OUT/'TARGET_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'},indent=2))


if __name__=='__main__':main()
