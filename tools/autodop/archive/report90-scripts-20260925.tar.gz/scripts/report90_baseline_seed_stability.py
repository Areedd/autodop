"""Replicate existing flat-model controls at seeds29/43, with a pilot before each full fit."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
from autodop.training import file_sha256
from report90_coverage_choices import BASE, read

OUT = BASE / 'baseline_seed_stability'
SOURCE = Path(__file__).with_name('report90_coverage_baselines.py')


def save(path, value):
    tmp = path.with_suffix('.tmp'); tmp.write_text(json.dumps(value, indent=2) + '\n'); tmp.replace(path)


def main():
    assert not OUT.exists(), 'Preserve previous baseline replication'
    original = read(BASE / 'additional_baselines_full/RESULT.json'); assert original['status'] == 'verified'
    OUT.mkdir(); os.sched_setaffinity(0, {35})
    protocol = {'frozen_at': datetime.datetime.now().astimezone().isoformat(), 'reference_seed': 17,
        'additional_seeds': [29, 43], 'models': ['mlp_rank', 'mlp_regression', 'xgb_regression'],
        'rule': 'Reuse the executed seed17 trainer; only seed constants, output directories and relocated source references change. Same data, feature/target normalization, sampling, two settings per model,100epochs and validation-only selection. Each twoepoch pilot must verify before full fit.',
        'scope': 'Stochasticity control after observed90 scoring. All seeds reported, no best-seed selection. Validation has been reused; this is not untouched-test evidence or an SQL experiment.',
        'source_sha256': {str(p): file_sha256(p) for p in [Path(__file__), SOURCE, BASE / 'additional_baselines_full/RESULT.json']}}
    save(OUT / 'PROTOCOL.json', protocol)
    results = {'17': original}
    for seed in protocol['additional_seeds']:
        source = SOURCE.read_text()
        replacements = {
            "'additional_baselines_'": (repr(f'baseline_seed_stability/seed{seed}_'), 2),
            "'additional_baselines_pilot/RESULT.json'": (repr(f'baseline_seed_stability/seed{seed}_pilot/RESULT.json'), 1),
            "'seed': 17": (f"'seed': {seed}", 1),
            'torch.manual_seed(17); rng = random.Random(17)': (f'torch.manual_seed({seed}); rng = random.Random({seed})', 1),
            'random_state=17,': (f'random_state={seed},', 1),
            "Path(__file__).with_name('report90_models.py')": ('Path(' + repr(str(SOURCE.with_name('report90_models.py'))) + ')', 1),
            "Path(__file__).with_name('report90_complex_retrain.py')": ('Path(' + repr(str(SOURCE.with_name('report90_complex_retrain.py'))) + ')', 1),
        }
        for old, (new, count) in replacements.items():
            assert source.count(old) == count, (old, source.count(old)); source = source.replace(old, new)
        script = OUT / f'seed{seed}_trainer.py'; compile(source, str(script), 'exec'); script.write_text(source)
        save(OUT / f'seed{seed}_SOURCE_TRANSFORM.json', {'original_sha256': file_sha256(SOURCE),
             'generated_sha256': file_sha256(script), 'literal_changes': replacements})
        for stage in ['pilot', 'full']:
            save(OUT / 'STATUS.json', {'status': 'running', 'stage': f'seed{seed}_{stage}', 'pid': os.getpid()})
            with (OUT / f'seed{seed}_{stage}.log').open('w') as stream:
                subprocess.run([sys.executable, str(script), '--stage', stage], stdout=stream, stderr=subprocess.STDOUT, check=True)
            r = read(OUT / f'seed{seed}_{stage}/RESULT.json')
            assert r['status'] == 'verified' and all(c['independent_reload_verified'] for c in r['candidates'])
        results[str(seed)] = r
    for p, expected in protocol['source_sha256'].items(): assert file_sha256(p) == expected
    qualities = {seed: {k: v['selected']['validation'] for k, v in r['selected'].items()} for seed, r in results.items()}
    aggregate = {}
    for kind in protocol['models']:
        values = [q[kind]['weighted_regret'] for q in qualities.values()]
        aggregate[kind] = {'mean_regret': sum(values) / len(values), 'min': min(values), 'max': max(values)}
    save(OUT / 'RESULT.json', {'status': 'verified', 'qualities': qualities, 'aggregate': aggregate,
         'selected_models': {seed: r['selected'] for seed, r in results.items()}, 'protocol_sha256': file_sha256(OUT / 'PROTOCOL.json')})
    lines = ['# MLP与回归树的三种子复测', '', protocol['scope'], '',
             '| 种子 | 模型 | 综合选择损失 | 复杂选择损失 |', '|---|---|---:|---:|']
    for seed, models in qualities.items():
        for kind, q in models.items():
            lines.append(f"| {seed} | {kind} | {100*q['weighted_regret']:.2f}% | {100*q['cohorts']['complex_new']['mean_regret']:.2f}% |")
    lines += ['', '17复用已完成独立核验，29和43先短训练检查，再完成全部候选训练和重载核验。每个种子仍只根据相同开发验证集选设置/检查点；不按种子择优。XGBoost采用全行全列采样，其种子结果可能相同，不据此宣称对数据扰动也不敏感。']
    (OUT / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    save(OUT / 'STATUS.json', {'status': 'complete'})


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        if OUT.exists(): save(OUT / 'STATUS.json', {'status': 'failed', 'error': repr(error), 'pid': os.getpid()})
        raise
