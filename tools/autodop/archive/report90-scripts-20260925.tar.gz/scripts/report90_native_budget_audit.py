"""Verify all native admission pilot queries and report every factorial mode."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import time
import numpy as np

from report90_execute import ROOT, RUN
from report90_native_predictor import NativePredictor
from report90_native_budget_pilot import MODES, OUT, SUPPORT


def main():
    read = lambda p: json.loads(p.read_text())
    events = [json.loads(line) for line in (OUT/'scored/events.jsonl').read_text().splitlines()]
    assert len(events)==128 and all(e['status']=='verified' for e in events)
    assert read(OUT/'scored/independent_verification.json')['all_expected_executions_verified']
    manifest = {q['id']:q for q in read(SUPPORT/'manifest.json')['queries']}
    native = {(r['id'],r['pipeline_dop']):r for r in read(RUN/'native_memory_features17_full/RESULT.json')['records']}
    predictor = NativePredictor.load(RUN/'native_predictor_service17/MODEL.json')
    calls = read(OUT/'PREDICTOR_REQUESTS.json'); assert not calls['errors']
    calls = [r for r in calls['records'] if r['mode']!='bootstrap']
    assert len(calls)==128
    expected_csv = Counter((e['mode'],native[e['id'],4 if e['autodop_enabled'] else 0]['csv']) for e in events)
    assert Counter((p['mode'],p['csv']) for p in calls)==expected_csv, 'Native CSV changed or unaccounted callbacks'
    for p in calls:
        assert predictor.predict_csv(p['csv'],MODES[p['mode']])==p['prediction']
    wanted = {e['query_id']:e for e in events};assert len(wanted)==128
    matches = {}
    for _ in range(15):
        matches = {}
        with (ROOT.parents[1]/'output/fe/log/fe.audit.log').open() as stream:
            for line in stream:
                if ' [query] ' not in line: continue
                m=re.search(r'\|QueryId=([0-9a-f-]+)\|',line)
                if not m or m[1] not in wanted: continue
                assert m[1] not in matches
                matches[m[1]]=line.rstrip('\n')
        if matches.keys()==wanted.keys(): break
        time.sleep(1)
    assert matches.keys()==wanted.keys()
    history = read(OUT/'SLOT_HISTORY.json')['rows']
    normalize = lambda s:' '.join(s.split()).rstrip(';').rstrip()
    rows=[]
    for qid,e in wanted.items():
        line=matches[qid];q=manifest[e['id']]
        assert '|State=EOF|' in line and '|ErrorCode=|' in line and '|Db='+q['database']+'|' in line
        assert normalize(line.split('|Stmt=',1)[1].split('|Digest=',1)[0])==normalize(Path(q['sql_file']).read_text())
        pred=predictor.predict_csv(native[e['id'],4 if e['autodop_enabled'] else 0]['csv'],MODES[e['mode']])
        assert '|PredictMemBytes='+str(pred['encoded_cost_bytes'])+'|' in line
        expected=pred['expected_physical_slots'];assert '|Slots='+str(expected)+'|' in line
        slots=[h for h in history if h['query_id'].replace('-','')==qid.replace('-','')]
        assert len(slots)==1
        slot=slots[0];assert slot['state']=='RELEASED'
        assert int(slot['allocate_slots'])==int(slot['est_costs_slots'])==expected
        rows.append(dict(query_id=qid,id=e['id'],mode=e['mode'],phase=e['phase'],slots=expected,audit_line=line,slot_history=slot))
    for p in [OUT/'QUEUE_SETTINGS.json',OUT/'frontend_settings.json',OUT/'scored/frontend_settings.json']:
        assert read(p)['restored']
    rounds=read(OUT/'scored/collection.json')['rounds'];assert len(rounds)==8
    result={}
    for mode in MODES:
        rs=[r for r in rounds if r['mode']==mode and r['phase']=='measured'];assert len(rs)==1
        es=[e for e in events if e['mode']==mode and e['phase']=='measured'];assert len(es)==16
        lat=np.array([e['client_latency_ms'] for e in es])
        result[mode]=dict(batch_seconds=rs[0]['workload_wall_seconds'],qps=rs[0]['verified_queries_per_second'],
                          mean_ms=float(lat.mean()),p50_ms=float(np.percentile(lat,50)),p90_ms=float(np.percentile(lat,90)),p99_ms=float(np.percentile(lat,99)))
    comparisons={}
    for name,base,new in [('admission_native','native','native_budget'),('admission_heterogeneous','policy_static','policy_budget'),('heterogeneous_fixed8','native','policy_static'),('heterogeneous_predicted','native_budget','policy_budget')]:
        comparisons[name]={k:100*(1-result[new][k]/result[base][k]) for k in ['batch_seconds','mean_ms','p50_ms','p90_ms','p99_ms']}
    proof=dict(status='verified',executions=128,rows=rows,metrics=result,latency_reduction_percent=comparisons,
               scope='Two historical development queries; one measured finite batch per mode. Frozen full-development memory fit. Native V2 MBE, identical result verification, no retries. No unseen-query generalization, steady-state or contract claim.')
    proof['source_sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),OUT/'PREDICTOR_REQUESTS.json',OUT/'SLOT_HISTORY.json',OUT/'scored/events.jsonl',OUT/'scored/collection.json',OUT/'scored/independent_verification.json']}
    (OUT/'ALLOCATION_AUDIT.json').write_text(json.dumps(proof,indent=2)+'\n')
    lines=['# 原生预算准入并发小测','','| 模式 | 整批秒数 | QPS | 平均请求毫秒 | p90毫秒 |','|---|---:|---:|---:|---:|']
    for k,v in result.items():lines.append(f"| {k} | {v['batch_seconds']:.3f} | {v['qps']:.4f} | {v['mean_ms']:.2f} | {v['p90_ms']:.2f} |")
    lines+=['','128次执行全部核对结果、唯一查询ID、实际DOP（适用时）、预算响应、FE审计Slots及实际分配/释放。每组16任务正式批次；排队和预测计入请求耗时。固定预算对应8并发，预测预算独立于查询级/异构DOP模式。未重试，不自动扩大。','',proof['scope']]
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
    (OUT/'STATUS.json').write_text(json.dumps(dict(status='verified',executions=128))+'\n')
    print(json.dumps(dict(metrics=result,comparisons=comparisons)),flush=True)


if __name__=='__main__':main()
