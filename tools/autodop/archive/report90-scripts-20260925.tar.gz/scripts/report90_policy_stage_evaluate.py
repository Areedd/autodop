"""Evaluate fixed-final policy ablations through the existing identical online collector."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import torch
from autodop.model import load_policy_model
from collect_trusted_dataset import frontend_settings
from report90_execute import check
from report90_queue_extension import connect
from report90_wait_for_idle import wait_for_idle
from report90_policy_response_audit import audit as audit_policy_responses

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'runs/report90_20260912'
BASE=RUN/'policy_final_stage_ablation'


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_models():
    protocol=json.loads((BASE/'PROTOCOL.json').read_text())
    evaluation=json.loads((BASE/'EVALUATION_PROTOCOL.json').read_text())
    result=json.loads((BASE/'full/RESULT.json').read_text())
    assert result['status']=='verified' and result['phase']=='full'
    summary_path=BASE/'full/TRAINING_AUDIT.json'
    if not summary_path.exists():
        subprocess.run([sys.executable,str(ROOT/'scripts/report90_policy_stage_summary.py'),'--phase','full'],check=True)
    training_audit=json.loads(summary_path.read_text())
    assert training_audit['status']=='verified_recomputed_training_outputs' and training_audit['phase']=='full'
    for path,digest in training_audit['source_sha256'].items(): assert sha(path)==digest
    for path,digest in result['source_sha256'].items(): assert sha(path)==digest
    for path,digest in protocol['source_sha256'].items(): assert sha(path)==digest
    for path,digest in evaluation['source_sha256'].items(): assert sha(path)==digest
    torch.set_num_threads(1)
    initial,saved=load_policy_model(protocol['initial_policy'])
    contract=json.loads(Path(protocol['training_contract']).read_text())
    variants={};proof={}
    for arm,path in evaluation['checkpoints'].items():
        model,checkpoint=load_policy_model(path)
        assert checkpoint['metadata']==saved['metadata'] and checkpoint['model_config']==saved['model_config']
        if arm!='initial_no_final_stage':
            trained=result['arms'][arm]
            assert sha(path)==trained['checkpoint_sha256']
            assert trained['epochs']==protocol['epochs']==1000 and trained['steps']==1000 and trained['exact_reload']
            adaptation=checkpoint['training']['adaptation']
            assert adaptation['arm']==arm and adaptation['weights']==protocol['arms'][arm]
            assert adaptation['seed']==protocol['seed'] and adaptation['epochs']==1000
            assert adaptation['initial_policy_sha256']==sha(protocol['initial_policy'])
            assert set(adaptation['gradient_plan_keys'])==set(contract['train_plan_keys'])
        mode='stage_'+arm
        variants[mode]=dict(checkpoint=path,checkpoint_sha256=sha(path),load_correction=False)
        proof[arm]=dict(checkpoint_sha256=sha(path),parameter_count=sum(x.numel() for x in model.parameters()))
    full,_=load_policy_model(evaluation['checkpoints']['full'])
    deployed,_=load_policy_model(evaluation['deployed_reference'])
    a,b=full.state_dict(),deployed.state_dict()
    assert set(a)==set(b)
    reproduction=dict(exact_parameters=all(torch.equal(a[k],b[k]) for k in a),
                      max_abs_parameter_difference=max(float((a[k]-b[k]).abs().max()) for k in a),
                      scope='Parameter comparison, not an assumption that retraining must reproduce historical execution performance.')
    return evaluation,variants,dict(status='verified_fixed_final_checkpoints',models=proof,deployed_reproduction=reproduction)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--phase',choices=['pilot','full'],required=True)
    args=parser.parse_args()
    evaluation,variants,proof=verify_models()
    if args.phase=='full':
        pilot=BASE/'online_pilot/scored/independent_verification.json'
        assert json.loads(pilot.read_text())['all_expected_executions_verified']
        assert json.loads((BASE/'online_pilot/STATUS.json').read_text())['status']=='verified'
        assert json.loads((BASE/'online_pilot/POLICY_RESPONSE_AUDIT.json').read_text())['all_collection_modes_replayed']
    out=BASE/('online_'+args.phase)
    out.mkdir(exist_ok=False)
    def save(name,value): (out/name).write_text(json.dumps(value,indent=2)+'\n')
    selected=evaluation['pilot_query_ids'] if args.phase=='pilot' else evaluation['full_query_ids']
    manifest=json.loads((RUN/'manifest.json').read_text())
    queries=[q for q in manifest['queries'] if q['id'] in selected]
    assert len(queries)==len(selected)
    manifest['queries']=queries
    save('manifest.json',manifest);save('policy_variants.json',variants);save('MODEL_AUDIT.json',proof)
    cmd=[sys.executable,str(ROOT/'collect_paper_evaluations.py'),'--manifest',str(out/'manifest.json'),
         '--trusted-collection',str(ROOT/'runs/preference_random200_20260911/random200/trusted_merged.json'),
         '--output-dir',str(out/'scored'),'--policy-variants',str(out/'policy_variants.json'),
         '--modes',','.join(variants),'--scenario','serial','--query-timeout-s','180',
         '--auto-dop-max-dop','16','--torch-threads','1','--decision-timeout-ms',str(evaluation['decision_timeout_ms']),
         '--warmup','1','--repetitions','1','--seed','20260912']
    save('COMMAND.json',cmd)
    save('SOURCE_HASHES.json',{str(p):sha(p) for p in [Path(__file__),ROOT/'collect_paper_evaluations.py',
         ROOT/'scripts/verify_paper_evaluations.py',ROOT/'autodop/engine.py',BASE/'EVALUATION_PROTOCOL.json',BASE/'full/RESULT.json']})
    save('STATUS.json',dict(status='prepared',queries=len(queries),modes=len(variants),executions=2*len(queries)*len(variants)))
    wait_for_idle(check,out/'IDLE.json')
    try:
        with connect() as control,frontend_settings(control.cursor(),{'auto_dop_min_confidence':str(evaluation['confidence_threshold'])},
                                                   out/'confidence_settings.json',restore_connection_factory=connect):
            subprocess.run(cmd,check=True)
        subprocess.run([sys.executable,str(ROOT/'scripts/verify_paper_evaluations.py'),'--collection-dir',str(out/'scored'),
                        '--output',str(out/'scored/independent_verification.json')],check=True)
        assert json.loads((out/'scored/independent_verification.json').read_text())['all_expected_executions_verified']
        response_proof=audit_policy_responses(out/'scored',out/'POLICY_RESPONSE_AUDIT.json',threshold=evaluation['confidence_threshold'])
        assert response_proof['all_collection_modes_replayed']
        assert json.loads((out/'confidence_settings.json').read_text())['restored']
        save('STATUS.json',dict(status='verified',queries=len(queries),modes=len(variants),restored=True))
    except BaseException as error:
        save('STATUS.json',dict(status='failed',error=repr(error)))
        raise


if __name__=='__main__':main()
