"""Training-only reconstruction of deterministic flat graph statistics."""
import torch


def score_and_reconstruct(model, graph, head, target):
    nodes=model.encoder(graph)
    pooled,_=model.global_readout(nodes)
    score=model.scorer(pooled).squeeze(-1)
    reconstruction=head(pooled)
    if reconstruction.shape != target.shape:
        raise ValueError('reconstruction target shape mismatch')
    loss=torch.nn.functional.mse_loss(reconstruction,target)
    return score,loss
