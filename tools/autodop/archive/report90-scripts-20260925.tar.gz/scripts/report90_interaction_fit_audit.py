"""Measure training/validation fit of the selected interaction model without fitting."""
import argparse
import json
import os
from pathlib import Path

import numpy as np
import torch
import xgboost as xgb
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.training import select_partition
from report90_interaction_model import load_interaction_model
from report90_interaction_pair_audit import BASE, accuracy, make_pairs, sha
from report90_models import flat_features


def main(seed):
    os.sched_setaffinity(0, {35})
    torch.set_num_threads(1)
    folder = BASE / f'interaction_ranking/seed{seed}'
    audit_path = BASE / f'interaction_pair_audit_seed{seed}/RESULT.json'
    audit = json.loads(audit_path.read_text())
    for path, digest in audit['source_sha256'].items():
        assert sha(path) == digest
    record = json.loads((folder / 'RESULT.json').read_text())
    contract = json.loads((folder / 'CONTRACT.json').read_text())
    samples, pairs, metadata = load_dataset(BASE / 'merged_dataset')
    model, _ = load_interaction_model(record['selected']['transformer']['model'])
    model.eval()
    tree = xgb.XGBRanker()
    tree.load_model(record['selected']['xgboost_pairs']['model'])
    tree.set_params(n_jobs=1)
    norm = np.load(folder / 'FEATURE_NORMALIZATION.npz')
    result = {}
    for partition in ['train', 'valid']:
        subset, _ = select_partition(samples, pairs, contract, partition)
        subset = sorted(subset, key=lambda s: (s['plan_key'], s['config_key']))
        graphs = [build_graph(s, metadata) for s in subset]
        with torch.no_grad():
            scores = [float(model(g)) for g in graphs]
        flat = np.stack([(flat_features(g, metadata) - norm['mean']) / norm['std'] for g in graphs])
        tree_scores = tree.predict(flat).astype(float)
        assert np.isfinite(scores).all() and np.isfinite(tree_scores).all()
        pool = make_pairs(subset)
        result[partition] = {'samples': len(subset), 'plans': len({s['plan_key'] for s in subset}),
                             'transformer': accuracy(pool, scores), 'xgboost_pairs': accuracy(pool, tree_scores)}
        if partition == 'valid':
            for name in ['transformer', 'xgboost_pairs']:
                for metric in ['macro_accuracy', 'pooled_accuracy', 'cohorts']:
                    assert result[partition][name][metric] == audit['models'][name][metric]
    out = BASE / f'interaction_fit_audit_seed{seed}.json'
    assert not out.exists()
    result.update(status='verified', seed=seed,
                  scope='Selected development checkpoints; training fit is diagnostic only. Same 3% pair gap and tie rules in both partitions. No updates, no checkpoint selection, no SQL.',
                  source_sha256={str(p): sha(p) for p in [Path(__file__), audit_path, folder / 'RESULT.json', folder / 'CONTRACT.json', folder / 'FEATURE_NORMALIZATION.npz']})
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, choices=[17, 29, 43], required=True)
    main(parser.parse_args().seed)
