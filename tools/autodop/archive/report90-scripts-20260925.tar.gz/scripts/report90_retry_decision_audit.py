"""Join corroborated failed attempts to exact policy replay and independent traces."""
import collections
import json
import os
from pathlib import Path
import torch
from autodop.engine import PolicyEngine
from autodop.load_correction import apply_to_decision
from autodop.training import file_sha256
from report90_execute import RUN, ROOT
from verify_paper_evaluations import verify_trace


def main():
    out=RUN/'development17_retry';destination=out/'DECISION_AUDIT.json';assert not destination.exists()
    read=lambda p:json.loads(p.read_text())
    assert read(out/'RESULT.json')['status']=='verified'
    identities=read(out/'FAILURE_IDENTITY_AUDIT.json');assert identities['status']=='verified'
    os.sched_setaffinity(0,{35});torch.set_num_threads(1)
    protocol=read(RUN/'PROTOCOL.json');model=Path(protocol['model'])
    assert file_sha256(model)==protocol['model_sha256']
    engine=PolicyEngine(model)
    events_path=out/'scored/events.jsonl';decision_path=out/'scored/decisions.jsonl'
    events=[json.loads(x) for x in events_path.read_text().splitlines()]
    linked={qid:{**r,'attempt_status':'failed'} for qid,r in identities['failures'].items()}
    for e in events:
        if e['status']!='verified':continue
        qid=e['query_id'];assert qid not in linked
        linked[qid]={k:e[k] for k in ['id','mode','phase','client','sequence']}
        linked[qid].update(attempt_index=e['sql_attempt_count']-1,attempt_status='verified')
    traces={};trace_paths=sorted((out/'scored/raw').glob('*.jsonl'))
    for p in trace_paths:
        for line in p.read_text().splitlines():
            r=json.loads(line);qid=r.get('query_id')
            if qid not in linked:continue
            assert qid not in traces
            traces[qid]=r
    counts=collections.defaultdict(collections.Counter);rows=[];seen=set()
    for line in decision_path.read_text().splitlines():
        record=json.loads(line);qid=record['query_id'];assert qid not in seen;seen.add(qid)
        assert qid in linked,qid
        link=linked[qid];assert record['mode']==link['mode']
        request=record['request'];base=engine.decide(request)
        fragments={str(f['fragment_id']):f for f in request['fragments']}
        expected=base if record['mode']=='policy_static' else {**base,'decisions':[
            apply_to_decision(d,fragments[d['fragment_id']],request.get('worker_loads',{})) for d in base['decisions']]}
        assert expected['decisions']==record['response']['decisions']
        assert abs(expected['confidence']-record['response']['confidence'])<1e-7
        transitions=[f"{b['dop']}->{a['dop']}" for b,a in zip(base['decisions'],expected['decisions']) if b['dop']!=a['dop']]
        trace=traces.get(qid);installed=False;trace_error=None
        if trace is not None:
            try:
                installed=verify_trace(trace,qid)
                if installed:assert trace['response']['decisions']==record['response']['decisions']
            except (AssertionError,ValueError,RuntimeError) as error:
                trace_error=str(error)
        fresh=[l for l in request.get('worker_loads',{}).values() if l.get('fresh')]
        bucket=(link['mode'],link['phase'],link['attempt_status']);c=counts[bucket]
        c['decisions']+=1;c['changed']+=bool(transitions);c['installed_changed']+=bool(transitions) and installed
        c['trace_available']+=trace is not None;c['installation_verified']+=installed
        cpu=max((l['cpu_used'] for l in fresh),default=None)
        mem=max((l['mem_used_pct'] for l in fresh),default=None)
        c['cpu_over_threshold']+=cpu is not None and cpu>.4
        c['memory_over_threshold']+=mem is not None and mem>.65
        rows.append({'query_id':qid,**link,'max_fresh_cpu':cpu,'max_fresh_memory':mem,
                     'transitions':dict(collections.Counter(transitions)),'installation_verified':installed,
                     'trace_verification_error':trace_error,'decision_ms':record['decision_ms']})
    unlinked_auto=[qid for qid,r in linked.items() if r['mode']!='native' and qid not in seen]
    summaries=[{'mode':k[0],'phase':k[1],'attempt_status':k[2],**dict(v)} for k,v in sorted(counts.items())]
    result={'status':'verified','summaries':summaries,'rows':rows,'auto_attempts_without_decision':unlinked_auto,
            'scope':'All recorded decisions replay exactly. Failed attempt identity independently corroborated. Installation claimed only if unmodified trace verifier passes. Request-time load is not execution peak and does not establish causal effect of lowering DOP.',
            'source_sha256':{str(p):file_sha256(p) for p in [Path(__file__),model,events_path,decision_path,
                out/'FAILURE_IDENTITY_AUDIT.json',ROOT/'autodop/load_correction.py',ROOT/'scripts/verify_paper_evaluations.py',*trace_paths]}}
    destination.write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 重试并发中的成功与失败尝试决策核对','',result['scope'],'',
           '| 模式 | 阶段 | 尝试状态 | 精确复算决策 | 请求修正 | 核验安装修正 | CPU超阈值 | 内存超阈值 |',
           '|---|---|---|---:|---:|---:|---:|---:|']
    for r in summaries:
        lines.append(f"| {r['mode']} | {r['phase']} | {r['attempt_status']} | {r['decisions']} | {r['changed']} | {r['installed_changed']} | {r['cpu_over_threshold']} | {r['memory_over_threshold']} |")
    lines+=['',f'没有决策记录的AutoDOP尝试共{len(unlinked_auto)}次，单独保留，不推断其安装行为。',
             '请求时资源低于阈值不能排除执行期间内存超限；降DOP仍失败也不能单独证明降DOP无效，因为缺少同次执行的反事实。']
    (out/'DECISION_AUDIT.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))


if __name__=='__main__':main()
