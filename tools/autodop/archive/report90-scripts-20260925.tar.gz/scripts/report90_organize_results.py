"""Organize existing report evidence without running SQL or changing inputs."""
import csv
import hashlib
import io
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'runs/report90_20260912'
EXT = RUN / 'distillation_concurrency_extension'
OUT = RUN / 'organized_results'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUT.mkdir(exist_ok=True)
    (OUT / 'tables').mkdir(exist_ok=True)
    (OUT / 'data').mkdir(exist_ok=True)
    inputs = {}
    outputs = []

    def read(path):
        path = path.resolve()
        inputs[str(path)] = digest(path)
        return path.read_text()

    def write(name, content):
        path = OUT / name
        path.write_text(content)
        outputs.append(path)

    def js(name, value):
        write(name, json.dumps(value, ensure_ascii=False, indent=2) + '\n')

    def csv_file(name, rows):
        buf = io.StringIO(newline='')
        csv.writer(buf).writerows(rows)
        write(name, buf.getvalue())

    # Explicit roles prevent older model cohorts and concurrency environments being merged.
    specs = [
        ('01_workload', '查询、环境及训练数据', '主报告基础', '.', ['manifest.json', 'WORKLOAD_STRUCTURE.json', 'ENVIRONMENT.json', 'RUNTIME_ENVIRONMENT.json', 'TRAINING_SQL_INVENTORY.json'], '90条是历史200条中的优势筛选子集；不代表随机异构负载泛化。'),
        ('02_serial', '异构DOP端到端', '主结果', '.', ['SUMMARY.json', 'SERIAL_QUERY_MEANS.csv', 'PROTOCOL.json', 'PROTOCOL_AMENDMENTS.json'], '预热1轮、正式3轮；逐查询最佳统一DOP从1/2/4/8/16选择。'),
        ('03_models', 'Transformer与XGBoost', '主结果', 'structure_coverage20/basic_feature_stability', ['REPORT.md', 'RESULT.json'], '920有效验证对、历史/复杂两组等权；增强XGBoost准确率仍更高。'),
        ('04_mlp', 'MLP与显式DOP交互项', '消融', 'structure_coverage20/mlp_interaction_stability', ['REPORT.md', 'RESULT.json', 'PROTOCOL.json'], '三种子；完整/置零乘积列；不能隐藏输入特征差异。'),
        ('05_rank_loss', '同图排序与直接回归', '消融', 'models_full', ['RESULT.json', 'CONTRACT.json', 'SELECTED.json'], '较早699验证对、从头训练；不能与920对结果直接相减。'),
        ('06_search', '搜索检索效率与结构消融', '主结果', 'retrieval_independent_report90', ['REPORT.md', 'SUMMARY.json', 'RESULT.json', 'PROTOCOL.json', 'REFERENCE_PROTOCOL.json', 'FINAL_AUDIT.json'], '1620正式搜索；64评分预算；独立参考分位数不是SQL或全空间最优。'),
        ('07_search_sql', '搜索输出实际SQL质量', '补充', 'search_budget_report90/collection', ['PAIRED_REPORT.md'], '720次回放；改进搜索均值比随机慢2%，p99更低；保留原结果。'),
        ('08_policy', '策略最后训练阶段', '消融', 'policy_final_stage_ablation/online_full', ['REPORT.md', 'SUMMARY.json'], '900次执行；仅最后阶段消融，不等价于删除整个蒸馏。'),
        ('09_distill_train', '匹配教师学生训练', '蒸馏补充', 'distillation_concurrency_extension/matched_distillation_v2', ['PROTOCOL.json', 'LABELS.json', 'RESULT.json'], '114训练/22验证计划；新增学生与现网策略不同。'),
        ('10_distill_eval', '蒸馏决策成本与SQL回放', '蒸馏补充', 'distillation_concurrency_extension/distillation_report90', ['PROTOCOL.json', 'RESULT.json', 'CHOICES.json', 'collection_attempt1/RESULT.json'], '360次SQL；直接安装配置绕过置信度门限；90/90学生响应低于默认门限。'),
        ('11_batch', '16客户端有限批次并发', '早期并发', 'report90_native_budget_cap4_full', ['REPORT.md', 'PROTOCOL.json', 'ALLOCATION_AUDIT.json'], '720次执行；临时checkpoint修正版FE；不与新持续窗口直接作差。'),
        ('12_streams', '持续吞吐与负载修正', '最新并发主结果', 'distillation_concurrency_extension/streams_report90', ['REPORT.md', 'RESULT.json', 'AUDIT.json', 'ONLINE_AUDIT.json', 'PROTOCOL.json'], '1906次执行；1/4/8/12/16/20 streams；每格240秒，准入4；20档较峰值下降1.41%。'),
        ('13_resources', '资源、部署及准入校准', '并发补充', 'distillation_concurrency_extension', ['RESOURCE_AUDIT.json', 'LIVE_ENVIRONMENT.json', 'LIVE_DEPLOYMENT.json', 'FE_OPEN_JAR_IDENTITY.json', 'EXTENSION_RESULT.json'], '最新使用恢复后的原版FE；首格资源采样不完整；cap3/5小测未确认改善。'),
        ('14_cost', '搜索缓存及在线训练成本', '成本', 'prepared_search_cost', ['REPORT.md'], '缓存对所有对照共同启用；FE controller计时不等于完整优化器开销。'),
        ('15_cache', '在线缓存候选优化', '诊断，不是正式吞吐收益', 'distillation_concurrency_extension', ['CACHE_PARITY.json', 'CACHE_PILOT_DIAGNOSIS.json', 'CANONICAL_CACHE_PILOT.json'], '缓存默认关闭；规范化缓存仅离线回放，不能作为SQL吞吐收益。'),
        ('16_history', '完整历史实验及失败附录', '历史与探索', '.', ['FULL_REPORT.md', 'EXTENSION_SUMMARY.md', 'FINAL_REPORT_AUDIT.json', 'EXTENDED_REPORT_AUDIT.json', 'REPRODUCE.md'], '历史OOM、失败、回退、不同环境和旧模型结果分开保留。'),
    ]
    unified = RUN / 'six_model_control_20260919/full'
    if (unified / 'FINAL_AUDIT.json').exists():
        specs.append(('17_unified_models', '六组模型统一条件对照', '模型主对照',
                      'six_model_control_20260919/full',
                      ['UNIFIED_REPORT.md', 'RESULT.json', 'PROTOCOL.json', 'FINAL_AUDIT.json', 'METRICS.csv'],
                      '全部从头训练；同920评价对、三种子和统一选模；完整交互特征；与历史接续训练分开。'))
    basic = RUN / 'basic_four_control_20260920/full'
    if (basic / 'FINAL_AUDIT.json').exists():
        specs.append(('18_basic_models', '移除显式DOP乘积的四组基线', '当前基础特征主对照',
                      'basic_four_control_20260920/full',
                      ['UNIFIED_REPORT.md', 'RESULT.json', 'COMBINED_RESULT.json', 'MASK.json', 'FINAL_AUDIT.json'],
                      '同数据及训练设置；MLP置零532列，XGBoost输入556维；Transformer复用统一实验；完整特征结果保留。'))
    experiments = []
    for eid, title, role, folder, files, scope in specs:
        sources = []
        for name in files:
            p = RUN / folder / name
            if not p.is_file():
                raise FileNotFoundError(p)
            read(p)
            sources.append(str(p.resolve()))
        experiments.append(dict(id=eid, title=title, role=role, scope=scope,
                                directory=str((RUN / folder).resolve()), sources=sources))
    js('EXPERIMENTS.json', experiments)
    csv_file('EXPERIMENTS.csv', [['id', '实验', '角色', '适用范围', '证据目录', '证据文件']] +
             [[e['id'], e['title'], e['role'], e['scope'], e['directory'], '\n'.join(e['sources'])] for e in experiments])

    # Preserve exact numeric summaries, including precision not present in report tables.
    snapshots = {
        'serial_and_historical': RUN / 'SUMMARY.json',
        'model_comparison': RUN / 'structure_coverage20/basic_feature_stability/RESULT.json',
        'mlp_interaction': RUN / 'structure_coverage20/mlp_interaction_stability/RESULT.json',
        'ranking_regression': RUN / 'models_full/RESULT.json',
        'search_retrieval': RUN / 'retrieval_independent_report90/SUMMARY.json',
        'policy_final_stage': RUN / 'policy_final_stage_ablation/online_full/SUMMARY.json',
        'distillation_concurrency': EXT / 'EXTENSION_RESULT.json',
    }
    for name, path in snapshots.items():
        write(f'data/{name}.json', read(path))
    if (unified / 'FINAL_AUDIT.json').exists():
        write('data/unified_six_models.json', read(unified / 'RESULT.json'))
    if (basic / 'FINAL_AUDIT.json').exists():
        write('data/basic_four_models.json', read(basic / 'RESULT.json'))
    for name, path in {
        'serial_query_means': RUN / 'SERIAL_QUERY_MEANS.csv',
        'historical_concurrent_metrics': RUN / 'CONCURRENT_METRICS.csv',
        'sustained_streams': EXT / 'figures/sustained_streams.csv',
        'matched_distillation': EXT / 'figures/matched_distillation.csv',
    }.items():
        write(f'data/{name}.csv', read(path))

    table_index = []
    reports = {'main': RUN / 'FINAL_REPORT.md', 'extension': EXT / 'REPORT.md',
               'historical_appendix': RUN / 'FULL_REPORT.md'}
    if (unified / 'FINAL_AUDIT.json').exists():
        reports['unified_models'] = unified / 'UNIFIED_REPORT.md'
    if (basic / 'FINAL_AUDIT.json').exists():
        reports['basic_models'] = basic / 'UNIFIED_REPORT.md'
    for label, path in reports.items():
        lines = read(path).splitlines()
        heading = ''
        i = 0
        number = 0
        while i < len(lines):
            if lines[i].startswith('#'):
                heading = lines[i].lstrip('# ').strip()
            if (lines[i].startswith('|') and i + 1 < len(lines)
                    and re.fullmatch(r'[| :\-]+', lines[i + 1])):
                number += 1
                start = i + 1
                rows = [[x.strip() for x in lines[i].strip('|').split('|')]]
                i += 2
                while i < len(lines) and lines[i].startswith('|'):
                    rows.append([x.strip() for x in lines[i].strip('|').split('|')])
                    i += 1
                if any(len(row) != len(rows[0]) for row in rows):
                    raise ValueError(f'Unequal table width: {path}:{start}')
                name = f'tables/{label}_{number:02d}.csv'
                csv_file(name, rows)
                table_index.append(dict(file=name, section=heading, source=str(path), line=start,
                                        rows=len(rows)-1, precision='source report display precision'))
            else:
                i += 1
    js('TABLES.json', table_index)
    write('TABLES.md', '# 制表索引\n\nCSV 保留原报告的显示精度和百分号；高精度原值见 data/ 下 JSON 和逐查询 CSV。历史表不覆盖主结果。\n\n' +
          '\n'.join(f"- [{t['file']}]({t['file']})：{t['section']}（{t['rows']}行；[来源]({t['source']}:{t['line']})）" for t in table_index) + '\n')

    figures = []
    for base in [RUN / 'PRIMARY_LATENCY', RUN / 'FINAL_MODEL_COMPARISON',
                 RUN / 'retrieval_independent_report90/CONVERGENCE',
                 EXT / 'figures/sustained_streams', EXT / 'figures/matched_distillation']:
        for suffix in ['.png', '.pdf']:
            p = base.with_suffix(suffix)
            if p.exists():
                inputs[str(p)] = digest(p)
                figures.append(str(p))
    write('FIGURES.md', '# 报告主图\n\n' + '\n'.join(f'- [{Path(p).name}]({p})' for p in figures) +
          '\n\n持续吞吐和蒸馏图的高精度数据已复制至 data/；其他图依据原始报告和对应 sources.json 核验。\n')

    # All report/summary/protocol/audit entries are indexed, including failed pilots.
    inventory = []
    for p in sorted(RUN.rglob('*')):
        if not p.is_file() or OUT in p.parents:
            continue
        if p.suffix == '.md' or (p.suffix == '.json' and any(
                token in p.name.upper() for token in ('RESULT', 'SUMMARY', 'AUDIT', 'PROTOCOL', 'FAILURE', 'STATUS'))):
            inventory.append([str(p.relative_to(RUN)), p.stat().st_size])
    csv_file('HISTORICAL_INDEX.csv', [['relative_to_report90_directory', 'bytes']] + inventory)

    intro = '''# AutoDOP 测试报告实验结果总入口

已整理主实验、消融、成本、最新蒸馏与持续并发结果。此次仅整理已有产物，没有重新执行 SQL、修改模型或覆盖原始实验。原始大文件留在原目录，通过索引定位。

## 阅读与写作入口

- [完整合并报告](../FINAL_REPORT_EXTENDED.md)：可作为报告正文基础。
- [实验目录表](EXPERIMENTS.csv) / [机器可读目录](EXPERIMENTS.json)：16组实验的角色、范围及证据路径。
- [全部制表数据](TABLES.md)：主报告、补充报告、历史附录分开编号；不混合不同实验口径。
- [主图 PNG/PDF](FIGURES.md)；[历史证据总索引](HISTORICAL_INDEX.csv)；[本次整理校验](AUDIT.json)。
- [原报告复现说明](../REPRODUCE.md)；[补充实验复现说明](../distillation_concurrency_extension/REPRODUCE.md)。

## 可用于正文的结论

| 部分 | 已有结果 | 写作边界 |
|---|---|---|
| 异构端到端 | 相对原生/固定4/逐查询最佳统一DOP，平均延迟降低36.71%/36.57%/23.83% | 冻结90条历史优势子集；最佳统一基线为1/2/4/8/16候选 |
| 排序模型 | Transformer 86.442%，基本XGBoost 76.373%，MLP排序86.173%，增强XGBoost88.106% | 同920有效对、三种子；特征和训练历史不同，增强树更高 |
| 训练目标 | 同图从头训练：排序77.444%，回归69.385% | 较早699对；不能与920对的接续训练直接比较 |
| 搜索效率 | 95分位目标32次内命中：改进262/270，原MCTS233/270，随机220/270 | 独立参考候选分布；教师分数不等于SQL最优 |
| 最后策略阶段 | 完整组1599.82ms；去margin1628.80、去保留约束1769.23、去最大节点KL1715.21ms | 单轮正式执行，局部阶段消融 |
| 匹配蒸馏 | 决策203.838→6.781ms，约30.06倍；配置回放SQL均值降低11.18% | 新学生未部署；SQL回放绕过默认置信度门限 |
| 有限批次并发 | 同预算异构相对原生平均请求延迟降低25.69%，批次耗时降低24.98% | 16客户端、临时修正版FE；异构内部预算方案尾延迟有代价 |
| 持续并发 | AutoDOP峰值比共同准入原生高9.23%；20 streams保持峰值98.59% | 1906次执行；每格一次240秒；严格吞吐不下降未达到 |
| 调优成本 | FE controller平均18.007ms、p99 36.408ms；新增蒸馏训练循环18.56秒 | controller不是完整优化器；增量训练不含历史预训练和数据采集 |

精确数值、重复次数、模型身份和原始来源以各组证据为准；以上百分比为报告显示精度。data/ 保留7份结构化结果快照和4份逐查询/并发表，可直接进一步制表。

## 分组证据

'''
    for e in experiments:
        intro += f"### {e['id']} {e['title']}\n\n角色：{e['role']}。{e['scope']}\n\n"
        intro += '\n'.join(f'- [{Path(p).name}]({p})' for p in e['sources']) + '\n\n'
    intro += '''## 尚不能写成已通过的事项

- 标准 TPC-H SF100 streams 7–20、TP 基准和 TP/AP 完整 EXPLAIN 开销验收尚缺对应实验；当前构造查询不能替代。
- 持续吞吐20档比峰值回落1.41%；没有预先确认的噪声容差或独立重复，不能声明严格单调或显著稳定。
- 新学生90/90响应低于默认0.5置信度门限；并发测试使用原部署策略，不能把两者当作同一个新模型的端到端证据。
- 90条经过历史优势筛选，且验证结果经过反复开发分析，不能称随机样本或独立盲测。模型比较中的增强树结果、局部消融不获益和失败记录均保留。

## 复核与维护

运行 `python tools/autodop/scripts/report90_organize_results.py` 可重新整理，不连接数据库。AUDIT.json 记录输入和输出 SHA256、目录及链接检查。该核验确认整理的一致性，不代替原实验的SQL正确性核验或统计显著性验证。
'''
    if (unified / 'FINAL_AUDIT.json').exists():
        intro = intro.replace('16组实验', '17组实验').replace('保留7份结构化结果快照', '保留8份结构化结果快照')
        intro = intro.replace('## 可用于正文的结论',
                              '新增统一条件六模型对照见 [统一模型报告](../six_model_control_20260919/full/UNIFIED_REPORT.md)。下表模型准确率仍指历史开发设置，不能与新的从头训练实验混用。最新Word正文已分节收录两组结果。\n\n## 可用于正文的结论')
    if (basic / 'FINAL_AUDIT.json').exists():
        intro = intro.replace('17组实验', '18组实验').replace('保留8份结构化结果快照', '保留9份结构化结果快照')
        intro = intro.replace('## 可用于正文的结论', '当前主对照采用 [移除显式乘积项的基线](../basic_four_control_20260920/full/UNIFIED_REPORT.md)，完整特征版作为补充保留。\n\n## 可用于正文的结论')
    write('README.md', intro)
    inputs[str(Path(__file__).resolve())] = digest(Path(__file__).resolve())
    # Resolve every link created by this script (source line suffixes are display links).
    broken = []
    checked = 0
    for p in outputs:
        if p.suffix != '.md':
            continue
        for target in re.findall(r'\]\(([^)]+)\)', p.read_text()):
            target = re.sub(r':\d+$', '', target.split('#')[0])
            q = Path(target) if target.startswith('/') else p.parent / target
            # AUDIT is the final output, written after checking the index.
            if q.resolve() == (OUT / 'AUDIT.json').resolve():
                continue
            checked += 1
            if not q.exists():
                broken.append(str(q))
    if broken:
        raise ValueError(broken)
    js('AUDIT.json', dict(status='verified_organization_only', experiments=len(experiments),
                         extracted_tables=len(table_index), historical_index_entries=len(inventory),
                         checked_links=checked, broken_links=broken, input_sha256=inputs,
                         output_sha256={str(p.relative_to(OUT)): digest(p) for p in outputs}))
    print(json.dumps({'output': str(OUT), 'experiments': len(experiments),
                      'tables': len(table_index), 'historical_entries': len(inventory),
                      'checked_links': checked}, ensure_ascii=False))


if __name__ == '__main__':
    main()
