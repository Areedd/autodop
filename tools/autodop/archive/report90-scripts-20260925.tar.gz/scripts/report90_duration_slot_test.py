"""Exercise actual SlotTracker and SlotSelectionStrategyV2 using synthetic LogicalSlots."""
from pathlib import Path
import argparse
import json
import subprocess
import hashlib

ROOT = Path(__file__).resolve().parents[3]
SOURCE = r'''
package com.starrocks.qe.scheduler.slot;
import com.google.common.collect.ImmutableList;
import com.starrocks.common.Config;
import com.starrocks.metric.MetricRepo;
import com.starrocks.server.WarehouseManager;
import com.starrocks.system.BackendResourceStat;
import com.starrocks.thrift.TUniqueId;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class DurationSlotIntegrationTest {
    private boolean previous;
    private SlotSelectionStrategyV2 strategy;
    private SlotTracker tracker;
    private int total;
    @BeforeAll static void initialize() { MetricRepo.init(); }
    @BeforeEach void before() {
        previous = Config.enable_query_queue_v2;
        Config.enable_query_queue_v2 = true;
        BackendResourceStat.getInstance().setNumHardwareCoresOfBe(1, 16);
        var manager = new SlotManager(new ResourceUsageMonitor());
        strategy = new SlotSelectionStrategyV2(manager, WarehouseManager.DEFAULT_WAREHOUSE_ID);
        tracker = new SlotTracker(manager, ImmutableList.of(strategy));
        total = QueryQueueOptions.createFromEnv(WarehouseManager.DEFAULT_WAREHOUSE_ID).v2().getTotalSlots();
    }
    @AfterEach void after() {
        for (var slot : java.util.List.copyOf(tracker.getSlots())) tracker.releaseSlot(slot.getSlotId());
        assertEquals(0, ReportDurationBridge.REGISTRY.size());
        Config.enable_query_queue_v2 = previous;
        BackendResourceStat.getInstance().reset();
    }
    private LogicalSlot slot(long id, int slots, double duration) {
        var key = new TUniqueId(123, id);
        if (ReportDurationBridge.ENABLED && Double.isFinite(duration)) {
            long token = ReportDurationBridge.REGISTRY.begin(key);
            assertTrue(token > 0);
            assertTrue(ReportDurationBridge.REGISTRY.complete(key, token, duration));
        }
        return new LogicalSlot(key, "fe", 0, -1, slots, Long.MAX_VALUE, Long.MAX_VALUE, 0, 10, 1);
    }
    @Test void orderingRespectsCapacityAndReleasesPredictions() {
        var slow = slot(1, total, 50000); var fast = slot(2, total, 1);
        assertTrue(tracker.requireSlot(slow)); assertTrue(tracker.requireSlot(fast));
        var selected = strategy.peakSlotsToAllocate(tracker);
        assertEquals(1, selected.size());
        if (ReportDurationBridge.ENABLED) assertSame(fast, selected.get(0));
        var first = selected.get(0);
        tracker.allocateSlot(first);
        assertEquals(total, tracker.getNumAllocatedSlots());
        assertTrue(strategy.peakSlotsToAllocate(tracker).isEmpty());
        tracker.releaseSlot(first.getSlotId());
        assertTrue(Double.isNaN(ReportDurationBridge.REGISTRY.peek(first.getSlotId())));
        selected = strategy.peakSlotsToAllocate(tracker);
        assertEquals(1, selected.size());
        tracker.allocateSlot(selected.get(0));
        tracker.releaseSlot(selected.get(0).getSlotId());
        assertEquals(0, tracker.getNumAllocatedSlots());
        assertTrue(tracker.getSlots().isEmpty());
    }
    @Test void cancelledPendingPredictionIsRemovedWithoutAllocation() {
        var running = slot(3, total, 1); var pending = slot(4, total, 2);
        tracker.requireSlot(running); strategy.peakSlotsToAllocate(tracker); tracker.allocateSlot(running);
        tracker.requireSlot(pending);
        assertTrue(strategy.peakSlotsToAllocate(tracker).isEmpty());
        assertSame(pending, tracker.releaseSlot(pending.getSlotId()));
        assertTrue(Double.isNaN(ReportDurationBridge.REGISTRY.peek(pending.getSlotId())));
        assertEquals(total, tracker.getNumAllocatedSlots());
        tracker.releaseSlot(running.getSlotId());
        assertTrue(strategy.peakSlotsToAllocate(tracker).isEmpty());
    }
    @Test void missingPredictionUsesFifoWithoutLosingQueries() {
        var first = slot(5, total, 50000); var second = slot(6, total, 1);
        var unknown = slot(7, total, Double.NaN);
        tracker.requireSlot(first); tracker.requireSlot(second); tracker.requireSlot(unknown);
        var selected = strategy.peakSlotsToAllocate(tracker);
        assertEquals(1, selected.size());
        if (ReportDurationBridge.ENABLED) assertSame(first, selected.get(0));
        tracker.allocateSlot(selected.get(0)); tracker.releaseSlot(selected.get(0).getSlotId());
        for (int i = 0; i < 2; i++) {
            selected = strategy.peakSlotsToAllocate(tracker); assertEquals(1, selected.size());
            tracker.allocateSlot(selected.get(0)); tracker.releaseSlot(selected.get(0).getSlotId());
        }
        assertTrue(tracker.getSlots().isEmpty());
    }
    @Test void configuredBoundIsAppliedByActualStrategy() {
        if (!ReportDurationBridge.ENABLED) return;
        assertEquals(3, Integer.getInteger("autodop.report.maxDurationBypasses"));
        var old = slot(10, total, 50000);
        tracker.requireSlot(old);
        for (long id=11; id<=16; id++) tracker.requireSlot(slot(id,total,1));
        for (int i=0; i<3; i++) {
            var selected = strategy.peakSlotsToAllocate(tracker);
            assertEquals(1, selected.size()); assertNotSame(old,selected.get(0));
            tracker.allocateSlot(selected.get(0)); tracker.releaseSlot(selected.get(0).getSlotId());
        }
        var selected = strategy.peakSlotsToAllocate(tracker);
        assertEquals(1,selected.size()); assertSame(old,selected.get(0));
        tracker.allocateSlot(old); tracker.releaseSlot(old.getSlotId());
    }
}
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('integration', type=Path)
    args = parser.parse_args()
    integration = args.integration.resolve()
    out = integration / 'slot_validation'
    out.mkdir(exist_ok=False)
    source = out / 'DurationSlotIntegrationTest.java'
    source.write_text(SOURCE)
    prior = json.loads((integration / 'COMPILE_COMMAND.json').read_text())
    cp = str(integration / 'classes') + ':' + prior[prior.index('-cp') + 1]
    compile_cmd = ['javac', '--release', '17', '-proc:none', '-cp', cp, '-d', str(out), str(source)]
    run = ROOT / 'tools/autodop/runs/report90_20260912'
    junit = json.loads((run / 'duration_queue_validation/JUNIT_COMMAND.json').read_text())
    junit[junit.index('-cp') + 1] = str(out) + ':' + cp
    junit[-1] = 'com.starrocks.qe.scheduler.slot.DurationSlotIntegrationTest'
    commands = [('compile', compile_cmd)]
    for enabled in ['false', 'true']:
        commands.append((enabled, [junit[0], '-Dautodop.report.maxDurationBypasses=3', '-Dautodop.report.durationQueue=' + enabled, *junit[1:]]))
    result = dict(status='running', scope='Real FE slot tracker/strategy with synthetic slots, no live SQL or performance evidence.')
    try:
        for name, cmd in commands:
            (out / (name + '.command.json')).write_text(json.dumps(cmd, indent=2) + '\n')
            with (out / (name + '.log')).open('w') as log:
                process = subprocess.run(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=60)
            result[name] = process.returncode
            if process.returncode:
                result['status'] = 'failed'
                raise RuntimeError(str(out / (name + '.log')))
            if name != 'compile':
                assert '4 tests successful' in (out / (name + '.log')).read_text()
        result['status'] = 'verified_synthetic_slot_integration'
    finally:
        result['source_sha256'] = hashlib.sha256(source.read_bytes()).hexdigest()
        (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(dict(output=str(out), **result), indent=2))


if __name__ == '__main__':
    main()
