"""Recheck raw callback rows and FE audit identities independently of collection."""
from pathlib import Path
import argparse,csv,hashlib,io,json,re

BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/matched_development_duration'

def main(phase):
    out=BASE/phase;r=json.loads((out/'RESULT.json').read_text());assert r['status']=='verified'
    for p,h in r['source_sha256'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
    manifest=json.loads((BASE/'manifest.json').read_text());queries={q['id']:q for q in manifest['queries']}
    expected=set(manifest['pilot_ids']) if phase=='pilot' else set(queries)
    records=r['executions'];assert len(records)==2*len(expected) and {e['id'] for e in records}==expected
    raw=json.loads((out/'CAPTURE.json').read_text());assert not raw['errors'] and len(raw['calls'])==len(records)
    assert json.loads((out/'frontend_settings.json').read_text())['restored']
    calls={c['token']:c for c in raw['calls']};assert len(calls)==len(records)
    qids=set();phases={}
    for e in records:
        q=queries[e['id']];c=calls[e['token']]
        assert e['feature_record']==c
        assert e['result_digest']==q['native_result_digest'] and e['sql_sha256']==q['sql_sha256']
        assert hashlib.sha256(Path(q['sql_file']).read_bytes()).hexdigest()==q['sql_sha256']
        rows=list(csv.reader(io.StringIO(c['csv'])));assert rows[0]==c['header'] and list(map(int,rows[1]))==c['values']
        values=dict(zip(c['header'],c['values']));assert len(values)==384
        assert {k:values[k] for k in ['env_0','env_1','env_2','var_0']}==dict(env_0=3,env_1=8,env_2=23,var_0=0)
        line=e['audit_line'];assert e['token'] in line and '|QueryId='+e['query_id']+'|' in line
        assert '|PredictMemBytes='+str(e['sentinel_bytes'])+'|' in line and '|State=EOF|' in line
        assert e['query_id'] not in qids;qids.add(e['query_id'])
        assert e['client_latency_ms']>0
        phases.setdefault(e['id'],[]).append(e['phase'])
    assert all(sorted(v)==['measured','warmup'] for v in phases.values())
    sources=[Path(__file__),out/'RESULT.json',out/'CAPTURE.json',out/'frontend_settings.json',BASE/'manifest.json']
    result=dict(status='verified',queries=len(expected),executions=len(records),columns=384,restored=True,
                scope='Raw CSV/schema/environment/native DOP, complete phases, trusted result digests, callback tokens and FE query IDs rechecked. Client durations include callback overhead; not BE-only latency or model accuracy.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    (out/'INDEPENDENT_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['pilot','full'],required=True);main(p.parse_args().phase)
