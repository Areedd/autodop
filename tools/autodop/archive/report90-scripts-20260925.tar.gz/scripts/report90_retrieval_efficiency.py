"""Descriptive first-hit efficiency from existing development search traces."""
import json
import hashlib
from pathlib import Path
import numpy as np

RUN = Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    source = RUN/'search_budget_screen/RESULT.json'
    raw = json.loads(source.read_text())
    assert raw['status'] == 'verified_prefix_screen'
    rows = [r for r in raw['rows'] if r['budget'] == 64]
    assert len(rows) == 24
    methods = ['refined', 'random_batch']
    queries = sorted({r['query'] for r in rows})
    records = []
    for query in queries:
        pool = {}
        for r in rows:
            if r['query'] != query:
                continue
            assert len(r['configs']) == len(r['scores']) == 64
            for config, score in zip(r['configs'], r['scores']):
                key = tuple(config)
                if key in pool:
                    assert pool[key] == score
                pool[key] = score
        # Shared empirical targets for both methods and all seeds of this query.
        # This is observed surrogate quality, not a global optimum or SQL quality.
        for quantile in [.90, .95, 1.0]:
            target = float(np.quantile(list(pool.values()), quantile, method='higher'))
            for r in rows:
                if r['query'] != query:
                    continue
                hits = [i+1 for i, score in enumerate(r['scores']) if score >= target]
                records.append(dict(query=query, seed=r['seed'], method=r['method'],
                    target_quantile=quantile, target_score=target,
                    pooled_unique_candidates=len(pool), first_hit=hits[0] if hits else None,
                    capped_cost=hits[0] if hits else 65,
                    hit_by_budget={str(b): bool(hits and hits[0] <= b) for b in [16,32,64]}))
    summary = []
    for quantile in [.90, .95, 1.0]:
        for method in methods:
            selected = [r for r in records if r['target_quantile'] == quantile and r['method'] == method]
            assert len(selected) == 12
            summary.append(dict(method=method, target_quantile=quantile, trials=12,
                hits={str(b): sum(r['hit_by_budget'][str(b)] for r in selected) for b in [16,32,64]},
                mean_capped_cost=float(np.mean([r['capped_cost'] for r in selected]))))
    out = RUN/'retrieval_efficiency'
    out.mkdir(exist_ok=True)
    (out/'RESULT.json').write_text(json.dumps(dict(status='verified_trace_summary',
        protocol='Post-hoc descriptive analysis. Shared per-query deduplicated pool across both methods and three seeds; empirical score quantiles90/95/100. Failed64-budget trials assigned65 only for capped descriptive cost. No per-step timestamps; no time-to-target claim.',
        summary=summary, records=records,
        source_sha256={str(p): sha(p) for p in [Path(__file__), source]}), indent=2)+'\n')
    lines = ['# 搜索检索效率：已有开发轨迹复核', '',
        '按用户最新要求，候选检索效率成为搜索主要评价；查询执行延迟保留为质量参考，不再要求平均执行延迟领先。', '',
        '复用4条开发查询、固定3种子、每方法64次评分。每条查询合并两方法全部种子的候选并按DOP向量去重，以冻结教师评分的90%、95%分位数及观测最高分作共同目标。全部三个目标同时列出，不选有利阈值。', '',
        '| 共同目标 | 方法 | 16次内命中/12 | 32次内命中/12 | 64次内命中/12 | 截断评分次数均值 |',
        '|---|---|---:|---:|---:|---:|']
    for r in summary:
        lines.append(f"| {100*r['target_quantile']:.0f}%分位 | {r['method']} | {r['hits']['16']} | {r['hits']['32']} | {r['hits']['64']} | {r['mean_capped_cost']:.2f} |")
    lines += ['', '未达到目标的试验记为>64；仅在截断描述均值中记65，不删除失败，也不将65解释为真正命中次数。评分次数包含锚点和重复候选；不包含重要性编码，因此实际耗时另报。', '',
        '共同目标来自当前候选池，是事后描述性的代理分数标准，不是全空间最优、实际SQL最优或独立验证。不能比较不同查询的原始分数。该轨迹没有逐候选时间戳，不能推算达到目标的真实耗时。', '',
        '已有同构图、同静态缓存的64候选计时：改进搜索240.95ms、批量随机172.83ms（4查询各4轮、查询中位数的平均）。它们是固定预算耗时，不是上述目标命中耗时。见 [计时证据](../prepared_search_cost/REPORT.md)。', '',
        '后续正式检索效率对照应统一模型、候选域和实现优化，比较原MCTS、改进MCTS、随机搜索及注意力/等价类消融；记录每次评分后的最佳分数与累计实际时间，报告命中率、评分次数和时间曲线。小规模可穷举空间再报告真实代理目标差距，不能把经验池最高分写成全局最优。', '',
        '[全部逐查询记录及来源](RESULT.json)。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
