"""Frozen four-query native scheduling pilot; every callback carries the FE execution ID."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pymysql
from collect_trusted_dataset import frontend_settings, fetch_timed, result_digest
import report90_fe_timing as fe
from report90_execute import check
from report90_native_duration_predictor import DurationPredictor
from report90_queue_extension import settings_guard
from report90_wait_for_idle import wait_for_idle

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'runs/report90_20260912'
BASE = RUN / 'duration_concurrent_development'


def main():
    protocol = json.loads((BASE / 'PROTOCOL.json').read_text())
    expected_jar = os.environ['REPORT90_DURATION_JAR_SHA256']
    assert fe.sha(fe.JAR) == expected_jar
    assert b'-Dautodop.report.durationQueue=true' in Path(f'/proc/{fe.fe_pid()}/cmdline').read_bytes()
    out = BASE / 'pilot'
    out.mkdir(exist_ok=False)
    def save(name, value):
        (out / name).write_text(json.dumps(value, indent=2) + '\n')
    save('STATUS.json', dict(status='preflight', pid=os.getpid()))
    wait_for_idle(check, out / 'IDLE.json')
    os.sched_setaffinity(0, {35})
    for path, digest in protocol['source_sha256'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
    queries = {q['id']: q for q in protocol['queries']}
    for q in queries.values():
        assert hashlib.sha256(Path(q['sql_file']).read_bytes()).hexdigest() == q['sql_sha256']
    header = json.loads((RUN / 'matched_development_duration/full/RESULT.json').read_text())['executions'][0]['feature_record']['header']
    adapter = DurationPredictor.load(protocol['model'], header, protocol['model_sha256'])
    connect = lambda: pymysql.connect(host='127.0.0.1', port=9030, user='root', autocommit=True,
                                      connect_timeout=5, read_timeout=200)
    lock = threading.Lock()
    state = dict(mode='bootstrap', batch=-1)
    calls, errors, executions, batches = [], [], [], []
    healthy = threading.Event()
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args): pass
        def do_GET(self):
            self.send_response(200 if self.path == '/health_check' else 404)
            self.end_headers()
            if self.path == '/health_check': healthy.set()
        def do_POST(self):
            try:
                start = time.monotonic_ns()
                assert self.path == '/predict_csv'
                query_id = str(uuid.UUID(self.headers['X-AutoDOP-Execution-Id']))
                size = int(self.headers['Content-Length'])
                assert 0 < size < 1000000
                body = self.rfile.read(size).decode()
                duration = adapter.predict_csv(body)
                with lock:
                    record = dict(state, query_id=query_id, csv=body, duration_ms=duration,
                                  service_ns=time.monotonic_ns()-start)
                    calls.append(record)
                self.send_response(200)
                if record['mode'] == 'predicted_duration':
                    self.send_header('X-AutoDOP-Duration-Ms', str(duration))
                self.end_headers()
                self.wfile.write(str(protocol['fixed_memory_response_bytes']).encode())
            except BaseException as error:
                with lock: errors.append(repr(error))
                self.send_response(500); self.end_headers()
    class Server(ThreadingHTTPServer):
        daemon_threads = False
        block_on_close = True
    server = Server(('127.0.0.1', 18083), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    def setup(cursor, q):
        cursor.execute('USE `' + q['database'] + '`')
        for setting in ['enable_auto_dop=false', 'pipeline_dop=0', 'enable_runtime_adaptive_dop=false',
                        'enable_query_cache=false', 'enable_spill=false', 'enable_profile=false', 'query_timeout=180']:
            cursor.execute('SET ' + setting)
    try:
        for filename in ['fe.log', 'fe.audit.log']:
            path = ROOT.parents[1] / 'output/fe/log' / filename
            save(filename + '.start.json', dict(path=str(path), inode=path.stat().st_ino, offset=path.stat().st_size))
        with settings_guard(out), connect() as control:
            with control.cursor() as cursor:
                cursor.execute("ADMIN SHOW FRONTEND CONFIG LIKE 'enable_query_queue_v2'")
                assert str(cursor.fetchone()[2]).lower() == 'true'
                updates = dict(query_queue_slots_estimator_strategy='MBE', query_queue_v2_concurrency_level='4',
                               query_cost_prediction_service_address='http://127.0.0.1:18083', enable_query_cost_prediction='true')
                with frontend_settings(cursor, updates, out / 'frontend_settings.json', restore_connection_factory=connect):
                    # Explicit scheduler-only bootstrap initializes the health checker; no BE data execution.
                    with connect() as bootstrap, bootstrap.cursor() as c:
                        q = queries[protocol['orders']['short_first'][0]]
                        setup(c, q)
                        c.execute('EXPLAIN SCHEDULER /* duration_bootstrap */ ' + Path(q['sql_file']).read_text().strip().rstrip(';'))
                        save('BOOTSTRAP.json', dict(rows=c.fetchall(), included_in_performance=False))
                    assert healthy.wait(45), 'Prediction health not ready; fixed MBE slots cannot be assumed'
                    for batch_id, batch in enumerate(protocol['batch_sequence']):
                        with lock: state.update(mode=batch['mode'], batch=batch_id)
                        jobs = [query for query in protocol['orders'][batch['order']] for _ in range(protocol['copies_per_query'])]
                        release = {}
                        barrier = threading.Barrier(len(jobs) + 1, timeout=30,
                                                    action=lambda: release.update(start=time.monotonic() + .2))
                        def worker(rank, query):
                            q = queries[query]
                            event = dict(batch=batch_id, **batch, rank=rank, id=query, database=q['database'],
                                         token='duration_concurrent_' + uuid.uuid4().hex)
                            try:
                                with connect() as client, client.cursor() as c:
                                    setup(c, q)
                                    barrier.wait()
                                    target = release['start'] + rank * protocol['release_interval_ms'] / 1000
                                    delay = target - time.monotonic()
                                    if delay > 0: time.sleep(delay)
                                    event['released_monotonic'] = time.monotonic()
                                    event['release_lateness_ms'] = (event['released_monotonic'] - target) * 1000
                                    sql = '/* ' + event['token'] + ' */ ' + Path(q['sql_file']).read_text().strip().rstrip(';')
                                    event['sql'] = sql
                                    rows = fetch_timed(c, sql, event)
                                    event['result_digest'] = result_digest(rows)
                                    assert event['result_digest'] == q['native_result_digest']
                                    event['status'] = 'result_verified'
                            except BaseException as error:
                                event.update(status='failed', error=repr(error))
                            return event
                        with concurrent.futures.ThreadPoolExecutor(max_workers=protocol['clients']) as pool:
                            futures = [pool.submit(worker, rank, q) for rank, q in enumerate(jobs)]
                            barrier.wait()
                            rows = [future.result() for future in futures]
                        executions.extend(rows)
                        finish = max(r.get('sql_finished_monotonic', release['start']) for r in rows)
                        batches.append(dict(batch=batch_id, **batch, start=release['start'], finish=finish,
                                            duration_s=finish-release['start']))
                        save('CAPTURE.json', dict(executions=executions, calls=calls, errors=errors, batches=batches))
                        assert all(r['status'] == 'result_verified' for r in rows) and not errors
                        print(json.dumps(dict(batch=batch_id, completed=len(executions), expected=protocol['total_executions'])), flush=True)
        assert len(executions) == protocol['total_executions']
        assert json.loads((out / 'QUEUE_SETTINGS.json').read_text())['restored']
        assert json.loads((out / 'frontend_settings.json').read_text())['restored']
        save('STATUS.json', dict(status='collected_pending_audit', executions=len(executions), restored=True))
    except BaseException as error:
        save('CAPTURE.json', dict(executions=executions, calls=calls, errors=errors, batches=batches))
        save('STATUS.json', dict(status='failed', error=repr(error)))
        raise
    finally:
        server.shutdown(); server.server_close()
        for filename in ['fe.log', 'fe.audit.log']:
            marker = out / (filename + '.start.json')
            if marker.exists():
                start = json.loads(marker.read_text())
                with Path(start['path']).open('rb') as stream:
                    assert os.fstat(stream.fileno()).st_ino == start['inode'], 'Log rotated; cannot certify capture'
                    stream.seek(start['offset'])
                    (out / (filename + '.captured')).write_bytes(stream.read())


if __name__ == '__main__':
    main()
