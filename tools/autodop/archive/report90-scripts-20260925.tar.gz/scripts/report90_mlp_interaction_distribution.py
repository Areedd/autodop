"""Query-level feature effects; descriptive cluster intervals, not blind inference."""
import json
import os
from pathlib import Path
import numpy as np
from autodop.data import load_dataset
from autodop.training import select_partition
from report90_interaction_pair_audit import BASE,sha,make_pairs,accuracy


def main():
    os.sched_setaffinity(0,{35})
    out=BASE/'mlp_interaction100';path=out/'PAIR_AUDIT.json'
    audit=json.loads(path.read_text());assert audit['status']=='verified_independent_pair_replay'
    for p,digest in audit['source_sha256'].items():assert sha(p)==digest
    samples,pairs,_=load_dataset(BASE/'merged_dataset')
    contract=json.loads((BASE/'retrained/CONTRACT.json').read_text())
    valid,_=select_partition(samples,pairs,contract,'valid')
    valid=sorted(valid,key=lambda s:(s['plan_key'],s['config_key']))
    pool=make_pairs(valid);assert len(pool)==920
    queries=sorted({p['plan_key'] for p in pool});assert len(queries)==22
    results={};rng=np.random.default_rng(20260914)
    cohorts=sorted({p['cohort'] for p in pool})
    draws={}
    for cohort in cohorts:
        n=len({p['plan_key'] for p in pool if p['cohort']==cohort})
        draws[cohort]=rng.integers(0,n,size=(10000,n))
    for kind,arms in audit['models'].items():
        for arm,r in arms.items():assert accuracy(pool,r['scores'])['macro_accuracy']==r['macro_accuracy']
        rows=[]
        for plan in queries:
            ps=[p for p in pool if p['plan_key']==plan]
            counts={}
            for arm,r in arms.items():
                scores=r['scores'];counts[arm]=sum(scores[p['fast_index']]>scores[p['slow_index']] for p in ps)
            rows.append(dict(plan_key=plan,cohort=ps[0]['cohort'],pairs=len(ps),correct=counts,
                             difference_pp=100*(counts['full']-counts['no_explicit_interaction'])/len(ps)))
        bootstrap=np.zeros(10000)
        for cohort in cohorts:
            rs=[r for r in rows if r['cohort']==cohort]
            numerator=np.array([r['correct']['full']-r['correct']['no_explicit_interaction'] for r in rs])
            denominator=np.array([r['pairs'] for r in rs])
            ix=draws[cohort]
            bootstrap+=100*numerator[ix].sum(1)/denominator[ix].sum(1)/len(cohorts)
        results[kind]=dict(full_minus_masked_pp=100*(arms['full']['macro_accuracy']-arms['no_explicit_interaction']['macro_accuracy']),
                           queries_full_better=sum(r['difference_pp']>0 for r in rows),
                           queries_full_worse=sum(r['difference_pp']<0 for r in rows),
                           queries_tied=sum(r['difference_pp']==0 for r in rows),
                           descriptive_interval95_pp=np.quantile(bootstrap,[.025,.975]).tolist(),queries=rows)
    result=dict(status='verified_query_distribution',models=results,bootstrap_seed=20260914,draws=10000,
                scope='Paired query-cluster resampling within cohorts. Post-selection reused validation, fixed seed17; descriptive only, no blind-test significance or training-seed uncertainty.',
                source_sha256={str(p):sha(p) for p in [Path(__file__),path,BASE/'merged_dataset/samples.jsonl',BASE/'retrained/CONTRACT.json']})
    (out/'QUERY_DISTRIBUTION.json').write_text(json.dumps(result,indent=2)+'\n')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,3,figsize=(12,4),sharey=True)
    for ax,(kind,r) in zip(axes,results.items()):
        values=[row['difference_pp'] for row in r['queries']]
        ax.bar(range(1,23),values,color=['#2563eb' if v>=0 else '#d97706' for v in values])
        ax.axhline(0,color='black',linewidth=.7);ax.set_title(kind);ax.set_xlabel('Validation query index')
    axes[0].set_ylabel('Full minus no-interaction accuracy (pp)')
    fig.suptitle('MLP feature intervention: 100 epochs, seed17, reused validation')
    fig.tight_layout();fig.savefig(out/'QUERY_DISTRIBUTION.png',dpi=180);fig.savefig(out/'QUERY_DISTRIBUTION.pdf');plt.close(fig)
    lines=['# MLP交互项收益的查询分布','',
           '| 模型 | 完整组胜/负/平 | 等权准确率差（百分点） | 描述性95%区间 |','|---|---|---:|---|']
    for kind,r in results.items():
        lo,hi=r['descriptive_interval95_pp']
        lines.append(f"| {kind} | {r['queries_full_better']}/{r['queries_full_worse']}/{r['queries_tied']} | {r['full_minus_masked_pp']:.3f} | [{lo:.3f}, {hi:.3f}] |")
    lines += ['', '![逐查询准确率差](QUERY_DISTRIBUTION.png)', '',
              '按两类查询分层，以整条查询为单位配对重采样10000次，保留同一查询内部排序对的相关性。区间基于已选模型和复用开发集，仅作描述，不能当作盲测显著性，也未覆盖训练种子随机性。', '',
              '横轴按计划哈希排序，三图查询顺序相同；全部22条查询均保留。图中逐查询百分点与主指标两类等权汇总的权重不同，不可简单对柱高取均值替代主指标。', '',
              '完整计数：[QUERY_DISTRIBUTION.json](QUERY_DISTRIBUTION.json)；可导出图：[PDF](QUERY_DISTRIBUTION.pdf)。']
    (out/'QUERY_DISTRIBUTION.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:{a:v for a,v in r.items() if a!='queries'} for k,r in results.items()},indent=2))


if __name__=='__main__':main()
