"""Measure original teacher on frozen validation and already measured90 candidate pools."""
import json,hashlib
from pathlib import Path
from collections import defaultdict
import numpy as np
import torch
import xgboost as xgb
from report90_models import prepare_data,flat_features,metrics,RUN
from autodop.data import load_dataset
from autodop.model import load_cost_model
from autodop.graph import build_graph,sample_from_request

torch.set_num_threads(1);O=RUN/'original_teacher_audit';O.mkdir(exist_ok=True)
samples,tr,va,tp,meta,contract=prepare_data();oldpath=RUN.parent/'multi_structure_feedback_cost05_20260910/model/cost.pt';old,ck=load_cost_model(oldpath);old.eval()
new,_=load_cost_model(RUN/'models_full/transformer_rank_s17_h1/model.pt');new.eval();tree=xgb.XGBRanker();tree.load_model(RUN/'models_full/xgb_rank_s17_h1/model.ubj');tree.set_params(n_jobs=1);norm=np.load(RUN/'models_full/FEATURE_NORMALIZATION.npz')
assert set(ck['training']['valid_plan_keys'])==set(contract['valid_plan_keys'])

def score(sample):
 g=build_graph(sample,meta);og=build_graph(sample,ck['metadata'])
 with torch.no_grad():a=float(old(og));b=float(new(g))
 c=float(tree.predict(np.array([(flat_features(g,meta)-norm['mean'])/norm['std']]))[0])
 return a,b,c
names=['original_multistage_transformer','retrained30_transformer','xgboost_rank']
out={'model':str(oldpath),'sha256':hashlib.sha256(oldpath.read_bytes()).hexdigest(),'model_config':ck['model_config'],'evaluations':{}}
dataset_scores={}
for label,ss in [('train_descriptive',tr),('validation',va)]:
 scores=np.array([score(s) for s in ss]);dataset_scores.update({(s['plan_key'],s['config_key']):list(sc) for s,sc in zip(ss,scores)});out['evaluations'][label]={name:metrics(ss,scores[:,i]) for i,name in enumerate(names)};print(label,[(n,out['evaluations'][label][n]['rank_accuracy']) for n in names],flush=True)
_,all_pairs,_=load_dataset(RUN.parent/'multi_structure_feedback_cost05_20260910/dataset')
for label,keys in [('curated_train_pairs',set(contract['train_plan_keys'])),('curated_valid_pairs',set(contract['valid_plan_keys']))]:
 pp=[p for p in all_pairs if p['plan_key'] in keys];out['evaluations'][label]={name:{'ranking_pairs':len(pp),'rank_accuracy':sum(dataset_scores[p['plan_key'],p['fast_config_key']][i]>dataset_scores[p['plan_key'],p['slow_config_key']][i] for p in pp)/len(pp)} for i,name in enumerate(names)}
 print(label,out['evaluations'][label],flush=True)
summary=json.loads((RUN/'SUMMARY.json').read_text());means=summary['serial']['per_query_mean_ms'];repaired=set(summary['serial_repair']['replaced_queries']);vectors={f:json.loads((RUN/f/'vectors.json').read_text()) for f in ['choices','choices_attempt1']}
replay=['cost_transformer_rank','cost_transformer_regression','cost_mlp_rank','cost_xgb_regression','cost_xgb_rank','teacher_mcts','search_no_equivalence','search_no_attention','search_random','policy_vector']
sets={'fixed90_uniform':([],[]),'fixed90_observed_pool':([],[])};details=[]
for q in sorted(means['native']):
 v=vectors['choices_attempt1' if q in repaired else 'choices'];entry=v['policy_vector'][q];sample=sample_from_request(entry['request']);pool=defaultdict(list)
 for mode in replay:pool[tuple(v[mode][q]['fragment_dops'][fid] for fid in sample['fragment_ids'])].append(means[mode][q])
 uniforms=[]
 for d in [1,2,4,8,16]:
  config=tuple(1 if f.get('is_gather_root') else d for f in sample['fragments']);uniforms.append(config);pool[config].append(means['uniform'+str(d)][q])
 for config,latencies in pool.items():
  scores=score({**sample,'dop_config':list(config)});record={'plan_key':q,'config_key':str(config),'latency_ms':float(np.mean(latencies))}
  sets['fixed90_observed_pool'][0].append(record);sets['fixed90_observed_pool'][1].append(scores)
  if config in uniforms:
   u={**record,'latency_ms':means['uniform'+str([1,2,4,8,16][uniforms.index(config)])][q]};sets['fixed90_uniform'][0].append(u);sets['fixed90_uniform'][1].append(scores)
  details.append({'id':q,'dops':config,'mode_mean_latencies_ms':latencies,'scores':dict(zip(names,scores))})
for label,(ss,scores) in sets.items():
 scores=np.array(scores);out['evaluations'][label]={name:metrics(ss,scores[:,i]) for i,name in enumerate(names)};print(label,[(n,out['evaluations'][label][n]['rank_accuracy']) for n in names],flush=True)
out['scope']={'train_descriptive':'Training labels, not heldout accuracy.','validation':'Same14 heldout plans148configurations; exclude pairs <3% latency difference, strictscoreties incorrect.','fixed90_uniform':'90 queries times5 uniformDOPs, same887pairs as prior audit; predictions offline, no newSQL.','fixed90_observed_pool':'Only actually measured fiveuniform and ten replaymode configs. Identical configs pooled using mean ofmode means. Posthoc diagnostic, not complete candidatepool/globalranking; excludes onlinepolicy confidencefallback and native.'}
(O/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n');(O/'POOL_SCORES.json').write_text(json.dumps(details,indent=2)+'\n')
