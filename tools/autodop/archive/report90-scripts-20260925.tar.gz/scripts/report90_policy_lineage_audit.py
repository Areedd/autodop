"""Read retained policy checkpoints and audit hash-linked training ancestry.

This is a provenance audit, not a training ablation or a performance experiment.
"""
import hashlib
import json
from pathlib import Path
import subprocess

import torch

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'runs/report90_20260912'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    out = RUN / 'policy_lineage_audit'
    out.mkdir(exist_ok=False)
    # Scan every retained .pt filename, including checkpoints not named policy.pt.
    names = subprocess.check_output(
        ['rg', '--files', '--hidden', '--no-ignore', str(ROOT / 'runs'), '-g', '*.pt'], text=True
    ).splitlines()
    inventory, errors = [], []
    for name in sorted(names):
        path = Path(name)
        try:
            saved = torch.load(path, map_location='cpu', weights_only=False)
        except Exception as error:
            errors.append(dict(path=name, error=repr(error)))
            continue
        if not isinstance(saved, dict) or saved.get('kind') != 'policy':
            continue
        training = saved.get('training', {})
        adaptation = training.get('adaptation', {})
        parents = []
        def walk(value, prefix='training'):
            if isinstance(value, dict):
                for key, item in value.items():
                    field = prefix + '.' + key
                    if key in ('initial_policy_sha256', 'initial_sha256') and isinstance(item, str):
                        parents.append(dict(field=field, sha256=item))
                    walk(item, field)
        walk(training)
        inventory.append(dict(path=name, sha256=sha(path), parent_references=parents,
                              train_plans=len(training.get('train_plan_keys', [])),
                              valid_plans=len(training.get('valid_plan_keys', [])),
                              adaptation=adaptation,
                              training_keys=sorted(training)))
    by_hash = {}
    for item in inventory:
        by_hash.setdefault(item['sha256'], []).append(item)
    deployed = ROOT / 'runs/structural_scale_development01_20260911/policy_preservation02/model/policy.pt'
    current = sha(deployed)
    chain, seen = [], set()
    while current in by_hash and current not in seen:
        seen.add(current)
        copies = by_hash[current]
        row = copies[0]
        parents = sorted({r['sha256'] for r in row['parent_references']})
        chain.append(dict(sha256=current, paths=[r['path'] for r in copies],
                          train_plans=row['train_plans'], valid_plans=row['valid_plans'],
                          parent_sha256=parents))
        if len(parents) != 1:
            stop = 'no_parent_reference' if not parents else 'ambiguous_parent_references'
            break
        current = parents[0]
    else:
        stop = 'cycle' if current in seen else 'parent_checkpoint_not_retained'
    result = dict(status='audited', scope='Retained checkpoint ancestry only; does not establish exact historical retrainability.',
                  scanned_pt_files=len(names), policy_checkpoints=len(inventory), load_errors=errors,
                  chain=chain, stop_reason=stop, unresolved_sha256=current,
                  inventory=inventory, source_sha256={r['path']:r['sha256'] for r in inventory})
    result['source_sha256'][str(Path(__file__))] = sha(__file__)
    (out/'RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
    lines = ['# 策略训练链可恢复性审计', '',
             f'扫描 {len(names)} 个 .pt 文件，识别 {len(inventory)} 个策略检查点；读取失败 {len(errors)} 个。', '',
             '| 从部署模型向前追溯 | 训练计划 | 验证计划 |', '|---|---:|---:|']
    for row in chain:
        lines.append(f"| {Path(row['paths'][0]).relative_to(ROOT)} | {row['train_plans']} | {row['valid_plans']} |")
    lines += ['', f'追溯停止原因：`{stop}`；当前哈希：`{current}`。', '',
              '现有最终阶段四组消融不等价于删除整个策略蒸馏。检查点连续也不自动证明训练数据、目标和优化器轨迹完整。', '',
              '若前驱缺失，完整训练链消融应从共同可恢复起点重新建立各组训练过程，不能把现有不同来源检查点直接当作消融结果。', '',
              '本次未训练模型、未执行 SQL、未改动部署。所有检查点路径、训练元数据及哈希见 [RESULT.json](RESULT.json)。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('inventory','source_sha256')}, indent=2))


if __name__ == '__main__':
    main()
