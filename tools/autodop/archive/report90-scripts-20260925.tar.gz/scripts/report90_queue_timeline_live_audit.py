"""Join complete diagnostic queue events to verified SQL IDs."""
import hashlib,json
from pathlib import Path
from report90_queue_timeline_parse import validate

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'runs/report90_20260912'
OUT=RUN/'report90_native_budget_timeline_power2'


def main():
    proof=json.loads((OUT/'ALLOCATION_AUDIT.json').read_text())
    assert proof['status']=='verified' and proof['executions']==128
    for name,digest in proof['source_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
    cursor=json.loads((RUN/'report90_native_budget_timeline_restart/LOG_START.json').read_text())
    log=Path(cursor['path'])
    with log.open('rb') as f:
        import os
        assert os.fstat(f.fileno()).st_ino==cursor['inode'],'Log rotated; capture requires recovery before audit'
        f.seek(cursor['offset'])
        lines=[s for s in f.read().decode().splitlines() if 'AUTODOP_QUEUE_TIMELINE' in s]
    (OUT/'QUEUE_TIMELINE.log').write_text('\n'.join(lines)+'\n')
    timeline=validate(lines)
    events={e['query_id']:e for e in map(json.loads,(OUT/'scored/events.jsonl').read_text().splitlines())}
    assert len(events)==128
    joined=[]
    for expected in proof['rows']:
        query=expected['query_id'];rows=[r for r in timeline if r['query_id']==query]
        assert [r['event'] for r in rows]==['REQUIRE','ALLOCATE','RELEASE'],query
        assert all(r['slots']==expected['slots'] for r in rows)
        require,allocate,release=rows;e=events[query]
        joined.append(dict(query_id=query,id=e['id'],mode=e['mode'],phase=e['phase'],client=e['client'],
                           require_sequence=require['sequence'],allocate_sequence=allocate['sequence'],
                           require_ns=require['ns'],allocate_ns=allocate['ns'],release_ns=release['ns'],
                           queue_ms=(allocate['ns']-require['ns'])/1e6,
                           held_ms=(release['ns']-allocate['ns'])/1e6,
                           slots=expected['slots'],client_ms=e['client_latency_ms']))
    sources=[Path(__file__),Path(__file__).with_name('report90_queue_timeline_parse.py'),OUT/'ALLOCATION_AUDIT.json',OUT/'scored/events.jsonl',OUT/'QUEUE_TIMELINE.log']
    result=dict(status='verified_diagnostic',queries=len(joined),timeline_events=len(timeline),rows=joined,
                scope='Post-transition FE tracker timestamps. Held time is slot occupancy, not pure BE execution. All diagnostic queries retained; logging can affect scheduling. Extra helper SQL lifecycle events checked too. One instrumented arm, no causal performance comparison.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    (OUT/'TIMELINE_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('rows','source_sha256')},indent=2))

if __name__=='__main__':main()
