"""Collect the complete 20-query coverage pilot with request journals and strict verification."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from report90_execute import ROOT,RUN,check
from report90_cpu_observe import workers
from autodop.data import _hash,load_dataset

BASE=RUN/'structure_coverage20';OUT=BASE/'labels'
SUPPORT=RUN/'complex_development24/diagnostic_support'

def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,v):
    p=OUT/name;t=p.with_suffix('.tmp');t.write_text(json.dumps(v,indent=2)+'\n');t.replace(p)
def raw_plan(s):
    return _hash({'fragments':[{k:v for k,v in f.items() if k!='worker_ids'} for f in s['fragments']],'edges':s['edges']})

def main():
    assert read(BASE/'STATUS.json')['status']=='semantic_verified'
    semantic=read(BASE/'SEMANTIC_AUDIT.json');assert semantic['status']=='verified' and len(semantic['queries'])==20
    frozen=read(BASE/'PROTOCOL.json');assert sha(BASE/'manifest.json')==frozen['manifest_sha256']
    for p,expected in frozen['source_sha256'].items():assert sha(Path(p))==expected
    for p,expected in read(SUPPORT/'PREPARATION.json')['source_sha256'].items():assert sha(Path(p))==expected
    OUT.mkdir(exist_ok=False);os.sched_setaffinity(0,set(range(27,35)))
    save('STATUS.json',{'status':'running','stage':'preflight','pid':os.getpid()})
    manifest=BASE/'manifest.json';audit=ROOT/'runs/paper_campaign_20260905/environment/audit_tpcds_sf100.json'
    protocol={'frozen_at':datetime.datetime.now().astimezone().isoformat(),'queries':20,'train_queries':20,'valid_queries':0,
        'configs':8,'config_design':'balanced','dops':[1,2,4,8,16],'seed':2026091318,'warmup':1,'repetitions':3,
        'expected_formal_executions':480,'expected_total_executions':680,
        'design':'Five uniform and three random heterogeneous configurations frozen from native-discovered plan before timing. Fixed generation seed; no latency-based selection.',
        'gate':'All20 accepted with all8 configurations and3 verified formal observations; independent trace/journal/digest reconciliation, same-plan batch identity and no raw-graph overlap with protected validation. No automatic retry or replacement.',
        'scope':'Training coverage pilot only. All20 together; no report90 execution, no policy deployment. Reuse historical scale audit and verify current BE image/semantic slices separately.'}
    save('PROTOCOL.json',protocol)
    sources=[Path(__file__),manifest,BASE/'PROTOCOL.json',BASE/'SEMANTIC_AUDIT.json',SUPPORT/'collector.py',SUPPORT/'PREPARATION.json',ROOT/'scripts/report90_fixed_request_journal.py',ROOT/'scripts/build_trusted_dataset.py',ROOT/'scripts/verify_paper_dataset.py',audit]
    save('EXECUTION_SOURCE_SHA256.json',{str(p):sha(p) for p in sources})
    nodes=workers();assert all(n['image_id']=='sha256:73548ebadb50d11fec58e9937ebd5ee189205fd8f1acf8359fc63923132c476b' for n in nodes);save('DEPLOYMENT.json',nodes)
    for attempt in range(20):
        try:check(OUT/f'IDLE_{attempt}.json');break
        except RuntimeError:
            if attempt==19:raise
            time.sleep(15)
    command=[sys.executable,str(SUPPORT/'collector.py'),'--manifest',str(manifest),'--output-dir',str(OUT/'collection'),
        '--configs','8','--config-design','balanced','--dops','1,2,4,8,16','--audit',str(audit),
        '--probe-timeout-s','180','--query-timeout-s','180','--repetitions','3','--warmup','1','--seed',str(protocol['seed'])]
    save('COMMAND.json',command);save('STATUS.json',{'status':'running','stage':'configuration_labels','pid':os.getpid()})
    subprocess.run(command,check=True)
    c=read(OUT/'collection/collection.json');assert c['status']=='finished' and len(c['queries'])==20
    assert all(q['status']=='accepted' and len(q['configs'])==8 for q in c['queries']), 'Preserve exclusions and diagnose before any retry'
    digests={q['id']:q['native_result_digest'] for q in semantic['queries']}
    assert all(q['native_result_digest']==digests[q['id']] for q in c['queries'])
    subprocess.run([sys.executable,str(ROOT/'scripts/build_trusted_dataset.py'),'--input',str(OUT/'collection/measured/accepted.jsonl'),
        '--manifest',str(manifest),'--collection',str(OUT/'collection/collection.json'),'--output',str(OUT/'dataset')],check=True)
    subprocess.run([sys.executable,str(ROOT/'scripts/verify_paper_dataset.py'),'--collection-dir',str(OUT/'collection'),
        '--dataset-dir',str(OUT/'dataset'),'--output',str(OUT/'dataset/verification.json')],check=True)
    proof=read(OUT/'dataset/verification.json');assert proof['status']=='verified'
    samples=[json.loads(l) for l in (OUT/'dataset/all/samples.jsonl').open()]
    assert len(samples)==160 and all(s['split']=='train' for s in samples)
    protected,_,_=load_dataset(RUN/'complex_development24/merged_dataset')
    protected_hashes={raw_plan(s) for s in protected if s['split']=='valid'}
    overlap={raw_plan(s) for s in samples}&protected_hashes
    assert not overlap,'Raw graph overlap with protected validation; do not fit'
    assert read(OUT/'collection/frontend_settings.json')['restored']
    result={'status':'complete','queries':20,'samples':160,'formal_executions':480,'protected_validation_raw_graph_overlap':0,
        'native_digest_semantics_verified':True,'verification':proof,'source_sha256':{str(p):sha(p) for p in [OUT/'dataset/all/samples.jsonl',OUT/'dataset/all/pairs.jsonl',OUT/'dataset/verification.json',RUN/'complex_development24/merged_dataset/samples.jsonl']}}
    save('RESULT.json',result);save('STATUS.json',{'status':'complete','at':datetime.datetime.now().astimezone().isoformat()})

if __name__=='__main__':
    if OUT.exists():raise SystemExit('Preserve existing coverage label collection')
    try:main()
    except BaseException as error:
        if OUT.exists():save('STATUS.json',{'status':'failed','error':repr(error),'pid':os.getpid()})
        raise
