"""Experimental integer-slot encoding; requires a matching FE estimator, not legacy MBE."""
from report90_native_predictor_fixed4 import NativePredictor as FrozenPredictor


class NativePredictor(FrozenPredictor):
    def encode(self, budget):
        if type(budget) is not int or budget <= 0:
            raise ValueError('invalid budget bytes')
        needed = (budget * 5 + 3 * self.slot_bytes - 1) // (3 * self.slot_bytes)
        granted = min(needed, self.slots_per_worker)
        return dict(encoded_cost_bytes=granted * self.slot_bytes,
                    expected_physical_slots=granted * self.workers,
                    nominal_bytes_per_worker=granted * self.slot_bytes,
                    saturated=needed > self.slots_per_worker,
                    covers_scaled_budget=granted * self.slot_bytes * 3 >= budget * 5)
