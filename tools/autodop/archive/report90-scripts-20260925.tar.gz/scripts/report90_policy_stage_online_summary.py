"""Summarize all frozen policy-stage arms after independent online verification."""
import argparse
import hashlib
import json
import math
from pathlib import Path
from statistics import mean

BASE = Path(__file__).resolve().parents[1] / 'runs/report90_20260912/policy_final_stage_ablation'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def quantile(values, p):
    ordered = sorted(values)
    index = (len(ordered) - 1) * p
    lower = math.floor(index)
    upper = math.ceil(index)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (index - lower)


def summarize(directory, protocol):
    phase = directory.name.removeprefix('online_')
    status = json.loads((directory / 'STATUS.json').read_text())
    assert status['status'] == 'verified' and status['restored']
    sources = [Path(__file__), BASE / 'EVALUATION_PROTOCOL.json', directory / 'STATUS.json']
    for relative in ['scored/independent_verification.json', 'POLICY_RESPONSE_AUDIT.json']:
        path = directory / relative
        proof = json.loads(path.read_text())
        if relative.startswith('scored/'):
            assert proof['all_expected_executions_verified']
        else:
            assert proof['all_collection_modes_replayed']
        for source, digest in proof['source_sha256'].items():
            assert sha(source) == digest, source
        sources.append(path)
    events_path = directory / 'scored/events.jsonl'
    events = [json.loads(line) for line in events_path.read_text().splitlines()]
    sources.append(events_path)
    ids = set(protocol[phase + '_query_ids'])
    modes = ['stage_' + arm for arm in protocol['checkpoints']]
    expected = {(mode, query, phase_name) for mode in modes for query in ids
                for phase_name in ['warmup', 'measured']}
    observed = [(e['mode'], e['id'], e['phase']) for e in events]
    assert len(observed) == len(expected) and set(observed) == expected
    assert all(e['status'] == 'verified' for e in events)
    measured = {(e['mode'], e['id']): e for e in events if e['phase'] == 'measured'}
    metrics = {}
    per_query = {}
    for mode in modes:
        rows = [measured[mode, query] for query in sorted(ids)]
        times = [float(e['client_latency_ms']) for e in rows]
        assert all(math.isfinite(t) and t > 0 for t in times)
        applied = sum(bool(e['dop_validation']['applied']) for e in rows)
        metrics[mode] = dict(mean_ms=mean(times), p50_ms=quantile(times, .5),
                             p90_ms=quantile(times, .9), p99_ms=quantile(times, .99),
                             applied=applied, fallback=len(rows)-applied, queries=len(rows))
        per_query[mode] = {q: measured[mode, q]['client_latency_ms'] for q in sorted(ids)}
    full = metrics['stage_full']
    comparisons = {}
    for mode in modes:
        if mode == 'stage_full':
            continue
        comparisons[mode] = {key + '_reduction_pct': 100 * (1 - full[key] / metrics[mode][key])
                             for key in ['mean_ms', 'p50_ms', 'p90_ms', 'p99_ms']}
        comparisons[mode]['full_faster_queries'] = sum(
            per_query['stage_full'][q] < per_query[mode][q] for q in ids)
    return dict(status='verified_complete_paired_summary', phase=phase, metrics=metrics,
                full_vs_ablation=comparisons, per_query_ms=per_query,
                scope='One measured execution per query/arm; all frozen queries and fallbacks retained. '
                      'Descriptive final-policy-stage ablation, not whole distillation or statistical robustness.',
                source_sha256={str(path): sha(path) for path in sources})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=['pilot', 'full'], required=True)
    args = parser.parse_args()
    directory = BASE / ('online_' + args.phase)
    protocol = json.loads((BASE / 'EVALUATION_PROTOCOL.json').read_text())
    result = summarize(directory, protocol)
    with (directory / 'SUMMARY.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    lines = ['# 策略最终训练阶段在线对照：' + args.phase, '', result['scope'], '',
             '| 配置 | 平均 ms | p50 | p90 | p99 | 安装/回退 |',
             '|---|---:|---:|---:|---:|---:|']
    for mode, row in result['metrics'].items():
        lines.append(f"| {mode} | {row['mean_ms']:.2f} | {row['p50_ms']:.2f} | "
                     f"{row['p90_ms']:.2f} | {row['p99_ms']:.2f} | {row['applied']}/{row['fallback']} |")
    lines += ['', '完整组相对各消融组的延迟降低（正数为完整组更好）：', '',
              '| 对照 | 平均 | p50 | p90 | p99 | 完整组更快查询数 |',
              '|---|---:|---:|---:|---:|---:|']
    for mode, row in result['full_vs_ablation'].items():
        cells = ' | '.join(f"{row[k + '_reduction_pct']:.2f}%" for k in ['mean_ms', 'p50_ms', 'p90_ms', 'p99_ms'])
        lines.append(f"| {mode} | {cells} | {row['full_faster_queries']}/{len(result['per_query_ms'][mode])} |")
    lines += ['', '计时包含在线调用和实际置信度回退；未按性能删除查询或选择检查点。'
              '本轮与原主实验的三轮测量分别统计，不能合并为更多重复轮次。']
    (directory / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
