"""Train regression/MLP development controls on the frozen augmented dataset."""
import argparse
import collections
import datetime
import json
import math
import os
import random
import time
from pathlib import Path

import numpy as np
import torch
import xgboost as xgb
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import dynamic_margin_ranking_loss
from autodop.training import file_sha256, select_partition
from report90_models import MLP, flat_features
from report90_complex_retrain import validation, order, pair_index, epoch_pairs, key
from report90_coverage_choices import BASE, read


def save(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2) + '\n')
    tmp.replace(path)


def main(stage):
    out = BASE / ('additional_baselines_' + stage)
    assert not out.exists(), 'Preserve previous run'
    if stage == 'full':
        pilot = read(BASE / 'additional_baselines_pilot/RESULT.json')
        assert pilot['status'] == 'verified' and pilot['source_sha256'][str(Path(__file__))] == file_sha256(__file__)
    reference = read(BASE / 'retrained/SCORE_REPLAY.json')
    assert reference['status'] == 'verified'
    out.mkdir()
    os.sched_setaffinity(0, {35})
    torch.set_num_threads(1)
    save(out / 'STATUS.json', {'status': 'running', 'stage': 'prepare', 'pid': os.getpid()})
    samples, pairs, meta = load_dataset(BASE / 'merged_dataset')
    contract = read(BASE / 'retrained/CONTRACT.json')
    train, tp = select_partition(samples, pairs, contract, 'train')
    valid, _ = select_partition(samples, pairs, contract, 'valid')
    assert len(train) == 1365 and len(valid) == 212 and all(s['split'] == 'train' for s in train)
    norm = np.load(BASE / 'retrained/FEATURE_NORMALIZATION.npz')
    started = time.perf_counter()
    raw = {key(s): flat_features(build_graph(s, meta), meta) for s in samples}
    train_x = np.stack([raw[key(s)] for s in train])
    mean = train_x.mean(0); std = train_x.std(0); std[std < 1e-6] = 1
    assert np.array_equal(mean, norm['mean']) and np.array_equal(std, norm['std'])
    flat = {k: torch.tensor((v - mean) / std, dtype=torch.float32) for k, v in raw.items()}
    xx = torch.stack([flat[key(s)] for s in train]); vx = torch.stack([flat[key(s)] for s in valid])
    cohorts = collections.defaultdict(lambda: collections.defaultdict(list))
    for i, s in enumerate(train):
        cohorts[s['source_cohort']][s['plan_key']].append(i)
    weights = np.zeros(len(train))
    for plans in cohorts.values():
        for indices in plans.values():
            weights[indices] = .5 / len(plans) / len(indices)
    assert abs(weights.sum() - 1) < 1e-9
    target = np.log1p([s['latency_ms'] for s in train])
    target_mean = float(weights @ target)
    target_std = float(np.sqrt(weights @ ((target - target_mean) ** 2)))
    assert target_std > 0
    yy = torch.tensor((target - target_mean) / target_std, dtype=torch.float32)
    by = pair_index(train, tp)
    epochs = 2 if stage == 'pilot' else 100
    settings = [0] if stage == 'pilot' else [0, 1]
    protocol = {'frozen_at': datetime.datetime.now().astimezone().isoformat(), 'stage': stage,
                'models': ['mlp_rank', 'mlp_regression', 'xgb_regression'], 'seed': 17,
                'epochs': epochs, 'mlp_learning_rates': [3e-4, 1e-3], 'mlp_width': [64, 64],
                'xgb_depths': [3, 6], 'xgb_trees': 5 if stage == 'pilot' else 200,
                'xgb_learning_rate': .05, 'draws_per_epoch': 624,
                'sampling': 'Equal historical/complex cohorts, uniform plans, then uniform pairs or point configurations. Regression XGB uses equivalent point weights.',
                'features': 'Same train-normalized flat features as existing XGBoost; includes dependency and competition aggregates. No new feature removal to weaken baselines.',
                'regression_target': 'Train-weighted standardized log1p latency; ranking scores negate prediction. Inverse transform retained for interpretation.',
                'selection': 'Full stage every10epochs, minimum equal-cohort validation regret, then ranking accuracy, then earlier epoch/lower setting. Pilot final epoch only.',
                'scope': 'Additional model-family controls on reused development validation. Transformer retains historical multistage initialization; these controls start fresh. Not isolated architectural causality, equal total historical training budget, SQL superiority, or a relaxation of the existing SQL gate.'}
    save(out / 'PROTOCOL.json', protocol)
    sources = [Path(__file__), BASE / 'merged_dataset/samples.jsonl', BASE / 'merged_dataset/pairs.jsonl',
               BASE / 'retrained/CONTRACT.json', BASE / 'retrained/FEATURE_NORMALIZATION.npz',
               BASE / 'retrained/SCORE_REPLAY.json', Path(__file__).with_name('report90_models.py'),
               Path(__file__).with_name('report90_complex_retrain.py')]
    hashes = {str(p): file_sha256(p) for p in sources}
    save(out / 'SOURCE_SHA256.json', hashes)
    save(out / 'PREPARATION.json', {'seconds': time.perf_counter() - started, 'target_mean': target_mean,
                                   'target_std': target_std, 'train_samples': len(train), 'valid_samples': len(valid),
                                   'features': xx.shape[1], 'normalization_recomputed_train_only': True})
    results = []
    for kind in protocol['models']:
        for setting in settings:
            folder = out / f'{kind}_h{setting}'; folder.mkdir()
            save(out / 'STATUS.json', {'status': 'running', 'stage': folder.name, 'pid': os.getpid()})
            started = time.perf_counter(); torch.manual_seed(17); rng = random.Random(17)
            history = []; best = None
            if kind == 'xgb_regression':
                model = xgb.XGBRegressor(objective='reg:squarederror', n_estimators=protocol['xgb_trees'],
                    max_depth=protocol['xgb_depths'][setting], learning_rate=.05, n_jobs=1,
                    random_state=17, tree_method='hist', subsample=1., colsample_bytree=1.)
                # Scale weights to mean1 to keep regularization on its usual scale.
                model.fit(xx.numpy(), yy.numpy(), sample_weight=weights * len(train))
                scores = -model.predict(vx.numpy()).astype(float)
                q = validation(valid, scores); best = {'epoch': None, 'validation': q}
                path = folder / 'model.ubj'; model.save_model(path)
                loaded = xgb.XGBRegressor(); loaded.load_model(path); loaded.set_params(n_jobs=1)
                replay_scores = -loaded.predict(vx.numpy()).astype(float)
            else:
                model = MLP(xx.shape[1]); optimizer = torch.optim.Adam(model.parameters(), lr=protocol['mlp_learning_rates'][setting])
                for epoch in range(1, epochs + 1):
                    model.train(); losses = []
                    if kind == 'mlp_rank':
                        jobs = epoch_pairs(by, rng)
                    else:
                        jobs = []
                        for cohort in sorted(cohorts):
                            plans = sorted(cohorts[cohort])
                            jobs.extend(rng.choice(cohorts[cohort][rng.choice(plans)]) for _ in range(312))
                        rng.shuffle(jobs)
                    for offset in range(0, len(jobs), 16):
                        batch = jobs[offset:offset + 16]; optimizer.zero_grad()
                        if kind == 'mlp_rank':
                            fa = model(torch.stack([flat[(p['plan_key'], p['fast_config_key'])] for p in batch]))
                            sl = model(torch.stack([flat[(p['plan_key'], p['slow_config_key'])] for p in batch]))
                            loss = torch.stack([dynamic_margin_ranking_loss(a, b, p['fast_latency_ms'], p['slow_latency_ms']) for a, b, p in zip(fa, sl, batch)]).mean()
                        else:
                            loss = (model(xx[batch]) - yy[batch]).square().mean()
                        assert torch.isfinite(loss); loss.backward(); optimizer.step(); losses.append(float(loss.detach()))
                    entry = {'epoch': epoch, 'loss': float(np.mean(losses))}
                    if epoch % 10 == 0 or epoch == epochs:
                        model.eval()
                        with torch.no_grad(): scores = model(vx).numpy().astype(float)
                        if kind == 'mlp_regression': scores = -scores
                        q = validation(valid, scores); entry['validation'] = q
                        if best is None or (*order(q), epoch) < (*order(best['validation']), best['epoch']):
                            best = {'epoch': epoch, 'validation': q}
                            torch.save({'state': model.state_dict(), 'width': xx.shape[1], 'target_mean': target_mean,
                                        'target_std': target_std, 'kind': kind}, folder / 'model.pt')
                    history.append(entry); save(folder / 'PROGRESS.json', {'history': history})
                path = folder / 'model.pt'; checkpoint = torch.load(path, weights_only=False)
                loaded = MLP(checkpoint['width']); loaded.load_state_dict(checkpoint['state']); loaded.eval()
                with torch.no_grad(): replay_scores = loaded(vx).numpy().astype(float)
                if kind == 'mlp_regression': replay_scores = -replay_scores
            q = validation(valid, replay_scores)
            assert q == best['validation']
            result = {'kind': kind, 'setting': setting, 'selected': best, 'seconds': time.perf_counter() - started,
                      'model': str(path), 'model_sha256': file_sha256(path), 'independent_reload_verified': True}
            save(folder / 'RESULT.json', result); results.append(result)
            print(kind, setting, q['weighted_regret'], flush=True)
    selected = {kind: min([r for r in results if r['kind'] == kind], key=lambda r: (*order(r['selected']['validation']), r['setting'])) for kind in protocol['models']}
    for path, expected in hashes.items(): assert file_sha256(path) == expected
    save(out / 'RESULT.json', {'status': 'verified', 'candidates': results, 'selected': selected, 'source_sha256': hashes})
    lines = ['# 补充数据上的回归与MLP对照', '', protocol['scope'], '',
             '| 模型 | 历史选择损失 | 复杂选择损失 | 等权选择损失 | 历史/复杂排序准确率 |', '|---|---:|---:|---:|---:|']
    qualities = {**reference['after'], **{k: r['selected']['validation'] for k, r in selected.items()}}
    for kind, q in qualities.items():
        h, c = q['cohorts']['historical'], q['cohorts']['complex_new']
        lines.append(f"| {kind} | {100*h['mean_regret']:.2f}% | {100*c['mean_regret']:.2f}% | {100*q['weighted_regret']:.2f}% | {100*h['rank_accuracy']:.2f}% / {100*c['rank_accuracy']:.2f}% |")
    lines += ['', '新增模型全部重新加载并复算验证指标，与保存时记录一致。Transformer与两种排序XGBoost复用前一轮独立核验结果；新增模型使用同一训练样本与相同输入归一化。MLP和回归模型均从头训练，与Transformer的历史接续训练预算不同。所有候选耗时见RESULT.json，历史训练成本不计入本轮。',
              '', '验证标签用于选模，未用于拟合。回归目标标准化及样本权重均由训练集计算。竞争关系与Transformer不单独拆分，平坦模型保留竞争/依赖汇总特征作为较强对照。']
    (out / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    save(out / 'STATUS.json', {'status': 'complete'})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--stage', choices=['pilot', 'full'], required=True)
    args = parser.parse_args()
    try:
        main(args.stage)
    except BaseException as error:
        folder = BASE / ('additional_baselines_' + args.stage)
        if folder.exists() and not (folder / 'RESULT.json').exists():
            save(folder / 'STATUS.json', {'status': 'failed', 'error': repr(error), 'pid': os.getpid()})
        raise
