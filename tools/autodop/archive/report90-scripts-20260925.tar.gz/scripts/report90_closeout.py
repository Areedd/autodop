"""Close out the fixed report scope, preserving unsuccessful overload outcomes."""
import datetime
import hashlib
import json
from pathlib import Path


def closeout(run, data):
    protocol=json.loads((run/'PROTOCOL.json').read_text())
    manifest=run/'manifest.json'
    assert hashlib.sha256(manifest.read_bytes()).hexdigest()==protocol['source_sha256'][str(manifest.resolve())]
    assert hashlib.sha256(Path(protocol['model']).read_bytes()).hexdigest()==protocol['model_sha256']
    trained=json.loads((run/'models_full/RESULT.json').read_text())
    assert trained['status']=='complete' and len(trained['candidates'])==30 and len(trained['selected'])==15
    assert len(data['serial']['per_query_mean_ms']['policy_static'])==90
    expected_keys={f'{m}_c{c}' for m in ('native','policy_static','policy_load') for c in (1,2,4,8,16)}
    assert set(data['concurrent'])==expected_keys
    assert sum(v['expected'] for v in data['concurrent'].values())==2700
    timing=json.loads((run/'fe_timing/RESULT.json').read_text())
    assert timing['status']=='complete' and timing['measured']==180 and timing['binary_restored']
    assert json.loads((run/'fe_timing/RESTORATION.json').read_text())['restored']
    binary=json.loads((run/'fe_timing/BINARY_AUDIT.json').read_text())
    assert hashlib.sha256((run.parents[3]/'output/fe/lib/starrocks-fe.jar').read_bytes()).hexdigest()==binary['original_sha256']
    stages=[]
    for folder in sorted(run.glob('*/scored')):
        proof=folder/'independent_verification.json'
        if not proof.exists():continue
        v=json.loads(proof.read_text());assert v['evidence_valid'],str(folder)
        settings=json.loads((folder/'frontend_settings.json').read_text())
        assert settings['restored'] and not settings['restore_errors'],str(folder)
        stages.append({'stage':folder.parent.name,'expected_slots':v['expected_slots'],
                       'failed_slots':v['failed_slots'],'missing_slots':v['missing_slots'],
                       'all_successful':v['all_expected_executions_verified'],'settings_restored':True})
    artifacts=['FULL_REPORT.md','SUMMARY.json','SERIAL_QUERY_MEANS.csv','CONCURRENT_METRICS.csv',
               'PRIMARY_LATENCY.png','PRIMARY_LATENCY.pdf','ABLATIONS.png','ABLATIONS.pdf',
               'CONCURRENCY.png','CONCURRENCY.pdf','fe_timing/RESULT.json','fe_timing/BINARY_AUDIT.json','fe_timing/RESTORATION.json']
    source_files=[*sorted((run.parents[1]/'scripts').glob('report90_*.py')),*sorted((run/'fe_timing').rglob('*.java'))]
    if (run/'cpu_capacity_fix/RESULT.json').exists():
        source_files += [run.parents[3]/name for name in ('be/src/util/cpu_usage_info.cpp','be/src/util/cpu_usage_info.h','be/test/util/cpu_usage_info_test.cpp')]
    (run/'FINAL_SOURCE_SHA256.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files},indent=2)+'\n')
    artifacts+=['FINAL_SOURCE_SHA256.json','REPRODUCE.md','FAILURE_BREAKDOWN.json']
    if (run/'model_comparison_audit/REPORT.md').exists():artifacts+=['model_comparison_audit/REPORT.md','model_comparison_audit/AUDIT.json','model_comparison_audit/DIAGNOSTICS.json']
    if (run/'original_teacher_audit/REPORT.md').exists():
        artifacts += ['original_teacher_audit/'+name for name in ('REPORT.md','RESULT.json','LINEAGE.json','DATA_PROVENANCE.json','CHECKS.json')]
    extensions = None
    if (run/'EXTENSION_SUMMARY.json').exists():
        artifacts += ['EXTENSION_SUMMARY.json','EXTENSION_SUMMARY.md']
        extensions = [{'run': stage.get('run'), 'stage': stage['stage'], 'status': stage['status']}
                      for stage in json.loads((run/'EXTENSION_SUMMARY.json').read_text())['stages']]
    for name in ['CPU_NORMALIZATION_OBSERVATION.json','cpu_capacity_fix/RESULT.json','cpu_capacity_fix/REPORT.md',
                 'convergence_20260913/REPORT.md','convergence_20260913/OFFLINE_AUDIT.json','convergence_20260913/SELECTED.json',
                 'search_convergence_20260913/REPORT.md','search_convergence_20260913/SCORE_DIAGNOSTIC.json',
                 'cpu_capacity_fix/BUILD_COMPLETE.json','cpu_capacity_fix/BUILD_ATTEMPT5.json',
                 'cpu_capacity_fix/CANDIDATE_IMAGE.json','cpu_capacity_fix/DEPLOYMENT_RESULT.json',
                 'cpu_capacity_fix/DEPLOYMENT_VALIDATION.json','cpu_capacity_fix/PARITY_ORIGINAL.json',
                 'cpu_capacity_fix/CPU_GATE_SELFTEST.json',
                 'AUXILIARY_WORKLOADS.json','QUEUE_SUMMARY_GATE_TEST.json']:
        if (run/name).exists():artifacts.append(name)
    development_screens = []
    for folder, result_name in [('development17_calibration', 'RESULT.json'),
                                ('development17_pressure', 'AUDITED_RESULT.json'),
                                ('development17_cpu_threshold', 'RESULT.json')]:
        result_path = run/folder/result_name
        if result_path.exists():
            development = json.loads(result_path.read_text())
            development_screens.append({'stage': folder, 'status': development['status'],
                                        'screen_passed': development.get('screen_passed'),
                                        'selected_mode': development.get('selected_mode'),
                                        'result': str(result_path.relative_to(run))})
            for name in [result_name, 'REPORT.md', 'PROTOCOL.json', 'EXECUTION_SOURCE_SHA256.json',
                         'QUEUE_SETTINGS.json', 'OFFLINE_CHECK.json', 'POSTPROCESS_REPAIR.json',
                         'ONSET_DIAGNOSTIC.json', 'scored/independent_verification.json']:
                if (run/folder/name).exists():
                    artifacts.append(str(Path(folder)/name))
    for name in ['training_structure_audit/REPORT.md', 'training_structure_audit/RESULT.json']:
        if (run/name).exists():artifacts.append(name)
    for name in ['complex_development24/REPORT.md', 'complex_development24/PROTOCOL.json',
                 'complex_development24/manifest.json', 'complex_development24/SEMANTIC_AUDIT.json',
                 'complex_development24/TRUSTED_NATIVE.json', 'complex_development24/prepass/AUDITED_RESULT.json',
                 'complex_development24/prepass/PLAN_SEPARATION.json', 'complex_development24/prepass/POSTPROCESS_REPAIR.json',
                 'complex_development24/prepass/scored/independent_verification.json']:
        if (run/name).exists():artifacts.append(name)
    corrected = run/'queue_cpu_corrected_20260913'
    for folder in ('complex_development24/retrained', 'complex_development24/preservation_ablation',
                   'structure_coverage20', 'structure_coverage20/retrained', 'structure_coverage20/prepared',
                   'structure_coverage20/labels_recovery', 'structure_coverage20/additional_baselines_full',
                   'structure_coverage20/additional_baselines_pilot', 'load_quantization_audit',
                   'structure_coverage20/seed_stability', 'structure_coverage20/seed_stability/seed29',
                   'structure_coverage20/seed_stability/seed43', 'structure_coverage20/parameter_average3',
                   'structure_coverage20/cosine_decay', 'structure_coverage20/cosine_decay/seed17',
                   'structure_coverage20/cosine_decay/seed29', 'structure_coverage20/cosine_decay/seed43',
                   'structure_coverage20/diagnostic_execution8', 'failure_capture_smoke',
                   'structure_coverage20/candidate_pool_audit', 'structure_coverage20/observed90_audit',
                   'structure_coverage20/baseline_seed_stability',
                   'structure_coverage20/observed90_seed_audit',
                   'structure_coverage20/observed90_seed_audit_support',
                   'structure_coverage20/top_candidate_audit', 'structure_coverage20/margin_signal_audit', 'structure_coverage20/top_sampling',
                   'structure_coverage20/top_sampling/seed17', 'structure_coverage20/top_sampling/seed29',
                   'structure_coverage20/top_sampling/seed43', 'structure_coverage20/top_sampling/seed17_pilot',
                   'structure_coverage20/gap_calibration', 'structure_coverage20/gap_calibration/seed17',
                   'structure_coverage20/gap_calibration/seed29', 'structure_coverage20/gap_calibration/seed43',
                   'structure_coverage20/gap_calibration/seed17_pilot', 'development17_retry',
                   'development17_retry_support'):
        for name in ('REPORT.md', 'RESULT.json', 'SCORE_REPLAY.json', 'CHOICE_DIAGNOSIS.json',
                     'PROTOCOL.json', 'RETRAIN_PROTOCOL.json', 'SEMANTIC_AUDIT.json',
                     'EXECUTION_SOURCE_SHA256.json', 'TRAINING_LOOP_AUDIT.json', 'RECOVERY_NOTE.md',
                     'PLAN_DRIFT_DIAGNOSIS.json', 'SOURCE_SHA256.json', 'PREPARATION.json',
                     'SEED_SUMMARY.json', 'SEED_SUMMARY.md', 'SCORES.json', 'COMPARISON.json', 'SAMPLING_AUDIT.json',
                     'LOSS_CHECK.json', 'SUMMARY_SOURCE_TRANSFORM.json', 'SOURCE_TRANSFORM.json',
                     'FAILURE_IDENTITY_AUDIT.json', 'FAILED_ATTEMPT_AUDIT_LINES.json',
                     'DECISION_AUDIT.json', 'DECISION_AUDIT.md'):
            path = Path(folder)/name
            if (run/path).exists():
                artifacts.append(str(path))
    diagnostic = run/'structure_coverage20/diagnostic_execution8'
    if (diagnostic/'RESULT.json').exists():
        for name in ('scored/independent_verification.json', 'scored/frontend_settings.json',
                     'vectors.json', 'manifest.json', 'CHOICES.json'):
            artifacts.append(str((diagnostic/name).relative_to(run)))
    if corrected.exists():
        for folder in sorted(corrected.iterdir()):
            if folder.is_dir() and (folder/'CPU_GATE.json').exists():
                for name in ['CPU_GATE.json','CORRECTION_DIAGNOSTIC.json','CORRECTION_DIAGNOSTIC.md']:
                    if (folder/name).exists():artifacts.append(str((folder/name).relative_to(run)))
                observer=corrected/(folder.name+'_CPU.jsonl')
                if observer.exists():artifacts.append(str(observer.relative_to(run)))
    artifacts += [p.name for extension in ('png','pdf') for p in sorted(run.glob('queue_extension_*_CONCURRENCY.'+extension))]
    artifacts += [p.name for extension in ('png','pdf') for p in sorted(run.glob('queue_cpu_corrected_*_CONCURRENCY.'+extension))]
    result={'status':'complete','completed_at':datetime.datetime.now().astimezone().isoformat(),
        'scope':'Fixed90 performance; five cost models; search and deployed-policy comparisons; five finite-batch concurrency levels; measured tuning/training costs.',
        'not_covered':['Independent workload generalization','Standard TPC-H/TP contractual acceptance','Whole optimizer-stage contractual EXPLAIN test','Default50ms concurrency configuration'],
        'serial_measured_observations':4860,
        'fe_controller_timing_measured_observations':180,
        'concurrent_measured_attempts':2700,
        'concurrent_measured_successes':sum(v['verified'] for v in data['concurrent'].values()),
        'concurrent_measured_failures':sum(v['failed_or_missing'] for v in data['concurrent'].values()),
        'completion_note':'Original fixed-scope experiments completed does not mean every query succeeded or that the broader all-components-superior objective is achieved. All overload failures and the original repaired serial failures remain in the evidence. Supplementary experiment status is reported separately.',
        'supplementary_experiments':extensions,
        'development_screens':development_screens,
        'current_BE_deployment':json.loads((run/'cpu_capacity_fix/DEPLOYMENT_RESULT.json').read_text())['status'] if (run/'cpu_capacity_fix/DEPLOYMENT_RESULT.json').exists() else 'not_changed_by_CPU_fix',
        'stages':stages,'artifacts_sha256':{name:hashlib.sha256((run/name).read_bytes()).hexdigest() for name in artifacts}}
    (run/'CLOSEOUT.json').write_text(json.dumps(result,indent=2)+'\n')
