"""Paired full-workload budget comparison after720 verified executions."""
import json
from pathlib import Path
import numpy as np
from report90_neighborhood_prepare import RUN,sha


def main():
    base=RUN/'search_budget_report90';out=base/'collection'
    result=json.loads((out/'RESULT.json').read_text())
    protocol=json.loads((base/'PROTOCOL.json').read_text())
    assert result['status']=='verified' and result['executions']==720 and result['restored']
    for path,digest in result['source_sha256'].items():assert sha(Path(path))==digest
    queries=protocol['queries'];assert len(queries)==len(set(queries))==90
    arrays={mode:np.array([v[q] for q in queries],dtype=float) for mode,v in result['per_query_ms'].items()}
    assert set(arrays)==set(protocol['modes']) and all(np.isfinite(a).all() and (a>0).all() for a in arrays.values())
    stats={mode:dict(mean_ms=float(a.mean()),p50_ms=float(np.quantile(a,.5)),p90_ms=float(np.quantile(a,.9)),p99_ms=float(np.quantile(a,.99))) for mode,a in arrays.items()}
    contrasts=[('refined_budget32','random_budget32'),('refined_budget64','random_budget64'),
               ('refined_budget32','refined_budget64'),('refined_budget32','random_budget64')]
    rng=np.random.default_rng(2026091452);indices=rng.integers(0,90,size=(10000,90))
    comparisons={}
    for method,baseline in contrasts:
        a,b=arrays[method],arrays[baseline]
        boot=100*(1-a[indices].mean(1)/b[indices].mean(1))
        per_query=[dict(query=q,method_ms=float(x),baseline_ms=float(y),reduction_percent=float(100*(1-x/y))) for q,x,y in zip(queries,a,b)]
        comparisons[method+'_vs_'+baseline]=dict(method=method,baseline=baseline,
                  reductions_percent={metric:100*(1-stats[method][metric]/stats[baseline][metric]) for metric in stats[method]},
                  wins=int((a<b).sum()),losses=int((a>b).sum()),ties=int((a==b).sum()),
                  wins_at_least3percent=int((a<=.97*b).sum()),regressions_at_least3percent=int((a>=1.03*b).sum()),
                  median_query_reduction_percent=float(np.median(100*(1-a/b))),
                  descriptive_query_bootstrap_interval95=np.quantile(boot,[.025,.975]).tolist(),per_query=per_query)
    summary=dict(status='verified_paired_summary',statistics=stats,comparisons=comparisons,
                 scope='All90historically selected queries, one formal observation per configuration. Query-cluster intervals describe workload composition only, not execution-repeat uncertainty or blind-test significance. Search time excluded.',
                 source_sha256={str(p):sha(p) for p in [Path(__file__),out/'RESULT.json',base/'PROTOCOL.json',out/'scored/events.jsonl']})
    (out/'PAIRED_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
    lines=['# 全部90查询的搜索预算对照','',
           '4组×90查询，各预热一次、正式一次，共720次执行，全部结果及DOP安装通过独立核验，FE设置恢复。', '',
           '| 配置来源 | 平均ms | p50 | p90 | p99 |','|---|---:|---:|---:|---:|']
    for mode,s in stats.items():lines.append('| '+mode+' | '+' | '.join(f'{s[k]:.3f}' for k in ['mean_ms','p50_ms','p90_ms','p99_ms'])+' |')
    lines+=['', '| 比较（正数为降低） | 平均降低 | p50降低 | p90降低 | p99降低 | 胜/负/平 |','|---|---:|---:|---:|---:|---|']
    for name,r in comparisons.items():
        lines.append('| '+name+' | '+' | '.join(f"{r['reductions_percent'][k]:+.2f}%" for k in ['mean_ms','p50_ms','p90_ms','p99_ms'])+f" | {r['wins']}/{r['losses']}/{r['ties']} |")
    lines += ['', '同预算比较与跨预算比较分别列示。这里的延迟是固定配置执行与取回结果的时间，不含离线搜索开销；不能把不同批次搜索计时直接相加后称作端到端测量。', '',
              '所有90条历史筛选查询全部保留。每配置只有一次正式观测，不能证明重复执行稳定性或无偏任意查询性能。配对查询重采样区间只反映该查询集合组成的变化，不反映测量噪声或盲测显著性。', '',
              '完整逐查询差异和描述性区间：[PAIRED_SUMMARY.json](PAIRED_SUMMARY.json)。']
    (out/'PAIRED_REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:{j:v for j,v in r.items() if j!='per_query'} for k,r in comparisons.items()},indent=2))


if __name__=='__main__':main()
