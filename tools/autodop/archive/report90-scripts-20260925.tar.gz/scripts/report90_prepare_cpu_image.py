"""Stage and smoke-test the rebuilt BE without replacing live containers."""
import hashlib
import json
import os
import shutil
from pathlib import Path
import subprocess
from report90_cpu_deployment_check import check as check_deployment

RUN = Path(__file__).resolve().parents[1] / 'runs/report90_20260912'
OUT = RUN / 'cpu_capacity_fix'


def sha256(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def main():
    # No image mutation until measurement predecessors and build output are ready.
    for name in ['queue_extension_20260913_attempt3', 'convergence_execution_20260913']:
        assert json.loads((RUN / name / 'STATUS.json').read_text())['status'] == 'complete', name
    search = RUN / 'search_convergence_20260913/STATUS.json'
    if search.exists():
        assert json.loads(search.read_text())['status'] == 'complete', 'Search recheck still incomplete'
    binary = OUT / 'build_output/be/lib/starrocks_be'
    assert binary.is_file()
    assert (OUT / 'BUILD_COMPLETE.json').exists(), 'Record successful full build before staging'
    build = json.loads((OUT / 'BUILD_COMPLETE.json').read_text())
    binary_sha = sha256(binary)
    assert build['binary_sha256'] == binary_sha and build['exit_code'] == 0
    baseline = json.loads((OUT / 'DEPLOYMENT_BASELINE.json').read_text())
    assert len({b['image_id'] for b in baseline}) == 1
    deployed = check_deployment(baseline[0]['image_id'])
    preflight = json.loads((OUT / 'DEPLOYMENT_PREFLIGHT.json').read_text())
    assert deployed['compose_sha256'] == preflight['compose_sha256'], 'Compose changed since preflight'
    assert {b['container']: b['config_sha256'] for b in deployed['containers']} == {
        b['container']: b['config_sha256'] for b in preflight['containers']
    }, 'BE configuration changed since preflight'
    for b in baseline:
        current = json.loads(subprocess.check_output(['docker', 'inspect', b['container']], text=True))[0]
        assert current['Image'] == b['image_id'] and current['State']['Running'], b['container']
        assert current['HostConfig']['CpusetCpus'] == b['cpuset']
        assert current['HostConfig']['Memory'] == b['memory_limit']
        mounts = [{'type': m['Type'], 'source': m['Source'], 'destination': m['Destination']} for m in current['Mounts']]
        mount_key = lambda m: (m['type'], m['source'], m['destination'])
        assert sorted(mounts, key=mount_key) == sorted(b['mounts'], key=mount_key)
    assert not (OUT / 'CANDIDATE_IMAGE.json').exists()
    context = OUT / 'image_context'
    context.mkdir(exist_ok=False)
    os.link(binary, context / 'starrocks_be')
    dependency = json.loads((OUT / 'BUILD_ATTEMPT5.json').read_text())
    unwind = Path(dependency['runtime_library'])
    assert sha256(unwind) == dependency['runtime_library_sha256']
    shutil.copyfile(unwind, context / 'libunwind.so.8')
    original_tag = 'autodop/be-original:' + baseline[0]['image_id'].split(':')[-1][:12]
    candidate_tag = 'autodop/be-cpu-capacity:' + binary_sha[:12]
    (context / 'Dockerfile').write_text(f'FROM {original_tag}\nCOPY starrocks_be /opt/starrocks/be/lib/starrocks_be\nCOPY libunwind.so.8 /opt/starrocks/be/lib/libunwind.so.8\n')
    (context / '.dockerignore').write_text('**\n!Dockerfile\n!starrocks_be\n!libunwind.so.8\n')
    commands = []
    def run(command, label):
        commands.append(command)
        result = subprocess.run(command, capture_output=True, text=True)
        (OUT / (label + '.log')).write_text(result.stdout + result.stderr)
        assert result.returncode == 0, f'{label} failed; inspect its log'
        return result.stdout + result.stderr
    run(['docker', 'tag', baseline[0]['image_id'], original_tag], 'image_tag_original')
    run(['docker', 'build', '--pull=false', '-t', candidate_tag, str(context)], 'image_build')
    smoke = ['docker', 'run', '--rm', '--network', 'none', '--cpuset-cpus', '36', '--memory', '2g',
             '-e', 'LD_LIBRARY_PATH=/opt/starrocks/be/lib/hadoop/native:/usr/lib/jvm/java-17-openjdk-amd64/lib/server:/usr/lib/jvm/java-17-openjdk-amd64/lib:/opt/starrocks/be/lib']
    dependencies = run([*smoke, '--entrypoint', '/usr/bin/ldd', candidate_tag,
                        '/opt/starrocks/be/lib/starrocks_be'], 'image_ldd')
    assert 'not found' not in dependencies, 'Candidate has unresolved libraries'
    run([*smoke, '--entrypoint', '/opt/starrocks/be/lib/starrocks_be', candidate_tag, '--version'], 'image_version')
    image_id = json.loads(subprocess.check_output(['docker', 'image', 'inspect', candidate_tag], text=True))[0]['Id']
    override = {'services': {b['compose_service']: {'image': candidate_tag, 'cpuset': b['cpuset'],
                 'mem_limit': b['memory_limit']} for b in baseline}}
    # JSON is a valid Compose configuration and avoids shell/YAML interpolation.
    (OUT / 'compose_candidate.json').write_text(json.dumps(override, indent=2) + '\n')
    rollback = {'services': {b['compose_service']: {'image': original_tag, 'cpuset': b['cpuset'],
                 'mem_limit': b['memory_limit']} for b in baseline}}
    (OUT / 'compose_original.json').write_text(json.dumps(rollback, indent=2) + '\n')
    for b in baseline:
        current = json.loads(subprocess.check_output(['docker', 'inspect', b['container']], text=True))[0]
        assert current['Image'] == b['image_id'] and current['State']['Running']
    result = {'status': 'smoke_passed_not_deployed', 'candidate_tag': candidate_tag,
              'candidate_image_id': image_id, 'original_tag': original_tag,
              'original_image_id': baseline[0]['image_id'], 'binary_sha256': binary_sha,
              'commands': commands, 'live_containers_unchanged': True,
              'runtime_library_sha256': dependency['runtime_library_sha256'],
              'scope': 'Original image plus rebuilt BE executable and its required libunwind.so.8 dependency; original startup scripts and configs retained. No data volumes or network in smoke tests. Daemon startup and query behavior still require controlled deployment validation.',
              'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (OUT / 'CANDIDATE_IMAGE.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
