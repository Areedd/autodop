"""Join query results, FE audit, callbacks and actual queue lifecycles before comparison."""
from pathlib import Path
import json
import re
import math
import hashlib
import numpy as np
from report90_native_duration_predictor import DurationPredictor
from report90_queue_timeline_parse import validate

RUN = Path(__file__).resolve().parents[1] / 'runs/report90_20260912'
BASE = RUN / 'duration_concurrent_development'


def main():
    out = BASE / 'pilot'
    protocol = json.loads((BASE / 'PROTOCOL.json').read_text())
    capture = json.loads((out / 'CAPTURE.json').read_text())
    rows = capture['executions']
    assert len(rows) == protocol['total_executions'] and not capture['errors']
    queries = {q['id']: q for q in protocol['queries']}
    tokens = {r['token']: r for r in rows}
    assert len(tokens) == len(rows)
    matches = {}
    for line in (out / 'fe.audit.log.captured').read_text().splitlines():
        if ' [query] ' not in line: continue
        token = re.search(r'duration_concurrent_[0-9a-f]{32}', line)
        if not token or token[0] not in tokens: continue
        assert token[0] not in matches
        row = tokens[token[0]]
        assert '|State=EOF|' in line and '|ResourceGroup=default_wg|' in line
        assert '|Db=' + row['database'] + '|' in line
        normalize = lambda s: ' '.join(s.split()).rstrip(';').rstrip()
        assert normalize(line.split('|Stmt=', 1)[1].split('|Digest=', 1)[0]) == normalize(row['sql'])
        assert '|PredictMemBytes=' + str(protocol['fixed_memory_response_bytes']) + '|' in line
        matches[token[0]] = re.search(r'\|QueryId=([0-9a-f-]+)\|', line)[1]
    assert set(matches) == set(tokens) and len(set(matches.values())) == len(rows)
    log = (out / 'fe.log.captured').read_text().splitlines()
    timeline = validate(log, capacity=protocol['total_physical_slots'])
    lifecycle = {}
    for event in timeline:
        lifecycle.setdefault(event['query_id'], {})[event['event']] = event
    bindings = {}
    for line in log:
        m = re.search(r'AUTODOP_DURATION_REQUIRE query=([0-9a-f-]+) durationMs=(\S+) slots=(\d+)', line)
        if m:
            assert m[1] not in bindings
            bindings[m[1]] = (float(m[2]), int(m[3]))
    callbacks = {}
    for call in capture['calls']:
        assert call['query_id'] not in callbacks
        callbacks[call['query_id']] = call
    workload_calls = {call['query_id'] for call in capture['calls'] if call['batch'] >= 0}
    assert workload_calls == set(matches.values())
    bootstrap_calls = [call for call in capture['calls'] if call['batch'] == -1]
    assert len(bootstrap_calls) == 1 and bootstrap_calls[0]['mode'] == 'bootstrap'
    header = json.loads((RUN / 'matched_development_duration/full/RESULT.json').read_text())['executions'][0]['feature_record']['header']
    adapter = DurationPredictor.load(protocol['model'], header, protocol['model_sha256'])
    for row in rows:
        assert row['status'] == 'result_verified' and row['result_digest'] == queries[row['id']]['native_result_digest']
        query_id = matches[row['token']]
        call = callbacks[query_id]
        assert (call['mode'], call['batch']) == (row['mode'], row['batch'])
        prediction = adapter.predict_csv(call['csv'])
        assert math.isclose(prediction, call['duration_ms'], rel_tol=1e-12, abs_tol=1e-9)
        duration, slots = bindings[query_id]
        assert slots == protocol['physical_slots_per_query']
        if row['mode'] == 'fifo': assert math.isnan(duration)
        else: assert math.isclose(duration, prediction, rel_tol=1e-12, abs_tol=1e-9)
        events = lifecycle[query_id]
        assert set(events) == {'REQUIRE', 'ALLOCATE', 'RELEASE'}
        assert all(event['slots'] == slots for event in events.values())
        row.update(query_id=query_id, queue_wait_ms=(events['ALLOCATE']['ns']-events['REQUIRE']['ns'])/1e6,
                   require_ns=events['REQUIRE']['ns'], service_ms=call['service_ns']/1e6,
                   feature_sha256=hashlib.sha256(call['csv'].encode()).hexdigest())
    summaries, gates = [], []
    for batch in capture['batches']:
        current = [r for r in rows if r['batch'] == batch['batch']]
        assert len(current) == protocol['queries_per_batch']
        actual = [r['id'] for r in sorted(current, key=lambda r:r['require_ns'])]
        intended = [q for q in protocol['orders'][batch['order']] for _ in range(protocol['copies_per_query'])]
        gates.append(dict(batch=batch['batch'], group_order_matches=actual == intended, actual=actual, intended=intended))
        latencies = [r['client_latency_ms'] for r in current]
        summaries.append(dict(batch, mean_ms=float(np.mean(latencies)), p50_ms=float(np.quantile(latencies,.5)),
                              p90_ms=float(np.quantile(latencies,.9)), p99_ms=float(np.quantile(latencies,.99)),
                              qps=len(current)/batch['duration_s'], mean_queue_ms=float(np.mean([r['queue_wait_ms'] for r in current]))))
    comparisons = {}
    for order in protocol['orders']:
        pair = {s['mode']:s for s in summaries if s['phase']=='measured' and s['order']==order}
        comparisons[order] = {key:100*(1-pair['predicted_duration'][key]/pair['fifo'][key])
                              for key in ['duration_s','mean_ms','p50_ms','p90_ms','p99_ms']}
    feature_counts = {q:len({r['feature_sha256'] for r in rows if r['id']==q}) for q in queries}
    for name in ['QUEUE_SETTINGS.json','frontend_settings.json']:
        assert json.loads((out/name).read_text())['restored']
    sources = [Path(__file__),BASE/'PROTOCOL.json',out/'CAPTURE.json',out/'fe.log.captured',out/'fe.audit.log.captured']
    result = dict(status='verified_execution_and_binding', executions=len(rows), summaries=summaries,
                  comparisons_percent_reduction=comparisons, arrival_order_gates=gates,
                  all_arrival_orders_match=all(g['group_order_matches'] for g in gates),
                  feature_variants_per_query=feature_counts, rows=rows,
                  scope='Native development queries, finite batches only. Arrival-order failures invalidate controlled order claims. Feature equality does not prove plan identity. No report90 or heterogeneous-DOP generalization.',
                  source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    (out/'AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(comparisons=comparisons, all_arrival_orders_match=result['all_arrival_orders_match'],
                         feature_variants_per_query=feature_counts),indent=2))


if __name__ == '__main__': main()
