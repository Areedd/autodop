"""Independently replay selected model scores after retraining; no SQL or fitting."""
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
import xgboost as xgb
from report90_execute import ROOT,RUN
from report90_complex_retrain import validation
from report90_models import flat_features
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from autodop.training import select_partition

BASE=RUN/'complex_development24'
OUT=BASE/'retrained'


def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    result=read(OUT/'RESULT.json');assert result['status']=='complete'
    for path,expected in read(OUT/'EXECUTION_SOURCE_SHA256.json').items():assert sha(Path(path))==expected
    torch.set_num_threads(1)
    samples,pairs,_=load_dataset(BASE/'merged_dataset');contract=read(OUT/'CONTRACT.json')
    valid,_=select_partition(samples,pairs,contract,'valid');assert len(valid)==212
    metadata=read(OUT/'METADATA.json');graphs=[build_graph(s,metadata) for s in valid]
    norms=np.load(OUT/'FEATURE_NORMALIZATION.npz')
    xx=np.stack([(flat_features(g,metadata)-norms['mean'])/norms['std'] for g in graphs])
    verified={}
    for kind,selected in result['selected'].items():
        path=Path(selected['model']);assert sha(path)==selected['model_sha256']
        if kind=='transformer':
            model,checkpoint=load_cost_model(path);model.eval();assert checkpoint['metadata']==metadata
            with torch.no_grad():scores=[float(model(g)) for g in graphs]
        else:
            model=xgb.XGBRanker();model.load_model(path);model.set_params(n_jobs=1);scores=model.predict(xx)
        quality=validation(valid,scores)
        assert quality==selected['selected']['validation'], (kind,'saved scores/selection metrics differ')
        verified[kind]=quality
    parent=ROOT/'runs/multi_structure_feedback_cost05_20260910/model/cost.pt'
    model,ck=load_cost_model(parent);model.eval()
    with torch.no_grad():scores=[float(model(build_graph(s,ck['metadata']))) for s in valid]
    verified['original_multistage_teacher']=validation(valid,scores)
    choices=[]
    for kind,quality in verified.items():
        for cohort,metrics in quality['cohorts'].items():
            for plan,config in metrics['choices'].items():
                candidates=[sample for sample in valid if sample['plan_key']==plan]
                chosen=next(sample for sample in candidates if sample['config_key']==config)
                fastest=min(candidates,key=lambda sample:(sample['latency_ms'],sample['config_key']))
                choices.append({'model':kind,'cohort':cohort,'plan_key':plan,
                    'query':chosen.get('template_id'),'candidate_count':len(candidates),
                    'chosen_config':config,'chosen_dops':chosen['dop_config'],
                    'chosen_latency_ms':chosen['latency_ms'],
                    'observed_best_config':fastest['config_key'],'observed_best_dops':fastest['dop_config'],
                    'observed_best_latency_ms':fastest['latency_ms'],
                    'regret':chosen['latency_ms']/fastest['latency_ms']-1})
    assert len(choices)==22*len(verified)
    (OUT/'CHOICE_DIAGNOSTICS.json').write_text(json.dumps({'scope':'All validation plans for every compared model; observed candidate costs, no fresh execution or independent-test claim.','choices':choices},indent=2)+'\n')
    audit={'status':'verified_selected_model_replay','models':verified,'validation_samples':212,
        'development_gate_passed':result['development_gate_passed'],
        'scope':'Observed-candidate validation used for model selection. No untouched-test/generalization/online superiority claim.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),OUT/'RESULT.json',OUT/'EXECUTION_SOURCE_SHA256.json',parent]}}
    (OUT/'SCORE_REPLAY.json').write_text(json.dumps(audit,indent=2)+'\n')
    lines=['# 原多阶段模型接续与监督对照','','保留原多阶段Transformer作为接续起点，使用16条新复杂训练查询，8条新复杂验证查询只参与模型选择。所有查询、配置和原始失败来源均保留。','','| 模型 | 历史验证配置选择损失 | 复杂验证配置选择损失 | 两组等权损失 | 历史/复杂排序准确率 |','|---|---:|---:|---:|---:|']
    for kind,q in verified.items():
        h=q['cohorts']['historical'];n=q['cohorts']['complex_new']
        lines.append(f"| {kind} | {100*h['mean_regret']:.2f}% | {100*n['mean_regret']:.2f}% | {100*q['weighted_regret']:.2f}% | {100*h['rank_accuracy']:.2f}% / {100*n['rank_accuracy']:.2f}% |")
    lines+=['',f"预设开发门槛：{'通过' if result['development_gate_passed'] else '未通过'}。门槛要求接续Transformer相对两种XGBoost，在等权损失和复杂验证损失上均不更差。",'',
        '配置选择损失为模型所选配置延迟相对已测候选最快延迟的额外比例，越低越好。排序准确率统计延迟差至少3%的配置对，越高越好。二者不能互相替代。', '',
        '这是一项方法级对照，包含原多阶段初始化，不是只改变网络结构的单因素消融，也不是等训练计算量的对照。XGBoost点样本分组与同排序对分组两种基线都保留。', '',
        '选定检查点已重新加载，所有验证指标与训练记录完全一致。原多阶段模型另行评估作为参照。验证集已经参与模型选择，不能把这里的胜出直接写成报告90条查询或独立测试集上的提升。后续需另行执行小测。']
    lines += ['', '逐计划选择明细见 CHOICE_DIAGNOSTICS.json，覆盖每种模型的全部 22 个验证计划，包括所选 DOP、已测最优 DOP 和配置选择损失；不只列举获益查询。']
    preparation=read(OUT/'PREPARATION.json')
    lines += ['', '## 训练成本', '',
        '| 方法 | 本轮候选训练数 | 候选训练累计耗时（秒） | 选定候选训练耗时（秒） |',
        '|---|---:|---:|---:|']
    for kind,selected in result['selected'].items():
        candidates=[c for c in result['candidates'] if c['kind']==kind]
        lines.append(f"| {kind} | {len(candidates)} | {sum(c['seconds'] for c in candidates):.2f} | {selected['seconds']:.2f} |")
    lines += ['', f"共享图构建、教师锚点计算和特征准备耗时 {preparation['seconds']:.2f} 秒。训练样本 {preparation['train_samples']} 个，验证样本 {preparation['valid_samples']} 个。",
        '', '耗时是该次固定单 CPU 核执行的观测值；Transformer 候选耗时包含定期验证及进度写盘，XGBoost 候选耗时包含拟合、验证及保存。不是严格等工作量的拟合速度比较，也不包含之前的多阶段预训练、SQL 采集、等待时间或部署成本。初始化的历史训练成本不能视为零。']
    from report90_complex_learning_plot import render as render_curves
    render_curves(result,OUT)
    lines += ['', '## 完整学习曲线', '', '![两个预设学习率的全部训练轮次与验证检查点](LEARNING_CURVES.png)', '', '图中包含两个预设学习率的全部轮次及每 10 轮验证结果。虚线表示按预设规则选定的 XGBoost 验证结果，不是 XGBoost 的训练过程。原始绘图数据见 LEARNING_CURVES.json，矢量图见 LEARNING_CURVES.svg。']
    (OUT/'PLOT_SOURCE_SHA256.json').write_text(json.dumps({str(ROOT/'scripts/report90_complex_learning_plot.py'):sha(ROOT/'scripts/report90_complex_learning_plot.py')},indent=2)+'\n')
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({'status':audit['status'],'development_gate_passed':audit['development_gate_passed']},indent=2))


if __name__=='__main__':main()
