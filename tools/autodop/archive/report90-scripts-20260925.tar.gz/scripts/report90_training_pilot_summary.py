"""Compare all matched original-encoder calibration training pilots, with provenance."""
import json
import hashlib
import os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR','/tmp/autodop-report-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20'
OUT=BASE/'matched_training_pilots'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    assert not OUT.exists()
    variants={
        'Original sampling':('statistical_readout_pilot/pilot_original_readout','statistical_readout_pilot/audit_original_readout'),
        'Encoder LR x0.1':('encoder_lr_pilot/pilot','encoder_lr_pilot/pair_audit'),
        'Uniform pairs':('pair_sampling_pilot/pilot','pair_sampling_pilot/pair_audit'),
        'Hard pairs, refresh10':('hard_pair_pilot/pilot','hard_pair_pilot/pair_audit'),
        'Hard pairs, refresh1':('hard_pair_refresh_pilot/pilot','hard_pair_refresh_pilot/pair_audit'),
    }
    sources=[Path(__file__)];records={};reference_xgb=None
    for label,(folder,afolder) in variants.items():
        folder=BASE/folder;afolder=BASE/afolder
        audit=json.loads((afolder/'RESULT.json').read_text());assert audit['status']=='verified_independent_pair_replay'
        for path,digest in audit['source_sha256'].items():assert sha(Path(path))==digest
        replay=json.loads((folder/'SCORE_REPLAY.json').read_text());assert replay['status']=='verified'
        result=json.loads((folder/'transformer_h0/RESULT.json').read_text())
        assert len(result['history'])==30
        expected=audit['models']['transformer']['macro_accuracy']
        assert expected==result['selected']['validation']['weighted_rank_accuracy']
        counts=json.loads((folder/'PREPARATION.json').read_text());assert counts['train_samples']==1365 and counts['valid_samples']==212
        pinned=json.loads((folder/'EXECUTION_SOURCE_SHA256.json').read_text())
        for name in ['samples.jsonl','pairs.jsonl','CONTRACT.json','metadata.json']:
            path=BASE/'merged_dataset'/name;assert pinned[str(path)]==sha(path)
        xgb=audit['models']['xgboost_pairs'];xgb_scores=xgb['scores']
        if reference_xgb is None:reference_xgb=xgb_scores
        else:assert reference_xgb==xgb_scores
        records[label]={'macro_accuracy':expected,'pooled_accuracy':audit['models']['transformer']['pooled_accuracy'],
            'selected_epoch':result['selected']['epoch'],
            'validation_history':[{'epoch':h['epoch'],'macro_accuracy':h['validation']['weighted_rank_accuracy']} for h in result['history'] if 'validation' in h],
            'training_loop_seconds':result['seconds']}
        sources += [folder/'transformer_h0/RESULT.json',folder/'SCORE_REPLAY.json',folder/'PREPARATION.json',folder/'EXECUTION_SOURCE_SHA256.json',afolder/'RESULT.json']
    OUT.mkdir()
    result={'status':'verified_matched_pilot_summary','seed':17,'train_samples':1365,'validation_samples':212,'pairs':920,
        'records':records,'xgboost_pairs_macro':xgb['macro_accuracy'],
        'scope':'All five matched predeclared30-epoch training-only pilots with the unchanged original architecture and calibrated loss are shown. Architecture-changing pilots and other losses remain separate experiments. Same data, split, loss, seed, optimizer base LR and cosine100 horizon. Each variant changes its stated training factor. Reused validation; not independent tests or equal wall-time runs. Extra hard-pair mining inference included in its loop times. No best-seed or report90 selection.',
        'source_sha256':{str(p):sha(p) for p in sources}}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    fig,ax=plt.subplots(figsize=(9,4.8))
    for label,r in records.items():
        h=r['validation_history'];ax.plot([v['epoch'] for v in h],[100*v['macro_accuracy'] for v in h],marker='o',label=label)
    ax.axhline(100*xgb['macro_accuracy'],color='black',linestyle='--',label='XGBoost pair ranking')
    ax.set(xlabel='Training epoch',ylabel='Equal-cohort pair accuracy (%)',title='Matched training pilots (seed17, reused development validation)',xticks=[10,20,30]);ax.grid(alpha=.2);ax.legend(fontsize=8,loc='best');fig.tight_layout()
    fig.savefig(OUT/'accuracy_curves.png',dpi=180);fig.savefig(OUT/'accuracy_curves.pdf');plt.close(fig)
    lines=['# 匹配训练小测汇总','',result['scope'],'','| 方案 | 两类等权准确率 | 汇总准确率 | 选定轮次 |','|---|---:|---:|---:|']
    for label,r in records.items():lines.append(f"| {label} | {100*r['macro_accuracy']:.3f}% | {100*r['pooled_accuracy']:.3f}% | {r['selected_epoch']} |")
    lines += ['',f"XGBoost成对排序等权准确率：{100*xgb['macro_accuracy']:.3f}%。全部变体的XGBoost预测分数完全相同。",'', '![训练曲线](accuracy_curves.png)','', '这些单种子小测不能替代三种子复核或独立测试。所有已列变体均保留，曲线展示验证集检查点波动；不能把最佳检查点当作多次独立重复。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');print(OUT)

if __name__=='__main__':main()
