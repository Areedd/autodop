"""Match each native CSV capture to its unique EXPLAIN audit statement."""
import argparse
import hashlib
import json
from pathlib import Path
import re


def main(phase):
    root=Path(__file__).resolve().parents[3]
    out=root/f'tools/autodop/runs/report90_20260912/native_memory_features17_{phase}'
    read=lambda p:json.loads(p.read_text())
    status=read(out/'STATUS.json');assert status['status']=='captured'
    result=read(out/'RESULT.json');assert result['status']=='captured' and not result['errors']
    rows={r['audit_token']:r for r in result['records']};assert len(rows)==len(result['records'])
    matches={};audit=root/'output/fe/log/fe.audit.log'
    normalize=lambda s:' '.join(s.split()).rstrip(';').rstrip()
    with audit.open() as stream:
        for line in stream:
            if ' [query] ' not in line:continue
            m=re.search(r'autodop_memory_features_[0-9a-f]{32}',line)
            if not m or m[0] not in rows:continue
            token=m[0];assert token not in matches
            assert '|State=EOF|' in line and '|ErrorCode=|' in line
            assert '|ScanBytes=0|' in line and '|ScanRows=0|' in line
            sql=line.split('|Stmt=',1)[1].split('|Digest=',1)[0]
            assert normalize(sql)==normalize(rows[token]['explain_sql'])
            assert '|Db='+rows[token]['database']+'|' in line
            qid=re.search(r'\|QueryId=([0-9a-f-]+)\|',line)[1]
            matches[token]=dict(query_id=qid,audit_line=line.rstrip('\n'))
    assert rows.keys()==matches.keys()
    assert len({r['query_id'] for r in matches.values()})==len(rows)
    assert read(out/'frontend_settings.json')['restored']
    differences={}
    for key in sorted({r['id'] for r in rows.values()}):
        pair=sorted([r for r in rows.values() if r['id']==key],key=lambda r:r['pipeline_dop'])
        assert len(pair)==2 and [r['pipeline_dop'] for r in pair]==[0,4]
        a,b=pair;assert a['header']==b['header']
        differences[key]=[k for k,x,y in zip(a['header'],a['values'],b['values']) if x!=y]
    paths=[out/'RESULT.json',out/'PROTOCOL.json',out/'frontend_settings.json',Path(__file__).resolve()]
    verified=dict(status='verified',records=len(rows),columns=len(result['header']),matches=matches,
                  dop0_vs4_different_columns=differences,
                  source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
                  scope='Exact Explain text, unique query ID, database, success and zero scan audit matched. '
                        'Native callback associated with one serialized Explain. No latency benchmark or trained service.')
    (out/'IDENTITY_AUDIT.json').write_text(json.dumps(verified,indent=2)+'\n')
    (out/'STATUS.json').write_text(json.dumps(dict(status='verified',records=len(rows),columns=len(result['header'])),indent=2)+'\n')
    print('Verified native feature captures:',len(rows),'DOP differences:',differences)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['pilot','full'],required=True)
    main(p.parse_args().phase)
