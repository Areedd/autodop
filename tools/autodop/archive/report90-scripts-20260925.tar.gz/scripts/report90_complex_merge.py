"""Merge verified historical/new cohorts without mixing validation into fitting."""
import collections
import hashlib
import json
from pathlib import Path
from report90_execute import ROOT,RUN
from autodop.data import load_dataset,write_jsonl
from autodop.training import make_training_contract,select_partition

BASE=RUN/'complex_development24'
NEW=BASE/'verified_labels'
OUT=BASE/'merged_dataset'


def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    assert not OUT.exists(), 'Preserve existing merge'
    audit=read(NEW/'ASSEMBLY_AUDIT.json');assert audit['status']=='complete' and audit['samples']==192
    for name,expected in audit['source_sha256'].items():assert sha(Path(name))==expected
    historical=Path(read(RUN/'PROTOCOL.json')['training_dataset'])
    old,old_pairs,_=load_dataset(historical);new,new_pairs,_=load_dataset(NEW)
    assert len(old)==1225 and len(new)==192
    assert {s['plan_key'] for s in old}.isdisjoint(s['plan_key'] for s in new)
    report_hashes={q['sql_sha256'] for q in read(RUN/'manifest.json')['queries']}
    assert not report_hashes&{s['sql_sha256'] for s in old+new}
    assert {s['sql_sha256'] for s in old}.isdisjoint(s['sql_sha256'] for s in new)
    samples=[{**s,'source_cohort':cohort} for cohort,group in [('historical',old),('complex_new',new)] for s in group]
    pairs=old_pairs+new_pairs;lookup={(s['plan_key'],s['config_key']):s for s in samples}
    assert len(lookup)==1417
    plan_splits={s['plan_key']:s['split'] for s in samples}
    assert all(s['split'] in ['train','valid'] and s['split']==plan_splits[s['plan_key']] for s in samples)
    pair_ids=set();historical_pair_repeats=0
    for pair in pairs:
        identity=(pair['plan_key'],pair['fast_config_key'],pair['slow_config_key'])
        fast=lookup[(pair['plan_key'],pair['fast_config_key'])];slow=lookup[(pair['plan_key'],pair['slow_config_key'])]
        assert fast['split']==slow['split'] and fast['source_cohort']==slow['source_cohort']
        assert 0 < pair['fast_latency_ms'] < pair['slow_latency_ms']
        if identity in pair_ids:
            assert fast['source_cohort']=='historical', 'New labels must have unique configuration pairs'
            historical_pair_repeats+=1
        pair_ids.add(identity)
        if fast['source_cohort']=='complex_new':
            assert fast['latency_ms']==pair['fast_latency_ms'] and slow['latency_ms']==pair['slow_latency_ms']
        # Historical pair margins intentionally retain own-batch measurements.
        # See HISTORICAL_PAIR_CHECK.json; never overwrite them with cross-batch point labels.
    splits={split:sorted({s['plan_key'] for s in samples if s['split']==split}) for split in ['train','valid','test']}
    assert len(splits['train'])==94 and len(splits['valid'])==22 and not splits['test']
    assert collections.Counter(s['split'] for s in samples)=={'train':1205,'valid':212}
    OUT.mkdir()
    write_jsonl(OUT/'samples.jsonl',samples);write_jsonl(OUT/'pairs.jsonl',pairs)
    (OUT/'model_split.json').write_text(json.dumps(splits,indent=2)+'\n')
    (OUT/'metadata.json').write_text((BASE/'warmstart/METADATA.json').read_text())
    contract=make_training_contract(samples,pairs,.2,2026091312,OUT/'model_split.json')
    train,tp=select_partition(samples,pairs,contract,'train');valid,vp=select_partition(samples,pairs,contract,'valid')
    assert len(train)==1205 and len(valid)==212
    train_ids={s['plan_key'] for s in train};valid_ids={s['plan_key'] for s in valid}
    assert not train_ids&valid_ids and all(p['plan_key'] in train_ids for p in tp)
    result={'status':'complete','samples':1417,'pairs':len(pairs),'train_samples':len(train),'valid_samples':len(valid),
        'train_plans':94,'valid_plans':22,'train_pairs':len(tp),'valid_pairs':len(vp),
        'historical_repeated_pair_observations_preserved':historical_pair_repeats,
        'cohort_samples':dict(collections.Counter(s['source_cohort']+'/'+s['split'] for s in samples)),
        'label_scope':'Historical and corrected-BE labels kept in separate query cohorts. Ranking pairs never cross queries, cohorts or splits. No timing blending.',
        'training_metadata':'Function-preserving warmstart metadata, new vocabulary from train graphs only; no validation-fitted features.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),historical/'samples.jsonl',historical/'pairs.jsonl',NEW/'samples.jsonl',NEW/'pairs.jsonl',NEW/'ASSEMBLY_AUDIT.json',BASE/'warmstart/METADATA.json']}}
    (OUT/'CONTRACT.json').write_text(json.dumps(contract,indent=2)+'\n')
    (OUT/'ASSEMBLY_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
