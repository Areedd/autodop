"""Controlled train-only top-candidate sampling experiment, unchanged graph model."""
import argparse
import datetime
import os
from pathlib import Path
import subprocess
import sys
import torch
from autodop.training import file_sha256
from report90_coverage_choices import BASE, read
import report90_coverage_stability as common

OUT = BASE / 'top_sampling'

HELPER = '''
def top_epoch_pairs(by, top_by, rng):
    jobs=[]
    for cohort in COHORTS:
        plans=sorted(by[cohort])
        for index in range(312):
            plan=rng.choice(plans)
            pool=top_by[cohort][plan] if index<156 else by[cohort][plan]
            jobs.append(rng.choice(pool))
    rng.shuffle(jobs)
    return jobs

'''


def main(stage):
    os.sched_setaffinity(0, {35}); torch.set_num_threads(1)
    if stage == 'pilot':
        assert not OUT.exists()
        assert read(BASE/'top_candidate_audit/RESULT.json')['status']=='verified'
        OUT.mkdir()
        common.save(OUT/'PROTOCOL.json', {
            'at':datetime.datetime.now().astimezone().isoformat(), 'seeds':[17,29,43],
            'epochs':100, 'pilot_epochs':2, 'total_pair_draws_per_epoch':624,
            'sampling':'Each cohort312 draws:156 uniform plan then top-involving pair,156 uniform plan then any pair. Top uses train-only canonical point latency within3% of minimum. Preserve original batch-specific pair labels, no new pairs.',
            'unchanged':'Original multistage initialization, graph Transformer and competition edges, dynamic margin loss, zero preservation weight, batch16, cosine1e-4 to1e-5 horizon100, validation every10 and same minimum-regret selection.',
            'scope':'Development optimization, all seeds retained, no report90 labels in fitting. No automatic SQL or deployment. Sampling allocation changes RNG trajectory; this is not identical minibatch ordering.',
            'hypothesis':'Emphasize candidate selection while retaining general ordering; existing top ranking is strong so improvement is uncertain. No claim of missing training coverage.',
            'source_sha256':{str(p):file_sha256(p) for p in [Path(__file__),Path(common.__file__),common.SOURCE,
                BASE/'top_candidate_audit/RESULT.json',BASE/'cosine_decay/RESULT.json']}})
    protocol=read(OUT/'PROTOCOL.json')
    for p,h in protocol['source_sha256'].items(): assert file_sha256(p)==h
    if stage=='full': assert read(OUT/'seed17_pilot/SCORE_REPLAY.json')['status']=='verified'
    common.OUT=OUT
    seeds=[17] if stage=='pilot' else protocol['seeds']
    for seed in seeds:
        name=f'seed{seed}'+('_pilot' if stage=='pilot' else '')
        folder=OUT/name; assert not folder.exists()
        source,changes=common.staged_source(seed,folder,stage=='pilot')
        replacements={
            '\ndef main():': '\n'+HELPER+'\ndef main():',
            "    sources=[Path(__file__)":
                "    top_by={c:{} for c in COHORTS}\n"
                "    for c,plans in by.items():\n"
                "        for plan,pp in plans.items():\n"
                "            ss=[s for s in train if s['plan_key']==plan]\n"
                "            best=min(s['latency_ms'] for s in ss)\n"
                "            top={s['config_key'] for s in ss if s['latency_ms']<=1.03*best}\n"
                "            top_by[c][plan]=[p for p in pp if p['fast_config_key'] in top or p['slow_config_key'] in top]\n"
                "            assert top_by[c][plan], 'No top pair; do not silently change sampling'\n"
                "    sources=[Path(__file__)",
            'jobs=epoch_pairs(by,rng)':'jobs=top_epoch_pairs(by,top_by,rng)',
            'model,_=load_cost_model(warm);optimizer=torch.optim.Adam(model.parameters(),lr=lr)':
                'model,_=load_cost_model(warm);optimizer=torch.optim.Adam(model.parameters(),lr=lr)\n        scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=100,eta_min=1e-5)',
            "entry={'epoch':epoch,'loss':float(np.mean(losses))}":
                "entry={'epoch':epoch,'loss':float(np.mean(losses)),'learning_rate':optimizer.param_groups[0]['lr']}\n            scheduler.step()",
        }
        for old,new in replacements.items():
            assert source.count(old)==1,old
            source=source.replace(old,new);changes[old]={'replacement':new,'occurrences':1}
        script=OUT/(name+'_trainer.py');compile(source,str(script),'exec');script.write_text(source)
        common.save(OUT/(name+'_SOURCE_TRANSFORM.json'),{'original_sha256':file_sha256(common.SOURCE),
                    'generated_sha256':file_sha256(script),'literal_changes':changes})
        common.save(OUT/'STATUS.json',{'status':'running','stage':name,'pid':os.getpid()})
        with (OUT/(name+'.log')).open('w') as stream:
            subprocess.run([sys.executable,str(script)],stdout=stream,stderr=subprocess.STDOUT,check=True)
        common.replay(folder)
    if stage=='full':
        qualities={str(s):read(OUT/f'seed{s}/SCORE_REPLAY.json')['models'] for s in seeds}
        common.save(OUT/'RESULT.json',{'status':'verified','seeds':qualities,
                    'before_cosine':read(BASE/'cosine_decay/RESULT.json')['after_cosine'],
                    'protocol_sha256':file_sha256(OUT/'PROTOCOL.json')})
    common.save(OUT/'STATUS.json',{'status':'pilot_verified' if stage=='pilot' else 'complete'})


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['pilot','full'],required=True)
    args=parser.parse_args()
    try: main(args.stage)
    except BaseException as e:
        if OUT.exists(): common.save(OUT/'STATUS.json',{'status':'failed','error':repr(e)})
        raise
