"""Read-only CPU capacity samples, independent of AutoDOP request telemetry."""
import argparse
import datetime
import json
import os
from pathlib import Path
import subprocess
import time

import pymysql


def ticks(pid):
    # comm may contain spaces or parentheses; fields after its final ')' are stable.
    fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
    return int(fields[11]) + int(fields[12]), int(fields[19])


def workers():
    result = []
    for index in range(1, 4):
        name = f'starrocks-be{index}'
        state = json.loads(subprocess.check_output(['docker', 'inspect', name], text=True))[0]
        assert state['State']['Running']
        rows = subprocess.check_output(['docker', 'top', name, '-eo', 'pid,comm'], text=True).splitlines()[1:]
        pids = [int(row.split()[0]) for row in rows if row.split()[1] == 'starrocks_be']
        assert len(pids) == 1, (name, pids)
        pid = pids[0]
        cpus = sorted(os.sched_getaffinity(pid))
        assert len(cpus) == 8, (name, cpus)
        result.append({'container': name, 'pid': pid, 'cpus': cpus,
                       'heartbeat_port': 9049 + index, 'image_id': state['Image']})
    return result


def observe(output, samples, interval, stop=None):
    assert samples > 0 and interval >= 1
    nodes = workers()
    hz = os.sysconf('SC_CLK_TCK')
    with output.open('x') as stream:
        stream.write(json.dumps({'type': 'metadata', 'workers': nodes, 'clock_ticks': hz,
                                 'host_cpus': os.cpu_count(), 'interval_seconds': interval}) + '\n')
        stream.flush()
        previous = {n['pid']: ticks(n['pid']) for n in nodes}
        start = time.monotonic()
        for _ in range(samples):
            if stop is not None:
                if stop.wait(interval):
                    break
            else:
                time.sleep(interval)
            now = time.monotonic()
            current = {n['pid']: ticks(n['pid']) for n in nodes}
            with pymysql.connect(host='127.0.0.1', port=9030, user='root', connect_timeout=5,
                                 read_timeout=10, autocommit=True,
                                 cursorclass=pymysql.cursors.DictCursor) as connection:
                with connection.cursor() as cursor:
                    cursor.execute('SHOW BACKENDS')
                    backends = {int(r['HeartbeatPort']): r for r in cursor.fetchall()}
            rows = []
            for n in nodes:
                pid = n['pid']
                assert current[pid][1] == previous[pid][1], 'Process identity changed'
                assert sorted(os.sched_getaffinity(pid)) == n['cpus'], 'CPU assignment changed'
                busy = (current[pid][0] - previous[pid][0]) / hz / (now - start)
                backend = backends[n['heartbeat_port']]
                reported = float(str(backend['CpuUsedPct']).rstrip('%')) / 100
                rows.append({'container': n['container'], 'backend_id': str(backend['BackendId']),
                             'busy_cores': busy, 'process_fraction_of_capacity': busy / len(n['cpus']),
                             'fe_reported_fraction': reported, 'fe_reported_cores': backend['CpuCores'],
                             'alive': backend['Alive']})
            stream.write(json.dumps({'type': 'sample', 'at': datetime.datetime.now().astimezone().isoformat(),
                                     'interval_seconds': now - start, 'workers': rows}) + '\n')
            stream.flush()
            previous, start = current, now


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--samples', type=int, default=100)
    parser.add_argument('--interval', type=float, default=3)
    args = parser.parse_args()
    observe(args.output, args.samples, args.interval)
