"""Same frozen pilot, allowing bounded settling time before measurements."""
import hashlib
import json
from pathlib import Path

import report90_native_report_timeline_pilot as pilot
from report90_wait_for_idle import wait_for_idle
from report90_plan_stability_gate import verify_stable_plans
from report90_queue_extension import connect


def main():
    original_check = pilot.check
    def checked(output):
        policy = dict(scope='Pre-measurement idle waiting and bounded Explain stability checks; same 45% threshold. Six attempts, 10 seconds between busy checks. No query starts until the original gate passes.',
                      sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path(__file__).with_name('report90_wait_for_idle.py'),Path(__file__).with_name('report90_plan_stability_gate.py')]})
        (pilot.OUT/'IDLE_WAIT_POLICY.json').write_text(json.dumps(policy,indent=2)+'\n')
        wait_for_idle(original_check,output)
        manifest=json.loads((pilot.SUPPORT/'manifest.json').read_text())
        def fetch(query,dop):
            path=Path(query['sql_file'])
            assert hashlib.sha256(path.read_bytes()).hexdigest()==query['sql_sha256']
            with connect() as connection,connection.cursor() as cursor:
                cursor.execute('USE `'+query['database']+'`')
                for setting in ['enable_auto_dop=false',f'pipeline_dop={dop}','enable_runtime_adaptive_dop=false','enable_query_cache=false','enable_spill=false']:
                    cursor.execute('SET '+setting)
                cursor.execute('EXPLAIN VERBOSE '+path.read_text().strip().rstrip(';'))
                return '\n'.join(str(row[0]) for row in cursor.fetchall())+'\n'
        verify_stable_plans(manifest['queries'],fetch,pilot.OUT/'PLAN_STABILITY')
    pilot.check = checked
    pilot.main()


if __name__ == '__main__':main()
