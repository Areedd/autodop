"""Strict native-DOP0 CSV adapter for frozen development duration models."""
import csv,io,json,hashlib
from pathlib import Path
import joblib
import numpy as np
from report90_train_matched_duration import predict


class DurationPredictor:
    def __init__(self,bundle,header):
        self.bundle=bundle;self.header=list(header)
        names=bundle['feature_names']
        if len(self.header)!=384 or len(set(self.header))!=384:raise ValueError('Invalid schema')
        if not all(n.startswith(('env_','operators_')) for n in names):raise ValueError('Identity fields in model')
        self.indices=[self.header.index(n) for n in names]
        self.environment={'env_0':3,'env_1':8,'env_2':23}

    @classmethod
    def load(cls,model_path,header,expected_sha256):
        path=Path(model_path)
        if hashlib.sha256(path.read_bytes()).hexdigest()!=expected_sha256:raise ValueError('Model digest mismatch')
        return cls(joblib.load(path),header)

    def predict_csv(self,body):
        rows=list(csv.reader(io.StringIO(body)))
        if len(rows)!=2 or rows[0]!=self.header or len(rows[1])!=len(self.header):raise ValueError('Native CSV schema mismatch')
        try:values=[int(v) for v in rows[1]]
        except ValueError as e:raise ValueError('Integer CSV fields required') from e
        for key,expected in self.environment.items():
            if values[self.header.index(key)]!=expected:raise ValueError('Environment changed: '+key)
        if values[self.header.index('var_0')]!=0:raise ValueError('Only native DOP0 validated')
        x=np.array([[values[i] for i in self.indices]],dtype=float)
        if not np.isfinite(x).all():raise ValueError('Nonfinite features')
        value=float(predict(self.bundle,x)[0])
        if not np.isfinite(value) or value<=0:raise ValueError('Invalid predicted duration')
        return value
