"""Export verified matched development observations with explicit feature boundaries."""
import csv,hashlib,json
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/matched_development_duration'


def main():
    proof=BASE/'full/INDEPENDENT_AUDIT.json';audit=json.loads(proof.read_text());assert audit['status']=='verified' and audit['executions']==122
    for name,h in audit['source_sha256'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h
    source=BASE/'full/RESULT.json';rows=json.loads(source.read_text())['executions']
    header=rows[0]['feature_record']['header'];features=[n for n in header if n.startswith(('env_','operators_'))]
    meta=['id','split','phase','query_id','sql_sha256'];target='client_latency_ms'
    out=BASE/'DATASET.csv'
    with out.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=meta+[target]+features);writer.writeheader()
        for r in sorted(rows,key=lambda r:(r['split'],r['id'],r['phase'])):
            values=dict(zip(r['feature_record']['header'],r['feature_record']['values']))
            writer.writerow({**{k:r[k] for k in meta+[target]},**{k:values[k] for k in features}})
    with out.open(newline='') as f:
        exported=list(csv.DictReader(f))
    assert len(exported)==122 and len({r['id'] for r in exported})==61
    assert len({r['id'] for r in exported if r['split']=='train'})==53
    assert len({r['id'] for r in exported if r['split']=='valid'})==8
    schema=dict(metadata_columns=meta,target_column=target,feature_columns=features,
                excluded_from_features=['query ID','SQL hash','SQL/table identity','phase','split','response sentinel','target duration','var_0 (constant native DOP0)'],
                feature_count=len(features),rows=122,queries=61,
                scope='Actual native serial execution duration including feature callback; not memory labels, pure BE time, concurrent latency or heterogeneous DOP labels. Metadata must never enter the model input.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),proof,source,out]})
    (BASE/'DATASET_SCHEMA.json').write_text(json.dumps(schema,indent=2)+'\n')
    (BASE/'README.md').write_text('''# 同次执行的开发侧计划特征与耗时数据

61条开发SQL、53条训练和8条原有验证查询，每条一次预热和一次正式执行，共122行。验证集曾用于此前开发，不是新独立测试。与90条报告SQL的哈希无重合。

DATASET.csv 的输入列只使用 DATASET_SCHEMA.json 中列出的 feature_columns；id、query_id、SQL哈希、划分、阶段、响应标记不得作为特征。目标 client_latency_ms 包含实际SQL执行和结果获取，也包含FE特征提取及回调开销。

特征通过实际执行时的原生CSV回调获取，使用串行唯一标记、FE审计QueryId及返回值关联，并核对可信结果摘要。未请求profile，AutoDOP关闭，pipeline_dop=0，V2准入关闭。配置恢复和独立核验见 full/INDEPENDENT_AUDIT.json。

保留原始回调、SQL与审计证据，不按耗时删样本。预热/正式的波动见 full/QUALITY_AUDIT.json（如已生成）；模型比较见 models/REPORT.md（如已完成）。这些数据不直接证明新调度策略有效。
''')
    print(json.dumps({k:schema[k] for k in ['feature_count','rows','queries']},indent=2))

if __name__=='__main__':main()
