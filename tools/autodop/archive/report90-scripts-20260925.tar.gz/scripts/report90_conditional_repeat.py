"""One fixed repeat of all conditional training contrasts before fitting labels."""
import json
from pathlib import Path
import subprocess
import sys
from report90_conditional_contrasts_prepare import OUT as BASE
from report90_neighborhood_prepare import sha


def main():
    prior = json.loads((BASE / 'collection/RESULT.json').read_text())
    assert prior['status'] == 'verified'
    for p, digest in prior['source_sha256'].items():
        assert sha(Path(p)) == digest
    assert not (BASE / 'repeat').exists()
    protocol_path = BASE / 'REPEAT_PROTOCOL.json'
    assert not protocol_path.exists()
    original = Path(__file__).with_name('report90_conditional_contrasts_collect.py')
    generated = BASE / 'repeat_collector_staged.py'
    changes = {
        "OUT = BASE / 'collection'": "OUT = BASE / 'repeat'",
        "'--seed', '2026091422'": "'--seed', '2026091423'",
        'one formal observation per configuration.': 'one additional formal observation per configuration, with a fresh warmup; same28 frozen configurations.',
        "    save('SOURCES.json', {str(p): sha(p) for p in sources})":
            "    sources += [Path(" + repr(str(protocol_path)) + "), Path(" + repr(str(original)) + ")]\n    save('SOURCES.json', {str(p): sha(p) for p in sources})",
    }
    text = original.read_text()
    for old, new in changes.items():
        assert text.count(old) == 1, old
        text = text.replace(old, new)
    compile(text, str(generated), 'exec')
    generated.write_text(text)
    protocol_path.write_text(json.dumps({
        'scope': 'All4 existing training queries, all28 frozen conditional configurations. One warmup and one formal round:56 executions. No favorable-query selection, no report90 measurements, no automatic dataset merge or fitting.',
        'reason': 'Only2of12 conditional endpoints agreed with>=3% in warm/formal phases. Check formal repeat consistency before using new labels.',
        'analysis': 'Keep measurement batches separate. Report all12 endpoint effects in both formal rounds and all within-query pair agreement; no cross-batch pair labels. Two formal observations cannot establish statistical significance.',
        'changes': changes,
        'source_sha256': {str(p): sha(p) for p in [Path(__file__), original, generated, BASE / 'collection/RESULT.json', BASE / 'SUMMARY.json', BASE / 'PROTOCOL.json', BASE / 'vectors.json']},
    }, indent=2) + '\n')
    subprocess.run([sys.executable, str(generated)], check=True)


if __name__ == '__main__':
    main()
