"""Publication-style model and feature figures using all fixed seeds."""
import hashlib
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

RUN=Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def main():
    xp=RUN/'structure_coverage20/basic_feature_stability/RESULT.json'
    mp=RUN/'structure_coverage20/mlp_interaction_stability/RESULT.json'
    x=json.loads(xp.read_text());m=json.loads(mp.read_text())
    assert x['status']=='verified_three_seed_shared_pairs' and m['status']=='verified_three_seeds'
    seeds=[17,29,43]
    values=[
        [100*r['transformer'] for r in sorted(x['records'],key=lambda r:r['seed'])],
        [100*r['no_explicit_dop_interaction'] for r in sorted(x['records'],key=lambda r:r['seed'])],
        [100*r['full'] for r in sorted(x['records'],key=lambda r:r['seed'])]]
    kinds=['mlp_rank','mlp_smooth_rank','mlp_regression']
    for kind in kinds:
        values.append([100*next(r['full'] for r in m['rows'] if r['method']==kind and r['seed']==seed) for seed in seeds])
    labels=['Transformer + competition','XGBoost basic (no products)','XGBoost enhanced','MLP rank','MLP smooth rank','MLP regression']
    fig,axes=plt.subplots(1,2,figsize=(12,5.5),layout='constrained')
    ax=axes[0];y=np.arange(len(labels));means=np.mean(values,axis=1)
    ax.barh(y,means,color=['#2468a2','#a6b6c3','#607889','#aaa','#aaa','#aaa'],alpha=.8)
    for i,v in enumerate(values):
        ax.scatter(v,[i-.13,i,i+.13],color='black',s=15,zorder=3)
        ax.text(max(v)+1.5,i,f'{means[i]:.2f}',va='center',fontsize=8)
    ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlim(0,100)
    ax.set_xlabel('Equal-cohort pair accuracy (%)')
    ax.set_title('Same 920 pairs; dots show all 3 seeds')
    ax.grid(axis='x',alpha=.2)
    ax=axes[1];y=np.arange(3)
    for offset,field,label,color in [(-.18,'full','Explicit DOP products','#2468a2'),(.18,'no_interaction','Products masked','#b9c5cf')]:
        vals=[[100*next(r[field] for r in m['rows'] if r['method']==kind and r['seed']==seed) for seed in seeds] for kind in kinds]
        means=np.mean(vals,axis=1)
        ax.barh(y+offset,means,height=.32,label=label,color=color)
        for i,v in enumerate(vals):
            ax.scatter(v,[i+offset-.06,i+offset,i+offset+.06],s=12,c='black',zorder=3)
    ax.set_yticks(y,['MLP rank','MLP smooth rank','MLP regression']);ax.invert_yaxis()
    ax.set_xlim(0,100);ax.set_xlabel('Equal-cohort pair accuracy (%)')
    ax.set_title('100 epochs; all 3 paired seeds')
    ax.legend(loc='lower left',fontsize=8);ax.grid(axis='x',alpha=.2)
    for extension in ['png','pdf']:
        fig.savefig(RUN/f'FINAL_MODEL_COMPARISON.{extension}',dpi=180)
    plt.close(fig)
    (RUN/'FINAL_MODEL_COMPARISON.sources.json').write_text(json.dumps(dict(
        scope='Means and all fixed seed points; no confidence intervals or blind-test claim.',
        source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),xp,mp]}),indent=2)+'\n')
    print('Model and feature figures generated with all seeds and enhanced control.')


if __name__=='__main__':main()
