"""Three-seed feature comparison; reuse verified full-feature100epoch baselines."""
import json
from pathlib import Path
import subprocess
import sys
from report90_interaction_pair_audit import BASE,sha


def main():
    prior=BASE/'mlp_interaction100';out=BASE/'mlp_interaction_stability';out.mkdir(exist_ok=False)
    assert json.loads((prior/'PAIR_AUDIT.json').read_text())['status']=='verified_independent_pair_replay'
    source=prior/'pilot_no_explicit_interaction_trainer.py'
    methods=['mlp_rank','mlp_smooth_rank','mlp_regression']
    protocol=dict(seeds=[17,29,43],epochs=100,methods=methods,
                  design='Reuse completed seed17 paired feature audit and all three existing full-feature baselines. Train only no-explicit-interaction arms for seeds29/43 with same100epoch budget and learning-rate grid.',
                  scope='Explicit feature ablation, not hidden baseline replacement. Reused validation; no SQL, report90 selection or best-seed choice.',
                  source_sha256={str(p):sha(p) for p in [Path(__file__),source,prior/'PAIR_AUDIT.json',prior/'PROTOCOL.json']})
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    audits={17:json.loads((prior/'PAIR_AUDIT.json').read_text())}
    provenance=[prior/'PAIR_AUDIT.json']
    for seed in [29,43]:
        folder=out/f'seed{seed}';folder.mkdir()
        local=dict(protocol,seed=seed)
        (folder/'PROTOCOL.json').write_text(json.dumps(local,indent=2)+'\n')
        text=source.read_text();assert text.count(str(prior))==3
        text=text.replace(str(prior),str(folder))
        script=folder/'trainer.py';compile(text,str(script),'exec');script.write_text(text)
        (folder/'TRANSFORM.json').write_text(json.dumps(dict(source_sha256=sha(source),generated_sha256=sha(script),changes=f'Relocate outputs/protocol; CLI seed={seed}; no other training changes'),indent=2)+'\n')
        (out/'STATUS.json').write_text(json.dumps(dict(status='running',seed=seed))+'\n')
        with (folder/'train.log').open('w') as log:
            subprocess.run([sys.executable,str(script),'--stage','pilot','--seed',str(seed),'--cpu','35'],stdout=log,stderr=subprocess.STDOUT,check=True)
        old=BASE/f'accuracy_baselines_seed{seed}_full/RESULT.json'
        original=json.loads(old.read_text());assert original['status']=='verified'
        for path,digest in original['source_sha256'].items():assert sha(path)==digest
        # A manifest of reused models, not a claim to have retrained this arm.
        reused=dict(original,selected={k:v for k,v in original['selected'].items() if k in methods},
                    candidates=[r for r in original['candidates'] if r['kind'] in methods],
                    reused_from=str(old),reused_manifest_sha256=sha(old))
        reused['source_sha256']=dict(original['source_sha256'],**{str(old):sha(old)})
        (folder/'pilot_full').mkdir()
        (folder/'pilot_full/RESULT.json').write_text(json.dumps(reused,indent=2)+'\n')
        paths=[folder/f'pilot_{arm}/RESULT.json' for arm in ['full','no_explicit_interaction']]
        (folder/'RESULT.json').write_text(json.dumps(dict(status='completed_reload_verified_pending_independent_audit',source_sha256={str(p):sha(p) for p in paths}),indent=2)+'\n')
        audit_source=Path(__file__).with_name('report90_mlp_interaction_audit.py')
        text=audit_source.read_text();assert text.count("BASE/'mlp_interaction_pilot'")==1
        text=text.replace("BASE/'mlp_interaction_pilot'",'Path('+repr(str(folder))+')')
        text=text.replace('seed17',f'seed{seed}').replace('30轮','100轮')
        script=folder/'audit.py';script.write_text(text)
        (folder/'AUDIT_TRANSFORM.json').write_text(json.dumps(dict(source_sha256=sha(audit_source),generated_sha256=sha(script),changes='Output relocation and seed/epoch description'),indent=2)+'\n')
        subprocess.run([sys.executable,str(script)],check=True)
        audits[seed]=json.loads((folder/'PAIR_AUDIT.json').read_text());provenance.append(folder/'PAIR_AUDIT.json')
        # Avoid retaining inherited pilot prose as the100epoch replication report.
        (folder/'REPORT.md').write_text(f'# MLP交互项复核 seed{seed}\n\n无交互项版本训练100轮；完整版本复用已有同种子100轮模型。具体检查点、全部结果及限制见[总报告](../REPORT.md)，本种子独立计数见[核验](PAIR_AUDIT.json)。\n')
    rows=[]
    for seed,audit in audits.items():
        assert audit['status']=='verified_independent_pair_replay'
        for method,arms in audit['models'].items():
            rows.append(dict(seed=seed,method=method,full=arms['full']['macro_accuracy'],
                             no_interaction=arms['no_explicit_interaction']['macro_accuracy']))
    aggregate={}
    for method in methods:
        r=[v for v in rows if v['method']==method]
        assert len(r)==3
        aggregate[method]=dict(full_mean=sum(v['full'] for v in r)/3,
                               no_interaction_mean=sum(v['no_interaction'] for v in r)/3,
                               all_seeds_full_better=all(v['full']>v['no_interaction'] for v in r))
    result=dict(status='verified_three_seeds',rows=rows,aggregate=aggregate,
                source_sha256={str(p):sha(p) for p in provenance+[Path(__file__),out/'PROTOCOL.json']})
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# MLP交互项三种子100轮对照','',
           '| 方法 | seed | 完整特征 | 无显式交互项 |','|---|---:|---:|---:|']
    for row in rows:
        lines.append(f"| {row['method']} | {row['seed']} | {100*row['full']:.4f}% | {100*row['no_interaction']:.4f}% |")
    lines += ['', '| 方法 | 完整特征均值 | 无交互项均值 | 三个种子均改善 |','|---|---:|---:|---|']
    for method,r in aggregate.items():
        lines.append(f"| {method} | {100*r['full_mean']:.4f}% | {100*r['no_interaction_mean']:.4f}% | {r['all_seeds_full_better']} |")
    lines += ['', '固定种子17/29/43全部报告。两组均100轮、相同网络尺寸、归一化、数据及选模规则；完整组复用已核验基线，只补训无交互组。每种子均重算212验证配置的920有效对。', '',
              '这是复用开发集上的特征干预稳定性结果，不是独立盲测，也不意味着Transformer全面优于完整特征MLP。训练种子重复不增加独立查询数量。', '',
              '证据：[RESULT.json](RESULT.json)、[协议](PROTOCOL.json)。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    (out/'STATUS.json').write_text(json.dumps(dict(status='verified_complete'))+'\n')
    print(json.dumps(aggregate,indent=2))


if __name__=='__main__':main()
