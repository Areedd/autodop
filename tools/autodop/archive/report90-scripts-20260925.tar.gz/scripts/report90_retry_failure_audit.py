"""Corroborate every retained memory failure against FE audit identity and SQL."""
import hashlib
import json
import re
from pathlib import Path
from report90_execute import RUN


def main():
    out=RUN/'development17_retry'
    read=lambda p:json.loads(p.read_text())
    assert read(out/'STATUS.json')['status']=='complete'
    assert read(out/'RESULT.json')['status']=='verified'
    destination=out/'FAILURE_IDENTITY_AUDIT.json';assert not destination.exists()
    source=out/'scored/events.jsonl'
    events=[json.loads(line) for line in source.read_text().splitlines()]
    failed={}
    for e in events:
        for a in e['sql_attempts']:
            if a['status']!='failed':continue
            qid=a.get('failed_query_id_candidate');assert qid and qid not in failed
            assert re.fullmatch('[0-9a-f-]{36}',qid)
            failed[qid]={'id':e['id'],'mode':e['mode'],'phase':e['phase'],
                         'client':e['client'],'sequence':e['sequence'],'attempt_index':a['attempt_index']}
    assert not set(failed)&{e.get('query_id') for e in events}
    manifest=RUN/'DEVELOPMENT17_MANIFEST.json'
    queries={q['id']:q for q in read(manifest)['queries']}
    for query in queries.values():
        sql_path=Path(query['sql_file'])
        assert hashlib.sha256(sql_path.read_bytes()).hexdigest()==query['sql_sha256']
        query['sql']=sql_path.read_text()
    normalize=lambda sql:' '.join(sql.split()).rstrip(';').rstrip()
    audit=RUN.parents[3]/'output/fe/log/fe.audit.log'
    matched={}
    with audit.open() as stream:
        for line in stream:
            # Slow-query audit duplicates the query channel for the same execution.
            if ' [query] ' not in line:continue
            m=re.search(r'\|QueryId=([0-9a-f-]+)\|',line)
            if m is None or m[1] not in failed:continue
            qid=m[1];assert qid not in matched
            assert '|State=ERR|' in line and '|ErrorCode=MEM_LIMIT_EXCEEDED|' in line
            statement=line.split('|Stmt=',1)[1].split('|Digest=',1)[0]
            query=queries[failed[qid]['id']]
            assert '|Db='+query['database']+'|' in line
            assert normalize(statement)==normalize(query['sql']),qid
            matched[qid]=line.rstrip('\n')
    assert set(matched)==set(failed),{'missing':sorted(set(failed)-set(matched))}
    lines_path=out/'FAILED_ATTEMPT_AUDIT_LINES.json'
    lines_path.write_text(json.dumps(matched,indent=2)+'\n')
    result={'status':'verified','failed_physical_attempts':len(failed),
            'all_failure_ids_unique_and_sql_matched':True,'failures':failed,
            'scope':'Every memory-error attempt matched by query ID, database, whitespace-normalized SQL and FE error code. Does not establish DOP installation or causality for failed executions.',
            'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),source,manifest,lines_path,out/'RESULT.json']}}
    destination.write_text(json.dumps(result,indent=2)+'\n');print('Verified failed SQL identities:',len(failed))


if __name__=='__main__':main()
