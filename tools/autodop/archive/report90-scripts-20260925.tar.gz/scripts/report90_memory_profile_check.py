"""Validate development profile memory semantics and retain display rounding."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re


def memory(text, name):
    matches=re.findall(r'^\s*- '+name+r': ([0-9]+\.[0-9]{3}) (B|KB|MB|GB|TB)\s*$',text,re.MULTILINE)
    assert len(matches)==1,(name,matches)
    value,unit=matches[0];scale=1024**['B','KB','MB','GB','TB'].index(unit)
    # Preserve uncertainty introduced by the profile's %.3f formatter.
    return dict(display=f'{value} {unit}',approx_bytes=float(value)*scale,
                lower_bytes=max(0,math.floor((float(value)-.0005)*scale)),
                upper_bytes=math.ceil((float(value)+.0005)*scale))


def main(phase):
    root=Path(__file__).resolve().parents[3]
    out=root/f'tools/autodop/runs/report90_20260912/development17_memory_profiles_{phase}'
    read=lambda p:json.loads(p.read_text())
    assert read(out/'STATUS.json')['status']=='complete'
    proof=read(out/'scored/independent_verification.json');assert proof['all_expected_executions_verified']
    rows=[];sources=[out/'STATUS.json',out/'scored/independent_verification.json',out/'scored/events.jsonl',
                     Path(__file__).resolve(),root/'be/src/exec/pipeline/query_context.h',
                     root/'be/src/exec/pipeline/pipeline_driver_executor.cpp',
                     root/'fe/fe-core/src/main/java/com/starrocks/qe/scheduler/QueryRuntimeProfile.java',
                     root/'fe/fe-core/src/main/java/com/starrocks/common/util/RuntimeProfile.java',
                     root/'fe/fe-core/src/main/java/com/starrocks/common/util/DebugUtil.java']
    for e in map(json.loads,(out/'scored/events.jsonl').read_text().splitlines()):
        p=Path(e['profile_file']);assert hashlib.sha256(p.read_bytes()).hexdigest()==e['profile_sha256']
        text=p.read_text();assert re.search(r'Query ID: '+re.escape(e['query_id'])+r'\s*$',text,re.MULTILINE)
        peak=memory(text,'QueryPeakMemoryUsagePerNode');total=memory(text,'QuerySumMemoryUsage')
        assert peak['lower_bytes']>0 and total['upper_bytes']>=peak['lower_bytes']
        assert total['lower_bytes']<=3*peak['upper_bytes']
        rows.append(dict(id=e['id'],mode=e['mode'],phase=e['phase'],query_id=e['query_id'],
                         peak_per_node=peak,sum_per_node_peaks=total,
                         profile_file=str(p),profile_sha256=e['profile_sha256']))
        sources.append(p)
    assert len(rows)==proof['expected_slots']
    result=dict(status='verified',rows=rows,
                semantics='Peak per node is max across BE query trackers. Sum is sum of BE peaks, not simultaneous cluster peak. '
                          'It excludes unrelated process baseline memory. Profiles enabled; not latency benchmark. '
                          'A prior observed maximum is not a guaranteed future bound. All warmup and measured samples retained.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    destination=out/'MEMORY_PROFILE_CHECK.json';assert not destination.exists()
    destination.write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 开发查询内存 profile', '',result['semantics'],'',
           '| 查询 | 模式 | 阶段 | 每BE峰值最大值 | 各BE峰值之和 |','|---|---|---|---:|---:|']
    for r in rows:
        lines.append(f"| {r['id']} | {r['mode']} | {r['phase']} | {r['peak_per_node']['display']} | {r['sum_per_node_peaks']['display']} |")
    (out/'MEMORY_PROFILE_CHECK.md').write_text('\n'.join(lines)+'\n')
    print('Verified memory profiles:',len(rows))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['pilot','full'],required=True)
    main(p.parse_args().phase)
