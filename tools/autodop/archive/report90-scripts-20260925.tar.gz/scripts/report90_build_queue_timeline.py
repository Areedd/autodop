"""Build opt-in queue lifecycle diagnostics without editing production source."""
from pathlib import Path
import hashlib,json,subprocess,zipfile

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'runs/report90_20260912'

def main():
    out=RUN/'queue_timeline_validation';out.mkdir(exist_ok=True)
    source=ROOT.parents[1]/'fe/fe-core/src/main/java/com/starrocks/qe/scheduler/slot/BaseSlotTracker.java'
    original=source.read_text();s=original
    method='''
    // Experiment-only; opt-in at process startup, no SQL text or plan serialization.
    private static final boolean REPORT_TIMELINE = Boolean.getBoolean("autodop.report.queueTimeline");
    private long reportTimelineSequence = 0;

    private void reportTimeline(String event, LogicalSlot slot) {
        if (REPORT_TIMELINE) {
            LOG.info("AUTODOP_QUEUE_TIMELINE seq={} ns={} warehouse={} event={} query={} slots={} pending={} allocated={} running={}",
                    ++reportTimelineSequence, System.nanoTime(), warehouseId, event,
                    UUIDUtil.fromTUniqueid(slot.getSlotId()), slot.getNumPhysicalSlots(),
                    pendingSlots.size(), numAllocatedSlots, allocatedSlots.size());
        }
    }
'''
    anchor='    protected final ConcurrentMap<TUniqueId, LogicalSlot> slots'
    assert s.count(anchor)==1;s=s.replace(anchor,method+'\n'+anchor)
    for call,event in [('slot.onRequire();','REQUIRE'),('slot.onAllocate();','ALLOCATE'),('slot.onRelease();','RELEASE')]:
        assert s.count(call)==1;s=s.replace(call,call+'\n        reportTimeline("'+event+'", slot);')
    src=out/'src/com/starrocks/qe/scheduler/slot/BaseSlotTracker.java';src.parent.mkdir(parents=True,exist_ok=True);src.write_text(s)
    classes=out/'classes';classes.mkdir(exist_ok=True)
    prior=json.loads((RUN/'integer_slot_estimator_validation/COMPILE_COMMAND.json').read_text())
    cp=prior[prior.index('-cp')+1]
    # Use restored original API first; no previous experimental compiled classes.
    cp=':'.join(x for x in cp.split(':') if 'integer_slot_estimator_validation/classes' not in x)
    cp += ':/home/shaokun/.m2/repository/org/assertj/assertj-core/3.24.2/assertj-core-3.24.2.jar'
    cmd=['javac','--release','17','-proc:none','-cp',cp,'-d',str(classes),str(src)]
    (out/'COMPILE_COMMAND.json').write_text(json.dumps(cmd,indent=2)+'\n')
    p=subprocess.run(cmd,capture_output=True,text=True);(out/'COMPILE.log').write_text(p.stdout+p.stderr)
    if p.returncode:raise RuntimeError(p.stderr)
    base=RUN/'integer_slot_estimator_validation/integer-fe.jar'
    assert hashlib.sha256(base.read_bytes()).hexdigest()==json.loads((base.parent/'BINARY_AUDIT.json').read_text())['integer_sha256']
    name='com/starrocks/qe/scheduler/slot/BaseSlotTracker.class';dest=out/'timeline-fe.jar'
    with zipfile.ZipFile(base) as a,zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as b:
        for info in a.infolist():b.writestr(info,(classes/name).read_bytes() if info.filename==name else a.read(info.filename))
    with zipfile.ZipFile(base) as a,zipfile.ZipFile(dest) as b:
        assert a.namelist()==b.namelist()
        changed=[n for n in a.namelist() if a.read(n)!=b.read(n)]
        assert changed==[name],changed
    cmd=json.loads((RUN/'integer_slot_estimator_validation/JUNIT_COMMAND.json').read_text())
    i=cmd.index('-cp')+1;cmd[i]=str(dest)+':'+cp
    cmd[-1]='com.starrocks.qe.scheduler.slot.SlotTrackerTest'
    (out/'JUNIT_COMMAND.json').write_text(json.dumps(cmd,indent=2)+'\n')
    p=subprocess.run(cmd,capture_output=True,text=True);(out/'JUNIT.log').write_text(p.stdout+p.stderr)
    result=dict(status='verified_not_deployed' if p.returncode==0 else 'tests_failed',changed_classes=changed,
                test_exit_code=p.returncode,base_sha256=hashlib.sha256(base.read_bytes()).hexdigest(),
                timeline_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),
                source_sha256={str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in [Path(__file__),source,src]},
                scope='Opt-in process property autodop.report.queueTimeline, three post-transition events with per-tracker sequence and monotonic timestamp. Logger cost is part of diagnostic execution. No production source edit, deployment or SQL result.')
    (out/'BINARY_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
    if p.returncode:print((p.stdout+p.stderr)[-2500:]);raise SystemExit(p.returncode)

if __name__=='__main__':main()
