"""Attribute the completed validation gap without changing labels or selecting SQL."""
import collections
import json
from pathlib import Path
from autodop.training import file_sha256
from report90_coverage_choices import BASE, COM, read


def main():
    replay = read(BASE / 'retrained/SCORE_REPLAY.json')
    assert replay['status'] == 'verified'
    samples_path = BASE / 'merged_dataset/samples.jsonl'
    evidence_path = COM / 'verified_labels/sample_evidence.jsonl'
    samples = [json.loads(l) for l in samples_path.open()]
    groups = collections.defaultdict(list)
    for s in samples:
        if s['split'] == 'valid' and s['source_cohort'] == 'complex_new':
            groups[s['plan_key']].append(s)
    evidence = {(e['plan_key'], e['config_key']): e for l in evidence_path.open() if (e := json.loads(l))}
    rows = []
    for plan, candidates in sorted(groups.items()):
        assert len(candidates) == 8
        lookup = {s['config_key']: s for s in candidates}
        best = min(candidates, key=lambda s: s['latency_ms'])
        choices = {}
        for kind, quality in replay['after'].items():
            key = quality['cohorts']['complex_new']['choices'][plan]
            s = lookup[key]
            choices[kind] = {'config_key': key, 'dop_config': s['dop_config'], 'median_ms': s['latency_ms'],
                             'raw_latencies_ms': evidence[(plan, key)]['latencies_ms'],
                             'regret': s['latency_ms'] / best['latency_ms'] - 1}
        rows.append({'id': best['template_id'], 'plan_key': plan,
                     'best_candidate_ms': best['latency_ms'], 'best_candidate_dops': best['dop_config'],
                     'choices': choices})
    differing = [r for r in rows if r['choices']['transformer']['config_key'] != r['choices']['xgboost_pairs']['config_key']]
    artifact = {'status': 'complete', 'queries': len(rows), 'same_transformer_pair_xgb_choices': len(rows) - len(differing),
                'different_queries': [r['id'] for r in differing], 'rows': rows,
                'interpretation': 'Candidate-selection diagnosis using existing development validation labels. No SQL executed, labels altered, query removed, or gate relaxed. Eight queries and three timings per configuration are insufficient to establish robust statistical equivalence.',
                'source_sha256': {str(p): file_sha256(p) for p in [Path(__file__), BASE / 'retrained/SCORE_REPLAY.json', samples_path, evidence_path]}}
    out = BASE / 'retrained/CHOICE_DIAGNOSIS.json'
    assert not out.exists(), 'Preserve previous diagnosis'
    out.write_text(json.dumps(artifact, indent=2) + '\n')
    print(json.dumps({'queries': len(rows), 'same_choices': len(rows) - len(differing), 'different_queries': artifact['different_queries']}))


if __name__ == '__main__':
    main()
