"""Separate heterogeneous candidate opportunity from learned candidate selection."""
import collections
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'runs/report90_20260912/structure_coverage20'


def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    out = BASE / 'candidate_pool_audit'; assert not out.exists()
    comparison = read(BASE / 'cosine_decay/RESULT.json'); assert comparison['status'] == 'verified'
    extra = read(BASE / 'additional_baselines_full/RESULT.json'); assert extra['status'] == 'verified'
    samples_path = BASE / 'merged_dataset/samples.jsonl'; groups = collections.defaultdict(list)
    for line in samples_path.open():
        s = json.loads(line)
        if s['split'] == 'valid' and s['source_cohort'] == 'complex_new': groups[s['template_id']].append(s)
    assert len(groups) == 8 and all(len(v) == 8 for v in groups.values())
    models = comparison['after_cosine']['17'].copy()
    models.update({k: v['selected']['validation'] for k, v in extra['selected'].items()})
    rows = []; counts = {kind: {'best_candidate_selected': 0, 'heterogeneous_selected': 0} for kind in models}
    for qid, samples in sorted(groups.items()):
        configs = {}
        for s in samples:
            dops = {d for d, f in zip(s['dop_config'], s['fragments']) if not f.get('is_gather_root')}
            configs[s['config_key']] = {'latency_ms': s['latency_ms'], 'kind': 'uniform' if len(dops) == 1 else 'heterogeneous',
                                      'uniform_dop': next(iter(dops)) if len(dops) == 1 else None}
        uniform = [(k, v) for k, v in configs.items() if v['kind'] == 'uniform']
        heter = [(k, v) for k, v in configs.items() if v['kind'] == 'heterogeneous']
        assert len(uniform) == 5 and len(heter) == 3
        bu = min(uniform, key=lambda kv: (kv[1]['latency_ms'], kv[0]))
        bh = min(heter, key=lambda kv: (kv[1]['latency_ms'], kv[0]))
        best = min(configs.values(), key=lambda v: v['latency_ms'])['latency_ms']
        selections = {}
        for kind, quality in models.items():
            selected = quality['cohorts']['complex_new']['choices'][samples[0]['plan_key']]
            c = configs[selected]
            counts[kind]['best_candidate_selected'] += int(c['latency_ms'] == best)
            counts[kind]['heterogeneous_selected'] += int(c['kind'] == 'heterogeneous')
            selections[kind] = {'config_key': selected, **c, 'regret': c['latency_ms'] / best - 1}
        rows.append({'id': qid, 'best_uniform': {'config_key': bu[0], **bu[1]},
                     'best_heterogeneous': {'config_key': bh[0], **bh[1]},
                     'best_heterogeneous_gain_vs_best_uniform': 1 - bh[1]['latency_ms'] / bu[1]['latency_ms'],
                     'all_candidates': configs, 'model_selections': selections})
    wins = [r for r in rows if r['best_heterogeneous_gain_vs_best_uniform'] > 0]
    sources = [Path(__file__), samples_path, BASE / 'cosine_decay/RESULT.json', BASE / 'additional_baselines_full/RESULT.json']
    result = {'status': 'complete', 'queries': 8, 'heterogeneous_best_queries': len(wins), 'model_counts': counts, 'rows': rows,
              'scope': 'Existing development label medians, three formal measurements per candidate. Five uniform DOPs and three random heterogeneous candidates per query. Candidate minimum is hindsight within the measured pool, not an implementable oracle, exhaustive DOP optimum, or fresh execution.',
              'source_sha256': {str(p): sha(p) for p in sources}}
    out.mkdir(); (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    lines = ['# 复杂开发查询的候选收益与模型选择', '', result['scope'], '',
             '| 查询 | 最佳统一DOP | 最佳统一 ms | 最佳异构 ms | 异构相对统一降低 |', '|---|---:|---:|---:|---:|']
    for r in rows:
        lines.append(f"| {r['id']} | {r['best_uniform']['uniform_dop']} | {r['best_uniform']['latency_ms']:.0f} | {r['best_heterogeneous']['latency_ms']:.0f} | {100*r['best_heterogeneous_gain_vs_best_uniform']:.2f}% |")
    lines += ['', '| 模型 | 选中已测候选最优配置 | 选择异构配置 |', '|---|---:|---:|']
    for kind, c in counts.items(): lines.append(f"| {kind} | {c['best_candidate_selected']}/8 | {c['heterogeneous_selected']}/8 |")
    lines += ['', 'Transformer采用预先参考种子17的下降学习率模型；三个下降学习率种子在这8条上的配置选择完全相同。XGBoost和MLP为对应同数据控制。未挑选查询、修改标签或执行SQL。', '',
              '这8条中多数存在异构候选收益，但多个模型已在相同查询上选中同一最优候选，模型之间可区分的选择差异集中。不能从该小候选集推断模型在完整搜索空间中等价，也不能将候选集事后最小值视为可部署策略。']
    (out / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({'heterogeneous_best_queries': len(wins), 'model_counts': counts}))


if __name__ == '__main__': main()
