"""Prepare all90 queries with32/64 search budgets; no execution labels accessed."""
import json
import os
from pathlib import Path
import random
import torch
from autodop import graph
from autodop.model import load_cost_model
from collect_paper_evaluations import VectorEngine
from report90_prepared_graph import PreparedGraph
from report90_neighborhood_prepare import RUN,sha


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1)
    out=RUN/'search_budget_report90';out.mkdir(exist_ok=False)
    old=RUN/'search_refinement_report90'
    source_protocol=json.loads((old/'PROTOCOL.json').read_text())
    original=json.loads((old/'vectors.json').read_text())
    records=json.loads((old/'CHOICES.json').read_text())
    choices={r['id']:r for r in records if r['mode']=='refined_full' and r['seed']==17}
    manifest=json.loads((old/'manifest.json').read_text())
    queries=[q['id'] for q in manifest['queries']];assert len(queries)==90 and set(queries)==set(choices)
    model_path=Path(source_protocol['model']);model,ck=load_cost_model(model_path);model.eval();meta=ck['metadata']
    code=RUN/'graph_construction_pilot/competition_staged.py';namespace=dict(vars(graph));exec(compile(code.read_text(),str(code),'exec'),namespace)
    modes=['refined_budget32','refined_budget64','random_budget32','random_budget64']
    protocol=dict(status='frozen_before_preparation',queries=queries,modes=modes,seed=17,expected_executions=720,
                  rationale='Small4query pilot completed first. Evaluate32budget tradeoff on all90; retain both64budget controls and same32budget random control. No SQL filtering or best-seed selection.',
                  scope='Previously selected favorable90; reused report workload, not blind test. Fixed-vector replay excludes search cost. Warmup1 and measured1 per mode/query.',
                  source_sha256={str(p):sha(p) for p in [Path(__file__),old/'PROTOCOL.json',old/'CHOICES.json',old/'vectors.json',old/'manifest.json',model_path,code,Path(graph.__file__),Path(__file__).with_name('report90_prepared_graph.py'),RUN/'search_budget_sql/collection/RESULT.json']})
    assert json.loads((RUN/'search_budget_sql/collection/RESULT.json').read_text())['status']=='verified'
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    vectors={mode:{} for mode in modes};audits=[]
    with torch.inference_mode():
        for query in queries:
            request=original['refined_full'][query]['request'];sample=graph.sample_from_request(request)
            sample['dop_config']=[1 if f.get('is_gather_root') else 4 for f in sample['fragments']]
            prepared=PreparedGraph(sample,meta,namespace['_competition'])
            trace=choices[query]['details']['records'];assert len(trace)==64
            low=max(trace[:32],key=lambda r:r['score']);high=max(trace,key=lambda r:r['score'])
            assert high['config']==choices[query]['config']
            for r in [low,high]:assert float(model(prepared.build(r['config'])))==r['score']
            domains=[graph.supported_dops(f,meta['dop_classes']) for f in sample['fragments']]
            rng=random.Random(17);configs=[[rng.choice(d) for d in domains] for _ in range(64)]
            scores=[float(model(prepared.build(config))) for config in configs]
            best32=max(range(32),key=lambda i:scores[i]);best64=max(range(64),key=lambda i:scores[i])
            old_random=original['original_independent_random'][query]['fragment_dops']
            assert configs[best64]==[old_random[f] for f in sample['fragment_ids']]
            proposals=[low['config'],high['config'],configs[best32],configs[best64]]
            for mode,config in zip(modes,proposals):
                vectors[mode][query]=dict(request=request,fragment_dops=dict(zip(sample['fragment_ids'],config)))
            audits.append(dict(query=query,refined32_same_as64=low['config']==high['config'],random32_same_as64=best32==best64,refined_scores_replayed_exact=True,random64_choice_reproduced=True))
            if len(audits)%30==0:print(len(audits),flush=True)
    for mode,entries in vectors.items():
        engine=VectorEngine(entries)
        for record in entries.values():engine.decide(record['request'])
    for p,digest in protocol['source_sha256'].items():assert sha(Path(p))==digest
    for name,value in [('vectors.json',vectors),('manifest.json',manifest),('CHOICE_AUDIT.json',audits)]:
        (out/name).write_text(json.dumps(value,indent=2)+'\n')
    (out/'PREPARATION.json').write_text(json.dumps(dict(status='verified',queries=90,modes=4,
         refined32_same_as64=sum(r['refined32_same_as64'] for r in audits),random32_same_as64=sum(r['random32_same_as64'] for r in audits),
         source_sha256={str(p):sha(p) for p in [out/'PROTOCOL.json',out/'vectors.json',out/'manifest.json',out/'CHOICE_AUDIT.json']}),indent=2)+'\n')
    print('Prepared all90 queries and4modes; no new SQL executed.')


if __name__=='__main__':main()
