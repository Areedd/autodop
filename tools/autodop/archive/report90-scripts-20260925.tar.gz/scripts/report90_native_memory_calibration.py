"""Nested query-excluded calibration, never using the outer held query target."""
import hashlib
import json
import math
import os
from pathlib import Path
import numpy as np
from sklearn.preprocessing import StandardScaler


def main():
    root=Path(__file__).resolve().parents[1]/'runs/report90_20260912'
    parent=root/'native_memory_prediction_loo17';out=root/'native_memory_nested_calibration17';out.mkdir(exist_ok=False)
    os.sched_setaffinity(0,{35})
    dataset_path=parent/'DATASET.json';d=json.loads(dataset_path.read_text())
    X=np.array(d['features']);y=np.array(d['target_bytes']);ids=d['ids'];assert len(ids)==17
    save=lambda n,v:(out/n).write_text(json.dumps(v,indent=2)+'\n')
    save('PROTOCOL.json',dict(method='For each outer held query, inner leave-one-query-out on the remaining16 '
          'estimates max observed/predicted ratio; multiplier=max(1.25, that ratio). '
          'Predict outer query with max target among3 standardized-feature neighbors of the16. '
          'No clipping or tuning on outer targets.',
          scope='Post-diagnostic development calibration, not independent test or guaranteed coverage.',
          original_screen='No under-reservation and median reservation/peak<=2, unchanged.',
          dataset_sha256=hashlib.sha256(dataset_path.read_bytes()).hexdigest()))
    def predict(test,train):
        assert test not in train and len(train)>=3
        scaler=StandardScaler().fit(X[train])
        dist=np.linalg.norm(scaler.transform(X[train])-scaler.transform(X[[test]])[0],axis=1)
        selected=np.array(train)[np.argsort(dist,kind='stable')[:3]]
        return float(max(y[selected])),[ids[i] for i in selected]
    rows=[]
    for held in range(17):
        train=[i for i in range(17) if i!=held];inner=[]
        for test in train:
            inner_train=[i for i in train if i!=test];assert held not in inner_train
            pred,neighbors=predict(test,inner_train)
            inner.append(dict(id=ids[test],train_ids=[ids[i] for i in inner_train],neighbors=neighbors,
                              observed_over_predicted=float(y[test]/pred)))
        factor=max(1.25,max(r['observed_over_predicted'] for r in inner))
        pred,neighbors=predict(held,train);reservation=max(64*1024**2,math.ceil(factor*pred))
        rows.append(dict(id=ids[held],outer_train_ids=[ids[i] for i in train],inner=inner,
                         multiplier=factor,prediction_bytes=pred,neighbors=neighbors,
                         reservation_bytes=reservation,observed_peak_bytes=float(y[held]),
                         reservation_ratio=float(reservation/y[held]),under_reserved=bool(reservation<y[held])))
    ratios=[r['reservation_ratio'] for r in rows];under=sum(r['under_reserved'] for r in rows)
    summary=dict(under_reserved_queries=under,median_reservation_ratio=float(np.median(ratios)),
                 max_reservation_ratio=max(ratios),min_multiplier=min(r['multiplier'] for r in rows),
                 max_multiplier=max(r['multiplier'] for r in rows),
                 exploratory_screen_passed=bool(under==0 and np.median(ratios)<=2))
    result=dict(status='verified',summary=summary,rows=rows,
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [dataset_path,Path(__file__).resolve()]})
    save('RESULT.json',result)
    lines=['# 原生计划内存预测的嵌套校准','',
           '每个外层留出查询完全不参与特征缩放、近邻选择、标签拟合或倍率校准。内层16次留一仅使用外层训练查询，取最大观测/预测比与1.25的较大值。', '',
           f"预算低于观测峰值：{under}/17；中位预算比：{summary['median_reservation_ratio']:.2f}；最大预算比：{summary['max_reservation_ratio']:.2f}。",
           f"各外层训练折推导的倍率范围：{summary['min_multiplier']:.3f}–{summary['max_multiplier']:.3f}。",
           f"原开发筛查通过：{summary['exploratory_screen_passed']}。", '',
           '此方法在看到之前诊断后提出，属于开发分析；即使通过也不代表未来覆盖保证。未使用90条报告查询，未部署或执行新的SQL。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
