"""Decompose the completed duration scheduling pilot; no new SQL or model fitting."""
from pathlib import Path
import hashlib
import json
from statistics import mean
from report90_queue_timeline_parse import validate

RUN = Path(__file__).resolve().parents[1] / 'runs/report90_20260912'
BASE = RUN / 'duration_concurrent_development/pilot'


def main():
    audit_path = BASE / 'AUDIT.json'
    audit = json.loads(audit_path.read_text())
    for name, digest in audit['source_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest
    assert audit['status'] == 'verified_execution_and_binding'
    events = validate((BASE / 'fe.log.captured').read_text().splitlines(), capacity=96)
    by_query = {}
    for event in events:
        by_query.setdefault(event['query_id'], {})[event['event']] = event
    calls = {c['query_id']: c for c in json.loads((BASE / 'CAPTURE.json').read_text())['calls']}
    rows = []
    for row in audit['rows']:
        timeline = by_query[row['query_id']]
        start, end = timeline['ALLOCATE']['ns'], timeline['RELEASE']['ns']
        waiting = (start - timeline['REQUIRE']['ns']) / 1e6
        held = (end - start) / 1e6
        assert abs(waiting-row['queue_wait_ms']) < 1e-6
        rows.append(dict(row, allocated_ns=start, released_ns=end, held_ms=held,
                         client_minus_wait_and_held_ms=row['client_latency_ms']-waiting-held,
                         predicted_native_ms=calls[row['query_id']]['duration_ms']))
    summaries = []
    for batch in audit['summaries']:
        current = [r for r in rows if r['batch'] == batch['batch']]
        ids = {r['query_id'] for r in current}
        stream = [event for event in events if event['query_id'] in ids]
        pending, running = set(), set()
        last = stream[0]['ns']
        running_integral = pending_saturated = pending_idle_capacity = 0
        for event in stream:
            elapsed = event['ns']-last
            running_integral += elapsed*len(running)
            if pending:
                if len(running) == 4: pending_saturated += elapsed
                else: pending_idle_capacity += elapsed
            last = event['ns']
            if event['event'] == 'REQUIRE': pending.add(event['query_id'])
            elif event['event'] == 'ALLOCATE':
                pending.remove(event['query_id']); running.add(event['query_id'])
            else: running.remove(event['query_id'])
        assert not pending and not running
        total_held = sum(r['held_ms'] for r in current)
        assert abs(running_integral/1e6-total_held) < 1e-5
        groups = {}
        for query in sorted({r['id'] for r in current}):
            group = [r for r in current if r['id'] == query]
            groups[query] = {name: mean(r[name] for r in group) for name in
                             ['client_latency_ms','queue_wait_ms','held_ms','client_minus_wait_and_held_ms','predicted_native_ms']}
        summaries.append(dict(batch=batch['batch'], phase=batch['phase'], order=batch['order'], mode=batch['mode'],
                              groups=groups, mean_held_ms=total_held/len(current),
                              mean_residual_ms=mean(r['client_minus_wait_and_held_ms'] for r in current),
                              reservation_occupancy=running_integral/(4*(stream[-1]['ns']-stream[0]['ns'])),
                              pending_at_capacity_ms=pending_saturated/1e6,
                              pending_with_spare_capacity_ms=pending_idle_capacity/1e6,
                              allocation_order=[r['id'] for r in sorted(current,key=lambda r:r['allocated_ns'])],
                              last_release_query=max(current,key=lambda r:r['released_ns'])['id']))
    differences = {}
    for order in ['short_first','long_first']:
        pair = {s['mode']:s for s in summaries if s['phase']=='measured' and s['order']==order}
        differences[order] = {query: {metric: pair['predicted_duration']['groups'][query][metric]-values[metric]
                                      for metric in ['client_latency_ms','queue_wait_ms','held_ms','client_minus_wait_and_held_ms']}
                              for query, values in pair['fifo']['groups'].items()}
    out = BASE / 'overlap_analysis'
    out.mkdir(exist_ok=False)
    result = dict(status='verified_timeline_decomposition', executions=len(rows), summaries=summaries,
                  formal_predicted_minus_fifo_ms=differences,
                  scope='Slot holding includes FE/BE lifecycle overhead, not pure BE execution. Reservation occupancy is not CPU or memory utilization. Residual is an accounting difference of intervals, not a separately timed optimizer stage. Observational decomposition cannot isolate contention causality.',
                  source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
                                 [Path(__file__),audit_path,BASE/'fe.log.captured',BASE/'CAPTURE.json']})
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 时长排序并发小测：排队与槽位持有时间分解','',result['scope'],'',
           '| 到达顺序 | 查询 | 请求变化 ms | 排队变化 ms | 槽位持有变化 ms | 剩余区间变化 ms |',
           '|---|---|---:|---:|---:|---:|']
    for order, groups in differences.items():
        for query, values in groups.items():
            lines.append('| '+order+' | '+query+' | '+' | '.join(f'{v:.2f}' for v in values.values())+' |')
    lines += ['', '变化均为预测排序减 FIFO，正数表示增加。每个单元是同一批次中该查询四次执行的平均值。全部 128 次执行纳入核验，表中仅展示正式批次差值。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines))


if __name__ == '__main__': main()
