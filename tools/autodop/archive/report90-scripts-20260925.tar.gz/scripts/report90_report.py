"""Render a reproducible report and scientific figures from measured stage summaries."""
import json
import datetime
import os
import numpy as np
os.environ.setdefault('MPLCONFIGDIR', '/tmp/autodop-report-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def render(run, data):
    number=lambda x:'NA' if x is None else f'{x:.2f}'
    complete = bool(data['serial']) and len(data['concurrent']) == 15 and data['costs'].get('fe_controller_stages',{}).get('status')=='complete'
    lines = ['# AutoDOP 固定 90 条异构查询实验报告', '',
             f"生成时间：{datetime.datetime.now().astimezone().isoformat()}。状态：{'原定固定查询集实验已完成；补充验证状态分别列示，尚不构成合同验收完成声明' if complete else '阶段性报告，尚有实验运行中'}。", '',
             '## 实验范围与方法', '',
             '本实验使用历史 200 条构造查询中选出的 90 条优势查询；筛选标准为历史平均耗时相对逐查询最佳候选统一 DOP 有正收益。名单在本轮执行前冻结，没有依据本轮结果再次筛选。因此，结果说明该固定子集上的性能，不代表任意异构查询上的无偏泛化性能。', '',
             '运行于同一物理服务器上的三个 BE 实例，每个实例绑定 8 个 CPU，容器内存上限 16 GiB；SHOW BACKENDS 上报的 BE MemLimit 为 11.520GB。实验控制与模型计算使用独立 CPU 集合 27–34。查询来自 TPC-DS SF100 数据上的结构化构造 SQL，不是标准 TPC-DS 查询集，也不是合同所定义的标准 TPC-H throughput 测试。', '',
             '服务器为共享环境，观测到其他数据库进程；CPU 绑定不等于排他独占。阶段开始前检查没有其他 FE 前台查询，并要求三个 BE CPU 组的采样忙碌比例均低于 45%。这一门槛不能证明完全无后台干扰，因此随机化对照和轮次波动需要一起报告；不能将环境表述为独占、零干扰服务器。', '',
             '串行比较使用全部 90 条查询，每个配置 1 轮预热、3 轮正式测量；配置顺序随机化。平均值及 p50/p90/p99 以每条查询的三次平均耗时为样本。逐查询最佳统一 DOP 是本轮 DOP 1/2/4/8/16 五个候选中查询平均耗时的最小值。', '',
             'native 的会话配置为关闭 AutoDOP、pipeline_dop=0；统一配置直接设置相应 pipeline_dop，并关闭 AutoDOP。全部配置统一关闭 runtime adaptive DOP、query cache 和 spill。这里的“原生”指上述受控会话配置，不应表述为未经调整的产品默认设置。', '',
             '实验期间 AutoDOP 调用超时设置为 1000 ms，SQL 超时为 180 秒；各阶段结束后恢复环境原来的 AutoDOP 50 ms 设置。因此，并发结果描述 1000 ms 调用超时下的系统，不能未经测试就等同于原 50 ms 部署配置。每阶段 frontend_settings.json 记录设置与恢复状态。', '',
             '并发实验为闭环客户端，档位为 1/2/4/8/16。每档每轮共 90 个任务，将完整查询集确定性分配给客户端，1 轮预热、2 轮正式测量。吞吐量按已验证完成数除以工作负载执行区间统计；该区间不包含轮后证据抓取。这是固定批次吞吐，包含批次末尾客户端陆续结束的影响，不等价于长时间稳态吞吐。', '',
             '模型对比整体保留图 Transformer 与竞争边，不单独设置竞争边消融。比较 Transformer 排序、同结构直接回归、MLP 排序、XGBoost 回归和 XGBoost 排序。全部使用相同历史训练/验证划分（78/14 个计划、1077/148 个样本），归一化仅拟合训练集。训练查询与 90 条测试 SQL 的 SHA 无交集，但仍共享数据和构造方法，不能视为严格跨分布测试。', '',
             'MLP 和 XGBoost 使用固定长度表示：fragment 数值特征、类别独热编码、DOP 及交互特征、依赖/竞争边的度统计，再按均值/和/最大值/标准差汇总，共 1040 维。它们保留基础信息及图统计，损失完整拓扑；这是模型和表示方式的整体比较，不是严格只改变单一网络层的对照。', '',
             '每种模型每个种子使用两组超参数，三个种子为 17/29/43，仅按验证集候选选择损失选模。神经网络固定训练 30 轮。主种子 17 用于实际 SQL 执行，其余种子保留离线结果，不能将三个种子表述为三组独立在线实测。', '',
             '五种成本模型在同一预先生成的候选池中选配置，候选包括统一 DOP、当前策略和冻结教师的搜索结果。该设计控制候选池，但可能偏向教师提出的候选；它只比较池内选择能力。搜索消融包含完整 MCTS、去等价约束、去注意力排序及随机搜索，均为 64 次候选评分。', '',
             '当前在线策略保持原部署权重。policy_before 对照为最后一次置信度强化之前的模型，因此这项对照只分析该训练阶段，不等价于删除整个策略蒸馏过程。', '']
    if data.get('serial_repair'):
        lines += ['## 计划变化与补测', '',
                  '首次 6480 次执行中有 77 次配置回放核验失败，涉及 3 条 SQL 的执行计划结构变化。原始失败证据保留。按照相同冻结算法为新计划生成替代配置，仍严格按规范化 fragment 图及特征匹配，未放宽验证。对这 3 条查询的全部 18 种配置重测，并整体替换其统计数据；其他 87 条使用原始结果。', '',
                  '补测查询：'+', '.join(data['serial_repair']['replaced_queries'])+'。补测与原始实验存在时间间隔；各查询的对照配置在同一测量阶段比较。', '']
    structure=run/'WORKLOAD_STRUCTURE.json'
    if structure.exists():
        w=json.loads(structure.read_text())
        lines += ['## 查询结构', '',
                  f"该集合含 2 分支查询 {w['branch_counts']['2']} 条、3 分支 {w['branch_counts']['3']} 条、4 分支 {w['branch_counts']['4']} 条。带分支家族标记的有序树签名为 {w['unique_ordered_structure_with_leaf_family']} 种，忽略叶子家族后为 {w['unique_ordered_structure_without_leaf_family']} 种有序结构。该计数不合并连接交换律/结合律下的等价树，不能视为同样多的独立计算模式。", '',
                  '根运算计数：'+json.dumps(w['root_operations'],ensure_ascii=False)+'。分支家族出现次数见 WORKLOAD_STRUCTURE.json；同一查询可计入多个家族。', '']
    serial = data['serial']
    if serial:
        lines += ['## 单查询性能', '', '| 基线 | 平均延迟降低 | p50 降低 | p90 降低 | p99 降低 | 更快查询数 |', '|---|---:|---:|---:|---:|---:|']
        for base in ('native','uniform4','best_uniform'):
            v=serial['comparisons'][base]['policy_static']
            lines.append(f"| {base} | {v['ratio_of_mean_gain_pct']:.2f}% | {v['p50_gain_pct']:.2f}% | {v['p90_gain_pct']:.2f}% | {v['p99_gain_pct']:.2f}% | {v['faster_queries']}/90 |")
        fig,axes=plt.subplots(2,2,figsize=(10,7))
        primary=['native','uniform4','best_uniform','policy_static']
        labels=['Native','Uniform 4','Best uniform','AutoDOP']
        for ax,stat in zip(axes.flat,['mean','p50','p90','p99']):
            values=[serial['query_mean_latency_ms'][m][stat] for m in primary]
            bars=ax.bar(labels,values,color=['#999999','#7999bb','#a8bba2','#346888'])
            ax.bar_label(bars,fmt='%.0f',padding=3,fontsize=9)
            ax.set_title(stat);ax.set_ylabel('Latency (ms)');ax.set_ylim(0,max(values)*1.15);ax.grid(axis='y',alpha=.2)
        fig.tight_layout()
        for ext in ('png','pdf'):fig.savefig(run/f'PRIMARY_LATENCY.{ext}',dpi=160,bbox_inches='tight')
        plt.close(fig)
        lines += ['', '![单查询延迟](PRIMARY_LATENCY.png)', '']
        lines += ['| 正式轮次编号 | 相对原生降低 | 相对固定 4 降低 | 相对最佳统一配置降低 |', '|---:|---:|---:|---:|']
        for rep,v in serial.get('round_primary_gain_pct',{}).items():
            lines.append(f"| {int(rep)+1} | {v['native']:.2f}% | {v['uniform4']:.2f}% | {v['best_uniform']:.2f}% |")
        lines += ['', '最佳统一配置先按三次平均值为每条查询确定，再分别统计各轮结果，没有为每一轮重新选择最优配置。补测三条查询使用对应补测轮次；该表描述本轮实验内部波动，不是三个独立日期的重复实验。', '']
        lines += ['## 结构分组结果', '', '| 分组 | 查询数 | 在线策略平均 ms | 最佳统一配置平均 ms | 平均延迟降低 | 更快查询数 |', '|---|---:|---:|---:|---:|---:|']
        for label,v in serial.get('structure_subgroups',{}).items():
            lines.append(f"| {label} | {v['queries']} | {v['policy_mean_ms']:.2f} | {v['best_uniform_mean_ms']:.2f} | {v['ratio_of_mean_gain_pct']:.2f}% | {v['faster_queries']} |")
        lines += ['', '分组使用冻结清单的分支数和根运算标签，不依据本轮收益筛选。两种分类分别覆盖全部 90 条查询，不能将两组计数相加。此表是同一筛选子集的描述性拆分，不是额外独立验证。', '']
        lines += ['', '## 模型与搜索消融', '', '| 配置 | 平均延迟 ms | 相对原生降低 |', '|---|---:|---:|']
        selected=['cost_transformer_rank','cost_transformer_regression','cost_mlp_rank','cost_xgb_regression','cost_xgb_rank','teacher_mcts','search_no_equivalence','search_no_attention','search_random','policy_vector','policy_static','policy_before']
        for mode in selected:
            lines.append(f"| {mode} | {serial['query_mean_latency_ms'][mode]['mean']:.2f} | {serial['comparisons']['native'][mode]['ratio_of_mean_gain_pct']:.2f}% |")
        model_winner=min(selected[:5],key=lambda m:serial['query_mean_latency_ms'][m]['mean'])
        search_winner=min(selected[5:9],key=lambda m:serial['query_mean_latency_ms'][m]['mean'])
        lines += ['', f'本轮共享候选池中平均执行延迟最低的模型为 {model_winner}；四种搜索配置中最低的为 {search_winner}。这两项结论仅按本轮固定协议结果描述，没有据此重选模型或重训。', '',
                  '如果完整 Transformer 或完整 MCTS 未胜出，应报告为组件收益未获支持，不能用整体相对原生的收益替代组件有效性证据。部署教师与现有策略的对比也不是“重训同一教师后蒸馏”的严格训练因果消融。', '']
        diag=run/'SEARCH_DIAGNOSTICS.json'
        if diag.exists():
            d=json.loads(diag.read_text());v=d['comparisons']['search_random']
            lines += [f"搜索诊断使用未发生计划变化的 {d['queries']} 条查询（主结果仍包含全部 90 条）：完整 MCTS 在 {v['higher_full_predicted_score']} 条上得到高于随机搜索的教师评分，但其中 {v['higher_score_but_at_least_3pct_slower_full']} 条的实际延迟反而至少高 3%。这直接说明部分候选的教师评分与实测排序不一致；仅提升预测评分不能保证更快。该诊断并不能独立排除搜索预算或候选探索方式的影响。", '']
        lines += ['', '回放配置的查询耗时不包含离线搜索或候选选择时间，在线 policy_static 包含实际服务调用。二者比较配置质量时应同时查看下方开销，不应将回放耗时直接等同于在线教师总延迟。', '',
                  'policy_vector 回放原始预测 DOP，并强制通过置信度门槛；它与 policy_static 的差异同时包含在线推理开销和置信度回退行为，不能单独归因于置信度门槛。', '',
                  'SUMMARY.json 提供逐查询均值、胜出查询数和成对查询 bootstrap 区间。区间针对“逐查询相对收益的平均值”，与表中的“总体均值之比”是不同统计量。90 条查询可能共享结构，查询级区间不充分反映模板相关性，不能单独据此作强显著性结论。', '']
        fig, axes = plt.subplots(1,2,figsize=(13,5))
        for ax,modes,title in [(axes[0],selected[:5],'Cost-model configuration selection'),(axes[1],selected[5:],'Search and policy comparisons')]:
            vals=[serial['query_mean_latency_ms'][m]['mean'] for m in modes]
            ax.barh(modes,vals,color='#4878a8');ax.invert_yaxis();ax.set_xlabel('Mean query latency (ms)');ax.set_title(title);ax.grid(axis='x',alpha=.2)
        fig.tight_layout()
        for ext in ('png','pdf'):fig.savefig(run/f'ABLATIONS.{ext}',dpi=160,bbox_inches='tight')
        plt.close(fig)
        lines += ['![消融结果](ABLATIONS.png)', '']
    if data['concurrent']:
        lines += ['## 并发性能', '', '| 客户端 | 配置 | 成功吞吐 q/s | 完成率 | 失败数 | 成功查询平均 ms | 成功查询 p99 ms |', '|---:|---|---:|---:|---:|---:|---:|']
        for v in sorted(data['concurrent'].values(),key=lambda v:(v['clients'],v['mode'])):
            lines.append(f"| {v['clients']} | {v['mode']} | {v['verified_queries_per_second']:.3f} | {100*v.get('completion_rate',1):.1f}% | {v.get('failed_or_missing',0)} | {number(v['latency_ms']['mean'])} | {number(v['latency_ms']['p99'])} |")
        lines += ['', '延迟分位数只描述成功查询，失败会改变成功样本构成，不能脱离完成率比较尾延迟。成功吞吐的时间分母包含失败尝试耗时；所有内存超限失败保留，不通过重复直到成功来抹去过载现象。', '']
        fig,(ax,completion_ax)=plt.subplots(1,2,figsize=(11,4))
        for mode in ('native','policy_static','policy_load'):
            vs=sorted([v for v in data['concurrent'].values() if v['mode']==mode],key=lambda v:v['clients'])
            ax.plot([v['clients'] for v in vs],[v['verified_queries_per_second'] for v in vs],'-o',label=mode)
            completion_ax.plot([v['clients'] for v in vs],[100*v['completion_rate'] for v in vs],'-o',label=mode)
        ax.set(xlabel='Concurrent clients',ylabel='Verified queries / second');ax.set_ylim(0,max(v['verified_queries_per_second'] for v in data['concurrent'].values())*1.12);ax.set_xticks([1,2,4,8,16]);ax.grid(alpha=.2);ax.legend()
        completion_ax.set(xlabel='Concurrent clients',ylabel='Successful completion (%)',ylim=(0,105));completion_ax.set_xticks([1,2,4,8,16]);completion_ax.grid(alpha=.2);fig.tight_layout()
        for ext in ('png','pdf'):fig.savefig(run/f'CONCURRENCY.{ext}',dpi=160)
        plt.close(fig)
        lines += ['', '![并发吞吐](CONCURRENCY.png)', '', '### 负载修正是否触发', '', '| 阶段 | 配置 | 决策数 | 修正查询数 | 观测最大 CPU 比例 | 观测最大内存比例 |', '|---|---|---:|---:|---:|---:|']
        for stage,ds in data.get('load_diagnostics',{}).items():
            if not stage.startswith('concurrent'):continue
            for label,d in ds.items():
                if not label.startswith('policy_load'):continue
                lines.append(f"| {stage} | {label} | {d['decisions']} | {d['corrected_queries']} | {d['reported_cpu']['max']:.4f} | {d['reported_memory']['max']:.4f} |")
        lines += ['', '若未发生修正，则这一档位不能证明负载修正模块有收益。报告同时保留 FE 输入负载、修正次数和吞吐结果，不以未触发的实验支持机制有效性。', '']
        if 'policy_load_c16' in data['concurrent']:
            load=data['concurrent']['policy_load_c16'];static=data['concurrent']['policy_static_c16']
            lines += [f"16 客户端下，负载修正策略正式完成 {load['verified']}/180，静态策略完成 {static['verified']}/180；对应成功吞吐为 {load['verified_queries_per_second']:.3f} 与 {static['verified_queries_per_second']:.3f} q/s。完成率小幅变化没有同时带来更高吞吐，两个轮次也不足以支持稳定收益结论。按分支数统计的失败明细见 FAILURE_BREAKDOWN.json；这是描述性分组，不是分支数量的独立因果实验。", '']
        lines += ['资源口径核对发现：容器内可见 192 个在线 CPU，但每个 BE 仅分配 8 个 CPU。本地 BE 源码的进程 CPU 统计除以硬件并发数；若部署二进制使用相同实现，满配额负载也只报告约 8/192=0.0417，低于 0.4 修正阈值。二进制与源码一致性未独立验证，故此处作为有源码和配置依据的解释；实际触发情况以日志为准，不能把报告 CPU 比例直接等同于 cpuset 使用率。详见 CPU_TELEMETRY_AUDIT.json。', '']
        lines += ['### 并发轮次波动', '', '| 客户端 | 配置 | 正式轮次 | 已验证吞吐 q/s |', '|---:|---|---:|---:|']
        for v in sorted(data['concurrent'].values(),key=lambda v:(v['clients'],v['mode'])):
            for rr in v['rounds']:
                lines.append(f"| {v['clients']} | {v['mode']} | {rr['round']+1} | {rr['verified_queries_per_second']:.3f} |")
    pilot=run/'concurrent_pilot_attempt1/scored/collection.json'
    if pilot.exists():
        pc=json.loads(pilot.read_text())
        if pc['status'].startswith('finished'):
            total=sum(r['executed'] for r in pc['rounds']);failed=sum(r['failed_or_missing'] for r in pc['rounds'])
            lines += ['', '## 高并发流程小测的内存失败', '',
                      f'额外的小测只使用固定的 2 条查询，集中重复执行，含预热共 {total} 次，其中 {failed} 次内存超限失败。它与完整 90 条查询的批次具有不同负载构成，不混入正式吞吐曲线。下表仅列小测正式轮次；全部原始记录保留。', '',
                      '| 客户端 | 配置 | 成功数 | 尝试数 |', '|---:|---|---:|---:|']
            for rr in pc['rounds']:
                if rr['phase']!='warmup':lines.append(f"| {rr['clients']} | {rr['mode']} | {rr['verified']} | {rr['expected']} |")
            requests=corrected=0
            for line in (pilot.parent/'decisions.jsonl').open():
                d=json.loads(line)
                if d['mode']=='policy_load':
                    requests+=1;corrected+=any('load_corrected' in v.get('reason','') for v in d.get('response',{}).get('decisions',[]))
            lines += ['',f'该集中负载小测的负载策略共处理 {requests} 次请求（含预热），其中 {corrected} 次产生了 DOP 修正响应。产生响应不等于查询成功；单轮小测也不能支持稳定收益的结论。']
            lines += ['', '这些已发生的失败说明，即使完整多样化批次的某档全部成功，也不能据此宣称对所有集中负载均能避免内存超限。', '']
    lines += ['## 在线应用与回退（成功查询）', '', '| 阶段 | 配置 | 成功执行数 | 应用数 | 回退数 |', '|---|---|---:|---:|---:|']
    for stage,entries in data.get('application_audit',{}).items():
        for mode,a in entries.items():
            if not mode.startswith(('policy_static','policy_load','policy_before')):continue
            lines.append(f"| {stage} | {mode} | {a['executions']} | {a['applied']} | {a['fallback']} |")
    lines += ['', '本表仅统计成功查询中可以核验的安装/回退状态。正常在线策略的低置信度或请求失败回退属于端到端行为，计入实际延迟并单列次数；固定配置回放发生回退则判为失败，不能作为该配置的有效测量。负载诊断则按正式轮次的模式和时间窗口纳入全部服务请求，包括最终内存失败的请求；“产生修正响应”不等于查询成功。详细回退原因见 SUMMARY.json。', '']
    lines += ['## 调优与训练成本', '', '| 项目 | 平均耗时 ms | p99 ms | 样本数 |', '|---|---:|---:|---:|']
    costs=data['costs']
    for k,v in costs.get('historical_same90_policy_components_ms',{}).items():
        if isinstance(v,dict) and 'mean' in v:lines.append(f"| 历史同 90 查询：{k} | {v['mean']:.3f} | {v['p99']:.3f} | {v['n']} |")
    for k,v in costs.get('offline_selection_ms',{}).items():
        lines.append(f"| {k} | {v['mean']:.3f} | {v['p99']:.3f} | {v['n']} |")
    for stage,values in costs.items():
        if stage!='serial' and not stage.startswith('concurrent'):continue
        for k,v in values.items():lines.append(f"| {stage}/{k} | {v['mean']:.3f} | {v['p99']:.3f} | {v['n']} |")
    for k,v in costs.get('fe_controller_stages',{}).get('stage_ms',{}).items():
        lines.append(f"| FE 独立阶段计时：{k} | {v['mean']:.3f} | {v['p99']:.3f} | {v['n']} |")
    fe_cost=costs.get('fe_controller_stages')
    if fe_cost:
        lines += ['',f"独立 FE 计时共 {fe_cost['measured']} 个正式样本、{fe_cost['queries']} 条查询，其中 {fe_cost['fallbacks']} 次回退。controller 总计时占这批查询端到端总延迟的 {fe_cost['controller_fraction_of_query_mean_percent']:.3f}%；分母为查询总延迟，不是优化器时间。", '']
    lines += ['', '图构建与推理开销复用本轮之前、同 90 条查询的独立计时。它们分别测量，不能要求分量之和精确等于另一次完整调用。FE 独立阶段计时在主性能实验结束后使用仅增加计时的临时二进制，先经 2 查询小测，再执行 90 查询的 1 轮预热和 2 轮测量；最后恢复原二进制。计时涵盖原 DOP 捕获与特征提取、HTTP 决策与校验、DOP 安装与捕获，包含置信度回退调用，安装跳过时该阶段为零。记录包含少量计时指令本身的成本。它不覆盖完整优化器、placement 或 trace 持久化，不据此声称满足优化器开销小于 5% 的合同指标。原始记录与二进制恢复证据见 fe_timing/。', '',
              '| 选定模型 | 训练秒数 | 验证集平均候选损失 | 验证排序准确率 |', '|---|---:|---:|---:|']
    for k,v in costs.get('selected_training',{}).items():
        lines.append(f"| {k} | {v['seconds']:.3f} | {v['validation']['mean_regret']:.4f} | {v['validation']['rank_accuracy']:.4f} |")
    training=run/'models_full/RESULT.json'
    if training.exists():
        t=json.loads(training.read_text());lines += ['',f"全部 30 个候选的累计训练计时为 {sum(x['seconds'] for x in t['candidates']):.2f} 秒，训练进程峰值 RSS 为 {t['peak_RSS_KiB']/1024:.2f} MiB。该峰值是整个训练进程的高水位，不是某一模型的独立内存消耗。", '']
    policy_training=run.parent/'ablation_cost_20260912/TRAINING_COST.json'
    if policy_training.exists():
        t=json.loads(policy_training.read_text())
        lines += [f"策略训练成本微测使用原 130 个训练计划和原目标函数，1 轮预热、3 轮测量，平均每轮 {t['measured_epoch_seconds']['mean']:.4f} 秒，准备时间 {t['setup_seconds']:.3f} 秒，进程峰值 RSS {t['max_rss_KiB']/1024:.2f} MiB。此计时没有保存或部署新权重，不是历史完整 1000 轮训练的实测总时长。", '']
    footprint=run.parent/'ablation_cost_20260912/full/OFFLINE_SUMMARY.json'
    if footprint.exists():
        t=json.loads(footprint.read_text())
        lines += [f"当前策略模型含 {t['parameters']} 个参数，checkpoint 文件为 {t['checkpoint_bytes']} 字节。模型文件大小不等于服务进程 RSS；采集进程还包含 PyTorch、日志与证据缓存，不能把其总 RSS 全部归因于模型。", '']
    lines += ['## 复现与证据', '',
              '查询与模型：manifest.json、PROTOCOL.json、PROTOCOL_AMENDMENTS.json、REPAIR_PROTOCOL.json、models_full/SELECTED.json。运行版本、FE 二进制 SHA、CPU 型号和内存信息见 RUNTIME_ENVIRONMENT.json；Python 依赖见 ENVIRONMENT.json。仓库 HEAD 不等于当前部署二进制，复现时应使用记录的二进制摘要和实际配置。', '',
              '运行证据：serial/scored、serial_repair/scored、concurrent_attempt*/scored 内的原始请求、响应、SQL 摘要、资源采样和 independent_verification.json。SUMMARY.json 保留全部 90 条查询的最终均值，不只报告本轮仍然获益的查询。', '',
              '上述实验覆盖当前约定的固定查询集性能、成本模型和搜索/策略消融、并发与调优开销。它不包含额外的跨数据集泛化、标准 TPCH/TP 类合同验收、完整优化器阶段验收，也不将这些未做项目表述为已完成。', '']
    if complete:
        c=data['serial']['comparisons'];best=c['best_uniform']['policy_static'];native=c['native']['policy_static'];fixed=c['uniform4']['policy_static']
        high=[data['concurrent'][f'{m}_c16'] for m in ('native','policy_static','policy_load')]
        conclusions=['## 核心结论', '',
          f"原 BE 镜像串行实验中，在线 AutoDOP 在冻结 90 条查询上的平均延迟，相对受控原生配置降低 {native['ratio_of_mean_gain_pct']:.2f}%，相对固定 DOP4 降低 {fixed['ratio_of_mean_gain_pct']:.2f}%，相对逐查询最佳候选统一 DOP 降低 {best['ratio_of_mean_gain_pct']:.2f}%；后者有 {best['faster_queries']}/90 条查询获益。", '',
          '组件比较分别报告原部署多阶段模型、从头训练 30 轮的模型和延长训练预算后的模型，避免将不同训练过程混为一谈。原始消融中 XGBoost 池内选择及随机搜索的平均延迟更低；后续训练预算诊断和搜索复测单独列示。整体异构 DOP 收益与各组件的增量收益分别判断。', '',
          '原未启用准入控制实验中，16 客户端下的正式测量完成率：'+ '、'.join(f"{v['mode']} {100*v['completion_rate']:.1f}%" for v in high)+'。这说明负载修正本身不能替代查询准入控制；共同原生队列配置的补测单独报告，不混用两种配置的结论。', '',
          '这些结论严格针对历史筛选的固定子集和本次有限批次。完整结果、失败、统计口径和复现文件如下。', '']
        lines[4:4]=conclusions
        extension_path = run/'EXTENSION_SUMMARY.json'
        if extension_path.exists():
            extension = json.loads(extension_path.read_text())
            trained = next((s for s in extension['stages']
                            if s.get('run') == 'convergence_execution_20260913'
                            and s['stage'] == 'full' and s['status'] == 'verified'), None)
            if trained:
                transformer = trained['modes']['extended_transformer_pool']
                xgb = trained['modes']['cost_xgb_rank']
                advantage = 100*(1-xgb['query_mean_latency_ms']/transformer['query_mean_latency_ms'])
                lines[4:4] = ['## 延长训练预算后的同期模型对照', '',
                    f"保持历史训练/验证划分和模型结构，训练上限扩展至 200 轮，仅按历史验证集选择检查点。冻结 90 条查询在共同候选池下的同期复测中，Transformer 平均延迟 {transformer['query_mean_latency_ms']:.2f} ms，XGBoost 为 {xgb['query_mean_latency_ms']:.2f} ms，后者低 {advantage:.2f}%。两种模型各完成 180 次正式执行，全部通过核验；Transformer 的 p99 仍较高。该结果不支持全面领先或等效性结论，也未替换当前在线策略权重。详见 [补充实验](EXTENSION_SUMMARY.md)。", '']
            verified = [s for s in extension['stages'] if s.get('run') == 'queue_extension_20260913_attempt3'
                        and s['stage'].startswith('full_c') and s['status'] == 'verified']
            if verified:
                levels = sorted(s['queue_activity']['clients'] for s in verified)
                latest = max(verified, key=lambda s:s['queue_activity']['clients'])
                native_qps = latest['modes']['native']['verified_queries_per_second']
                load_qps = latest['modes']['policy_load']['verified_queries_per_second']
                lines[4:4] = ['## 原 BE 镜像的共同准入控制对照', '',
                    f"相同原生队列上限 8 下，已通过独立核验的客户端级别为 {levels}，三个模式的这些完整批次均无查询失败。在其中最高的 {max(levels)} 客户端级别，AutoDOP load 吞吐为 {load_qps:.4f} 查询/秒，相对同配置原生基线提高 {100*(load_qps/native_qps-1):.2f}%。这是固定 90 查询、每级别一轮正式测量的有限批次结果；未完成级别不计入，不能直接视为标准 TPCH 吞吐验收。详细结果见 [补充实验](EXTENSION_SUMMARY.md)。", '']
    if (run/'model_comparison_audit/REPORT.md').exists():
        lines += ['## 模型比较复核补充', '', '重新加载模型、复算候选评分与均值，并重新核验 540 次实际 DOP 后，未发现数据或回放错配。历史图模型排序准确率高出约 10 个百分点的结果来自不同查询与训练设置。本轮验证集上 Transformer 的配置选择损失反而更低，不能将排序准确率、候选选择效果与模型整体能力混为一谈。详细结果见 [模型比较复核](model_comparison_audit/REPORT.md)。', '']
    if (run/'original_teacher_audit/REPORT.md').exists():
        lines += ['## 原多阶段成本模型复核', '',
                  '主表中的 Transformer 为同一历史划分上从头训练 30 轮的模型；它不能代表原部署多阶段模型。原模型的训练链、数据来源及重新测量的排序准确率见 [原多阶段模型审计](original_teacher_audit/REPORT.md)。其中保留验证对、重新枚举验证对及当前 90 查询已测候选子集分别统计，不混用口径。原模型在历史验证集上的优势不能直接推出当前查询集上的配置选择优势。', '']
    if (run/'EXTENSION_SUMMARY.md').exists():
        lines += ['## 补充实验', '',
                  '原多阶段 Transformer、30 轮 Transformer 和 XGBoost 在冻结共同候选池内的同期执行对照，以及共同原生准入控制下的并发验证，见 [补充实验结果](EXTENSION_SUMMARY.md)。该文件标注各阶段是否通过独立验证；未完成阶段不构成性能结论。共同原生队列的作用不归因于 AutoDOP，且新配置的结果不替代原无准入控制实验记录。', '']
    if (run/'convergence_20260913/REPORT.md').exists():
        lines += ['## 训练预算诊断', '',
                  '保持数据、结构和每轮采样方式，将 Transformer 排序模型的训练上限扩展至 200 轮，按历史验证集选择检查点，再评估已有候选子集。结果见 [训练预算检查](convergence_20260913/REPORT.md)。增加验证选择次数的诊断不替代冻结的同期执行对照，也不能单独证明收敛。', '']
    if (run/'cpu_capacity_fix/REPORT.md').exists():
        deployed = run/'cpu_capacity_fix/DEPLOYMENT_VALIDATION.json'
        verified_deployment = deployed.exists() and json.loads(deployed.read_text()).get('status') == 'health_and_sql_parity_verified'
        lines += ['## CPU 负载口径修复', '',
                  ('CPU 统计修复已部署，通过三个 BE 健康检查、两条冻结查询的结果一致性检查及实际容量上报核验。修复后并发对照与原镜像结果分开统计；当前负载修正的增量性能收益仍需由同期静态策略对照判断。详见 [CPU 口径修复与并发验证](cpu_capacity_fix/REPORT.md)。' if verified_deployment else
                   '同期进程采样发现容器可用 CPU 利用率与 AutoDOP 接收的整机归一化利用率存在明显差异。已修改 BE 源码并进行针对性测试；部署及端到端验证状态见 [CPU 口径修复](cpu_capacity_fix/REPORT.md)。尚未部署的修复不能用于解释为已有线上收益。'), '']
    if (run/'development17_calibration/README.md').exists():
        lines += ['## 独立开发侧参数校准', '',
                  '已冻结 17 条有历史原生结果摘要、与报告 90 查询无 SQL 哈希重合的训练侧查询，用于比较修正强度。原报告查询不参与参数选择，开发筛选通过也不等于报告查询上的收益已验证。流程和状态见 [开发校准说明](development17_calibration/README.md)。', '']
    for folder, result_file, title in [
            ('development17_pressure', 'AUDITED_RESULT.json', '开发侧内存压力试验'),
            ('development17_cpu_threshold', 'RESULT.json', '推迟 CPU 修正触发的开发试验')]:
        result_path = run/folder/result_file
        if result_path.exists():
            result = json.loads(result_path.read_text())
            if result.get('status') in ('complete', 'complete_with_observed_memory_failures'):
                passed = '通过开发门槛，仍需独立复测' if result['screen_passed'] else '未通过开发门槛，未扩大至报告查询'
                lines += ['## '+title, '',
                          f"使用与报告查询无精确 SQL 重合的 17 条历史训练查询。完整小测结论：{passed}；各模式有效吞吐、完成率及实际修正证据见 [{title}]({folder}/REPORT.md)。失败计入完整结果，不将开发参数的调整结果替代报告查询上的正式对照。", '']
    complex_report = run/'complex_development24/REPORT.md'
    load_audit = run/'load_quantization_audit/RESULT.json'
    if load_audit.exists():
        load_result = json.loads(load_audit.read_text())
        assert load_result['status'] == 'verified_replay'
        lines += ['## 负载修正离散幅度核验', '',
                  f"对两个开发并发实验的{len(load_result['rows'])}条请求重新运行原策略与修正规则，DOP决策逐条匹配原始记录。默认参数在CPU使用率98%、内存30%时会将DOP 4和8均降至1，16降至2；实际请求的转换次数见 [离散修正审计](load_quantization_audit/REPORT.md)。这说明修正幅度较大，但尚不单独证明吞吐下降原因。失败事件缺少查询ID时保持未关联，不将成功请求的负载冒充失败现场。", '']
    if complex_report.exists():
        lines += ['## 复杂结构开发数据补充', '',
                  '新增 24 条预先冻结的三/四分支 SQL（训练16、开发验证8），已经通过独立组合语义检查和96次原生/策略正确性小测。配置标签、接续训练及训练阶段消融的实际完成状态见 [复杂分支开发数据](complex_development24/REPORT.md)。该数据属于模型开发，不是新的独立最终测试；离线训练结果不等于在线部署或端到端收益。', '']
    coverage_replay = run/'structure_coverage20/retrained/SCORE_REPLAY.json'
    if coverage_replay.exists():
        coverage_result = json.loads(coverage_replay.read_text())
        assert coverage_result['status'] == 'verified'
        t = coverage_result['after']['transformer']
        lines += ['## 四分支训练覆盖补充后的模型比较', '',
                  f"新增20条仅用于训练的四分支SQL，按4种根算子与5种有序树形覆盖构造，不按查询延迟筛选。合并后训练集114个计划、1365个配置；原22个计划、212个验证配置保持不变。独立重载评分后，Transformer的等权选择损失为{100*t['weighted_regret']:.2f}%，复杂验证选择损失为{100*t['cohorts']['complex_new']['mean_regret']:.2f}%。完整同数据对照及成本见 [覆盖补充模型报告](structure_coverage20/retrained/REPORT.md)。", '',
                  ('通过预设离线开发门槛，仍需SQL执行小测验证。' if coverage_result['development_gate_passed'] else '未通过要求综合及复杂验证选择损失均不差于两种XGBoost的预设门槛，未启动SQL执行扩展或部署。') + ' 这是在已使用过的开发验证集上进行的数据覆盖比较，不是独立测试或新模型全面领先的证明。', '']
    coverage_path = run/'training_structure_audit/RESULT.json'
    extra_models = run/'structure_coverage20/additional_baselines_full/RESULT.json'
    stability_path = run/'structure_coverage20/seed_stability/RESULT.json'
    parameter_average = run/'structure_coverage20/parameter_average3/RESULT.json'
    cosine_path = run/'structure_coverage20/cosine_decay/RESULT.json'
    diagnostic_path = run/'structure_coverage20/diagnostic_execution8/RESULT.json'
    candidate_audit = run/'structure_coverage20/candidate_pool_audit/RESULT.json'
    observed_augmented = run/'structure_coverage20/observed90_audit/RESULT.json'
    if observed_augmented.exists():
        observed = json.loads(observed_augmented.read_text())
        assert observed['status'] == 'complete' and observed['queries'] == 90
        lines += ['## 新模型在90条历史已测候选上的离线评分', '',
                  f"对全部90条查询的{observed['observed_configurations']}个历史已测不同配置重新评分，模型在此次读取评分数据前固定；没有重新执行SQL。沿用旧BE环境下相同配置的模式均值合并口径。完整指标见 [90条离线评分](structure_coverage20/observed90_audit/REPORT.md)。", '',
                  '| 模型 | 平均选择损失 | 排序准确率 |', '|---|---:|---:|']
        for kind, q in observed['qualities'].items():
            lines.append(f"| {kind} | {100*q['mean_regret']:.2f}% | {100*q['rank_accuracy']:.2f}% |")
        lines += ['', '这是重复使用历史优势子集的诊断，候选来自既有模式，具有选择偏好。它不证明新模型在当前BE上的执行收益或独立泛化。三个Transformer种子均保留，其余MLP控制当前为种子17，不能据此推断各模型的种子稳定性相同。', '']
    seed_summary = run/'structure_coverage20/observed90_seed_audit/SEED_SUMMARY.json'
    if seed_summary.exists():
        seed_values = json.loads(seed_summary.read_text())
        lines += ['## 补齐基线种子后的90条候选选择比较', '',
                  '前一节保留首次评分。此处补齐MLP排序、MLP回归和XGBoost回归的种子29、43，全部种子按原验证规则选模，统一复用1091个已测配置，不根据90条结果挑选种子。详见 [三种子汇总](structure_coverage20/observed90_seed_audit/SEED_SUMMARY.md)。', '',
                  '| 模型 | 三种子平均选择损失 | 最小—最大 | 平均排序准确率 |', '|---|---:|---:|---:|']
        for kind, q in seed_values.items():
            lines.append(f"| {kind} | {q['mean_regret']:.2%} | {q['min_regret']:.2%}—{q['max_regret']:.2%} | {q['mean_rank_accuracy']:.2%} |")
        lines += ['', 'Transformer的种子平均选择损失低于MLP排序，但高于两种回归对照。排序准确率和最终候选选择质量不能互相替代。种子范围不是置信区间；这些结果属于历史筛选集合的开发诊断，不是新的SQL执行或独立测试。', '']
    retry_result = run/'development17_retry/RESULT.json'
    if retry_result.exists():
        retry = json.loads(retry_result.read_text())
        identities = json.loads((run/'development17_retry/FAILURE_IDENTITY_AUDIT.json').read_text())
        assert retry['status'] == identities['status'] == 'verified'
        lines += ['## 相同任务集合与有限重试的并发小测', '',
                  '17条历史开发查询、16客户端、共同准入上限16，每模式各34个预热任务和34个正式任务。所有模式最多4次SQL尝试，仅对BE进程内存超限错误按1/2/4秒等待重试；保留全部失败，等待和失败耗时计入整批及逻辑请求计时。详见 [有限重试对照](development17_retry/REPORT.md)。', '',
                  '| 模式 | 正式完成 | SQL尝试 | 失败尝试 | 整批秒数 | 完成任务/秒 |', '|---|---:|---:|---:|---:|---:|']
        for mode,m in retry['metrics'].items():
            lines.append(f"| {mode} | {m['completed_tasks']}/{m['logical_tasks']} | {m['physical_sql_attempts']} | {m['failed_physical_attempts']} | {m['batch_seconds']:.2f} | {m['verified_tasks_per_second']:.4f} |")
        lines += ['', f"全阶段204个逻辑任务共{retry['physical_attempts_all_phases']}次SQL尝试，其中{identities['failed_physical_attempts']}次内存超限失败均与FE主查询审计中的查询ID、数据库及SQL对应。正式阶段全部完成，静态策略预热阶段仍有3个请求达到重试上限后失败；没有删除。设置已恢复。", '',
                  '这项单轮开发小测中，静态AutoDOP完成相同任务集合快于原生与负载修正。重试规则由所有模式共用，不是AutoDOP贡献；结果不替代无重试实验，也不证明稳态、独立泛化或合同验收。失败身份核验不等于失败查询DOP安装核验。', '']
    retry_decisions = run/'development17_retry/DECISION_AUDIT.json'
    if retry_decisions.exists():
        audited = json.loads(retry_decisions.read_text())
        assert audited['status'] == 'verified'
        lines += ['## 并发重试的失败请求与负载决策关联', '',
                  '对重试中的AutoDOP请求逐个关联已核验身份的失败尝试或成功尝试，并重算策略及修正决策。详见 [决策与执行核对](development17_retry/DECISION_AUDIT.md)。', '',
                  '| 模式 | 阶段 | 尝试结果 | 决策复算数 | 请求修正数 | 核验安装修正数 | 内存超阈值请求 |', '|---|---|---|---:|---:|---:|---:|']
        for row in audited['summaries']:
            lines.append(f"| {row['mode']} | {row['phase']} | {row['attempt_status']} | {row['decisions']} | {row['changed']} | {row['installed_changed']} | {row['memory_over_threshold']} |")
        lines += ['', '正式阶段25次AutoDOP内存失败的请求时内存占用均低于阈值；请求时负载不是执行峰值，不能据此排除后续内存超限。负载修正的34次正式成功尝试全部确认安装修正；失败尝试不能通过相同安装核验，因此仅报告其请求决策。该结果提示需要检查资源观测时序和查询新增资源需求，不支持仅靠更改阈值就能解决问题的结论。', '']
    resource_timeline = run/'development17_retry/RESOURCE_TIMELINE_AUDIT.json'
    metric_cadence = run/'development17_retry/METRIC_CADENCE_AUDIT.json'
    if resource_timeline.exists() and metric_cadence.exists():
        timeline = json.loads(resource_timeline.read_text())
        cadence = json.loads(metric_cadence.read_text())
        assert timeline['status'] == cadence['status'] == 'verified'
        lines += ['## 并发内存观测的时间分辨率', '',
                  '已将全部120次内存失败与FE执行时间及三个BE的归档指标对齐。每个BE有155次抓取，但进程内存数值只变化21次；抓取间隔中位数约2.06秒，数值变化间隔中位数约14.43秒。源码中的后台指标刷新路径与该现象一致，但未据此假定历史运行配置。', '',
                  '因此，抓取时间较近不代表指标刚刚更新，现有指标不能可靠重建短查询的内存峰值，也不能证明资源平滑导致失败。BE向FE的资源上报直接读取内存跟踪器，属于另一条采样路径；不能将Prometheus刷新周期视为AutoDOP输入的刷新周期。后续小测应先补齐这两条路径的时间观测。详见 [时间线审计](development17_retry/RESOURCE_TIMELINE_AUDIT.md) 与 [指标刷新诊断](development17_retry/METRIC_CADENCE_AUDIT.md)。', '']
    direct_analysis = run/'development17_memory_observed/DIRECT_MEMORY_ANALYSIS.json'
    if direct_analysis.exists():
        direct = json.loads(direct_analysis.read_text())
        direct_result = json.loads((direct_analysis.parent/'RESULT.json').read_text())
        direct_observer = json.loads((direct_analysis.parent/'DIRECT_MEMORY_SUMMARY.json').read_text())
        assert direct['status'] == direct_result['status'] == direct_observer['status'] == 'verified'
        lines += ['## 增加直接内存观测的并发机制小测', '',
                  '沿用17条历史开发查询、三个模式、共同准入和有限重试设置，仅对所有模式增加每秒直接BE内存跟踪器与FE后端状态观测。先通过20周期/60次HTTP的采样小测，再运行完整开发批次；未改变模型或负载修正参数。该观测可能影响运行，结果仅在本轮内比较。', '',
                  '| 模式 | 正式完成 | SQL尝试 | 失败尝试 | 整批秒数 |', '|---|---:|---:|---:|---:|']
        for mode,m in direct_result['metrics'].items():
            lines.append(f"| {mode} | {m['completed_tasks']}/{m['logical_tasks']} | {m['physical_sql_attempts']} | {m['failed_physical_attempts']} | {m['batch_seconds']:.2f} |")
        lines += ['', f"直接内存观测完成{direct_observer['samples']}个周期，HTTP中位耗时{direct_observer['median_http_ms']:.2f}ms，超过计划采样周期的次数为{direct_observer['overruns']}。HTTP耗时不是服务器CPU开销，也不证明观测对实验无影响。", '',
                  '所有失败按FE查询ID和SQL核验，再按报错BE身份关联直接内存；执行期采样要求完整HTTP区间位于该SQL执行区间内。采样仍不等于真实峰值，共享BE的内存变化不能归因于单条查询。详见 [直接内存时间线](development17_memory_observed/DIRECT_MEMORY_ANALYSIS.md)。', '']
        total_failures = sum(r['failures'] for r in direct['summaries'])
        crossings = sum(r['sampled_crossing_65pct_after_low_start'] for r in direct['summaries'])
        high_samples = sum(r['sampled_above_90pct'] for r in direct['summaries'])
        lines += [f'全阶段{total_failures}次失败中，{crossings}次的同BE请求前近期直接读数低于或等于65%，随后执行期采样超过65%；{high_samples}次执行期采样超过90%。这表明请求后新增内存需求需要考虑，不能仅将失败归因于请求时对已有高内存的漏报。重叠查询共享资源及采样，计数不代表独立重复。下一步机制验证应优先考虑新增资源需求或准入，而非仅微调当前占用阈值。', '']
    memory_summary = run/'development17_memory_profiles_full/MEMORY_SUMMARY.json'
    if memory_summary.exists():
        mem = json.loads(memory_summary.read_text()); assert mem['status']=='verified'
        lines += ['## 开发查询的单查询内存需求', '',
                  '先用清单前两条查询完成8次profile采集与字段语义核验，再一次性对全部17条开发查询采集原生和静态策略的预热及正式profile，共68份全部核验通过。以下仅统计正式观测，不与未启用profile的延迟结果混用。QueryPeakMemoryUsagePerNode是各BE查询内存峰值的最大值；不是进程总内存或累计分配量，显示舍入范围已保留。', '',
                  '| 模式 | 最小 MiB | 中位数 MiB | 最大 MiB | 最大/最小 |', '|---|---:|---:|---:|---:|']
        for mode,v in mem['summaries'].items():
            lines.append(f"| {mode} | {v['min_mib']:.2f} | {v['median_mib']:.2f} | {v['max_mib']:.2f} | {v['max_min_ratio']:.2f} |")
        lines += ['',f"静态策略峰值更低的查询为{mem['static_smaller_peak_queries']}/17，更高为{mem['static_larger_peak_queries']}/17。执行加速不必然降低内存峰值。需求差异为按资源需求设置准入预算提供了开发动机，但尚未证明该机制收益；历史profile预算不等于未见查询内存预测模型。详见 [内存需求诊断](development17_memory_profiles_full/MEMORY_SUMMARY.md)。", '']
    budget_summary = run/'development17_budget_full/FACTORIAL_SUMMARY.json'
    if budget_summary.exists():
        budget = json.loads(budget_summary.read_text()); assert budget['status']=='verified'
        admission = json.loads((budget_summary.parent/'ADMISSION_AUDIT.json').read_text())
        assert admission['status']=='verified'
        lines += ['## 异构DOP与历史内存预算准入的四组对照', '',
                  '本节是新增客户端准入原型，不是原部署负载修正。先完成队列异常释放、并发等待和超时测试，再运行两条查询的小测及完整17条开发查询。原生/静态DOP各自与启用/不启用预算准入交叉比较；原生队列上限16、重试规则和观测工具一致。', '',
                  '预算在测试前冻结：总额度为已观测BE进程上限的60%，每条查询预留此前两模式预热/正式profile最大值的1.25倍，最低64MiB。两种DOP模式共用相同预算表，按先到先服务预留，重试期间保持预留，结束后释放。它使用开发查询的历史profile，并非已训练的未见查询内存预测模型，也不保证实际内存不会超额。', '',
                  '| 模式 | 正式完成 | 内存失败尝试 | 整批秒数 | 平均请求毫秒（含等待/重试） |', '|---|---:|---:|---:|---:|']
        for mode,m in budget['metrics'].items():
            lines.append(f"| {mode} | {m['completed_tasks']}/{m['logical_tasks']} | {m['failed_physical_attempts']} | {m['batch_seconds']:.2f} | {m['logical_latency_ms']['mean']:.2f} |")
        lines += ['', '| 比较 | 整批耗时降低 | 平均请求延迟降低 |', '|---|---:|---:|']
        for name,c in budget['comparisons'].items():
            if c['both_complete']:
                lines.append(f"| {name} | {c['batch_time_reduction']:.2%} | {c['latency_reduction']['mean']:.2%} |")
            else:
                lines.append(f'| {name} | 未全部完成 | 未全部完成 |')
        lines += ['', f"{admission['reservations']}次预留均与任务匹配，峰值记账额度未超过预算，结束额度为零；SQL尝试均处于对应预留区间，等待已计入请求延迟。该核验不等于实际内存边界保证。详见 [四组结果](development17_budget_full/FACTORIAL_SUMMARY.md)。单轮有限开发批次不能证明稳态吞吐、独立泛化或合同验收。", '']
    memory_loo = run/'memory_prediction_loo17/RESULT.json'
    if memory_loo.exists():
        loo = json.loads(memory_loo.read_text()); assert loo['status']=='verified'
        lines += ['## 不依赖查询ID查表的内存需求预测诊断', '',
                  '使用17条开发查询做逐查询留一验证，每折排除被预测查询的全部profile标签。输入为固定的fragment计划特征摘要，不含SQL文本、ID或运行时负载；缩放仅拟合其余16条。目标为此前两模式四次profile的每BE峰值最大值。预算仍为预测值×1.25、最低64MiB。', '',
                  '| 方法 | 预算低于观测峰值 | 中位Q误差 | 中位预算/峰值 | 最大预算/峰值 |', '|---|---:|---:|---:|---:|']
        for kind,m in loo['summaries'].items():
            lines.append(f"| {kind} | {m['under_reserved_queries']}/17 | {m['median_q_error']:.2f} | {m['median_reservation_ratio']:.2f} | {m['max_reservation_ratio']:.2f} |")
        lines += ['', '三个近邻的最大历史需求通过预先设定的开发筛查（无观测低估且中位预算比不超过2）；这是后续新查询验证的候选，不是安全保证。部分小查询仍明显高估。岭回归与随机树共34个折模型已重载核验；首次结果导出的数值类型问题修复后，全部模型文件与数据逐字节一致。', '',
                  '已冻结全开发集近邻预测器，未进行新查询SQL验证或部署。原生内存预测服务使用物理计划CSV，且准入发生在当前AutoDOP fragment放置之前，因此不能直接接入此fragment摘要模型；需对齐特征与调用时序。详见 [留一验证](memory_prediction_loo17/REPORT.md)。', '']
    native_memory_loo = run/'native_memory_prediction_loo17/RESULT.json'
    if native_memory_loo.exists():
        native_loo = json.loads(native_memory_loo.read_text()); assert native_loo['status']=='verified'
        capture = json.loads((run/'native_memory_features17_full/IDENTITY_AUDIT.json').read_text())
        assert capture['status']=='verified'
        lines += ['## 原生准入前特征的接口验证与内存模型对照', '',
                  '通过临时本地CostPredictor接口实际捕获CSV：先两条查询4次EXPLAIN SCHEDULER小测，再完整17条34次。每次仅生成调度计划，返回预测值0；全部以唯一标记、完整SQL、查询ID和零扫描审计核验，配置已恢复。每行384列，所有查询DOP0与4之间均仅var_0不同。', '',
                  '随后使用真正准入前可用的env/operations特征，剔除表ID和DOP字段，重复相同的17查询留一协议。目标、倍率1.25、模型参数和筛查条件与fragment特征实验保持一致。', '',
                  '| 方法 | 预算低于观测峰值 | 中位Q误差 | 中位预算/峰值 |', '|---|---:|---:|---:|']
        for kind,m in native_loo['summaries'].items():
            lines.append(f"| {kind} | {m['under_reserved_queries']}/17 | {m['median_q_error']:.2f} | {m['median_reservation_ratio']:.2f} |")
        lines += ['', '三近邻在原生特征下仍有1条预算低于观测峰值（预算约为观测的93.7%），未通过原开发筛查，不能沿用fragment特征上的通过结论。详见 [原生特征留一对照](native_memory_prediction_loo17/REPORT.md)。', '']
        nested_path = run/'native_memory_nested_calibration17/RESULT.json'
        if nested_path.exists():
            nested=json.loads(nested_path.read_text());assert nested['status']=='verified'
            m=nested['summary']
            lines += [f"进一步在每折16条训练查询内做嵌套留一，用最大观测/预测比校准倍率，完全排除外层目标。仍有{m['under_reserved_queries']}/17条未覆盖，中位预算比{m['median_reservation_ratio']:.2f}，未部署。该后续诊断提示需要补数据或验证原生槽位换算与资源余量，而不能直接以提高测试集倍率宣布成功。详见 [嵌套校准](native_memory_nested_calibration17/REPORT.md)。", '']
    slot_mapping = run/'native_slot_mapping17/RESULT.json'
    if slot_mapping.exists():
        slots=json.loads(slot_mapping.read_text());assert slots['status']=='verified' and slots['java_python_parity']
        bytecode=json.loads((slot_mapping.parent/'BYTECODE_AUDIT.json').read_text());assert bytecode['status']=='verified'
        lines += ['## 原生内存槽位换算与预算余量', '',
                  '原生MBE先将字节数整数除以每槽容量，再调整为不小于商的2次幂。因此名义槽位额度可能小于原字节请求。抽取Java原方法运行边界和17条预测案例，并与Python逐项复算一致；现有FE jar字节码也确认该运算顺序。', '',
                  '| 请求方式 | 名义额度低于观测峰值 | 未覆盖含40%余量的预算 |', '|---|---:|---:|']
        for mode,m in slots['summaries'].items():
            lines.append(f"| {mode} | {m['below_observed_peak']}/17 | {m['not_covering_headroom_scaled_budget']}/17 |")
        lines += ['', '向上编码方案沿用先前60%预算规则，将预算除以0.60后向上对齐槽位及2的幂，再传入对应字节数。它传递的是调度预留请求，不是原始内存预测值。当前17条名义额度覆盖观测不代表原预测门槛通过，更不保证新查询实际内存安全。', '',
                  '运行快照确认V2当前关闭且不能热切换；当前策略为MAX，以上仅验证MBE算术。尚未重启FE或运行V2集成实验。后续需在可恢复的独立协议中验证实际槽位分配、释放及性能，保留原生固定准入基线。详见 [槽位审计](native_slot_mapping17/REPORT.md)。', '']
    gap_comparison = run/'structure_coverage20/gap_calibration/COMPARISON.json'
    if gap_comparison.exists():
        gap = json.loads(gap_comparison.read_text())
        assert gap['status'] == 'verified' and gap['all_xgboost_controls_unchanged']
        lines += ['## 排序损失与延迟比间隔回归的对照', '',
                  '固定网络、初始化、数据、均匀抽样和学习率日程，仅将动态间隔hinge替换为拟合log(慢配置耗时/快配置耗时)的SmoothL1，beta固定为1。先完成两轮小测、梯度方向及模型重载核验，再训练全部三个种子；未使用90条报告查询标签拟合。详见 [损失函数对照](structure_coverage20/gap_calibration/REPORT.md)。', '',
                  '| 训练目标 | 三种子综合选择损失 | 三种子复杂选择损失 | 平均训练秒数 |', '|---|---:|---:|---:|']
        for phase, q in gap['aggregates'].items():
            lines.append(f"| {phase} | {q['weighted_regret']:.2%} | {q['complex_regret']:.2%} | {q['training_seconds']:.2f} |")
        lines += ['', f"综合与复杂损失均值同时改善：{gap['mean_weighted_and_complex_improved']}。全部保存模型重载核验通过，XGBoost控制结果不变。开发验证集已重复使用；该对照不构成独立测试或SQL执行收益证据。", '']
    margin_audit = run/'structure_coverage20/margin_signal_audit/RESULT.json'
    if margin_audit.exists():
        margin = json.loads(margin_audit.read_text())
        assert margin['status'] == 'verified'
        lines += ['## 排序损失的学习信号检查', '',
                  '现有动态间隔hinge损失对排序方向错误的正间隔候选对始终提供梯度，但不会惩罚超出要求的分数差。对固定余弦训练模型的检查显示，大部分训练候选对已满足间隔；这可以表示拟合充分，不能单独归因于训练停滞。训练与开发验证集逐种子、群组统计见 [间隔诊断](structure_coverage20/margin_signal_audit/REPORT.md)。这里沿用原始批次候选对及其重复记录，与全部规范化点标签形成的候选对指标口径不同。', '']
    sampling_comparison = run/'structure_coverage20/top_sampling/COMPARISON.json'
    if sampling_comparison.exists():
        sampling = json.loads(sampling_comparison.read_text())
        assert sampling['status'] == 'verified' and sampling['all_xgboost_controls_unchanged']
        lines += ['## 训练候选对抽样的控制实验', '',
                  '在相同网络、历史初始化、损失、余弦学习率和总抽样预算下，将一半抽样限定于涉及训练集最优3%候选的对。先完成两轮流程小测及重载核验，再运行全部三个种子；没有使用90条报告查询的标签训练。完整逐种子效果与成本见 [抽样对照](structure_coverage20/top_sampling/REPORT.md)。', '',
                  '| 抽样 | 三种子综合选择损失 | 三种子复杂选择损失 | 平均完整训练秒数 |', '|---|---:|---:|---:|']
        for phase, q in sampling['aggregates'].items():
            lines.append(f"| {phase} | {q['weighted_regret']:.2%} | {q['complex_regret']:.2%} | {q['training_seconds']:.2f} |")
        lines += ['', f"综合与复杂损失均值同时改善：{sampling['mean_weighted_and_complex_improved']}。各模型保存后重新加载核验，XGBoost控制结果保持一致。该实验衡量重复使用的开发验证集，不是独立测试；没有据此自动部署或扩展SQL实验。", '']
    top_audit = run/'structure_coverage20/top_candidate_audit/RESULT.json'
    if top_audit.exists():
        top_result = json.loads(top_audit.read_text())
        assert top_result['status'] == 'verified'
        lines += ['## 最优候选附近的排序诊断', '',
                  '在开发训练集中，涉及最优3%候选的对约占历史群组抽样的34.78%、复杂群组的29.80%，所有计划均有此类训练对，不能解释为最优候选未被训练覆盖。三个Transformer种子在复杂验证集上的最优附近候选对准确率均为98.21%，最优3%命中均为7/8；少量局部错误仍会影响最终配置选择。详见 [训练暴露与候选排序审计](structure_coverage20/top_candidate_audit/REPORT.md)。该诊断不单独证明因果或抽样调整有效。', '']
    if candidate_audit.exists():
        candidates = json.loads(candidate_audit.read_text())
        assert candidates['status'] == 'complete'
        lines += ['## 异构候选收益与模型选择的区分', '',
                  f"在8条复杂开发查询的既有配置标签中，{candidates['heterogeneous_best_queries']}条的最佳已测候选是异构配置。每条仅包含5档统一DOP及3个随机异构候选；这里的最小值为事后候选上限，不是完整搜索空间最优或可部署策略。各查询候选收益及模型是否选中见 [候选集审计](structure_coverage20/candidate_pool_audit/REPORT.md)。它与单轮客户端执行诊断使用不同统计口径，分别报告。", '']
    if diagnostic_path.exists():
        diagnostic = json.loads(diagnostic_path.read_text())
        assert diagnostic['status'] == 'complete' and diagnostic['verified_executions'] == 80
        lines += ['## 八条复杂开发查询的诊断性执行', '',
                  '原离线扩展门槛未通过。学习率对照的三个种子在8条复杂查询上选择完全相同，与成对XGBoost仅一条配置不同，因此另行冻结诊断协议，复测全部8条查询及全部5种模式；不把原门槛改写为通过，不扩展至90条或部署。80次预热/测量全部独立核验通过，设置已恢复。详见 [执行诊断](structure_coverage20/diagnostic_execution8/REPORT.md)。', '',
                  '| 模式 | 平均执行及取数延迟 ms |', '|---|---:|']
        for mode, stats in diagnostic['statistics'].items():
            lines.append(f"| {mode} | {stats['mean_ms']:.2f} |")
        lines += ['', '模型配置在执行前冻结，此表不包含离线评分/搜索时间。每条每模式仅一次预热、一次测量，结果只作诊断，不证明统计显著性或新方案端到端优越性。配置相同的模式也存在运行波动，不能把全部均值差异归因于模型。', '']
    if cosine_path.exists():
        cosine = json.loads(cosine_path.read_text())
        assert cosine['status'] == 'verified' and set(cosine['after_cosine']) == {'17', '29', '43'}
        lines += ['## 学习率下降的三种子对照', '',
                  '固定相同三个种子，将Transformer学习率从1e-4按预定余弦曲线降至1e-5；训练数据、初始化、损失和选模规则保持一致。固定学习率结果复用此前独立核验，新流程逐模型重载复核。完整结果见 [学习率对照](structure_coverage20/cosine_decay/REPORT.md)。', '',
                  '| 种子 | 固定学习率综合选择损失 | 下降学习率综合选择损失 | 固定/下降学习率复杂选择损失 |', '|---|---:|---:|---:|']
        for seed in ('17', '29', '43'):
            before = cosine['before_fixed_lr'][seed]['transformer']
            after = cosine['after_cosine'][seed]['transformer']
            lines.append(f"| {seed} | {100*before['weighted_regret']:.2f}% | {100*after['weighted_regret']:.2f}% | {100*before['cohorts']['complex_new']['mean_regret']:.2f}% / {100*after['cohorts']['complex_new']['mean_regret']:.2f}% |")
        lines += ['', '此对照是在已使用过的开发验证集上检查优化稳定性，不是独立测试，不按种子择优，也不自动部署或启动SQL扩展。', '']
    if parameter_average.exists():
        average = json.loads(parameter_average.read_text())
        assert average['status'] == 'verified' and average['prediction_reload_exact']
        q = average['quality']
        lines += ['## 三种子参数等权平均检查', '',
                  f"固定平均三个种子模型的全部参数，结构保持不变，未搜索权重。独立重载后综合选择损失为{100*q['weighted_regret']:.2f}%，复杂选择损失为{100*q['cohorts']['complex_new']['mean_regret']:.2f}%。完整协议及门槛结果见 [参数平均检查](structure_coverage20/parameter_average3/REPORT.md)。该检查使用三个既有完整训练模型，不代表单次训练成本；没有自动部署或执行SQL。", '']
    if stability_path.exists():
        stability = json.loads(stability_path.read_text())
        assert stability['status'] == 'verified' and set(stability['seeds']) == {'17', '29', '43'}
        lines += ['## 固定训练流程的三种子稳定性复测', '',
                  '固定相同数据、多阶段初始化、学习率、训练轮数和验证选模规则，报告种子17、29、43的全部结果，不按种子择优。种子17复用原完整训练与独立核验，另两个种子新训练并重新加载复核。完整逐种子指标见 [稳定性报告](structure_coverage20/seed_stability/REPORT.md)。', '',
                  '| 模型 | 综合选择损失的种子均值 | 最低—最高 |', '|---|---:|---:|']
        for kind, values in stability['aggregate'].items():
            lines.append(f"| {kind} | {100*values['weighted_regret_mean']:.2f}% | {100*values['min']:.2f}%—{100*values['max']:.2f}% |")
        lines += ['', '这衡量固定开发验证集上的训练随机性，不代表独立查询泛化或SQL重复运行波动；不能从单个最好种子推出稳定领先。原SQL扩展门槛不因本复测改变。', '']
    if extra_models.exists():
        extra_result = json.loads(extra_models.read_text())
        assert extra_result['status'] == 'verified'
        lines += ['## 补充数据上的回归与MLP模型对照', '',
                  '补充MLP排序、MLP延迟回归和XGBoost延迟回归，训练样本与既有三种模型一致；数值归一化和回归目标标准化仅使用训练数据。各模型在保存后重新加载，评分指标复算一致。详见 [补充模型比较](structure_coverage20/additional_baselines_full/REPORT.md)。平坦模型保留依赖/竞争汇总特征；本对照比较模型方案，不把竞争边单列为消融项，也不将从头训练与历史接续训练的差异冒充纯结构因果效果。', '']
    if coverage_path.exists():
        coverage = json.loads(coverage_path.read_text())
        lines += ['## 训练与验证结构覆盖', '',
                  f"训练图 fragment 数中位数为 {coverage['training_fragment_counts']['median']:.0f}，验证图中位数为 {coverage['validation_fragment_counts']['median']:.0f}、最大为 {coverage['validation_fragment_counts']['max']}；冻结报告查询中位数为 {coverage['report_fragment_counts']['median']:.0f}。这一覆盖差异提示应补充复杂结构的开发验证，不能仅通过增加训练轮数排除数据覆盖问题。该结构检查不读取查询延迟，不单独证明模型差距的原因；详见 [训练结构覆盖检查](training_structure_audit/REPORT.md)。", '']
    callback = run/'native_predictor_callback17/IDENTITY_AUDIT.json'
    if callback.exists():
        proof = json.loads(callback.read_text())
        assert proof['status'] == 'verified' and proof['records'] == 8
        lines += ['## 原生非零预算预测接口验证', '',
                  '冻结17条开发查询训练的原生计划特征预测器，先完成68个离线重载案例，再对两条查询、两种DOP和固定/预测预算执行8次Explain。服务返回值、Explain与FE审计PredictMemBytes逐条一致；配置已恢复。此阶段V2关闭，仅证明接口消费预算，不代表真实准入分配、未见查询预测质量或并发收益。详见 [回调身份核验](native_predictor_callback17/IDENTITY_AUDIT.json)。', '']
    allocation = run/'native_slot_live17/ALLOCATION_AUDIT.json'
    if allocation.exists():
        proof = json.loads(allocation.read_text())
        restoration = json.loads((run/'native_slot_restart17/RESTORATION.json').read_text())
        assert proof['status'] == 'verified' and restoration['restored']
        lines += ['## 原生V2槽位分配与释放小测', '',
                  '临时开启V2并使用MBE估算，8次Explain的预测预算、FE审计NumSlots及全局槽位历史逐条关联，实际分配数与预算编码一致，最终状态均为RELEASED。已恢复原FE配置和运行时设置。这完成接口至实际槽位分配/释放验证；Explain未执行数据计算，尚不构成并发收益证据。详见 [槽位核验](native_slot_live17/ALLOCATION_AUDIT.json)。', '']
    native_budget = run/'native_budget_pilot/ALLOCATION_AUDIT.json'
    if native_budget.exists():
        proof = json.loads(native_budget.read_text())
        restoration = json.loads((run/'native_budget_restart/RESTORATION.json').read_text())
        assert proof['status'] == 'verified' and restoration['restored']
        lines += ['## 原生V2预算准入的并发小测', '',
                  '两条历史开发查询、16客户端，每模式一轮预热和一轮正式测量，共128次执行。原生/异构DOP分别交叉固定8并发预算与预测预算；冻结同一内存模型，不重试，排队和预测计入请求耗时。全部SQL结果、身份、适用时的DOP、预算响应及实际槽位分配/释放核验通过。', '',
                  '| 模式 | 正式整批秒数 | QPS | 平均请求毫秒 | p90毫秒 |', '|---|---:|---:|---:|---:|']
        for mode, metric in proof['metrics'].items():
            lines.append(f"| {mode} | {metric['batch_seconds']:.3f} | {metric['qps']:.4f} | {metric['mean_ms']:.2f} | {metric['p90_ms']:.2f} |")
        lines += ['', '该小测使用内存训练阶段已观测的查询，只有一个正式有限批次，不构成未见查询泛化、稳态吞吐或合同验收证明。原FE配置已恢复。详见 [原生预算小测](native_budget_pilot/REPORT.md)。', '']
    native_budget_diagnostic = run/'native_budget_pilot/DIAGNOSTIC.json'
    if native_budget_diagnostic.exists() and not native_budget.exists():
        diagnostic = json.loads(native_budget_diagnostic.read_text())
        assert diagnostic['status'] == 'diagnostic_not_accepted'
        lines += ['## 原生并发集成的未通过小测', '',
                  '128次SQL结果与适用时DOP核验通过，但仅首个预热批次16条具有FE Slots及全局分配/释放证据，正式批次均无槽位证据。因此不将该批耗时作为原生预算机制效果，未扩大测试。257次预测回调包含128条数据查询、128条last_query_id辅助查询及一次初始化；全部响应重载一致。原FE和运行时配置恢复。该批保持未通过状态，后续定位与修复见下文；详见 [集成诊断](native_budget_pilot/REPORT.md)。', '']
    queue_repro = run/'native_queue_repro8/AUDIT.json'
    if queue_repro.exists():
        assert json.loads(queue_repro.read_text())['status'] == 'verified'
        lines += ['## 原生准入异常的最小复现', '',
                  '两条查询、4客户端、两个连续批次共8条，关闭AutoDOP与成本预测。两批的队列开关均保持开启，8条SQL结果、审计Slots及实际分配/释放全部核验通过，原FE恢复。该最小复现未触发前述异常，不改判128条小测通过。详见 [8条复现](native_queue_repro8/REPORT.md)。', '']
    queue_gates = run/'native_budget_instrumented32/GATE_AUDIT.json'
    if queue_gates.exists():
        gates = json.loads(queue_gates.read_text())
        assert gates['status'] == 'observed'
        assert json.loads((run/'native_queue_instrumented_restart/RESTORATION.json').read_text())['restored']
        lines += ['## 原采集流程的准入判定观测', '',
                  '临时字节码仅增加一处观测调用，原指令和元数据一致性经独立校验。32条SQL核验通过：前20条全局select准入开关和JobSpec准入均为true，后12条均为false；会话开关、需要排队、扫描节点和V2仍正常。全局开关翻转是绕过准入的直接条件。其时间与checkpoint加载旧镜像吻合，具体写入来源与修复验证见下文。原FE jar及配置已恢复。该轮不用于性能比较，详见 [判定诊断](native_budget_instrumented32/REPORT.md)。', '']
    checkpoint_fix = run/'checkpoint_variable_regression/RESULT.json'
    if checkpoint_fix.exists():
        fix = json.loads(checkpoint_fix.read_text())
        assert fix['status'] == 'verified' and fix['junit_passed'] == 13 and fix['live_checkpoint_verified']
        lines += ['## Checkpoint覆盖在线准入开关的修复', '',
                  '变量写入栈已直接证实：checkpoint worker加载历史镜像时，经VariableMgr.load改写了在线静态全局变量。修复为checkpoint保留独立历史快照，加载、重放和保存均使用该快照，正常在线赋值仍有效。原包独立镜像回归失败，修复后通过；原有10项与新增3项JUnit全部通过。临时修复包仅替换VariableMgr.class，真实checkpoint完成期间64次采样均保持在线队列开启。原运行包及配置已恢复，后续原生并发须明确使用修复包重新核验，不能改判原失败小测。详见 [修复验证](checkpoint_variable_regression/REPORT.md)。', '']
    historical_admission = run/'historical_admission_audit/RESULT.json'
    if historical_admission.exists():
        history = json.loads(historical_admission.read_text())
        found = sum(s['audit_found'] for s in history['summaries'].values())
        queued = sum(s['pending_field_present'] for s in history['summaries'].values())
        lines += ['## 历史并发的逐查询准入复核', '',
                  f'已找到{found}条历史查询审计，其中{queued}条带PendingTimeMs字段，表明进入全局准入队列。该证据不单独证明每个时刻的限额均为8；详见 [历史准入复核](historical_admission_audit/REPORT.md)。', '']
    fixed_budget = run/'native_budget_fixed32/ALLOCATION_AUDIT.json'
    if fixed_budget.exists():
        proof = json.loads(fixed_budget.read_text())
        restored = json.loads((run/'native_budget_fixed_restart/RESTORATION.json').read_text())
        assert proof['status'] == 'verified' and restored['restored']
        lines += ['## 修复后的原生预算并发小测', '',
                  '使用仅修复VariableMgr checkpoint隔离的FE包，两条开发查询、4客户端、四种模式各一轮预热和正式测量，共32次执行。结果、DOP、预测响应重载和实际槽位分配/释放全部核验通过。辅助查询回调单独核对；数据回调通过模式、表标识和预算多重集与FE审计关联，不宣称单次HTTP请求具有查询ID追踪。原包和设置已恢复。', '',
                  '| 模式 | 整批秒数 | 平均请求毫秒 | QPS |', '|---|---:|---:|---:|']
        for mode, metric in proof['metrics'].items():
            lines.append(f"| {mode} | {metric['batch_seconds']:.3f} | {metric['mean_ms']:.2f} | {metric['qps']:.4f} |")
        lines += ['', '固定预算和预测预算下，异构DOP平均请求延迟分别降低35.22%和27.10%。预算预测本身在查询级和异构模式下降低平均请求延迟15.73%和5.16%，但整批耗时增加4.24%和2.58%，不支持全面性能提升。每模式仅4个正式任务，尾分位只作描述；本轮用于集成门槛，不构成稳定性、未见查询泛化或合同验收。详见 [修复后小测](native_budget_fixed32/REPORT.md)。', '']
    fixed16 = run/'native_budget_fixed128/ALLOCATION_AUDIT.json'
    if fixed16.exists():
        proof = json.loads(fixed16.read_text())
        restored = json.loads((run/'native_budget_fixed16_restart/RESTORATION.json').read_text())
        assert proof['status']=='verified' and proof['executions']==128 and restored['restored']
        lines += ['## 原生预算准入的16客户端验证', '',
                  '在4客户端门槛通过后，仅将客户端数提高至16；保持同两条开发查询、冻结模型、四种模式和一轮预热/正式测量。128次查询结果及实际分配/释放均通过。无重试，排队和预测计入耗时，原FE包与配置恢复。', '',
                  '| 模式 | 整批秒数 | 平均请求毫秒 | QPS |', '|---|---:|---:|---:|']
        for mode, metric in proof['metrics'].items():
            lines.append(f"| {mode} | {metric['batch_seconds']:.3f} | {metric['mean_ms']:.2f} | {metric['qps']:.4f} |")
        lines += ['', '| 对照（正数为改善） | 整批耗时降低 | 平均请求延迟降低 |', '|---|---:|---:|']
        for comparison, metric in proof['latency_reduction_percent'].items():
            lines.append(f"| {comparison} | {metric['batch_seconds']:.2f}% | {metric['mean_ms']:.2f}% |")
        lines += ['', '单轮有限批次用于原生预算在压力下的开发验证，不构成未见查询泛化、稳态吞吐或合同验收。完整四组结果及逐查询证据见 [16客户端验证](native_budget_fixed128/REPORT.md)。', '']
    fixed17 = run/'native_budget_fixed17/ALLOCATION_AUDIT.json'
    if fixed17.exists():
        proof = json.loads(fixed17.read_text())
        restored = json.loads((run/'native_budget_fixed17_restart/RESTORATION.json').read_text())
        assert proof['status']=='verified' and proof['executions']==136 and restored['restored']
        lines += ['## 原生预算准入的17查询覆盖扩展', '',
                  '在2查询16客户端门槛通过后，冻结全部17条现有开发查询，无本轮结果筛选；包含同结构参数变体，不声称17种独立结构。保持16客户端、冻结模型、四种模式和一轮预热/正式测量。136次查询结果及实际分配/释放均通过。无重试，排队和预测计入耗时，原FE包与配置恢复。', '',
                  '| 模式 | 整批秒数 | 平均请求毫秒 | QPS |', '|---|---:|---:|---:|']
        for mode, metric in proof['metrics'].items():
            lines.append(f"| {mode} | {metric['batch_seconds']:.3f} | {metric['mean_ms']:.2f} | {metric['qps']:.4f} |")
        lines += ['', '| 对照（正数为改善） | 整批耗时降低 | 平均请求延迟降低 |', '|---|---:|---:|']
        for comparison, metric in proof['latency_reduction_percent'].items():
            lines.append(f"| {comparison} | {metric['batch_seconds']:.2f}% | {metric['mean_ms']:.2f}% |")
        lines += ['', '单轮有限批次用于原生预算在压力下的开发验证，不构成未见查询泛化、稳态吞吐或合同验收。完整四组结果及逐查询证据见 [17查询覆盖扩展](native_budget_fixed17/REPORT.md)。', '']
    report_features=run/'native_memory_features90_full/IDENTITY_AUDIT.json'
    if report_features.exists():
        feature_proof=json.loads(report_features.read_text())
        assert feature_proof['status']=='verified' and feature_proof['records']==180
        lines += ['## 报告查询的原生预算输入覆盖', '',
                  '冻结90条查询的DOP0和DOP4共180次Explain特征已采集，逐次回调、SQL文本、唯一查询ID、数据库和零扫描审计一致，配置恢复。冻结17查询内存模型可重放全部输入；这证明输入覆盖，不证明内存预测准确或并发收益。', '']
    report_memory=run/'report90_frozen_budget_evaluation/RESULT.json'
    if report_memory.exists():
        evaluation=json.loads(report_memory.read_text())
        if evaluation['status']=='memory_evaluated':
            application=evaluation['policy_application']
            lines += ['实际策略应用：'+str(application['applied'])+'/'+str(application['expected'])+'次；其余回退记录保留在内存评估中，不能全部归为已安装异构DOP。', '']
            lines += ['## 冻结内存模型在报告查询上的评估', '',
                      f"共180个查询/模式组合，内存上界取预热与正式观测的最大值并包含显示舍入。原始预算低于观测峰值的组合数为{evaluation['raw_budget_underestimates']}，编码后名义容量低于观测的组合数为{evaluation['encoded_nominal_underestimates']}；名义容量/观测峰值中位数为{evaluation['median_reservation_ratio']:.2f}，最大为{evaluation['max_reservation_ratio']:.2f}。模型未用报告查询结果重训或选模。观测覆盖不是未来内存保证，也不等同并发吞吐证明。", '']
    report_overload=run/'report90_native_budget_pilot/OVERLOAD_AUDIT.json'
    if report_overload.exists():
        proof=json.loads(report_overload.read_text())
        assert proof['status']=='audited_with_oom'
        assert json.loads((run/'report90_native_budget_pilot_restart/RESTORATION.json').read_text())['restored']
        lines += ['## 报告查询预算小测的过载结果', '',
                  '首2条冻结报告查询、16客户端、四模式共128次尝试。固定预算原生模式预热4次、正式2次BE内存超限，其余模式全部成功。128个FE查询ID及实际槽位分配/释放已核对；失败客户端记录只在批次/查询组层级与FE错误记录关联，不声称逐客户端身份确定。原全成功门槛仍为失败，未扩大90条；原环境恢复。', '',
                  '| 模式 | 正式成功/尝试 | 整批秒数 | 成功QPS |', '|---|---:|---:|---:|']
        for mode,metric in proof['formal_metrics'].items():
            lines.append(f"| {mode} | {metric['verified']}/{metric['expected']} | {metric['workload_wall_seconds']:.3f} | {metric['verified_queries_per_second']:.4f} |")
        lines += ['', '预测预算改善了本轮原生模式的完成率；不同完成率下不直接比较成功查询延迟。需另行校准无OOM的统一预算基线以完成延迟对照，本轮过载结果保持独立。详见 [报告查询小测](report90_native_budget_pilot/REPORT.md)。', '']
    cap4_pilot=run/'report90_native_budget_cap4_pilot/ALLOCATION_AUDIT.json'
    if cap4_pilot.exists():
        proof=json.loads(cap4_pilot.read_text())
        assert proof['status']=='verified'
        assert json.loads((run/'report90_native_budget_cap4_pilot_restart/RESTORATION.json').read_text())['restored']
        lines += ['## 统一4并发预算的事后校准小测', '',
                  '此前统一8并发基线发生OOM，另行冻结统一4并发预算，保留原过载结果。这是观察过报告小测后的基线校准，不是原先预注册的对照。学习模型180个报告输入的预测响应与此前逐条相同；仅统一预算改变。相同首2条查询、16客户端、四种模式共128次均成功并通过实际槽位分配/释放核验，原环境恢复。', '',
                  '| 模式 | 整批秒数 | 平均请求毫秒 | QPS |', '|---|---:|---:|---:|']
        for mode,metric in proof['metrics'].items():
            lines.append(f"| {mode} | {metric['batch_seconds']:.3f} | {metric['mean_ms']:.2f} | {metric['qps']:.4f} |")
        lines += ['', '| 对照 | 整批耗时降低 | 平均请求延迟降低 |', '|---|---:|---:|']
        for name,metric in proof['latency_reduction_percent'].items():
            lines.append(f"| {name} | {metric['batch_seconds']:.2f}% | {metric['mean_ms']:.2f}% |")
        lines += ['', '只有一个正式有限批次，不构成稳定性、稳态吞吐或合同验收。详见 [统一4并发校准](report90_native_budget_cap4_pilot/REPORT.md)。', '']
    cap4_full=run/'report90_native_budget_cap4_full/ALLOCATION_AUDIT.json'
    if cap4_full.exists():
        proof=json.loads(cap4_full.read_text())
        assert proof['status']=='verified' and proof['executions']==720
        assert json.loads((run/'report90_native_budget_cap4_full_restart/RESTORATION.json').read_text())['restored']
        lines += ['## 完整90查询的原生预算并发对照', '',
                  '统一4并发预算校准小测通过后，固定模型与协议扩展到全部90条查询。16客户端，四模式各一轮预热和正式测量，共720次；结果及实际槽位分配/释放全部核验通过，原环境恢复。统一4预算为观察到原8并发OOM后的校准结果；原过载记录保留，未把本轮表述为原预注册对照。', '',
                  '| 模式 | 整批秒数 | 平均请求毫秒 | p50 | p90 | p99 | QPS |', '|---|---:|---:|---:|---:|---:|---:|']
        for mode,metric in proof['metrics'].items():
            lines.append(f"| {mode} | {metric['batch_seconds']:.3f} | {metric['mean_ms']:.2f} | {metric['p50_ms']:.2f} | {metric['p90_ms']:.2f} | {metric['p99_ms']:.2f} | {metric['qps']:.4f} |")
        lines += ['', '| 对照（正数为改善） | 整批耗时降低 | 平均请求延迟降低 |', '|---|---:|---:|']
        for name,metric in proof['latency_reduction_percent'].items():
            lines.append(f"| {name} | {metric['batch_seconds']:.2f}% | {metric['mean_ms']:.2f}% |")
        lines += ['', '报告90条为历史优势筛选子集；本轮为单轮有限批次并发对照，不等同独立泛化、稳态吞吐或标准TPC-H合同验收。策略低置信度回退保留在结果中，适用时的实际DOP单独核验。详见 [完整预算并发实验](report90_native_budget_cap4_full/REPORT.md)。', '']
    logging_cost=run/'predictor_logging_cost/RESULT.json'
    if logging_cost.exists():
        log_cost=json.loads(logging_cost.read_text());last=log_cost['rows'][-1]
        lines += ['## 预测回调的实验记录开销', '',
                  f"当前采集器每次回调重写累计证据快照。冻结中途{last['records']}条回调的离线CPU诊断中，完整JSON序列化中位数为{last['full_snapshot_median_ms']:.2f}毫秒，单条记录为{last['single_record_median_ms']:.3f}毫秒；不含锁、文件写入和网络。prediction_ns仅代表模型计算。不同模式执行次序可能伴随累计日志大小变化，不能把小幅延迟差异直接归因于预算算法，也未使用离线值修正端到端结果。详见 [记录开销](predictor_logging_cost/REPORT.md)。", '']
    queue_tail=run/'native_queue_tail_analysis/RESULT.json'
    if queue_tail.exists():
        tail=json.loads(queue_tail.read_text())
        assert json.loads((run/'native_queue_tail_analysis/SCHEDULER_AUDIT.json').read_text())['status']=='verified'
        small=tail['summaries']['measured/policy_static/slots24'];large=tail['summaries']['measured/policy_static/slots48']
        lines += ['## 预算与排队优先级的耦合诊断', '',
                  f"SWRR实际运行包中24槽位队列权重5，48槽位队列权重2。正式异构配对中，前者{small['count']}条平均排队变化{small['paired_mean_wait_delta_ms']/1000:.2f}秒，后者{large['count']}条变化{large['paired_mean_wait_delta_ms']/1000:.2f}秒。预算同时改变资源占用和队列类别，不能将全部增量仅解释为内存预测质量。两轮配对的实际DOP向量变化{tail['installed_vector_changes']}次；该90条实验没有调度策略干预，结论为机制与观测一致，非单一原因的因果证明。详见 [尾延迟分析](native_queue_tail_analysis/REPORT.md)。", '']
    equal_budget = run/'native_journal_scheduler_comparison/RESULT.json'
    if equal_budget.exists():
        control = json.loads(equal_budget.read_text())
        assert control['status'] == 'verified_pilot' and control['executions'] == 256
        lines += ['## 追加日志后的同预算调度集成对照', '',
                  'SWRR/FIFO 共 256 次执行全部通过核验；使用同一最小 FIFO 测试包和追加式日志。两条查询全部分配 24 槽位，四种模式的平均延迟变化方向不一致，不能据此宣称 FIFO 更优或预算调度有效。此阶段用于验证运行闭环；包含 24/48 槽位的后续小测另行报告。两次启动前空闲检查失败记录保留，未计作执行成功。详见 [同预算调度对照](native_journal_scheduler_comparison/REPORT.md)。', '']
    mixed_budget = run/'native_mixed_scheduler_comparison/RESULT.json'
    if mixed_budget.exists():
        mixed = json.loads(mixed_budget.read_text())
        assert mixed['status'] == 'verified_pilot' and mixed['executions'] == 256
        lines += ['## 混合预算调度小测与计划变化', '', '混合预算 SWRR/FIFO 两组共 256 次执行全部通过核验并恢复原服务。异构预测预算模式中 FIFO 相对 SWRR 的平均延迟增加 6.47%，p90/p99 增加 3.95%/3.30%，未显示一致收益。配对审计发现 64 对异构执行中有 24 对安装 DOP 向量变化；其中一条查询出现 39-fragment/38-exchange 与 38-fragment/37-exchange 两种计划结构，记录的 DOP 会话设置相同。因此本轮不能隔离调度器的因果影响，先定位计划变化，不扩大 FIFO 全量测试。详见 [混合预算对照](native_mixed_scheduler_comparison/REPORT.md)及[配对等待诊断](native_mixed_scheduler_wait_analysis/REPORT.md)。', '']
    stable_budget = run/'native_stable_scheduler_comparison/RESULT.json'
    if stable_budget.exists():
        stable = json.loads(stable_budget.read_text())
        assert stable['executions'] == 256 and stable['status'] == 'measured'
        effect = stable['fifo_reduction_percent']['policy_budget']
        lines += ['## 计划预热后的调度对照', '',
                  f"两条混合预算查询、16客户端、SWRR/FIFO共256次执行。异构执行的计划描述及安装DOP一致性检查：{stable['plan_control_status']}。异构预测预算模式中FIFO相对SWRR平均/p90/p99延迟降低率分别为{effect['mean_ms']:.2f}%/{effect['p90_ms']:.2f}%/{effect['p99_ms']:.2f}%，负值表示恶化。", '',
                  '测量前要求每个查询/DOP组合连续三次完整Explain一致，最多观察六次，全部记录保留。此准备成本不计入在线查询延迟，也不是AutoDOP部署功能。原生关闭AutoDOP的执行没有同等模型请求trace，且两组按固定顺序运行，因此仍不能称为严格因果或显著性验证。详见 [计划预热对照](native_stable_scheduler_comparison/REPORT.md)。', '']
    stable_phases = run/'native_stable_phase_audit/RESULT.json'
    if stable_phases.exists():
        phases = json.loads(stable_phases.read_text())
        formal = [row for row in phases['summary'] if row['phase'] == 'measured']
        if formal and all(row['plan_variants'] == row['dop_variants'] == 1 for row in formal):
            lines += ['阶段分解显示正式阶段64次异构执行的计划描述与DOP向量按查询一致，变化出现在预热阶段。该事后分解不替代原定全程一致性要求。正式阶段FIFO在异构预测预算模式中平均延迟仍增加8.84%，未显示一致收益；不扩大FIFO全量测试。详见 [阶段一致性分解](native_stable_phase_audit/REPORT.md)。', '']
    rounding = run/'budget_rounding_analysis/RESULT.json'
    if rounding.exists():
        assert json.loads(rounding.read_text())['status'] == 'offline_diagnostic'
        lines += ['## 预算预留与槽位取整', '', '离线分解保持冻结预测、安全系数1.25和资源余量系数0.6不变，假设只把2的幂槽位取整改为整数槽位。开发集17折留一验证的名义预留总量减少23.21%，报告180配置减少28.98%；两组均未出现名义容量低于已观测峰值。该离线结果不是OOM安全或吞吐收益保证，不包含部署验证。整数编码已对180份CSV输入验证预测值、预算及邻居不变，固定4并发基线输出不变；在线使用需要配套的可选FE估算器。详见 [预算取整诊断](budget_rounding_analysis/REPORT.md)。', '']
    rounding_measured = run/'native_rounding_comparison/RESULT.json'
    if rounding_measured.exists():
        measured = json.loads(rounding_measured.read_text())
        assert measured['status'] == 'measured' and measured['executions'] == 256
        lines += ['## 整数槽位实测小测', '',
                  '两条冻结查询、16客户端，原取整与整数取整各128次执行，含预热。预测模型、安全系数及SWRR保持相同；槽位大小变化也可能改变SWRR队列类别。正值表示整数取整改善，负值表示恶化。', '',
                  '| 模式 | 整批时间降低 | 平均降低 | p50降低 | p90降低 | p99降低 |',
                  '|---|---:|---:|---:|---:|---:|']
        for mode, effect in measured['integer_reduction_percent'].items():
            lines.append('| '+mode+' | '+' | '.join(f'{effect[k]:.2f}%' for k in ('batch_seconds','mean_ms','p50_ms','p90_ms','p99_ms'))+' |')
        lines += ['', f"全程异构计划/DOP一致性检查：{measured['plan_control_status']}。固定顺序、单次正式批次的结果仅支持小测描述，不证明统计显著性或90查询整体收益。详见 [取整对照](native_rounding_comparison/REPORT.md)。", '']
    timing_diagnostic = run/'native_rounding_timing_diagnostic/RESULT.json'
    if timing_diagnostic.exists():
        timing = json.loads(timing_diagnostic.read_text())
        assert timing['status'] == 'descriptive_timing_audit' and timing['executions'] == 256
        spreads = [b['submit_spread_ms'] for b in timing['batches']]
        lines += ['## 并发波动的时间分解', '',
                  f"已有启动屏障下，各16请求批次的客户端提交跨度为{min(spreads):.3f}–{max(spreads):.3f} ms。固定预算对照中，一类查询的平均排队时间跨组增加6190.38 ms，另一类减少2463.75 ms；预测预算下对应增加2351.38 ms和减少897.88 ms。", '',
                  '客户端提交集中不保证FE完成优化、申请槽位或获得槽位的顺序一致。Time减PendingTimeMs仍包含规划、预测和执行等成本，不能作为纯BE执行时间。当前证据说明需要补充队列时序观测，不能确认波动由客户端启动或某个调度策略单独造成。详见 [时间分解](native_rounding_timing_diagnostic/REPORT.md)。', '']
    queue_timeline = run/'native_queue_timeline_summary/RESULT.json'
    if queue_timeline.exists():
        timeline = json.loads(queue_timeline.read_text())
        assert timeline['status'] == 'descriptive_diagnostic' and timeline['queries'] == 128
        lines += ['## 实际槽位生命周期诊断', '',
                  '两条冻结查询、四种模式共128次执行及387条槽位生命周期事件已完整关联并核验。实验包仅增加可选时序日志，日志开销包含在诊断测量中。固定预算模式入队与获准顺序没有逆序；预测预算存在跨槽位类别重排，同槽位类别内部没有逆序。入队跨度约8–26 ms。', '',
                  '正式异构固定预算和预测预算的工作负载槽位预留比例均接近100%，但这不是CPU或内存利用率。预测预算中大槽位查询的平均持有时间较短，同时等待更久；不能仅用槽位预留减少推断端到端收益。预热与正式阶段首先获准的查询类别存在差异，后续应在明确控制到达顺序的小测中检验其影响，不能由此单独解释历史跨组波动。详见 [实际队列时序](native_queue_timeline_summary/REPORT.md)。', '']
    arrival_path = run/'native_arrival_comparison/RESULT.json'
    if arrival_path.exists():
        arrival = json.loads(arrival_path.read_text())
        assert arrival['status'] == 'measured_diagnostic' and arrival['executions'] == 256
        lines += ['## 相反到达顺序下的预算增量', '',
                  f"两条查询、250 ms固定发送间隔、两种相反分组顺序，共256次执行。实际FE入队顺序控制通过：{arrival['arrival_order_passed']}；全程异构计划/DOP一致性：{arrival['plan_control_status']}。", '',
                  '| 首先到达的查询类别 | 异构预算平均降低 | p50降低 | p90降低 | p99降低 |',
                  '|---|---:|---:|---:|---:|']
        for order in ('low_first','high_first'):
            e = arrival['arms'][order]['effects']['budget_heterogeneous']
            lines.append('| '+order+' | '+' | '.join(f'{e[k]:.2f}%' for k in ('mean_ms','p50_ms','p90_ms','p99_ms'))+' |')
        lines += ['', '正值为预测预算相对固定预算改善，负值为恶化。两种顺序均保留；不能只选择有利顺序宣布预算策略稳定领先。刻意发送前等待不计入SQL延迟，但计入整批耗时。日志诊断和单次正式批次不支持强因果或统计显著性结论。详见 [相反顺序比较](native_arrival_comparison/REPORT.md)。', '']
        phase_path = run/'native_arrival_phase_audit/RESULT.json'
        if phase_path.exists():
            phases = json.loads(phase_path.read_text())
            formal = [r for r in phases['summary'] if r['phase'] == 'measured']
            if formal and all(r['plan_variants'] == r['dop_variants'] == 1 for r in formal):
                lines += ['事后阶段分解显示正式阶段64次异构执行按查询计划描述/DOP一致，变化在预热阶段；该分解不替代全程一致性要求。', '']
    duration_path = run/'development17_duration_screen/RESULT.json'
    if duration_path.exists():
        duration = json.loads(duration_path.read_text())
        assert duration['status'] == 'development_oof_diagnostic' and duration['queries'] == 17
        lines += ['## 开发侧执行时长预测可行性', '',
                  '仅使用17条开发SQL的原生DOP0计划特征和两次串行耗时中位数，按SQL留一，归一化仅拟合每折训练部分。未读取90条报告查询的延迟标签。最近邻与固定正则岭回归均未通过预定筛查，不接入在线调度器。', '',
                  '| 模型 | 中位Q-error | p90 Q-error | 跨查询排序准确率 |',
                  '|---|---:|---:|---:|']
        for name, r in duration['summary'].items():
            lines.append(f"| {name} | {r['median_qerror']:.3f} | {r['p90_qerror']:.3f} | {100*r['pair_accuracy']:.2f}% |")
        lines += ['', '该排序衡量不同查询的耗时顺序，不是同一查询不同DOP候选的排序准确率。留一训练中位数会随被排除样本变化，其排序值不是固定常数预测器的排序表现。特征与标签来自不同批次，精确物理计划一致性未验证；这只用于开发可行性诊断，不代表新调度方案的性能。见 [开发侧时长筛查](development17_duration_screen/REPORT.md)。', '']
    matched_path = run/'matched_development_duration/models/RESULT.json'
    if matched_path.exists():
        matched = json.loads(matched_path.read_text())
        assert matched['status'] == 'development_validation'
        lines += ['## 同次执行特征的开发侧时长模型', '',
                  '61条开发查询、122次原生串行执行及384列原生CSV已完成关联与独立核验，配置已恢复。模型仅使用380个env/operators特征，保留53条训练和8条原有验证查询，同一SQL的两次执行不跨划分。未使用90条报告SQL的耗时训练。', '',
                  '| 模型 | 中位Q-error | p90 Q-error | 跨查询排序准确率 | 预定筛查通过 |',
                  '|---|---:|---:|---:|---|']
        for name,r in matched['summary'].items():
            lines.append(f"| {name} | {r['median_qerror']:.3f} | {r['p90_qerror']:.3f} | {100*r['pair_accuracy']:.2f}% | {r['screen_passed']} |")
        lines += ['', '模型保存后重新加载预测逐值一致。Extra Trees与岭回归通过开发筛查，但验证集此前用于开发，28个查询对不是28个独立样本。该模型预测不同查询的原生串行时长，不能与Transformer的同查询DOP候选排序指标直接比较，也尚未证明调度收益。', '',
                  '采集中3条查询同时写入query和slow_query日志，首次解析误判重复；已按日志类别恢复关联，保留两类原始记录，无SQL重跑或样本删除。预热/正式耗时比的中位数为1.028、最大为1.523，4条查询的模型输入特征发生变化，所有观测均保留。数据见 [开发数据说明](matched_development_duration/README.md)，模型见 [开发验证](matched_development_duration/models/REPORT.md)。', '']
    duration_adapter = run/'matched_development_duration/adapter_audit/RESULT.json'
    if duration_adapter.exists():
        adapter = json.loads(duration_adapter.read_text())
        assert adapter['status'] == 'verified_offline'
        lines += ['## 时长预测接口与推理成本', '',
                  '两个冻结模型各重放122份原生CSV，逐请求预测与批量结果在规定浮点容差内一致。表ID修改不影响预测，非原生DOP0、环境变化与错误CSV被拒绝。以下离线计时包含CSV解析、校验、变换与推理，不含网络和FE特征构建。', '',
                  '| 模型 | 平均 ms | p50 ms | p99 ms |','|---|---:|---:|---:|']
        for name,r in adapter['summary'].items():
            lines.append(f"| {name} | {r['mean_ms']:.4f} | {r['p50_ms']:.4f} | {r['p99_ms']:.4f} |")
    shadow_path = run/'matched_development_duration/shadow/pilot/SHADOW_AUDIT.json'
    if shadow_path.exists():
        shadow = json.loads(shadow_path.read_text())
        assert shadow['status'] == 'verified_shadow' and shadow['restored']
        lines += ['', f"四条开发验证查询的8次在线回调小测已核验并恢复配置。两个模型合计适配与推理平均{shadow['combined_prediction_mean_ms']:.3f} ms、p99 {shadow['combined_prediction_p99_ms']:.3f} ms。时长预测仅记录，不改变DOP、内存核验返回值或准入；这证明接口联通，不能视为调度收益或独立泛化验证。", '',
                  '详见 [适配与成本](matched_development_duration/adapter_audit/REPORT.md) 和 [在线只记录预测的审计](matched_development_duration/shadow/pilot/SHADOW_AUDIT.json)。', '']
    for folder, label in [('duration_concurrent_development', '原生时长排序并发开发小测'),
                          ('duration_bounded_development', '有界时长排序并发开发小测')]:
        path = run/folder/'pilot/AUDIT.json'
        if not path.exists():
            continue
        diagnostic = json.loads(path.read_text())
        assert diagnostic['status'] == 'verified_execution_and_binding'
        lines += ['## '+label, '',
                  '四条开发查询、16客户端、每查询固定24槽，共128次数据执行（含预热）。全部结果、预测回调和槽位生命周期核验通过。两组都计算同一原生时长模型，FIFO组不返回时长头；此对照不是独立原生SWRR实测，也未改变DOP。', '',
                  '| 到达顺序，正数为改善 | 整批耗时降低 | 平均延迟降低 | p50降低 | p90降低 | p99降低 |',
                  '|---|---:|---:|---:|---:|---:|']
        for order, values in diagnostic['comparisons_percent_reduction'].items():
            lines.append('| '+order+' | '+' | '.join(f'{values[k]:.2f}%' for k in
                         ['duration_s','mean_ms','p50_ms','p90_ms','p99_ms'])+' |')
        lines += ['', f"实际查询组到达顺序全部符合计划：{diagnostic['all_arrival_orders_match']}。每个查询的特征CSV种数：{diagnostic['feature_variants_per_query']}。特征一致不等于完整物理计划一致。每个正式批次16次请求，分位数仅作描述，不作显著性或稳态吞吐结论。",
                  '这些是新调度变体的开发小测，不作为当前异构AutoDOP完整系统的性能证据。两个到达方向和不利结果均保留。',
                  f'详见 [完整小测与限制]({folder}/pilot/REPORT.md)。', '']
    stage = run/'policy_final_stage_ablation'
    if (stage/'full/TRAINING_AUDIT.json').exists():
        training = json.loads((stage/'full/TRAINING_AUDIT.json').read_text())
        assert training['status'] == 'verified_recomputed_training_outputs'
        lines += ['## 策略最终训练阶段受控消融', '',
                  '四组均从同一策略检查点开始，使用相同130个训练计划、随机种子和1000轮预算；14个已有验证计划及90条报告SQL不参与梯度更新。最终轮检查点固定，不按在线结果选模。该对照仅覆盖最后的置信度/保留训练阶段，不代表删除整个蒸馏或重建全部历史训练过程。', '',
                  '| 组别 | 训练循环秒 | 训练DOP改变计划 | 训练达阈值计划 | 验证DOP改变计划 | 验证达阈值计划 |',
                  '|---|---:|---:|---:|---:|---:|']
        for arm, values in training['arms'].items():
            t, v = values['train'], values['valid']
            lines.append(f"| {arm} | {values['training_seconds']:.2f} | {t['changed_dop_plans']}/130 | {t['accepted_at_half']}/130 | {v['changed_dop_plans']}/14 | {v['accepted_at_half']}/14 |")
        lines += ['', '配置改变相对于训练前模型；达阈值数量不是最优DOP准确率或查询性能。训练循环时间不包含初始化、图构建、保存及最终重放。四组保存结果均经独立预测重算核验。详见 [训练核验](policy_final_stage_ablation/full/TRAINING_REPORT.md)。', '']
        for phase, label in [('pilot', '四查询功能小测'), ('full', '全部90查询对照')]:
            path = stage/('online_'+phase)/'SUMMARY.json'
            if not path.exists():
                continue
            online = json.loads(path.read_text())
            assert online['status'] == 'verified_complete_paired_summary'
            lines += ['### '+label, '',
                      '五组包含四个重训组及训练前模型；每查询每组预热一次、正式一次，使用相同在线服务路径并保留置信度回退。单次测量只作描述性对照。', '',
                      '| 配置 | 平均 ms | p50 | p90 | p99 | 安装/回退 |',
                      '|---|---:|---:|---:|---:|---:|']
            for mode, values in online['metrics'].items():
                lines.append(f"| {mode} | {values['mean_ms']:.2f} | {values['p50_ms']:.2f} | {values['p90_ms']:.2f} | {values['p99_ms']:.2f} | {values['applied']}/{values['fallback']} |")
            lines += ['', f'逐查询结果及完整组相对各消融组的全部对照见 [在线结果](policy_final_stage_ablation/online_{phase}/REPORT.md)。', '']
        if not (stage/'online_full/SUMMARY.json').exists():
            lines += ['全部90条的在线结果尚未汇总核验，小测不能替代全量结论。', '']
        else:
            full_online = json.loads((stage/'online_full/SUMMARY.json').read_text())
            lines += ['| 完整组相对对照的改善 | 平均 | p50 | p90 | p99 | 更快查询数 |',
                      '|---|---:|---:|---:|---:|---:|']
            for mode, values in full_online['full_vs_ablation'].items():
                cells = ' | '.join(f"{values[k+'_reduction_pct']:.2f}%" for k in ['mean_ms','p50_ms','p90_ms','p99_ms'])
                lines.append(f"| {mode} | {cells} | {values['full_faster_queries']}/90 |")
            lines += ['', '本轮900次执行（含450次预热）及独立响应重放全部通过；完整组在平均延迟上低于各对照，但相对去间隔项和训练前模型的p50略差。每查询每组只有一次正式观测，不作稳定显著性结论。', '']
            mechanism_path = stage/'online_full/MECHANISM_AUDIT.json'
            if mechanism_path.exists():
                mechanism = json.loads(mechanism_path.read_text())
                assert mechanism['status'] == 'verified_response_feature_action_comparison'
                if all(v['same_features']==90 for v in mechanism['formal_vs_full'].values()):
                    lines += ['正式阶段全部90条查询的各组请求特征一致；这不是完整物理计划等价证明。训练改变DOP与改变置信度回退的作用同时存在，不能仅凭总耗时差分离两者。预热阶段存在特征摘要变化，原记录保留。详见 [机制核验](policy_final_stage_ablation/online_full/MECHANISM_AUDIT.json)。', '']
            if (stage/'online_full/COMPANION_WORKLOAD.json').exists():
                lines += ['本轮预热后段启动了CPU35上的离线开发模型训练；SQL控制进程使用CPU27–34、BE使用CPU0–23。CPU集合分离不证明共享缓存、内存或服务器后台干扰不存在；该运行条件见 [伴随负载记录](policy_final_stage_ablation/online_full/COMPANION_WORKLOAD.json)。', '']
    search_pilot = run/'search_refinement_development/pilot/RESULT.json'
    if search_pilot.exists():
        search_result = json.loads(search_pilot.read_text())
        assert search_result['status'] == 'verified' and search_result['executions'] == 64
        lines += ['## 搜索改进开发小测', '',
                  '固定原多阶段教师，比较保留较好配置的补全策略和UCT分数归一化。四条已有开发验证查询、八种配置，每次搜索严格64次模型评分，初始候选和重复评分均计数；注意力计算及完整搜索耗时另记。三个种子生成配置，预先指定种子17用于SQL，每配置每查询预热和正式执行各一次。', '',
                  '| 配置 | 平均 ms | p50 | p90 | p99 |', '|---|---:|---:|---:|---:|']
        for mode, values in search_result['statistics'].items():
            lines.append(f"| {mode} | {values['mean_ms']:.2f} | {values['p50_ms']:.2f} | {values['p90_ms']:.2f} | {values['p99_ms']:.2f} |")
        lines += ['', '完整改进组比原MCTS平均延迟降低14.13%，比原独立随机搜索降低12.06%；去归一化组平均延迟仍更低。全部64次执行及DOP安装核验通过，配置已恢复。该结果是四条重复使用开发查询的单次正式观测，不是统计显著性、90条测试集或全面领先证明。配置回放耗时不包含离线搜索开销。', '',
                  '完整对照和所有不利结果见 [搜索小测](search_refinement_development/pilot/REPORT.md)，逐次搜索评分、实际调用次数和耗时见 [搜索配置记录](search_refinement_development/CHOICES.json)。', '']
    combined_search_path = run/'search_refinement_summary/RESULT.json'
    if combined_search_path.exists():
        combined_search = json.loads(combined_search_path.read_text())
        assert combined_search['status'] == 'verified_disjoint_development_summary'
        lines += ['## 八条开发查询的搜索汇总', '',
                  '首批4条之外的全部剩余4条开发验证查询也已完成相同八方案对照，两批共128次执行全部核验通过。两批SQL不重叠，每查询每方案仅一次正式观测，不能算作重复轮次。', '',
                  '| 完整改进组相对对照 | 平均降低 | p50降低 | p90降低 | p99降低 | 更快查询数 |',
                  '|---|---:|---:|---:|---:|---:|']
        for mode, values in combined_search['comparisons'].items():
            cells = ' | '.join(f'{values[k]:.2f}%' for k in ['mean_ms','p50_ms','p90_ms','p99_ms'])
            lines.append(f"| {mode} | {cells} | {values['faster_queries']}/8 |")
        lines += ['', '总体平均延迟低于所有对照，但第二批完整组平均慢于原MCTS、分组随机和去等价分组；总体相对原MCTS/原随机的尾延迟也未全面占优。该结果支持进一步验证，不能宣称稳定全面领先。', '',
                  '全部查询均保留，两批分别报告，详见 [八条开发查询汇总](search_refinement_summary/REPORT.md) 和 [第二批完整结果](search_refinement_complement/pilot/REPORT.md)。', '']
    accuracy_path = run/'structure_coverage20/accuracy_comparison/RESULT.json'
    if accuracy_path.exists():
        accuracy = json.loads(accuracy_path.read_text())
        assert accuracy['status'] == 'verified_three_seed_accuracy_summary'
        lines += ['## 按排序准确率选模的完整模型对照', '',
                  '根据更新后的验收口径，Transformer比较重点为成对排序准确率，不要求新增实际SQL延迟测量。三个固定种子全部保留，同一920个开发验证对（历史699、复杂221）独立重放。差距小于3%的耗时对统一排除，预测平分计错。各模型按两类等权准确率选模，合并候选对准确率同时报告。', '',
                  '| 模型 | 合并候选对准确率均值 | 两类等权准确率均值 |', '|---|---:|---:|']
        for kind, values in accuracy['aggregate'].items():
            lines.append(f"| {kind} | {100*values['pooled_accuracy']['mean']:.3f}% | {100*values['macro_accuracy']['mean']:.3f}% |")
        lines += ['', 'Transformer在三个种子的合并候选对计分中均高于本轮其他模型，平均86.087%，最佳XGBoost为85.217%；但历史与复杂两类等权时仍落后。合并指标使候选对较多的历史查询占更高权重，两种指标不可混用。模型训练和选模使用过该验证集，因此这不是独立测试集上的领先证明。', '',
                  '完整种子范围、各类正确数、模型分数和共有候选对见 [排序对照与独立核验](structure_coverage20/accuracy_comparison/REPORT.md)。Transformer与竞争边保持整体，新增MLP平滑排序使用相同损失作为对照。', '']
    report_accuracy_path = run/'structure_coverage20/accuracy_observed90/RESULT.json'
    if report_accuracy_path.exists():
        observed_accuracy = json.loads(report_accuracy_path.read_text())
        assert observed_accuracy['status'] == 'complete' and observed_accuracy['queries'] == 90
        lines += ['## 准确率选模后在报告查询集上的复核', '',
                  '将全部7类模型、3个固定种子重新加载，评分90条报告查询已有的1091个实测不同配置，不新增SQL或梯度更新。沿用历史相同配置按模式均值再次求均值的标签口径，排序只计耗时差距至少3%的同查询候选对。', '',
                  '| 模型 | 三种子排序准确率均值 | 种子范围 |', '|---|---:|---:|']
        families = sorted({k.rsplit('_seed',1)[0] for k in observed_accuracy['qualities']})
        for family in families:
            values = [observed_accuracy['qualities'][f'{family}_seed{s}']['rank_accuracy'] for s in [17,29,43]]
            lines.append(f"| {family} | {100*sum(values)/3:.3f}% | {100*min(values):.3f}–{100*max(values):.3f}% |")
        lines += ['', 'Transformer开发验证集上的合并候选对优势未充分扩展到本报告查询集，MLP回归排序仍更高。此复核使用旧BE实测标签及历史候选子集，不是新SQL执行、全搜索空间评估或独立盲测；90条本身也是历史优势筛选子集。', '',
                  '全部逐种子结果和分数见 [报告查询排序复核](structure_coverage20/accuracy_observed90/REPORT.md)。后续实验将继续保留该结果，不据此挑选更有利的种子。', '']
    search_cost_path = run/'search_refinement_report90/COST_SUMMARY.json'
    if search_cost_path.exists():
        search_cost = json.loads(search_cost_path.read_text())
        assert search_cost['status'] == 'verified'
        lines += ['## 九十条查询的搜索开销', '',
                  '全部90条查询、8个方案各执行一次离线搜索，固定种子17，每次64次模型评分。以下为搜索计时段耗时，包含该段内的图构造和重要性计算；不包含模型加载、HTTP服务或SQL执行。', '',
                  '| 方案 | 平均 ms | p50 ms | p90 ms | p99 ms |', '|---|---:|---:|---:|---:|']
        for mode, value in search_cost['modes'].items():
            cells = ' | '.join(f'{value[k]:.2f}' for k in ['mean_ms', 'p50_ms', 'p90_ms', 'p99_ms'])
            lines.append(f'| {mode} | {cells} |')
        lines += ['', '本轮完整改进搜索的平均开销尚未低于原MCTS或独立随机搜索。预先搜索后固定配置回放的SQL延迟不含这笔开销，不能直接称为包含搜索的在线端到端延迟。配置质量需依据正式SQL结果另行判断。', '',
                  '候选覆盖与实际模型调用计数已核验，详见 [搜索开销证据](search_refinement_report90/COST_SUMMARY.json)。原始两种搜索未记录完整候选轨迹，其不同候选数保持未知，不推断为64。', '']
    graph_pilot_path = run/'graph_construction_pilot/RESULT.json'
    graph_verify_path = run/'graph_construction_verification/RESULT.json'
    if graph_pilot_path.exists() and graph_verify_path.exists():
        graph_pilot = json.loads(graph_pilot_path.read_text())
        graph_verify = json.loads(graph_verify_path.read_text())
        assert graph_pilot['status'] == graph_verify['status'] == 'verified'
        assert graph_verify['samples_verified'] == 1577 and graph_verify['tensor_checks'] == 12616
        lines += ['## 图构造开销优化验证', '',
                  '实验实现将竞争矩阵的逐元素张量写入改为先填充列表、再批量创建float32张量。保持竞争边公式、模型、候选预算和搜索算法不变。四条开发查询上的64个图逐张量及模型分数一致，三种搜索共12组输出一致；全部1577个训练/验证配置在已知和未知DOP两种情况下的12616项竞争张量比较均完全一致。', '',
                  '| 搜索 | 原构造平均秒 | 批量构造平均秒 | 降低 |', '|---|---:|---:|---:|']
        for mode, value in graph_pilot['aggregate_seconds'].items():
            lines.append(f"| {mode} | {value['baseline']:.4f} | {value['optimized']:.4f} | {value['reduction_pct']:.2f}% |")
        lines += ['', '以上为共享CPU35、伴随其他离线训练时的四查询配对小测，不能与此前时段约0.92秒的搜索耗时直接比较。优化同样适用于所有搜索对照，不是完整搜索算法独有的收益；生产代码和正在运行的正式SQL配置均未修改。尚未完成最终部署或独占资源下的完整耗时验证。', '',
                  '逐次计时与范围见 [图构造小测](graph_construction_pilot/REPORT.md)，完整配置一致性见 [核验结果](graph_construction_verification/RESULT.json)。', '']
    full_search_path = run/'search_refinement_report90/full/RESULT.json'
    if full_search_path.exists():
        full_search = json.loads(full_search_path.read_text())
        assert full_search['status'] == 'verified' and full_search['executions'] == 1440
        search_restore = json.loads((run/'search_refinement_report90/full/scored/frontend_settings.json').read_text())
        assert search_restore['restored']
        lines += ['## 九十条查询的正式搜索对照', '',
                  '冻结的90条报告查询全部保留，8个方案分别预热一次、正式执行一次，共1440次执行及DOP安装均通过独立核验，FE设置已恢复。所有方案使用原多阶段成本模型，固定64次评分预算；本轮不混入尚在训练的新成本模型。', '',
                  '| 方案 | 平均 ms | p50 ms | p90 ms | p99 ms |', '|---|---:|---:|---:|---:|']
        for mode, value in full_search['statistics'].items():
            cells = ' | '.join(f'{value[k]:.2f}' for k in ['mean_ms', 'p50_ms', 'p90_ms', 'p99_ms'])
            lines.append(f'| {mode} | {cells} |')
        lines += ['', '| 完整改进组相对对照 | 平均降低 | p50降低 | p90降低 | p99降低 | 更快查询数 |',
                  '|---|---:|---:|---:|---:|---:|']
        values = full_search['per_query_ms']
        for mode, value in full_search['full_reduction_percent'].items():
            cells = ' | '.join(f'{value[k]:.2f}%' for k in ['mean_ms', 'p50_ms', 'p90_ms', 'p99_ms'])
            wins = sum(values['refined_full'][q] < latency for q, latency in values[mode].items())
            lines.append(f'| {mode} | {cells} | {wins}/90 |')
        lines += ['', '正数表示完整组延迟更低，负数表示更高。仅每查询每方案一次正式观测，且90条本身为历史优势筛选子集，不能据此声称无偏泛化或稳定统计显著性。固定向量SQL回放不含离线搜索开销。正式测量期间CPU35存在离线训练，CPU集合分离并不排除共享缓存、内存和其他后台干扰。', '',
                  '全部结果、逐查询耗时和独立验证见 [正式搜索对照](search_refinement_report90/full/REPORT.md)；搜索耗时在前文单独报告。新图构造优化未用于本轮正式配置生成。', '']
    search_diagnostic_path = run/'search_refinement_report90/SCORE_LATENCY_DIAGNOSTIC.json'
    if search_diagnostic_path.exists():
        diagnostic = json.loads(search_diagnostic_path.read_text())
        assert diagnostic['status'] == 'verified_posthoc_diagnostic'
        lines += ['## 搜索评分与实际延迟的一致性', '',
                  f"本轮8种搜索的最终配置去重后共{diagnostic['unique_configurations']}个，以同查询耗时差至少3%构造{diagnostic['pairs']}对，原多阶段模型正确{diagnostic['correct']}对，准确率{100*diagnostic['pair_accuracy']:.2f}%。这是被各搜索选中的候选子集，不能与全候选池准确率直接混用。重复配置取各模式实测耗时均值，不删除不利查询。", '',
                  '完整搜索有74/90条查询取得比独立随机搜索更高的模型评分，但其中33条实际延迟至少高3%。结果提示搜索目标的评分误差可能限制实际收益，不能只用搜索得到更高分证明有效。单次正式执行以及准备阶段评分输入仍限制因果解释。', '',
                  '该诊断不进行训练或参数选择，完整证据见 [评分与延迟核验](search_refinement_report90/SCORE_LATENCY_DIAGNOSTIC.json)。', '']
    interaction_summary_path = run/'structure_coverage20/interaction_accuracy_comparison/RESULT.json'
    if interaction_summary_path.exists():
        interaction_summary = json.loads(interaction_summary_path.read_text())
        assert interaction_summary['status'] == 'verified_three_seed_accuracy_summary'
        lines += ['## 交互特征模型三种子复核', '',
                  '保留Transformer和竞争边整体，加入显式DOP与数值/类别特征交互输入，从原多阶段模型保持初始预测一致后训练。三个固定种子均完成100轮、按预定准确率选模并独立重放同一920个开发验证对。', '',
                  '| 模型 | 两类等权准确率均值 | 汇总准确率均值 |', '|---|---:|---:|']
        for kind, metrics in interaction_summary['aggregate'].items():
            lines.append(f"| {kind} | {100*metrics['macro_accuracy']['mean']:.3f}% | {100*metrics['pooled_accuracy']['mean']:.3f}% |")
        lines += ['', '该输入修改未改善既定主指标：Transformer两类等权均值84.798%，仍低于XGBoost成对排序88.106%。两个种子的汇总准确率也未超过XGBoost，不能用首个种子的结果宣称稳定领先。模型未部署，完整结果保留。', '',
                  '详见 [三种子独立排序核验](structure_coverage20/interaction_accuracy_comparison/REPORT.md)。新增分数间距约束和邻域数据训练属于另外的实验，不与本表混算。', '']
    interaction90_path = run/'structure_coverage20/interaction_observed90/RESULT.json'
    if interaction90_path.exists():
        interaction90 = json.loads(interaction90_path.read_text())
        assert interaction90['status'] == 'complete' and interaction90['queries'] == 90
        rank_means = {kind: sum(interaction90['qualities'][f'{kind}_seed{s}']['rank_accuracy'] for s in [17,29,43])/3
                      for kind in ['transformer', 'xgboost_pairs', 'mlp_regression']}
        lines += [f"交互模型在90条查询已有1091个实测配置上的离线复核也未领先：三种子平均排序准确率为{100*rank_means['transformer']:.3f}%，XGBoost成对排序为{100*rank_means['xgboost_pairs']:.3f}%，MLP回归为{100*rank_means['mlp_regression']:.3f}%。使用历史候选标签，未新增SQL、拟合或按报告查询选模；该候选池与本轮搜索最终配置子集不同，准确率不可直接混用。", '',
                  '完整评分见 [交互模型的报告查询排序复核](structure_coverage20/interaction_observed90/REPORT.md)。', '']
    calibration_path = run/'structure_coverage20/calibration_accuracy_comparison/RESULT.json'
    if calibration_path.exists():
        calibration = json.loads(calibration_path.read_text())
        assert calibration['status'] == 'verified_three_seed_accuracy_summary'
        lines += ['## 分数间距校准模型排序复核', '',
                  '按更新后的验收要求，本阶段只核验模型成对排序准确率，不新增Transformer实际SQL延迟测试。Transformer与竞争边保留为整体；增加分数间距校准损失，三个固定种子各训练100轮，按开发集两类等权准确率选择检查点。所有模型重放相同920对，不选择最佳种子。', '',
                  '| 模型 | 两类等权准确率均值 | 汇总准确率均值 |', '|---|---:|---:|']
        for kind, metrics in calibration['aggregate'].items():
            lines.append(f"| {kind} | {100*metrics['macro_accuracy']['mean']:.3f}% | {100*metrics['pooled_accuracy']['mean']:.3f}% |")
        lines += ['', 'Transformer汇总准确率已领先，但既定两类等权主指标仍低于XGBoost排序，尚未达到模型验收目标。验证集已多次用于开发，不能称为独立盲测。', '',
                  '详见 [三种子校准模型核验](structure_coverage20/calibration_accuracy_comparison/REPORT.md)。', '']
        uncertainty_path = run/'structure_coverage20/calibration_accuracy_comparison/QUERY_BOOTSTRAP.json'
        if uncertainty_path.exists():
            uncertainty = json.loads(uncertainty_path.read_text())
            assert uncertainty['status'] == 'verified_query_cluster_bootstrap'
            interval = uncertainty['contrasts']['xgboost_pairs']['percentile95_interval_pp']
            lines += [f'按查询整体重采样、在两类内分层进行10000次配对bootstrap，Transformer相对XGBoost排序的等权准确率差值95%百分位区间为[{interval[0]:.3f}, {interval[1]:.3f}]个百分点。区间跨零，不能据此证明稳定领先或稳定落后。它仅描述固定模型下查询组成的不确定性；验证集被反复用于选模，区间未校正选择偏差，也不代表训练种子或SQL重复测量的不确定性。见 [查询级区间](structure_coverage20/calibration_accuracy_comparison/QUERY_BOOTSTRAP.md)。', '']
        retrospective_path = run/'structure_coverage20/calibration_observed90/RESULT.json'
        if retrospective_path.exists():
            retrospective = json.loads(retrospective_path.read_text())
            assert retrospective['status'] == 'complete' and retrospective['queries'] == 90
            lines += ['90条历史报告查询的已有候选排序复核（未新增SQL、训练或选模）：', '',
                      '| 模型 | 三种子平均成对准确率 |', '|---|---:|']
            for kind in calibration['aggregate']:
                accuracy = sum(retrospective['qualities'][f'{kind}_seed{s}']['rank_accuracy'] for s in [17,29,43])/3
                lines.append(f'| {kind} | {100*accuracy:.3f}% |')
            lines += ['', '该池包含1091个已有实测配置，90条查询为历史优势筛选子集，并非独立盲测。详见 [报告查询排序复核](structure_coverage20/calibration_observed90/REPORT.md)。', '']
    pilot_summary_path = run/'structure_coverage20/matched_training_pilots/RESULT.json'
    if pilot_summary_path.exists():
        pilots = json.loads(pilot_summary_path.read_text())
        assert pilots['status'] == 'verified_matched_pilot_summary'
        lines += ['## 匹配训练方式小测', '',
                  '保持原Transformer及竞争边结构、校准损失、1365个训练样本和212个验证样本不变，比较五种训练方式。均为seed17、30轮，使用相同920对开发验证对；各实验XGBoost对照的全部预测分数一致。', '',
                  '| 训练方式 | 两类等权准确率 | 汇总准确率 | 选定轮次 |', '|---|---:|---:|---:|']
        for label, value in pilots['records'].items():
            lines.append(f"| {label} | {100*value['macro_accuracy']:.3f}% | {100*value['pooled_accuracy']:.3f}% | {value['selected_epoch']} |")
        lines += ['', '每10轮刷新训练错对的方案取得88.003%等权准确率，仍略低于XGBoost排序88.106%；每轮刷新降至85.917%，未通过扩大门槛。错对挖掘只读取训练样本，不使用报告查询；额外训练评分成本单独保留。单种子、反复使用的开发验证结果不构成稳定领先或独立盲测结论。', '',
                  '完整曲线与来源见 [匹配小测汇总](structure_coverage20/matched_training_pilots/REPORT.md)。', '']
    ema_pilot_path = run/'structure_coverage20/hard_pair_ema_pilot/pair_audit/RESULT.json'
    if ema_pilot_path.exists():
        ema_pilot = json.loads(ema_pilot_path.read_text())
        assert ema_pilot['status'] == 'verified_independent_pair_replay'
        trajectory = json.loads((run/'structure_coverage20/hard_pair_ema_pilot/TRAJECTORY_AUDIT.json').read_text())
        assert trajectory['status'] == 'verified_exact'
        lines += ['## 错对强化与权重平均复核', '',
                  '原Transformer与竞争边整体保留，训练错对池每10轮刷新、50%混合采样；新增固定0.99权重滑动平均，每次梯度更新后更新平均权重，用于验证和检查点保存。seed17的30轮损失及原始模型83个状态张量与无权重平均对照完全一致，训练数据和梯度轨迹未改变。', '',
                  'seed17小测等权准确率88.229%，高于XGBoost排序88.106%，差值仅0.123个百分点；汇总准确率88.696%。单种子小幅领先不足以证明稳定性，三个固定种子全部保留。', '']
        ema_summary_path = run/'structure_coverage20/hard_pair_ema_stability/RESULT.json'
        if ema_summary_path.exists():
            ema_summary = json.loads(ema_summary_path.read_text())
            assert ema_summary['status'] == 'verified_three_seed_summary'
            lines += ['三个种子均使用相同30轮训练预算和920个验证对，检查点按两类等权准确率选择；未新增超参数或选择最佳种子。', '',
                      '| 模型 | 等权准确率均值 | 种子范围 | 汇总准确率均值 |', '|---|---:|---:|---:|']
            for kind, value in ema_summary['models'].items():
                m = value['macro_accuracy']
                lines.append(f"| {kind} | {100*m['mean']:.3f}% | {100*m['minimum']:.3f}–{100*m['maximum']:.3f}% | {100*value['pooled_accuracy']['mean']:.3f}% |")
            lines += ['', f"是否每个种子都按等权指标超过全部对照：{'是' if ema_summary['every_seed_macro_beats_all_controls'] else '否'}。反复用于开发的验证集不能称为盲测，三个种子也不代表2760个独立查询对。详见 [三种子复核](structure_coverage20/hard_pair_ema_stability/REPORT.md)。", '']
        else:
            lines += ['三种子汇总尚未完成，当前只支持单种子小测结论。', '']
        ema90_path = run/'structure_coverage20/hard_pair_ema_observed90/RESULT.json'
        if ema90_path.exists():
            ema90 = json.loads(ema90_path.read_text())
            assert ema90['status'] == 'complete' and ema90['queries'] == 90 and ema90['observed_configurations'] == 1091
            lines += ['90条报告查询已有1091个实测候选的离线排序复核：', '', '| 模型 | 三种子平均排序准确率 |', '|---|---:|']
            for kind in ['transformer','xgboost_points','xgboost_pairs','mlp_rank','mlp_smooth_rank','mlp_regression','xgb_regression']:
                mean = sum(ema90['qualities'][f'{kind}_seed{s}']['rank_accuracy'] for s in [17,29,43])/3
                lines.append(f'| {kind} | {100*mean:.3f}% |')
            lines += ['', '仅重放历史候选标签，未新增SQL或按本结果训练、选模。90条为历史优势筛选子集，不是独立盲测。详见 [报告查询排序复核](structure_coverage20/hard_pair_ema_observed90/REPORT.md)。', '']
    ensemble_path = run/'structure_coverage20/hard_pair_ema_ensemble/RESULT.json'
    if ensemble_path.exists():
        ensemble = json.loads(ensemble_path.read_text())
        assert ensemble['status'] == 'verified_fixed_score_ensemble'
        lines += ['## 固定三检查点分数平均诊断', '',
                  '对每种模型都采用预先固定的三个种子分数算术平均，未学习权重、选择种子或使用报告查询训练。它是三检查点模型，不能替代单模型结果；每次评分最多需要三个模型推理及对应存储，额外运行开销尚未实测。', '',
                  '| 模型（三检查点平均） | 开发集等权准确率 | 开发集汇总准确率 |', '|---|---:|---:|']
        for kind, value in ensemble['models'].items():
            lines.append(f"| {kind} | {100*value['macro_accuracy']:.3f}% | {100*value['pooled_accuracy']:.3f}% |")
        lines += ['', '开发集等权准确率Transformer为88.693%，高于同样聚合的全部对照，但这是反复使用的开发验证集，不能证明独立测试领先。详见 [固定平均诊断](structure_coverage20/hard_pair_ema_ensemble/REPORT.md)。', '']
        ensemble90_path = run/'structure_coverage20/hard_pair_ema_ensemble_observed90/RESULT.json'
        if ensemble90_path.exists():
            ensemble90 = json.loads(ensemble90_path.read_text())
            assert ensemble90['status'] == 'verified_fixed_ensemble_observed90'
            lines += ['同一固定规则应用于90条查询的1091个已有实测候选：', '', '| 模型（三检查点平均） | 排序准确率 |', '|---|---:|']
            for kind, value in ensemble90['models'].items():
                lines.append(f"| {kind} | {100*value['rank_accuracy']:.3f}% |")
            lines += ['', 'Transformer为88.372%，高于XGBoost排序88.077%，但低于MLP回归89.361%；没有达到报告查询上超过全部对照的目标。没有新增SQL、筛掉不利查询或据此重新选模。详见 [报告候选复核](structure_coverage20/hard_pair_ema_ensemble_observed90/REPORT.md)。', '']
    flat_residual_path = run/'structure_coverage20/flat_residual_pilot/pair_audit/RESULT.json'
    if flat_residual_path.exists():
        flat_residual = json.loads(flat_residual_path.read_text())
        assert flat_residual['status'] == 'verified_independent_pair_replay'
        budget = json.loads((run/'structure_coverage20/flat_residual_pilot/PARAMETER_BUDGET.json').read_text())
        lines += ['## 固定特征残差结构小测', '',
                  '保留原Transformer、竞争边和全局读出，增加固定特征残差MLP。当前扩展词表的表示为1088维，与本阶段对照一致；原始历史模型阶段为1040维。归一化从1365个训练样本独立重算验证，新增输出层零初始化，1577个配置初始预测与原模型完全一致。', '',
                  f"新增{budget['residual_parameters']}个参数，总参数量从{budget['original_parameters']}增至{budget['hybrid_parameters']}；这是新的混合结构，不能称作原模型结果。seed17、30轮，数据、原采样和校准损失不变。", '',
                  '| 模型 | 等权准确率 | 汇总准确率 |', '|---|---:|---:|']
        for kind, value in flat_residual['models'].items():
            label = 'Transformer + fixed-feature residual' if kind == 'transformer' else kind
            lines.append(f"| {label} | {100*value['macro_accuracy']:.3f}% | {100*value['pooled_accuracy']:.3f}% |")
        lines += ['', '混合结构等权准确率85.263%，低于匹配原结构86.156%与XGBoost排序88.106%，未扩大或部署。新分支尚未纳入fragment重要性估计，不能据此直接替换搜索模型；CPU原型检查点被生产加载器拒绝。详见 [结构小测](structure_coverage20/flat_residual_pilot/REPORT.md)。', '']
        fast_path = run/'structure_coverage20/flat_residual_fast_pilot/pair_audit/RESULT.json'
        if fast_path.exists():
            fast = json.loads(fast_path.read_text())
            assert fast['status'] == 'verified_independent_pair_replay'
            lines += [f"随后仅将新分支学习率设为原图模型的10倍（图模型1e-4、分支1e-3），同30轮小测等权准确率为{100*fast['models']['transformer']['macro_accuracy']:.3f}%，低于等学习率设置85.263%，未扩大或部署。见 [分支学习率小测](structure_coverage20/flat_residual_fast_pilot/REPORT.md)。", '']
        component_path = run/'structure_coverage20/flat_residual_pilot/COMPONENT_DIAGNOSTIC.json'
        if component_path.exists():
            component = json.loads(component_path.read_text())
            assert component['status'] == 'verified_posthoc_component_scores'
            lines += ['固定等学习率检查点的事后分支诊断：完整模型训练对等权准确率97.274%，验证对85.263%；验证时仅使用已联合训练的图分支为83.548%。这不是分别重训的消融；训练使用6702个批次内标签对，验证使用920个标准3%候选对，两者标签范围不同，不能将差值直接解释为某一原因导致的泛化损失。见 [分支评分诊断](structure_coverage20/flat_residual_pilot/COMPONENT_DIAGNOSTIC.json)。', '']
    coverage_path = run/'structure_coverage20/training_coverage_audit/EFFECTIVE_DOMAINS.json'
    if coverage_path.exists():
        coverage = json.loads(coverage_path.read_text())
        assert coverage['status'] == 'verified_effective_domain_audit'
        lines += ['## 训练配置覆盖诊断', '',
                  '重新按实际可调fragment统计，固定gather根节点的DOP1不算异构调优。36条复杂训练查询共有288配置：180个统一DOP、108个异构DOP，即每查询5个统一配置和3个异构配置；每查询的中心化log2(DOP)矩阵秩均为4。此前按原始DOP是否多值统计会包含固定gather与其他fragment的差异，不能直接称为异构配置数。', '',
                  '复杂验证查询的fragment规模与DOP范围基本被训练覆盖，仅少量未见类别或数值越界。单查询内独立扰动有限，是下一步采集要检验的假设；不能由此断定共享非线性模型无法学习，或把它当成已证明的性能差距原因。', '',
                  '已设计训练专用的单组高低DOP对照：4条查询、每条9配置，预热与正式各一次，共72次执行；其他组固定，仅将目标组改为合法最低/最高DOP。初版候选在执行前发现gather约束问题并作废，v2已固定gather为1，初版没有执行SQL。该采集不修改活动训练数据，需完成验证后再决定是否用于训练。', '',
                  '详见 [实际可调域覆盖核对](structure_coverage20/training_coverage_audit/REPORT_EFFECTIVE.md)。', '']
        contrasts_path = run/'training_contrasts_pilot_v2/SUMMARY.json'
        if contrasts_path.exists():
            contrasts = json.loads(contrasts_path.read_text())
            assert contrasts['status'] == 'verified_controlled_contrast_summary'
            collection = json.loads((run/'training_contrasts_pilot_v2/collection/RESULT.json').read_text())
            assert collection['status'] == 'verified' and collection['executions'] == 72
            assert json.loads((run/'training_contrasts_pilot_v2/collection/scored/frontend_settings.json').read_text())['restored']
            lines += ['72次执行及DOP安装均已通过独立核验，FE设置恢复。四条训练查询的局部聚合组均表现为低DOP更快，预热与正式方向一致；DOP16相对DOP1的正式延迟增加约14.96%–57.19%。其他组多数差距小或方向不稳定。16个端点对照中仅8个正式差距达到3%，6个在两阶段均达到3%，其中4个方向一致。', '',
                      '36个配置共形成103个正式有效排序对；预热与正式均满足3%的77对中有56对方向一致。每条查询的worker重叠矩阵保持一致，但只有一次正式观测，不能据此声称统计显著或把全部新标签视为可靠监督。原始数据全部保留，尚未并入活动训练集。详见 [单组DOP对照](training_contrasts_pilot_v2/REPORT.md)。', '',
                      '后续条件对照已冻结：同四条训练查询将上述聚合组固定为DOP1，再测试其余三组，共28配置、56次执行；用于检查上下文是否掩盖其他组效应，不按测试或验证结果选样。', '']
        conditional_path = run/'training_conditional_contrasts/SUMMARY.json'
        if conditional_path.exists():
            conditional = json.loads(conditional_path.read_text())
            assert conditional['status'] == 'verified_controlled_contrast_summary'
            assert json.loads((run/'training_conditional_contrasts/collection/RESULT.json').read_text())['executions'] == 56
            assert json.loads((run/'training_conditional_contrasts/collection/scored/frontend_settings.json').read_text())['restored']
            lines += ['56次条件对照也已完成并核验，设置恢复。12组对照中7组正式差距≥3%，4组两阶段都≥3%，其中仅2组方向一致；没有正式差距≥20%的组。四个相同锚点配置跨批次变化约−1.63%至+2.27%，两批标签没有混合。详见 [条件对照](training_conditional_contrasts/REPORT.md)及 [跨批次与资源核对](training_conditional_contrasts/CONTEXT_COMPARISON.md)。', '',
                      'UNION训练查询出现相反偏好的描述性案例：局部聚合组DOP1/16对应1224/1924ms；将该组固定1后，合并聚合组DOP1/16对应1332/1175ms，高DOP快11.79%，预热与正式方向一致。这是事后选择的解释案例，两个对照背景不同，并非完整2×2实验、统一DOP基线比较或自动模型选优证据。其他查询与不利结果均保留，见 [案例与图表](training_contrast_case_study/REPORT.md)。', '',
                      '原局部聚合组高DOP的查询CPU计数增加约5.81%–21.75%，扫描行数和字节在对应低/高对照中一致；该计数属于整个查询，不能直接称作该fragment的CPU开销。整体采集信号仍不足以把所有新对作为可靠标签直接重训，活动训练集未改变。', '']
    probe_path = run/'training_probe_model_diagnostic/RESULT.json'
    if probe_path.exists():
        probe = json.loads(probe_path.read_text())
        assert probe['status'] == 'verified_frozen_model_probe_diagnostic'
        t = probe['models']['transformer_ensemble']['all_within_batch_pairs']['rank_accuracy']
        x = probe['models']['xgboost_pairs_ensemble']['all_within_batch_pairs']['rank_accuracy']
        lines += [f'冻结模型对全部139个新配置批次内有效对的诊断：Transformer三种子平均准确率{100*t:.2f}%，XGBoost排序{100*x:.2f}%。这是已知训练查询的新配置，不能替代未见查询评估；完整对照见 [预测核对](training_probe_model_diagnostic/REPORT.md)。', '']
    repeat_path = run/'training_conditional_contrasts/FORMAL_REPEAT_SUMMARY.json'
    if repeat_path.exists():
        repeated = json.loads(repeat_path.read_text())
        assert repeated['status'] == 'verified_formal_repeat_consistency'
        counts = repeated['totals']
        lines += [f"条件对照的28个配置已全部复测一轮；12组端点中，两轮正式差距均≥3%且方向一致的有{counts['endpoints_both_ge3pct_same_order']}组。两轮都达到3%的{counts['both_eligible']}个查询对中，{counts['both_eligible_same_order']}对方向一致。仅两次正式观测，不能宣称统计显著；保留所有配置，未跨批次拼接标签。见 [正式复测](training_conditional_contrasts/FORMAL_REPEAT_REPORT.md)。", '']
        lines += ['此前UNION合并聚合组高DOP快11.79%的案例未复现，第二轮为慢5.61%。原案例图仅保留为首轮观测记录，不能视为稳定的相反偏好证据。见 [案例复测更新](training_contrast_case_study/REPLICATION_UPDATE.md)。条件对照标签不并入训练，不无条件扩大采集。', '']
    gap_path = run/'structure_coverage20/pair_gap_pilot/RESULT.json'
    if gap_path.exists():
        gap = json.loads(gap_path.read_text())
        assert gap['status'] == 'verified'
        lines += ['成对对数延迟比回归小测已完成：原多阶段Transformer与竞争边保留，仅改训练损失，seed17、30轮的两组等权准确率85.321%，低于匹配原损失86.156%及XGBoost排序88.106%。独立重算920对一致，未扩大训练、未新增模型SQL对照。见 [损失小测](structure_coverage20/pair_gap_pilot/REPORT.md)。', '']
    parameter_path = run/'structure_coverage20/parameter_anchor_pilot/pair_audit/RESULT.json'
    if parameter_path.exists():
        parameter = json.loads(parameter_path.read_text())
        assert parameter['status'] == 'verified_independent_pair_replay'
        t = parameter['models']['transformer']['macro_accuracy']
        decision = json.loads((run/'structure_coverage20/parameter_anchor_pilot/RESULT.json').read_text())
        lines += [f"参数锚定小测保留错对强化和EMA，增加相对原多阶段参数的固定0.001距离惩罚。seed17、30轮，两组等权准确率{100*t:.3f}%，匹配的未锚定对照{100*decision['reference_macro_accuracy']:.3f}%；扩大门槛通过：{decision['expansion_gate_passed']}。这是训练正则化小测，不改变推理结构，也未新增SQL。见 [参数锚定](structure_coverage20/parameter_anchor_pilot/REPORT.md)。", '']
    ledger_path = run/'structure_coverage20/recent_model_tuning_audit/RESULT.json'
    if ledger_path.exists():
        ledger = json.loads(ledger_path.read_text())
        assert ledger['status'] == 'verified_recent_trial_ledger'
        lines += ['低排序温度小测已完成：seed17、30轮准确率87.978%，低于匹配原温度88.229%与XGBoost排序88.106%，不扩大。近期10项小测的匹配对照及扩大门槛已统一核对，见 [近期小测汇总](structure_coverage20/recent_model_tuning_audit/REPORT.md)。EMA单次通过，但此前三种子平均86.442%仍未领先。', '',
                  '训练监督核对：6702条原批次训练对包含6285条不同有向关系，未发现相反标签或循环排序；这不等价于证明测量无噪声。分数差导数诊断说明已有损失并未忽略错对，亦不能从导数分配直接推断泛化收益。见 [导数诊断](structure_coverage20/pair_gradient_audit/REPORT.md)。', '']
    identity_path = run/'structure_coverage20/input_identity_audit/RESULT.json'
    if identity_path.exists():
        identity = json.loads(identity_path.read_text())
        assert identity['status'] == 'verified_input_identity_audit'
        lines += ['模型输入核对：1577个DOP向量经编码后均可无损还原，同一查询内部未发现不同配置的精确图输入或平坦特征碰撞；原训练对输入碰撞为0。此检查不等价于图同构、表示压缩或泛化保证。见 [输入可区分性](structure_coverage20/input_identity_audit/REPORT.md)。', '']
    reconstruction_path = run/'structure_coverage20/feature_reconstruction_pilot/pair_audit/RESULT.json'
    if reconstruction_path.exists():
        reconstruction = json.loads(reconstruction_path.read_text())
        assert reconstruction['status'] == 'verified_independent_pair_replay'
        decision = json.loads((run/'structure_coverage20/feature_reconstruction_pilot/RESULT.json').read_text())
        score = reconstruction['models']['transformer']['macro_accuracy']
        lines += [f"训练期特征重建小测：保留原Transformer、竞争边、错对强化与EMA，增加仅训练时使用的统计特征重建头。seed17、30轮，两组等权排序准确率{100*score:.3f}%，匹配对照{100*decision['reference_macro_accuracy']:.3f}%；扩大门槛通过：{decision['expansion_gate_passed']}。辅助头不进入推理，但增加训练计算。见 [重建辅助小测](structure_coverage20/feature_reconstruction_pilot/REPORT.md)。", '']
    frozen_path = run/'structure_coverage20/frozen_probe_stability_v2/THREE_SEED_SUMMARY.json'
    if frozen_path.exists():
        frozen = json.loads(frozen_path.read_text())
        assert frozen['status'] == 'verified_three_seed_frozen_probe'
        lines += [f"冻结编码器后重新拟合成对线性读出，三种子平均准确率从{100*frozen['original_mean']:.3f}%变为{100*frozen['linear_mean']:.3f}%，仍低于XGBoost排序88.106%。同样线性读出用于原始统计特征时为81.921%，微调图表示的seed17为88.229%；说明图表示具有可线性利用的信息，但简单替换读出未解决稳定领先。全部固定种子与设置保留，见 [三种子读出诊断](structure_coverage20/frozen_probe_stability_v2/THREE_SEED_REPORT.md)及 [特征对照](structure_coverage20/frozen_representation_probe/REPORT.md)。", '']
    average_path = run/'structure_coverage20/hard_ema_parameter_average/RESULT.json'
    if average_path.exists():
        average = json.loads(average_path.read_text())
        assert average['status'] == 'verified_fixed_parameter_average'
        lines += [f"三个固定错对强化EMA检查点做等权参数平均，两组等权准确率为{100*average['quality']['macro_accuracy']:.3f}%，低于XGBoost88.106%及相同父模型的分数平均88.693%。未选种子子集或搜索混合权重；保持单模型推理结构，但需要三次父模型训练。未扩大或部署，见 [参数平均小测](structure_coverage20/hard_ema_parameter_average/REPORT.md)。", '']
    conflict_path = run/'structure_coverage20/cohort_gradient_conflict/RESULT.json'
    if conflict_path.exists():
        conflict = json.loads(conflict_path.read_text())
        assert conflict['status'] == 'verified_training_cohort_gradient_audit'
        lines += ['训练梯度诊断：预定4个小批次中，多阶段初始模型的历史/复杂查询梯度均为负点积，训练后原始模型为1/4；现有训练已缓解部分冲突。该小样本不能证明冲突导致泛化差距或梯度投影必然有效。仅训练数据参与，见 [两类查询梯度诊断](structure_coverage20/cohort_gradient_conflict/REPORT.md)。', '']
    projected_path = run/'structure_coverage20/projected_cohort_pilot/RESULT.json'
    if projected_path.exists():
        projected = json.loads(projected_path.read_text())
        assert projected['status'] == 'verified'
        checks = json.loads((run/'structure_coverage20/projected_cohort_pilot/GRADIENT_CHECK.json').read_text())
        assert checks['status'] == 'verified_gradient_algebra_and_counters'
        lines += ['两类梯度对称投影小测完成：保留错对强化与EMA，仅当小批次的历史/复杂查询梯度负点积时投影。seed17、30轮，两组等权准确率87.264%，低于匹配对照88.229%和XGBoost排序88.106%；1170次更新中591次执行投影，四项梯度代数检查和920对独立重算通过。未扩大、未增加SQL或改动线上模型。见 [梯度投影小测](structure_coverage20/projected_cohort_pilot/REPORT.md)。', '']
    batch_path = run/'batched_cost_verification/RESULT.json'
    if batch_path.exists():
        batch = json.loads(batch_path.read_text())
        pilot = json.loads((run/'batched_cost_pilot/RESULT.json').read_text())
        assert batch['status'] == 'verified_batched_numerical_parity' and pilot['status'] == 'verified_batch_inference_pilot'
        lines += ['## 候选批量评分成本', '', '实验性批量推理在不改变权重的情况下同时评分同fragment数的多个候选；当前未接入生产或搜索路径。单CPU、单torch线程，预构图后交替计时10轮，包含张量堆叠；不含构图、HTTP、FE或SQL。共享服务器上的局部微测不能当作独占资源下的端到端收益。', '', '| fragment数 | 候选数 | 逐条评分中位ms | 批量评分中位ms | 降低 |', '|---:|---:|---:|---:|---:|']
        for row in pilot['queries']:
            lines.append(f"| {row['fragments']} | {row['configs']} | {row['median_scalar_ms']:.3f} | {row['median_batch_ms']:.3f} | {100*(1-row['median_batch_ms']/row['median_scalar_ms']):.2f}% |")
        lines += ['', '2个fragment一行仅为数值/成本边界测试；当前控制器对少于5个fragment的查询绕过AutoDOP，不能将该行记为实际调优收益。10/31/46个fragment的局部评分耗时降低约62%–76%。', '', '四检查点、1577样本及已知/未知DOP模式共12616个分数满足预定数值容差。已知DOP下首选候选和所有3%有效查询对的排序未变；6个不满足3%差距的近并列对发生次序变化，因此不声称逐位相同或任意新输入的排序保证。未知DOP模式未做候选排序验证。顺序依赖的MCTS不能直接照搬批量评分收益。见 [小测原始计时](batched_cost_pilot/REPORT.md)及 [完整数值核验](batched_cost_verification/REPORT.md)。', '']
    pipeline_path = run/'candidate_pipeline_cost/RESULT.json'
    if pipeline_path.exists():
        pipeline = json.loads(pipeline_path.read_text())
        assert pipeline['status'] == 'verified_candidate_pipeline_cost' and pipeline['graph_module_unmodified']
        lines += ['完整本地候选处理成本另做2×2对照：原始/优化构图分别搭配逐条/批量评分。相同三个预选训练查询、每条8候选、四种处理顺序轮换8次；每次重新构图。', '', '| fragment数 | 原构图逐条ms | 原构图批量ms | 优化构图逐条ms | 优化构图批量ms | 合并降低 |', '|---:|---:|---:|---:|---:|---:|']
        for row in pipeline['queries']:
            m = row['medians']
            lines.append(f"| {row['fragments']} | {m['original_scalar']['total_ms']:.3f} | {m['original_batch']['total_ms']:.3f} | {m['fast_scalar']['total_ms']:.3f} | {m['fast_batch']['total_ms']:.3f} | {row['combined_total_reduction_percent']:.2f}% |")
        lines += ['', '大图构图占主要成本：31/46个fragment时，仅批量评分对整条本地路径的降低分别约6.84%/3.26%；合并构图优化后为约71.09%/76.27%。三个查询的构图张量逐值相等，每次计时分数均满足既定容差。未修改生产构图函数，也未接入搜索路径；不含HTTP、FE、遍历或SQL，不能宣称端到端搜索或查询延迟优势。详见 [构图与评分成本对照](candidate_pipeline_cost/REPORT.md)。', '']
    search_batch_path = run/'search_batch_cost/RESULT.json'
    if search_batch_path.exists():
        search_batch = json.loads(search_batch_path.read_text())
        assert search_batch['status'] == 'verified_search_batch_cost'
        values = search_batch['mean_of_query_medians_ms']
        lines += [f"在四条原开发查询上，所有搜索均采用优化构图，完整本地搜索的查询中位数平均为：原MCTS {values['original_mcts']:.3f}ms、改进搜索{values['refined_full']:.3f}ms、随机逐条{values['independent_random_scalar']:.3f}ms、随机批量{values['independent_random_batch']:.3f}ms。每种方法每条查询4轮、顺序轮换；随机两版本候选和首选一致。批量随机在四条查询均更快，不能据此声称当前搜索的成本优势。", '',
                  '独立计数确认每次64个逻辑候选分数；两种MCTS另有一次重要性编码，随机批量采用4次16候选调用。改进搜索及随机轨迹中未发现重复配置，分数缓存不会降低这批轨迹的评分次数。测量包括本地构图、候选生成和搜索遍历，不含HTTP、FE或SQL，生产路径未改。见 [完整本地搜索成本](search_batch_cost/REPORT.md)。', '']
    feature_path = run/'structure_coverage20/xgb_feature_ablation_pilot/RESULT.json'
    if feature_path.exists():
        feature = json.loads(feature_path.read_text())
        assert feature['status'] == 'verified'
        lines += ['## XGBoost输入特征诊断', '',
                  '同一1365训练样本、6702批次内排序对及212验证样本，seed17，各组200棵树、深度3/6。按两组等权排序准确率选深度；这是特征块诊断，不替换完整特征验收基线。', '',
                  '| 特征组 | 维度 | 等权排序准确率 |', '|---|---:|---:|']
        for arm, row in feature['selected'].items():
            lines.append(f"| {arm} | {row['features']} | {100*row['quality']['weighted_rank_accuracy']:.4f}% |")
        lines += ['', '移除显式交互后竞争统计仍可能携带DOP信息，移除图统计后算子特征仍保留结构信息。全部8个模型通过保存重载及920对独立核验；单种子、复用开发验证集，不能据此声称跨种子或盲测优势。见 [特征小测](structure_coverage20/xgb_feature_ablation_pilot/REPORT.md)。', '']
        diagnostic_path = feature_path.parent/'QUERY_DIAGNOSTIC.json'
        if diagnostic_path.exists():
            diagnostic = json.loads(diagnostic_path.read_text())
            assert diagnostic['status'] == 'verified'
            lines += ['完整特征深度3/6检查点与原XGBoost基线字节完全一致。移除显式交互时，完整组在22查询中胜15、负2、平5；移除图统计时胜5、负2、平15。',
                      '按查询分层配对重采样的描述性区间显示，显式交互项影响较大；图统计项影响较小且区间跨零。开发集已用于选深度，区间不构成盲测显著性或跨种子稳定性证明。Transformer此前的显式交互及统计残差试验未稳定达标，不能据此推断重复加入特征即可解决。详见 [逐查询诊断](structure_coverage20/xgb_feature_ablation_pilot/QUERY_DIAGNOSTIC.md)。', '']
    basic_path = run/'structure_coverage20/basic_feature_comparison/RESULT.json'
    if basic_path.exists():
        basic = json.loads(basic_path.read_text())
        assert basic['status'] == 'verified_shared_pair_pool'
        lines += ['## 基础与增强输入对照', '',
                  '按用户要求补列无显式DOP交互项的XGBoost基础版本，完整增强版本同时保留。相同seed17、212验证配置、920对，重新对齐配置及耗时标签后比较。', '',
                  '| 模型与特征 | 两组等权排序准确率 |', '|---|---:|']
        for name, value in basic['macro_accuracy'].items():
            lines.append(f'| {name} | {100*value:.4f}% |')
        lines += ['', '该对照使用多阶段Transformer＋错对采样＋EMA，无显式DOP乘积。训练过程及输入表示不同，基础基线又是在观察增强版结果后新增，不能视为预注册的纯架构实验。单种子优势不取代三种子稳定性验收。见 [基础与增强基线](structure_coverage20/basic_feature_comparison/REPORT.md)。', '']
    basic_stability_path = run/'structure_coverage20/basic_feature_stability/RESULT.json'
    if basic_stability_path.exists():
        stability = json.loads(basic_stability_path.read_text())
        assert stability['status'] == 'verified_three_seed_shared_pairs'
        lines += ['## 基础特征对照三种子复核', '',
                  '| seed | Transformer | XGBoost基础特征 | XGBoost增强特征 |', '|---:|---:|---:|---:|']
        for row in stability['records']+[dict(seed='均值',**stability['means'])]:
            lines.append(f"| {row['seed']} | {100*row['transformer']:.4f}% | {100*row['no_explicit_dop_interaction']:.4f}% | {100*row['full']:.4f}% |")
        lines += ['', f"三个种子均超过基础特征版：{stability['all_seeds_above_basic']}；均超过增强特征版：{stability['all_seeds_above_enhanced']}。相同验证配置及920对已重新对齐计数。基础版明确去掉DOP乘积项，增强版保留。两类模型训练历史不同，复用开发集，结果不等于盲测或全面领先。详见 [三种子复核](structure_coverage20/basic_feature_stability/REPORT.md)。", '']
    mlp_interaction_path = run/'structure_coverage20/mlp_interaction_pilot/PAIR_AUDIT.json'
    if mlp_interaction_path.exists():
        mlp_interaction = json.loads(mlp_interaction_path.read_text())
        assert mlp_interaction['status'] == 'verified_independent_pair_replay'
        lines += ['## MLP显式DOP交互项对照', '',
                  '两组均1088输入和64/64隐藏层，同一seed17、训练数据、采样与30轮预算。无交互组将532个归一化乘积项置零，其他556列逐值保留；参数维度和初始化规则不变。各组学习率3e-4/1e-3，按两组等权排序准确率选模。', '',
                  '| 模型 | 完整特征 | 无显式交互 | 完整减无交互（百分点） |', '|---|---:|---:|---:|']
        for kind, row in mlp_interaction['models'].items():
            a,b = row['full']['macro_accuracy'],row['no_explicit_interaction']['macro_accuracy']
            lines.append(f'| {kind} | {100*a:.4f}% | {100*b:.4f}% | {100*(a-b):+.4f} |')
        lines += ['', '两组均先通过2轮冒烟检查，30轮结果已独立重算相同920对。此为单种子开发小测；不能与已有100轮MLP混用预算，也不能据此替换更强基线。图统计仍可能包含DOP信息。见 [MLP交互项小测](structure_coverage20/mlp_interaction_pilot/REPORT.md)。', '']
    mlp100_path = run/'structure_coverage20/mlp_interaction100/PAIR_AUDIT.json'
    if mlp100_path.exists():
        mlp100 = json.loads(mlp100_path.read_text())
        assert mlp100['status'] == 'verified_independent_pair_replay'
        lines += ['## MLP交互项同预算100轮复核', '',
                  '在30轮小测之后，两组同样扩展到100轮，保持seed17、数据、采样、学习率候选和输入干预不变。100轮每组分别按开发集选模，不把30轮小测结果混入本表。', '',
                  '| 模型 | 完整特征 | 无显式交互 |', '|---|---:|---:|']
        for kind, row in mlp100['models'].items():
            lines.append(f"| {kind} | {100*row['full']['macro_accuracy']:.4f}% | {100*row['no_explicit_interaction']['macro_accuracy']:.4f}% |")
        lines += ['', '单种子、复用开发验证集，尚不构成跨种子稳定性或报告90查询的泛化结论。见 [100轮独立核验](structure_coverage20/mlp_interaction100/PAIR_AUDIT.json)。', '']
        distribution_path = mlp100_path.parent/'QUERY_DISTRIBUTION.json'
        if distribution_path.exists():
            distribution = json.loads(distribution_path.read_text())
            assert distribution['status'] == 'verified_query_distribution'
            lines += ['逐查询复核：完整特征组在成对排序、平滑排序、回归三个模型上，分别在22条查询中的17、17、20条取得更高排序准确率。因此这批开发集上的交互项收益不只来自单条查询；仍保留全部退步查询。', '',
                      '![MLP交互项逐查询影响](structure_coverage20/mlp_interaction100/QUERY_DISTRIBUTION.png)', '',
                      '按查询分层配对重采样的区间只作已选模型的描述，不作为盲测显著性或训练种子稳定性证明。主指标为两类查询等权汇总，不能直接对图中柱高取均值替代。详见 [逐查询分布](structure_coverage20/mlp_interaction100/QUERY_DISTRIBUTION.md)。', '']
    mlp_stability_path = run/'structure_coverage20/mlp_interaction_stability/RESULT.json'
    if mlp_stability_path.exists():
        mlp_stability = json.loads(mlp_stability_path.read_text())
        assert mlp_stability['status'] == 'verified_three_seeds'
        lines += ['## MLP交互项三种子复核', '',
                  '完整特征组复用已有100轮基线，无交互组补训固定种子29/43，合并已完成的seed17。每个种子均独立复算相同212配置及920排序对。', '',
                  '| 方法 | 完整特征均值 | 无交互项均值 | 三个种子均改善 |', '|---|---:|---:|---|']
        for kind, row in mlp_stability['aggregate'].items():
            lines.append(f"| {kind} | {100*row['full_mean']:.4f}% | {100*row['no_interaction_mean']:.4f}% | {row['all_seeds_full_better']} |")
        lines += ['', '固定17/29/43全部保留，不选最佳种子。结果仅支持该复用开发集上的特征干预稳定性，不等于盲测、额外独立查询或Transformer全面领先。见 [全部种子与证据](structure_coverage20/mlp_interaction_stability/REPORT.md)。', '']
    distill_path = run/'structure_coverage20/xgb_distillation_pilot/REPORT.md'
    if distill_path.exists():
        distill_root = distill_path.parent
        distill = json.loads((distill_root/'pair_audit/RESULT.json').read_text())
        decision = json.loads((distill_root/'EXPANSION_DECISION.json').read_text())
        assert distill['status'] == 'verified_independent_pair_replay'
        lines += ['## 树教师软排序蒸馏', '',
                  '固定训练集XGBoost教师，为原Transformer与竞争边增加0.25权重的软成对监督；保留错对采样与EMA，seed17、30轮。1365训练配置的教师评分及归一化已独立重算完全一致。推理仅使用Transformer，但训练依赖树教师，应计入额外训练成本。', '',
                  '| 模型 | 两组等权排序准确率 |', '|---|---:|']
        for kind, row in distill['models'].items():
            lines.append(f"| {kind} | {100*row['macro_accuracy']:.4f}% |")
        lines += ['', f"超过未蒸馏匹配模型及全部对照的扩大门槛：{decision['all_family_gate_passed']}。单种子且复用开发验证集，不是纯架构因果对比或最终90查询盲测。见 [蒸馏小测](structure_coverage20/xgb_distillation_pilot/REPORT.md)。", '']
    lineage_path = run/'policy_lineage_audit/RESULT.json'
    if lineage_path.exists():
        lineage = json.loads(lineage_path.read_text())
        lines += ['## 策略历史训练链可恢复性', '',
                  f"扫描{lineage['scanned_pt_files']}个检查点文件，识别{lineage['policy_checkpoints']}个策略文件（含重复快照）。部署策略向前哈希关联到{len(lineage['chain'])}个连续检查点后停止：{lineage['stop_reason']}。",
                  '这限定了历史精确重放的范围。按当前报告范围，历史训练链逐阶段消融不再列为必需实验；若另行研究其因果贡献，必须采用共同可恢复起点，不能将不同来源模型直接作因果对照。见 [训练链审计](policy_lineage_audit/REPORT.md)。', '']
    budget_path = run/'search_budget_screen/SUMMARY.json'
    if budget_path.exists():
        budget = json.loads(budget_path.read_text())
        lines += ['## 搜索候选预算筛查', '',
                  '4条开发查询、3种子、16/32/64候选，两方法使用同一构图优化；72次搜索全部完成。较小预算的候选及分数与64预算前缀逐项一致，但首选配置通常改变。', '',
                  '| 方法及预算 | 保留64预算首选配置 |', '|---|---:|']
        for name, count in budget['same_config_as64_out_of12'].items():
            lines.append(f'| {name} | {count}/12 |')
        lines += ['', '此处只记录离线筛查，后续SQL结果见下文预算小测及全部90查询对照；不能把候选预算减半视为无损加速，也不能用模型分数替代查询延迟。单次计时仅作筛查，不与旧成本数据合并。详见 [全部预算轨迹](search_budget_screen/REPORT.md)。', '']
    budget_sql_path = run/'search_budget_sql/collection/RESULT.json'
    if budget_sql_path.exists():
        budget_sql = json.loads(budget_sql_path.read_text())
        assert budget_sql['status'] == 'verified' and budget_sql['restored']
        lines += ['## 搜索预算SQL小测', '',
                  '4条已有开发查询，改进搜索与批量随机各16/32/64候选，固定seed17。每组预热一次、正式一次；48次执行及DOP安装已独立核验，FE设置恢复。', '',
                  '| 配置来源 | 平均查询延迟ms |', '|---|---:|']
        for mode,value in budget_sql['mean_ms'].items():
            lines.append(f'| {mode} | {value:.3f} |')
        lines += ['', '表中为固定配置回放，排除离线搜索耗时；每配置只有一次正式测量。不同候选预算明确列示，不能把小样本的延迟差称为稳定领先，也不能与先前不同运行批次直接拼成端到端指标。见 [逐查询结果](search_budget_sql/collection/REPORT.md)。', '']
    prepared_cost_path = run/'prepared_search_cost/RESULT.json'
    if prepared_cost_path.exists():
        prepared_cost = json.loads(prepared_cost_path.read_text())
        assert prepared_cost['status'] == 'verified_exact_search_cache'
        lines += ['## 查询静态特征缓存成本', '',
                  '缓存类别、数值、依赖和候选掩码等不随配置变化的特征，DOP相关竞争张量逐候选重算。1577个配置、两种DOP模式的31540项字段核验完全一致；按精确请求上下文缓存，不按plan_key跨请求复用。', '',
                  '| 方法 | 未缓存ms | 缓存ms | 降低 |', '|---|---:|---:|---:|']
        m = prepared_cost['mean_query_median_ms']
        for method in ['refined','random']:
            a,b=m[method+'_uncached'],m[method+'_cached']
            lines.append(f'| {method} | {a:.3f} | {b:.3f} | {100*(1-b/a):.2f}% |')
        lines += ['', '4条开发查询各4轮、顺序轮换；缓存初始化和拷贝成本计入，两种方法获得同样优化，所有候选和评分精确一致。缓存后改进搜索仍比批量随机搜索耗时更高，不能据此宣称算法搜索成本领先。测量不含HTTP/FE/SQL，未改生产代码。见 [缓存正确性](prepared_graph_verification/REPORT.md)、[本地搜索成本](prepared_search_cost/REPORT.md)。', '']
    budget90_path = run/'search_budget_report90/collection/PAIRED_SUMMARY.json'
    if budget90_path.exists():
        budget90 = json.loads(budget90_path.read_text())
        assert budget90['status'] == 'verified_paired_summary'
        lines += ['## 全部90查询搜索预算对照', '',
                  '开发小测后，全部90条报告查询统一执行32/64预算的改进搜索与随机搜索配置。四组各预热一次、正式一次，720次执行及DOP安装已独立核验，FE设置恢复。', '',
                  '| 配置来源 | 平均ms | p50 | p90 | p99 |', '|---|---:|---:|---:|---:|']
        for mode, row in budget90['statistics'].items():
            lines.append('| '+mode+' | '+' | '.join(f'{row[k]:.3f}' for k in ['mean_ms','p50_ms','p90_ms','p99_ms'])+' |')
        lines += ['', '| 比较（正数为降低） | 平均降低 | p50降低 | p90降低 | p99降低 | 胜/负/平 |', '|---|---:|---:|---:|---:|---|']
        for name, row in budget90['comparisons'].items():
            lines.append('| '+name+' | '+' | '.join(f"{row['reductions_percent'][k]:+.2f}%" for k in ['mean_ms','p50_ms','p90_ms','p99_ms'])+f" | {row['wins']}/{row['losses']}/{row['ties']} |")
        lines += ['', '同预算与跨预算比较分别标明。查询延迟来自固定配置回放，不含离线搜索开销；不能将不同批次计时相加后称作端到端实测。保留全部90条历史筛选查询，单次正式观测尚不能证明测量重复稳定性或任意查询泛化。见 [全量配对报告](search_budget_report90/collection/PAIRED_REPORT.md)。', '']
    diagnostic_path = run/'search_budget_report90/SCORE_DIAGNOSTIC.json'
    if diagnostic_path.exists():
        diagnostic = json.loads(diagnostic_path.read_text())
        assert diagnostic['status'] == 'completed_frozen_teacher_replay'
        row = diagnostic['comparisons']['refined_budget64_vs_random_budget64']
        lines += ['## 全量搜索预算评分诊断', '',
                  f"64预算的改进与随机搜索输出中，{row['valid3percent_pairs']}对配置实测差距达到3%，冻结教师仅排对{row['correct_ordering']}对（{100*row['accuracy']:.2f}%）。改进搜索在{row['higher_a_score']}条上得到更高分，其中{row['higher_a_score_but_at_least3percent_slower']}条却至少慢3%。因此提高旧教师评分不足以保证执行收益。", '',
                  '预算32/64之间保留相同配置的查询，其跨组绝对延迟变化中位数约3.2%；单次执行不能把全部排序冲突归因于模型。该诊断是对已用90查询的事后分析，不替代920对开发评估，也不用于训练。见 [评分与波动诊断](search_budget_report90/SCORE_DIAGNOSTIC.md)。', '']
    retrieval_path = run/'retrieval_timing_pilot/SUMMARY.json'
    if retrieval_path.exists():
        retrieval = json.loads(retrieval_path.read_text())
        assert retrieval['status'] == 'verified_first_hit_summary'
        lines += ['## 检索效率与实际命中耗时', '',
                  '4条开发查询、3种子、每组3次正式计时，六方法共216次正式搜索。共同目标为此前候选池教师评分第95百分位；计时包含每次缓存初始化、重要性编码、构图、评分和轨迹记录，批量随机按整批完成时间计入。', '',
                  '| 方法 | 64次评分内命中/12 | 200ms内命中/12 | 完整64候选耗时ms |', '|---|---:|---:|---:|']
        for row in retrieval['summary']:
            if row['target'] == '0.95':
                lines.append(f"| {row['method']} | {row['hits']} | {row['hit_by_median_time_ms']['200']} | {row['mean_trial_median_full_search_ms']:.2f} |")
        lines += ['', '改进搜索相对原MCTS与随机搜索提高该目标的命中率；完整跑满预算并不更快。移除等价类组的小测收敛更快，当前不能宣称完整组优于所有消融。参考池来自旧改进/随机候选，非全空间最优或独立方法中立基准，不能把高分检索优势等同SQL延迟优势。', '',
                  '![检索收敛曲线](retrieval_timing_pilot/CONVERGENCE.png)', '',
                  '未命中保留，不仅比较成功样本耗时；全部90/95/100百分位目标和详细计时见 [检索效率小测](retrieval_timing_pilot/REPORT.md)。未执行新SQL，未修改生产实现。', '']
    # Keep the principal measured outcome first, followed by model and concurrency evidence.
    if '## 核心结论' in lines:
        start = lines.index('## 核心结论')
        end = next((i for i in range(start+1, len(lines)) if lines[i].startswith('## ')), len(lines))
        lines = lines[:4] + lines[start:end] + lines[4:start] + lines[end:]
    (run/'FULL_REPORT.md').write_text('\n'.join(lines))
