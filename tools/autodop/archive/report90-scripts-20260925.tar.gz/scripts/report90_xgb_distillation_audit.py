"""All-family independent pair audit for the completed distillation pilot."""
import json
import os
from pathlib import Path
import runpy
from report90_interaction_pair_audit import BASE, sha


def main():
    os.sched_setaffinity(0,{34})
    root=BASE/'xgb_distillation_pilot'
    decision=json.loads((root/'RESULT.json').read_text())
    assert decision['status']=='replayed_pilot'
    assert json.loads((root/'TARGET_AUDIT.json').read_text())['status']=='verified_exact_training_targets'
    for p,digest in decision['source_sha256'].items():assert sha(p)==digest
    original=Path(__file__).with_name('report90_interaction_pair_audit.py')
    changes={
        "BASE = Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20'":'BASE = Path('+repr(str(BASE))+')',
        "BASE/f'interaction_ranking/seed{seed}'":'Path('+repr(str(root/'pilot'))+')',
        "BASE/f'interaction_pair_audit_seed{seed}'":'Path('+repr(str(root/'pair_audit'))+')',
        'from report90_interaction_model import load_interaction_model as load_cost_model':'from autodop.model import load_cost_model',
        "Path(__file__).with_name('report90_interaction_model.py')":'Path('+repr(str(Path(__file__).resolve().parents[1]/'autodop/model.py'))+')',
        'sources = [Path(__file__),':'sources = [Path(__file__), Path('+repr(str(original))+'), Path('+repr(str(Path(__file__)))+'),',
        'Interaction-augmented Transformer; unchanged flat controls.':'Train-only XGBoost soft-pair distillation into original Transformer+competition, seed17; unchanged flat controls.',
    }
    text=original.read_text()
    for old,new in changes.items():
        assert text.count(old)==1,old
        text=text.replace(old,new)
    path=root/'pair_audit_staged.py';assert not path.exists()
    compile(text,str(path),'exec');path.write_text(text)
    (root/'AUDIT_TRANSFORM.json').write_text(json.dumps(dict(source_sha256=sha(original),generated_sha256=sha(path),changes=changes),indent=2)+'\n')
    runpy.run_path(str(path),run_name='distillation_audit')['main'](17)
    result=json.loads((root/'pair_audit/RESULT.json').read_text())
    score=result['models']['transformer']['macro_accuracy']
    gate=score>decision['reference_macro_accuracy'] and all(score>r['macro_accuracy'] for k,r in result['models'].items() if k!='transformer')
    (root/'EXPANSION_DECISION.json').write_text(json.dumps(dict(status='audited',all_family_gate_passed=gate,action='eligible_for_three_seed_replication' if gate else 'do_not_expand',source_sha256={str(root/'pair_audit/RESULT.json'):sha(root/'pair_audit/RESULT.json')}),indent=2)+'\n')
    lines=['# XGBoost软排序蒸馏小测','',
           '使用冻结树教师在1365训练配置上的评分，将成对分数差的sigmoid作为软目标，以0.25权重加入原损失。保留原Transformer与竞争边、错对采样及EMA；推理不调用XGBoost。seed17，30轮，验证212配置，90条报告查询不参与选模。', '',
           '| 模型 | 两组等权排序准确率 | 汇总排序准确率 |','|---|---:|---:|']
    for kind,r in result['models'].items():
        lines.append(f"| {kind} | {100*r['macro_accuracy']:.4f}% | {100*r['pooled_accuracy']:.4f}% |")
    lines += ['',f"未蒸馏匹配对照：{100*decision['reference_macro_accuracy']:.4f}%。通过全部对照及匹配模型门槛：{gate}。",'',
              '教师采用已有开发结果的深度6模型；这不是盲选教师。教师训练集评分与归一化已独立重算，1365项完全一致；教师误排序不被删去。该实验改变训练监督来源，不能当成纯架构比较。教师训练成本应计入方法成本。', '',
              '仅单种子且复用开发验证集，不能据此宣称最终报告查询或三种子稳定领先。', '',
              '证据：[独立排序核验](pair_audit/RESULT.json)、[教师目标核验](TARGET_AUDIT.json)、[固定协议](PROTOCOL.json)。']
    (root/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(dict(macro_accuracy=score,all_family_gate_passed=gate)))


if __name__=='__main__':main()
