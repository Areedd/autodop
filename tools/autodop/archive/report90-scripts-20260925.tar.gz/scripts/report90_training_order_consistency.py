"""Audit conflicting and cyclic stored training orders without rewriting labels."""
import collections
import json
from pathlib import Path
from autodop.data import load_dataset
from autodop.training import select_partition
from report90_neighborhood_prepare import RUN,sha
BASE=RUN/'structure_coverage20'
OUT=BASE/'training_order_consistency'


def main():
    assert not OUT.exists()
    data=BASE/'merged_dataset';samples,pairs,metadata=load_dataset(data)
    train,tp=select_partition(samples,pairs,json.loads((data/'CONTRACT.json').read_text()),'train')
    assert len(train)==1365 and len(tp)==6702
    by=collections.defaultdict(list)
    for p in tp:by[p['plan_key']].append(p)
    results=[]
    for plan,pp in sorted(by.items()):
        directed=collections.Counter((p['fast_config_key'],p['slow_config_key']) for p in pp)
        vertices=sorted({v for edge in directed for v in edge})
        reach={v:set() for v in vertices}
        for a,b in directed:reach[a].add(b)
        for k in vertices:
            for v in vertices:
                if k in reach[v]:reach[v].update(reach[k])
        seen=set();cycles=[]
        for v in vertices:
            if v in seen:continue
            component=sorted(w for w in vertices if w==v or (w in reach[v] and v in reach[w]))
            seen.update(component)
            if len(component)>1:cycles.append(component)
        conflicts=[{'configs':[a,b],'a_before_b':directed[a,b],'b_before_a':directed[b,a]} for a,b in directed if a<b and (b,a) in directed]
        # Each contradictory pair requires at least the smaller multiplicity to be wrong for any scalar score.
        lower_bound=sum(min(c['a_before_b'],c['b_before_a']) for c in conflicts)
        results.append({'plan_key':plan,'pair_records':len(pp),'unique_directed_edges':len(directed),'configs':len(vertices),'conflicting_pairs':conflicts,'cyclic_components':cycles,'unavoidable_wrong_record_lower_bound':lower_bound})
    totals={'training_pair_records':len(tp),'unique_directed_edges':sum(r['unique_directed_edges'] for r in results),'plans':len(results),'plans_with_conflicts':sum(bool(r['conflicting_pairs']) for r in results),'conflicting_unordered_pairs':sum(len(r['conflicting_pairs']) for r in results),'plans_with_cycles':sum(bool(r['cyclic_components']) for r in results),'unavoidable_wrong_record_lower_bound':sum(r['unavoidable_wrong_record_lower_bound'] for r in results)}
    OUT.mkdir();result={'status':'verified_training_order_graph_audit','totals':totals,'plans':results,'scope':'Stored within-batch training comparisons retained. Conflicts across records can reflect measured variability, not data corruption. Bound applies to record-weighted strict scalar ranking, not cohort macro, held-out accuracy, or attainable best accuracy; cycles can impose further errors. No data filtering, fitting, validation or report90 labels.', 'source_sha256':{str(p):sha(p) for p in [Path(__file__),data/'samples.jsonl',data/'pairs.jsonl',data/'CONTRACT.json']}}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(totals))

if __name__=='__main__':main()
