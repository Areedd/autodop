"""Inspect captured plan descriptors without executing SQL or using latency selection."""
from collections import Counter,defaultdict
import hashlib
import json
from pathlib import Path

RUN=Path(__file__).resolve().parents[1]/'runs/report90_20260912'
FIELDS=('data_partition','output_partition','root_node','leftmost_node','operator_counts',
        'join_type','sink_type','is_bucket_shuffle','is_colocated','is_gather_root','is_replicated')


def main():
    variants={};groups=Counter();sources=[Path(__file__)];records=[]
    for arm in ('swrr','fifo'):
        path=RUN/('report90_native_budget_mixed_'+arm)/'scored/events.jsonl';sources.append(path)
        for e in map(json.loads,path.read_text().splitlines()):
            if not e['mode'].startswith('policy'):
                continue
            request=e['trace']['request'];fs=request['fragments']
            labels={f['fragment_id']:json.dumps({k:f.get(k) for k in FIELDS},sort_keys=True) for f in fs}
            edges=sorted((labels[x['source_fragment_id']],labels[x['dest_fragment_id']],x['partition_type']) for x in request['edges'])
            descriptor=dict(fragments=sorted(labels.values()),edges=edges)
            signature=hashlib.sha256(json.dumps(descriptor,sort_keys=True).encode()).hexdigest()
            ops=Counter()
            for f in fs:ops.update(f['operator_counts'])
            variants.setdefault(signature,dict(fragment_count=len(fs),edge_count=len(edges),operator_counts=dict(sorted(ops.items()))))
            groups[(arm,e['phase'],e['mode'],e['id'],signature)]+=1
            records.append(dict(arm=arm,id=e['id'],phase=e['phase'],mode=e['mode'],query_id=e['query_id'],descriptor_sha256=signature))
    by_query=defaultdict(set)
    for r in records:by_query[r['id']].add(r['descriptor_sha256'])
    result=dict(status='captured_plan_descriptor_audit',records=len(records),
                variants_per_query={q:len(v) for q,v in by_query.items()},variants=variants,
                groups=[dict(arm=k[0],phase=k[1],mode=k[2],id=k[3],signature=k[4],count=v) for k,v in sorted(groups.items())],
                scope='Only the 128 AutoDOP executions have captured model-request descriptors. Descriptor omits fragment/node IDs, DOP, worker placement and estimates. Different counts prove structural variation; equal descriptors do not prove full plan semantic equality. This is not a full graph-isomorphism or plan-dump audit.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    out=RUN/'native_mixed_plan_audit';out.mkdir(exist_ok=True);(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
