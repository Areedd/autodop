"""Small development-only search first-hit timing with frozen shared targets."""
import hashlib
import json
import os
import random
import time
from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch

from autodop import graph, mcts
from autodop.model import load_cost_model
from report90_batched_cost import score_batch
from report90_prepared_graph import PreparedGraph
from report90_search_refinement import search

RUN = Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    os.sched_setaffinity(0, {34})
    torch.set_num_threads(1)
    out = RUN/'retrieval_timing_pilot'
    out.mkdir(exist_ok=False)
    prior_path = RUN/'search_refinement_development/PROTOCOL.json'
    prior = json.loads(prior_path.read_text())
    vp = prior_path.parent/'vectors.json'
    vectors = json.loads(vp.read_text())
    screen_path = RUN/'search_budget_screen/RESULT.json'
    archived = [r for r in json.loads(screen_path.read_text())['rows'] if r['budget'] == 64]
    targets, pools = {}, {}
    for q in prior['queries']:
        pool = {}
        for r in archived:
            if r['query'] == q:
                for config, score in zip(r['configs'], r['scores']):
                    k = tuple(config)
                    assert k not in pool or pool[k] == score
                    pool[k] = score
        pools[q] = sorted(pool.values())
        targets[q] = {str(t): float(np.quantile(pools[q], t, method='higher')) for t in [.9,.95,1.]}
    modes = ['original_mcts', 'refined', 'no_attention', 'no_equivalence', 'random_scalar', 'random_batch']
    code = RUN/'graph_construction_pilot/competition_staged.py'
    model_path = Path(prior['model'])
    sources = [Path(__file__), prior_path, vp, screen_path, code, model_path,
               Path(graph.__file__), Path(mcts.__file__),
               Path(__file__).with_name('report90_prepared_graph.py'),
               Path(__file__).with_name('report90_batched_cost.py'),
               Path(__file__).with_name('report90_search_refinement.py')]
    protocol = dict(queries=prior['queries'], seeds=[17,29,43], modes=modes,
        budget=64, warmups_per_query_mode=1, timed_rounds_per_seed=3, batch_size=16,
        targets=targets, reference_score_pools=pools,
        scope='4 reused development queries only, no SQL or training. Targets frozen from prior refined/random traces, not method-neutral global optima. All methods share static cache and optimized competition. Timing includes per-search cache initialization, importance, graph construction, scoring and trace instrumentation; excludes model load, request parsing, HTTP, FE and SQL. Batch results become available together, and full batch evaluations count at a hit. Failures remain censored; successful-only speed ratios are not principal comparisons.',
        source_sha256={str(p):sha(p) for p in sources})
    (out/'PROTOCOL.json').write_text(json.dumps(protocol, indent=2)+'\n')
    model, ck = load_cost_model(model_path)
    model.eval()
    meta = ck['metadata']
    namespace = dict(vars(graph))
    exec(compile(code.read_text(), str(code), 'exec'), namespace)
    optimized = namespace['_competition']
    original_bindings = (graph._competition, graph.build_graph, mcts.build_graph,
                         mcts.attention_guided_groups, mcts.equivalence_groups)

    def natural(s, mdl, metadata, candidates, device='cpu'):
        return mcts.equivalence_groups(s, candidates)

    def individual(s, candidates):
        return [(i,) for i in range(len(candidates))]

    results = []
    with patch.object(graph, '_competition', optimized), torch.inference_mode():
        for qi, q in enumerate(prior['queries']):
            sample = graph.sample_from_request(vectors['refined_full'][q]['request'])
            sample['dop_config'] = [1 if f.get('is_gather_root') else 4 for f in sample['fragments']]

            def run(mode, seed):
                start = time.perf_counter_ns()
                prepared = PreparedGraph(sample, meta, optimized)
                trace = []
                last_config = None
                importance_calls = 0

                def elapsed():
                    return (time.perf_counter_ns()-start)/1e6

                def build(s, metadata, unknown_dop=False, device='cpu'):
                    nonlocal last_config
                    assert metadata is meta and s['fragments'] is sample['fragments']
                    last_config = list(s['dop_config'])
                    return prepared.build(last_config, unknown_dop, device)

                class Counted:
                    def eval(self):
                        return self

                    def fragment_importance(self, g):
                        nonlocal importance_calls
                        importance_calls += 1
                        return model.fragment_importance(g)

                    def __call__(self, g):
                        value = model(g)
                        score = float(value)
                        trace.append(dict(config=list(last_config), score=score,
                                          available_ms=elapsed(), evaluations=len(trace)+1))
                        return value

                counted = Counted()
                with patch.object(graph, 'build_graph', build), patch.object(mcts, 'build_graph', build):
                    if mode == 'original_mcts':
                        config, score = mcts.search(sample, counted, meta, iterations=64, seed=seed)
                    elif mode.startswith('random'):
                        domains = [graph.supported_dops(f, meta['dop_classes']) for f in sample['fragments']]
                        rng = random.Random(seed)
                        configs = [[rng.choice(d) for d in domains] for _ in range(64)]
                        if mode == 'random_scalar':
                            for config in configs:
                                counted(build({**sample,'dop_config':config}, meta))
                        else:
                            for i in range(0,64,16):
                                gs = [build({**sample,'dop_config':c}, meta) for c in configs[i:i+16]]
                                scores = score_batch(model, gs).tolist()
                                now = elapsed()
                                trace.extend(dict(config=list(c), score=float(s), available_ms=now,
                                                  evaluations=i+16) for c,s in zip(configs[i:i+16], scores))
                        best = max(trace, key=lambda r:r['score'])
                        config, score = best['config'], best['score']
                    else:
                        if mode == 'no_attention':
                            with patch.object(mcts, 'attention_guided_groups', natural):
                                value = search(sample, counted, meta, budget=64, seed=seed)
                        elif mode == 'no_equivalence':
                            with patch.object(mcts, 'equivalence_groups', individual):
                                value = search(sample, counted, meta, budget=64, seed=seed)
                        else:
                            value = search(sample, counted, meta, budget=64, seed=seed)
                        config, score = value['config'], value['score']
                total_ms = elapsed()
                assert len(trace) == 64 and score == max(t['score'] for t in trace)
                assert config == next(t['config'] for t in trace if t['score'] == score)
                assert all(t['available_ms'] <= total_ms for t in trace)
                assert all(a['available_ms'] <= b['available_ms'] for a,b in zip(trace,trace[1:]))
                return dict(query=q, method=mode, seed=seed, config=config, score=score,
                            total_ms=total_ms, importance_calls=importance_calls, trace=trace)

            warm = {mode:run(mode,17) for mode in modes}
            references = {}
            for si, seed in enumerate(protocol['seeds']):
                for ri in range(3):
                    shift = (qi+si+ri) % len(modes)
                    order = modes[shift:]+modes[:shift]
                    if (qi+si) % 2:
                        order = order[::-1]
                    for position, mode in enumerate(order):
                        value = run(mode,seed)
                        sequence = [(t['config'],t['score']) for t in value['trace']]
                        key = (mode,seed)
                        if key in references:
                            assert sequence == references[key]
                        else:
                            references[key] = sequence
                        if seed == 17:
                            assert sequence == [(t['config'],t['score']) for t in warm[mode]['trace']]
                        value.update(round=ri,position=position)
                        results.append(value)
                scalar, batched = references[('random_scalar',seed)], references[('random_batch',seed)]
                assert [c for c,s in scalar] == [c for c,s in batched]
                np.testing.assert_allclose([s for c,s in scalar],[s for c,s in batched],rtol=1e-6,atol=1e-6)
                for method in ['refined','random_batch']:
                    old = next(r for r in archived if (r['query'],r['seed'],r['method']) == (q,seed,method))
                    assert [c for c,s in references[(method,seed)]] == old['configs']
                    np.testing.assert_allclose([s for c,s in references[(method,seed)]],old['scores'],rtol=1e-6,atol=1e-6)
            (out/'PARTIAL.json').write_text(json.dumps(results)+'\n')
            print(f'{q}: {len(results)}/216 timed searches complete', flush=True)
    assert original_bindings == (graph._competition, graph.build_graph, mcts.build_graph,
                                 mcts.attention_guided_groups, mcts.equivalence_groups)
    for p,d in protocol['source_sha256'].items():
        assert sha(Path(p)) == d
    assert len(results) == 216
    (out/'RESULT.json').write_text(json.dumps(dict(status='verified_timed_traces',
        timed_searches=216, warmup_searches=24, module_bindings_restored=True,
        rows=results, protocol_sha256=sha(out/'PROTOCOL.json')), indent=2)+'\n')
    print('Completed216 timed searches; all repeated traces stable; no SQL or production changes.')


if __name__ == '__main__':
    main()
