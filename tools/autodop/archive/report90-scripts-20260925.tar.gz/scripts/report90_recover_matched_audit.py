"""Recover audit classification only; never re-execute or discard workload queries."""
from pathlib import Path
import hashlib,json,os,re

BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/matched_development_duration'

def main():
    out=BASE/'full';status=out/'STATUS.json';backup=out/'STATUS.before_audit_recovery.json'
    assert not backup.exists();backup.write_bytes(status.read_bytes())
    capture=json.loads((out/'CAPTURE.json').read_text());rows=capture['executions'];assert len(rows)==len(capture['calls'])==122 and not capture['errors']
    assert json.loads((out/'frontend_settings.json').read_text())['restored']
    tokens={r['token']:r for r in rows};assert len(tokens)==122
    cursor=json.loads((out/'AUDIT_START.json').read_text());matches={};slow={};raw=[]
    with Path(cursor['path']).open('rb') as f:
        assert os.fstat(f.fileno()).st_ino==cursor['inode']
        f.seek(cursor['offset'])
        for b in f:
            line=b.decode();m=re.search(r'autodop_matched_[0-9a-f]{32}',line)
            if not m or m[0] not in tokens:continue
            token=m[0];raw.append(line.rstrip())
            if ' [slow_query] ' in line:
                assert token not in slow;slow[token]=line.rstrip();continue
            assert ' [query] ' in line and token not in matches
            r=tokens[token]
            assert '|State=EOF|' in line and '|ErrorCode=|' in line and '|ResourceGroup=default_wg|' in line
            assert '|Db='+r['database']+'|' in line and '|PredictMemBytes='+str(r['sentinel_bytes'])+'|' in line
            normalize=lambda s:' '.join(s.split()).rstrip(';').rstrip()
            assert normalize(line.split('|Stmt=',1)[1].split('|Digest=',1)[0])==normalize(r['sql'])
            matches[token]=dict(query_id=re.search(r'\|QueryId=([0-9a-f-]+)\|',line)[1],audit_line=line.rstrip())
    assert matches.keys()==tokens.keys()
    for token,line in slow.items():
        assert re.search(r'\|QueryId=([0-9a-f-]+)\|',line)[1]==matches[token]['query_id']
        assert line.split('] ',1)[1]==matches[token]['audit_line'].split('] ',1)[1]
    assert len({r['query_id'] for r in matches.values()})==122
    for r in rows:r.update(matches[r['token']],status='verified')
    rawpath=out/'AUDIT_MATCHES_WITH_CATEGORIES.log';rawpath.write_text('\n'.join(raw)+'\n')
    sources=[Path(__file__),out/'CAPTURE.json',out/'frontend_settings.json',BASE/'manifest.json',rawpath,backup]
    result=dict(status='verified',queries=61,executions=rows,errors=[],
                scope='Actual-query capture recovered by selecting canonical [query] audit records. All [slow_query] duplicates retained and payload-matched; no SQL rerun, no sample removed. Callback overhead included.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    (out/'AUDIT_RECOVERY.json').write_text(json.dumps(dict(status='verified',canonical_queries=122,slow_query_duplicates=len(slow),queries_reexecuted=0,records_removed=0,reason='Audit parser did not distinguish query and slow_query categories; payloads are identical'),indent=2)+'\n')
    status.write_text(json.dumps(dict(status='verified',executions=122,restored=True,audit_recovered=True),indent=2)+'\n')
    print('Recovered 122 canonical queries; slow duplicates retained:',len(slow))

if __name__=='__main__':main()
