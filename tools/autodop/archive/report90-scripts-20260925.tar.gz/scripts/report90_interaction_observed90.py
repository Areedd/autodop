"""Score frozen augmented models on all90 historically measured candidate subsets."""
import collections
import datetime
import json
import os
from pathlib import Path
import numpy as np
import torch
import xgboost as xgb
from autodop.graph import build_graph, sample_from_request
from report90_interaction_model import load_interaction_model as load_cost_model
from autodop.training import file_sha256
from report90_models import MLP, flat_features, metrics
from report90_coverage_choices import BASE, read

RUN = BASE.parent
OUT = BASE / 'interaction_observed90'


def main():
    assert not OUT.exists(), 'Preserve prior evaluation'
    os.sched_setaffinity(0, {33}); torch.set_num_threads(1)
    assert read(BASE / 'interaction_accuracy_comparison/RESULT.json')['status'] == 'verified_three_seed_accuracy_summary'
    selected = {}
    selection_sources = [BASE/'interaction_accuracy_comparison/RESULT.json']
    for seed in [17,29,43]:
        primary_path = BASE/f'interaction_ranking/seed{seed}/RESULT.json'
        extra_path = BASE/f'accuracy_baselines_seed{seed}_full/RESULT.json'
        primary, extra = read(primary_path), read(extra_path)
        assert primary['status']=='complete' and extra['status']=='verified'
        audit = read(BASE/f'interaction_pair_audit_seed{seed}/RESULT.json')
        for path, digest in audit['source_sha256'].items(): assert file_sha256(path)==digest
        selection_sources += [primary_path,extra_path,BASE/f'interaction_pair_audit_seed{seed}/RESULT.json']
        for kind, record in {**primary['selected'],**extra['selected']}.items():
            selected[f'{kind}_seed{seed}'] = record
    for s in selected.values(): assert file_sha256(s['model']) == s['model_sha256']
    out = OUT; out.mkdir()
    protocol = {'frozen_at': datetime.datetime.now().astimezone().isoformat(), 'models': selected,
        'selection': 'All seven model families for all three fixed seeds, selected by development macro ranking accuracy; no model, seed or checkpoint selected using report90 scores or labels.',
        'scope': 'Retrospective scoring of the unchanged actually measured candidate subset for all90historically selected positive queries. Uses old BE environment latencies and prior pooling of identical configs by mean of mode means. Not newSQL, full candidate-space evaluation, untouched test, or current-BE execution superiority.',
        'source_sha256': {str(p): file_sha256(p) for p in [Path(__file__),*selection_sources,BASE/'retrained/FEATURE_NORMALIZATION.npz']}}
    (out / 'PROTOCOL.json').write_text(json.dumps(protocol, indent=2) + '\n')
    observed_path = RUN / 'original_teacher_audit/POOL_SCORES.json'; observed = read(observed_path)
    assert len(observed) == 1091 and len({r['id'] for r in observed}) == 90
    manifest = read(RUN / 'manifest.json'); ids = {q['id'] for q in manifest['queries']}
    assert ids == {r['id'] for r in observed}
    repaired = set(read(RUN / 'SUMMARY.json')['serial_repair']['replaced_queries'])
    sources = {name: read(RUN / name / 'vectors.json') for name in ['choices', 'choices_attempt1']}
    requests = {qid: sources['choices_attempt1' if qid in repaired else 'choices']['policy_vector'][qid]['request'] for qid in ids}
    base_samples = {qid: sample_from_request(req) for qid, req in requests.items()}
    metadata = read(BASE / 'retrained/METADATA.json'); norm = np.load(BASE / 'retrained/FEATURE_NORMALIZATION.npz')
    graphs = []; labels = []; unique = set()
    for row in observed:
        qid = row['id']; sample = base_samples[qid]
        assert len(row['dops']) == len(sample['fragment_ids'])
        identity = (qid, tuple(row['dops'])); assert identity not in unique; unique.add(identity)
        assert row['mode_mean_latencies_ms'] and all(np.isfinite(x) and x > 0 for x in row['mode_mean_latencies_ms'])
        graphs.append(build_graph({**sample, 'dop_config': row['dops']}, metadata))
        labels.append({'plan_key': qid, 'config_key': str(tuple(row['dops'])),
                       'latency_ms': float(np.mean(row['mode_mean_latencies_ms']))})
    features = np.stack([(flat_features(g, metadata) - norm['mean']) / norm['std'] for g in graphs])
    assert np.isfinite(features).all()
    qualities = {}; scores_by_model = {}
    for kind, s in selected.items():
        family = kind.rsplit('_seed',1)[0]
        if kind.startswith('transformer'):
            model, checkpoint = load_cost_model(s['model']); model.eval(); assert checkpoint['metadata'] == metadata
            with torch.no_grad(): scores = [float(model(g)) for g in graphs]
        elif kind.startswith('mlp'):
            checkpoint = torch.load(s['model'], weights_only=False)
            model = MLP(checkpoint['width']); model.load_state_dict(checkpoint['state']); model.eval()
            with torch.no_grad(): scores = model(torch.tensor(features, dtype=torch.float32)).numpy().astype(float)
            if family.endswith('regression'): scores = -scores
        else:
            model = xgb.XGBRegressor() if family.endswith('regression') else xgb.XGBRanker()
            model.load_model(s['model']); model.set_params(n_jobs=1); scores = model.predict(features).astype(float)
            if family.endswith('regression'): scores = -scores
        assert np.isfinite(scores).all()
        scores_by_model[kind] = [float(x) for x in scores]
        qualities[kind] = metrics(labels, scores)
        print(kind, qualities[kind]['mean_regret'], qualities[kind]['rank_accuracy'], flush=True)
    score_path = out / 'SCORES.json'; score_path.write_text(json.dumps(scores_by_model) + '\n')
    reloaded = read(score_path)
    assert all(metrics(labels, reloaded[k]) == q for k, q in qualities.items())
    evidence_paths = [observed_path, RUN / 'SUMMARY.json', RUN / 'manifest.json',
                      RUN / 'choices/vectors.json', RUN / 'choices_attempt1/vectors.json', score_path,
                      BASE / 'retrained/METADATA.json', Path(__file__).with_name('report90_models.py')]
    tf = [qualities[f'transformer_seed{s}'] for s in [17,29,43]]
    result = {'status': 'complete', 'queries': 90, 'observed_configurations': len(observed), 'qualities': qualities,
              'transformer_seed_mean_regret': float(np.mean([q['mean_regret'] for q in tf])),
              'transformer_seed_mean_rank_accuracy': float(np.mean([q['rank_accuracy'] for q in tf])),
              'score_serialization_metric_replay_verified': True, 'scope': protocol['scope'],
              'source_sha256': {str(p): file_sha256(p) for p in evidence_paths}}
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    lines = ['# DOP交互输入模型在90条已测候选子集上的排序复核', '', protocol['scope'], '',
             '全90条查询共1091个已测不同配置；模型与超参数在读取本次评分前固定。配置相同的历史模式耗时按模式均值再次求均值，沿用原诊断口径。保留全部三个Transformer种子，未选择最好一次。', '',
             '| 模型 | 平均候选选择损失 | 排序准确率 |', '|---|---:|---:|']
    for kind, q in qualities.items(): lines.append(f"| {kind} | {100*q['mean_regret']:.2f}% | {100*q['rank_accuracy']:.2f}% |")
    lines += ['', f"Transformer三种子选择损失均值为{100*result['transformer_seed_mean_regret']:.2f}%，排序准确率均值为{100*result['transformer_seed_mean_rank_accuracy']:.2f}%。", '',
              '所有模型从已有检查点重载；评分落盘后再次重算全部指标，结果一致。排序仅计实测差距至少3%的候选对，分数平局计错。无梯度更新、SQL执行或在线部署。', '',
              '候选集来自历史已执行模式，可能受这些模式的选择偏好影响，并非无偏搜索空间样本。90条查询本身是历史筛选后的优势子集，且已经用于开发诊断，不能称为独立盲测。']
    (out / 'REPORT.md').write_text('\n'.join(lines) + '\n')


if __name__ == '__main__': main()
