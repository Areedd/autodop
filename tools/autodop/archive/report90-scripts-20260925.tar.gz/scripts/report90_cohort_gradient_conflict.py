"""Small training-only audit of gradients from the two fixed query cohorts."""
import json
import os
from pathlib import Path
import random
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from autodop.training import select_partition
from report90_complex_retrain import pair_index
from report90_hard_pair_sampler import mine_pairs,epoch_pairs
from report90_neighborhood_prepare import RUN,sha
BASE=RUN/'structure_coverage20';OUT=BASE/'cohort_gradient_conflict'


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1);assert not OUT.exists()
    data=BASE/'merged_dataset';samples,pairs,metadata=load_dataset(data);contract=json.loads((data/'CONTRACT.json').read_text())
    train,tp=select_partition(samples,pairs,contract,'train');assert len(train)==1365 and len(tp)==6702
    by=pair_index(train,tp);graphs={(s['plan_key'],s['config_key']):build_graph(s,metadata) for s in train};cohort_of={s['plan_key']:s['source_cohort'] for s in train}
    paths={'multistage':BASE/'prepared/cost.pt','raw_final_seed17':BASE/'hard_pair_ema_pilot/pilot/transformer_h0/raw_final.pt'}
    OUT.mkdir();protocol={'checkpoints':{k:str(v) for k,v in paths.items()},'seed':17,'batches_per_checkpoint':4,'pairs_per_cohort_per_batch':16,'scope':'Training-only diagnostic, four fixed minibatches per checkpoint. Refresh hard pools at inspected model, take first64 draws per cohort from the existing624-pair sampler. Does not reconstruct actual historical gradient updates or establish causal interference. No validation/report90 data or model updates.', 'source_sha256':{str(p):sha(p) for p in [Path(__file__),data/'samples.jsonl',data/'pairs.jsonl',data/'metadata.json',data/'CONTRACT.json',Path(__file__).with_name('report90_hard_pair_sampler.py'),*paths.values()]}}
    (OUT/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    results={}
    for name,path in paths.items():
        model,_=load_cost_model(path);model.eval();hard,counts=mine_pairs(model,train,graphs,by);jobs=epoch_pairs(by,random.Random(17),hard)
        draws={c:[p for p in jobs if cohort_of[p['plan_key']]==c][:64] for c in by};assert all(len(v)==64 for v in draws.values())
        named=list(model.named_parameters());parameters=[p for k,p in named];records=[]
        for batch in range(4):
            gradients={};losses={}
            for cohort,pp in draws.items():
                terms=[]
                for p in pp[batch*16:(batch+1)*16]:
                    a=model(graphs[p['plan_key'],p['fast_config_key']]);b=model(graphs[p['plan_key'],p['slow_config_key']]);target=a.new_tensor(p['slow_latency_ms']/p['fast_latency_ms']).log()
                    terms.append(torch.nn.functional.softplus(target-a+b)+.1*torch.nn.functional.smooth_l1_loss(a-b,target))
                loss=torch.stack(terms).mean();losses[cohort]=float(loss.detach());gs=torch.autograd.grad(loss,parameters)
                gradients[cohort]={part:torch.cat([g.detach().double().flatten() for (k,p),g in zip(named,gs) if part=='all' or (k.startswith('encoder.') if part=='encoder' else not k.startswith('encoder.'))]) for part in ['all','encoder','readout']}
            parts={}
            for part in ['all','encoder','readout']:
                a,b=gradients['historical'][part],gradients['complex_new'][part];dot=float(a@b);norms=[float(a.norm()),float(b.norm())];cos=dot/(norms[0]*norms[1]) if min(norms)>0 else None
                parts[part]={'dot':dot,'norms':norms,'cosine':cos,'opposed':dot<0}
            records.append({'batch':batch,'losses':losses,'gradients':parts})
        results[name]={'batches':records,'negative_counts':{p:sum(x['gradients'][p]['opposed'] for x in records) for p in ['all','encoder','readout']}}
        print(name,results[name]['negative_counts'],flush=True)
    for p,d in protocol['source_sha256'].items():assert sha(Path(p))==d
    result={'status':'verified_training_cohort_gradient_audit','models':results,'scope':protocol['scope'],'protocol_sha256':sha(OUT/'PROTOCOL.json')}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 两类训练查询的梯度冲突诊断','',protocol['scope'],'','| 检查点 | 批次 | 全参数余弦 | 编码器余弦 | 读出余弦 |','|---|---:|---:|---:|---:|']
    for name,r in results.items():
        for b in r['batches']:lines.append(f"| {name} | {b['batch']} | {b['gradients']['all']['cosine']:.4f} | {b['gradients']['encoder']['cosine']:.4f} | {b['gradients']['readout']['cosine']:.4f} |")
    lines+=['','负点积表示当前所选小批次上存在一阶方向冲突；不能推断其必然损害泛化，或投影梯度一定能提高排序。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')

if __name__=='__main__':main()
