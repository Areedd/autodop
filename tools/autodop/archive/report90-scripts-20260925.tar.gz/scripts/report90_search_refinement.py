"""Experimental MCTS refinements; no deployment or measured-latency selection."""
import math
import random
import time

from autodop.mcts import Node


def search_domains(candidates, groups, score, budget=64, seed=17,
                   normalized=True, random_completion_probability=.25,
                   random_only=False):
    """Count every scorer call, including shared uniform anchors and duplicates.

    All variants here use the same anchors and remove fixed-domain variables.
    ``random_only`` samples the grouped domain, so it is not the independent-
    fragment random baseline. Original MCTS/random must also remain in reports.
    """
    if budget < 1 or not 0 <= random_completion_probability <= 1:
        raise ValueError('Invalid budget or completion probability')
    candidates = [sorted(set(values)) for values in candidates]
    if not candidates or any(not values for values in candidates):
        raise ValueError('Empty candidate domain')
    groups = [tuple(group) for group in groups]
    indices = [index for group in groups for index in group]
    if sorted(indices) != list(range(len(candidates))) or any(not g for g in groups):
        raise ValueError('Groups must partition fragments exactly once')
    actions = [sorted(set.intersection(*(set(candidates[i]) for i in group))) for group in groups]
    if any(not action for action in actions):
        raise ValueError('No shared legal action')
    fixed = [0]*len(candidates)
    movable, domains = [], []
    for group, values in zip(groups, actions):
        if len(values) == 1:
            for index in group:
                fixed[index] = values[0]
        else:
            movable.append(group)
            domains.append(values)
    rng = random.Random(seed)
    records = []
    best_config, best_score = None, -math.inf

    def evaluate(config, origin):
        nonlocal best_config, best_score
        assert len(records) < budget
        config = tuple(config)
        assert all(dop in values for dop, values in zip(config, candidates))
        assert all(len({config[i] for i in group}) == 1 for group in groups)
        value = float(score(config))
        if not math.isfinite(value):
            raise ValueError('Nonfinite model score')
        records.append(dict(config=list(config), score=value, origin=origin))
        if value > best_score:
            best_config, best_score = config, value
        return value

    # Deterministic uniform-like anchors projected onto each legal group domain.
    anchors = []
    for target in sorted(set(value for values in candidates for value in values)):
        config = list(fixed)
        for group, values in zip(movable, domains):
            action = min(values, key=lambda d: (abs(d-target), d))
            for index in group:
                config[index] = action
        if tuple(config) not in anchors:
            anchors.append(tuple(config))
    for config in anchors[:budget]:
        evaluate(config, 'anchor')
    center = sum(row['score'] for row in records)/len(records)
    scale = math.sqrt(sum((row['score']-center)**2 for row in records)/len(records))
    if scale == 0:
        scale = 1.
    root = Node(tuple(fixed), 0, movable, domains)
    while len(records) < budget:
        node = root
        if not random_only:
            while node.depth < len(movable) and not node.untried:
                node = max(node.children, key=lambda child: child.uct(node.visits, math.sqrt(2)))
            if node.depth < len(movable):
                action = node.untried.pop(rng.randrange(len(node.untried)))
                config = list(node.config)
                for index in movable[node.depth]:
                    config[index] = action
                child = Node(tuple(config), node.depth+1, movable, domains, node)
                node.children.append(child)
                node = child
        config = list(node.config)
        for group, values in zip(movable[node.depth:], domains[node.depth:]):
            if random_only or rng.random() < random_completion_probability:
                action = rng.choice(values)
            else:
                action = best_config[group[0]]
            for index in group:
                config[index] = action
        value = evaluate(config, 'grouped_random' if random_only else 'tree_rollout')
        reward = .5+.5*math.tanh((value-center)/scale) if normalized else value
        while node is not None:
            node.visits += 1
            node.value += reward
            node = node.parent
    assert len(records) == budget
    return dict(config=list(best_config), score=best_score, evaluations=len(records),
                unique_evaluations=len({tuple(row['config']) for row in records}),
                anchor_evaluations=min(len(anchors), budget), records=records,
                normalized=normalized, random_completion_probability=random_completion_probability,
                random_only=random_only)


def search(sample, model, metadata, budget=64, seed=17, **options):
    import torch
    from autodop.data import supported_dops
    from autodop.graph import build_graph
    from autodop.mcts import attention_guided_groups
    started = time.perf_counter()
    model.eval()
    candidates = [supported_dops(f, metadata['dop_classes']) for f in sample['fragments']]
    groups = attention_guided_groups(sample, model, metadata, candidates)

    def score(config):
        with torch.no_grad():
            return float(model(build_graph({**sample, 'dop_config':list(config)}, metadata)))

    result = search_domains(candidates, groups, score, budget=budget, seed=seed, **options)
    result['search_seconds'] = time.perf_counter()-started
    result['importance_forward_passes'] = 1
    return result
