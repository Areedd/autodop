"""Experimental batched inference for the unmodified CostModel; no production wiring."""
import math
import torch
from autodop.model import CostModel


def _attention(channel,nodes,edges):
    batch,count,width=nodes.shape
    def heads(value):return value.reshape(batch,count,channel.heads,channel.head_dim).transpose(1,2)
    q,k,v=[heads(layer(nodes)) for layer in [channel.query,channel.key,channel.value]]
    logits=q@k.transpose(-1,-2)/math.sqrt(channel.head_dim)+edges[:,None,:,:]*channel.edge_scale
    attended=(torch.softmax(logits,dim=-1)@v).transpose(1,2).contiguous().reshape(batch,count,width)
    return channel.output(attended)


@torch.inference_mode()
def score_batch(model,graphs):
    if type(model) is not CostModel:
        raise TypeError('batch prototype supports the standard CostModel only')
    if model.training:
        raise ValueError('batch scoring requires eval mode')
    if not graphs:
        raise ValueError('empty graph batch')
    count=graphs[0]['dop_ids'].numel()
    if any(g['dop_ids'].numel()!=count for g in graphs):
        raise ValueError('all graphs must have the same fragment count')
    fields={key:torch.stack([g[key] for g in graphs]) for key in ['categorical','numerical','dop_ids','dependency','competition']}
    encoder=model.encoder
    categories=[emb(fields['categorical'][:,:,i]) for i,emb in enumerate(encoder.category_embeddings)]
    nodes=encoder.input(torch.cat(categories+[fields['numerical'],encoder.dop_embedding(fields['dop_ids'])],dim=-1))
    competition=fields['competition'] if encoder.config['competition_edges'] else torch.zeros_like(fields['competition'])
    for layer in encoder.layers:
        dep=_attention(layer.dependency_attention,nodes,fields['dependency'])
        comp=_attention(layer.competition_attention,nodes,competition)
        attended=layer.channel_mix(torch.cat([dep,comp],dim=-1))
        nodes=layer.attention_norm(nodes+attended)
        nodes=layer.output_norm(nodes+layer.feed_forward(nodes))
    readout=model.global_readout;batch=nodes.shape[0]
    def heads(value):return value.reshape(batch,count,readout.heads,readout.head_dim).transpose(1,2)
    keys,values=heads(readout.key(nodes)),heads(readout.value(nodes))
    weights=torch.softmax(torch.einsum('hd,bhnd->bhn',readout.query,keys)/math.sqrt(readout.head_dim),dim=-1)
    pooled=torch.einsum('bhn,bhnd->bhd',weights,values).reshape(batch,-1)
    return model.scorer(readout.norm(readout.output(pooled))).squeeze(-1)
