"""Bounded native V2 pilot, with original FE file/runtime configuration recovery."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

import report90_fe_timing as fe
from report90_execute import ROOT, RUN, check
from report90_queue_extension import connect
from report90_wait_for_idle import wait_for_idle

OUT = RUN / 'duration_concurrent_restart'
CONF = ROOT.parents[1] / 'output/fe/conf/fe.conf'


def save(name, value):
    p = OUT / name
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2) + '\n')
    tmp.chmod(0o600)
    tmp.replace(p)


def configs():
    with connect() as c, c.cursor() as q:
        q.execute('ADMIN SHOW FRONTEND CONFIG')
        cols = [x[0].lower() for x in q.description]
        rows = [dict(zip(cols, r)) for r in q.fetchall()]
    return {r['key']: r for r in rows}


def restore_runtime():
    old = json.loads((OUT / 'RUNTIME_BEFORE.json').read_text())
    now = configs()
    changed = []
    with connect() as c, c.cursor() as q:
        for key, row in old.items():
            if str(row['ismutable']).lower() != 'true':
                continue
            if str(now[key]['value']) != str(row['value']):
                q.execute('ADMIN SET FRONTEND CONFIG (' + json.dumps(key) + ' = ' +
                          json.dumps(str(row['value'])) + ')')
                changed.append(key)
    final = configs()
    assert all(str(final[k]['value']) == str(r['value']) for k, r in old.items()
               if str(r['ismutable']).lower() == 'true')
    return changed


def verify_restoration():
    try:
        for _ in range(90):
            if fe.db_ready():
                break
            time.sleep(2)
        else:
            raise RuntimeError('Original FE readiness timeout')
        changed = restore_runtime()
        assert fe.sha(fe.JAR)=='fb2e974406e7291edd71df38d1826ac1610af043873e3ada93d9afeca8e53808'
        assert CONF.read_bytes() == (OUT / 'original-fe.conf').read_bytes()
        launch = json.loads((OUT / 'ORIGINAL_FE_LAUNCH.json').read_text())
        assert sorted(os.sched_getaffinity(fe.fe_pid())) == launch['affinity']
        assert str(configs()['enable_query_queue_v2']['value']).lower() == 'false'
        save('RESTORATION.json', dict(restored=True, pid=fe.fe_pid(), runtime_keys_restored=changed,
                                      configuration_sha256=fe.sha(CONF)))
        print('Original FE and runtime configuration restored', flush=True)
    except BaseException as error:
        save('RESTORATION.json', dict(restored=False, error=repr(error)))
        raise


def main():
    OUT.mkdir(exist_ok=False)
    save('STATUS.json', dict(stage='preflight', pid=os.getpid()))
    wait_for_idle(check, OUT / 'IDLE.json')
    current = RUN / 'native_predictor_service17/CURRENT_FE_LAUNCH.json'
    previous = json.loads(current.read_text())
    pid = fe.fe_pid()
    proc = Path('/proc')/str(pid)
    arguments = (proc/'cmdline').read_bytes().decode().strip('\0').split('\0')
    assert 'com.starrocks.StarRocksFE' in arguments
    assert (proc/'cwd').resolve() == ROOT.parents[1]
    environment = dict(part.split('=', 1) for part in (proc/'environ').read_bytes().decode().split('\0')
                       if '=' in part)
    launch = dict(pid=pid, executable=str((proc/'exe').resolve()), cwd=str((proc/'cwd').resolve()),
                  arguments=arguments, affinity=sorted(os.sched_getaffinity(pid)),
                  environment={key:environment[key] for key in previous['environment'] if key in environment},
                  config_sha256=fe.sha(CONF))
    assert fe.sha(fe.JAR) == 'fb2e974406e7291edd71df38d1826ac1610af043873e3ada93d9afeca8e53808'
    save('ORIGINAL_FE_LAUNCH.json', launch)
    shutil.copy2(CONF, OUT / 'original-fe.conf')
    (OUT / 'original-fe.conf').chmod(0o600)
    original = configs()
    assert str(original['enable_query_queue_v2']['value']).lower() == 'false'
    assert str(original['enable_query_cost_prediction']['value']).lower() == 'false'
    save('RUNTIME_BEFORE.json', original)
    save('PROTOCOL.json', dict(scope='Frozen four-query scheduling pilot, 128 native data executions, fixed24 slots per query, FIFO versus duration with mirrored arrival order. Collect all outcomes, independent audit required before performance claims; restore original FE and globals.',
         sources={str(p): fe.sha(p) for p in [Path(__file__), ROOT/'scripts/report90_duration_concurrent_pilot.py']}))
    fe.OUT = OUT
    stopped = False
    try:
        fe.stop_fe()
        stopped = True
        config = (OUT / 'original-fe.conf').read_text()
        assert config.count('JAVA_OPTS="') == 1
        config = config.replace('JAVA_OPTS="', 'JAVA_OPTS="-Dautodop.report.queueTimeline=true -Dautodop.report.durationQueue=true ', 1)
        CONF.write_text(config + '\nenable_query_queue_v2 = true\n')
        diagnostic_jar = RUN/'duration_integration_1789308246365866864/jar_validation/duration-fe.jar'
        assert fe.sha(diagnostic_jar)==json.loads((diagnostic_jar.parent/'RESULT.json').read_text())['jar_sha256']
        tmp=fe.JAR.with_suffix('.queue-diagnostic-tmp');shutil.copy2(diagnostic_jar,tmp);tmp.replace(fe.JAR)
        log = ROOT.parents[1]/'output/fe/log/fe.log'
        save('LOG_START.json', dict(path=str(log), inode=log.stat().st_ino, offset=log.stat().st_size))
        fe.start_fe()
        assert b'-Dautodop.report.queueTimeline=true' in Path(f'/proc/{fe.fe_pid()}/cmdline').read_bytes()
        restore_runtime()
        assert str(configs()['enable_query_queue_v2']['value']).lower() == 'true'
        save('STATUS.json', dict(stage='pilot', pid=os.getpid(), fe_pid=fe.fe_pid()))

        env = dict(os.environ, REPORT90_DURATION_JAR_SHA256=fe.sha(diagnostic_jar))
        subprocess.run([sys.executable, str(ROOT/'scripts/report90_duration_concurrent_pilot.py')], check=True, env=env)
        save('STATUS.json', dict(stage='collected_pending_audit', pid=os.getpid()))
    except BaseException as error:
        save('STATUS.json', dict(stage='failed', error=repr(error), pid=os.getpid()))
    finally:
        if stopped:
            pid = fe.fe_pid()
            proc = Path(f'/proc/{pid}/stat')
            if proc.exists() and not proc.read_text().split(') ')[1].startswith('Z'):
                fe.stop_fe()
            original_jar=RUN/'fe_timing/original-starrocks-fe.jar'
            assert fe.sha(original_jar)=='fb2e974406e7291edd71df38d1826ac1610af043873e3ada93d9afeca8e53808'
            tmp=fe.JAR.with_suffix('.queue-restore-tmp');shutil.copy2(original_jar,tmp);tmp.replace(fe.JAR)
            CONF.write_bytes((OUT / 'original-fe.conf').read_bytes())
            save('RESTORATION.json', dict(restored=False, configuration_restored=True, stage='starting_original'))
            # The restored FE remains this tool session's foreground process.
            # A child waits for readiness, restores mutable settings and writes proof.
            subprocess.Popen([sys.executable, str(Path(__file__)), '--verify-restoration'])
            fe.foreground_original_fe()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify-restoration', action='store_true')
    args = parser.parse_args()
    if args.verify_restoration:
        verify_restoration()
    else:
        main()
