"""Paired slot-class waiting diagnostic on all90 audited queries; no rerun."""
import json,re,hashlib
from pathlib import Path
import numpy as np
from report90_execute import RUN

def main():
 out=RUN/'report90_native_budget_cap4_full';proof=json.loads((out/'ALLOCATION_AUDIT.json').read_text())
 assert proof['status']=='verified' and proof['executions']==720
 for path,sha in proof['source_sha256'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==sha,path
 events={e['query_id']:e for e in map(json.loads,(out/'scored/events.jsonl').read_text().splitlines())}
 rows={(r['phase'],r['mode'],r['id']):r for r in proof['rows']};assert len(rows)==720
 values=[];summaries={}
 wait=lambda r:int(re.search(r'\|PendingTimeMs=(\d+)\|',r['audit_line'])[1])
 for phase in ['warmup','measured']:
  for base,new in [('native','native_budget'),('policy_static','policy_budget')]:
   ids={key[2] for key in rows if key[:2]==(phase,base)};assert len(ids)==90
   for key in ids:
    a,b=rows[phase,base,key],rows[phase,new,key];ea,eb=events[a['query_id']],events[b['query_id']]
    assert (ea['client'],ea['sequence'])==(eb['client'],eb['sequence'])
    assert a['slots']==24 and b['slots'] in [24,48]
    v=dict(id=key,phase=phase,baseline=base,predicted_mode=new,predicted_slots=b['slots'],
       baseline_wait_ms=wait(a),predicted_wait_ms=wait(b),baseline_client_ms=ea['client_latency_ms'],predicted_client_ms=eb['client_latency_ms'])
    if base=='policy_static':
     da,db=ea['dop_validation'],eb['dop_validation']
     v['same_policy_application']=da['applied']==db['applied']
     v['same_installed_vector']=da.get('installed_dop')==db.get('installed_dop') if da['applied'] and db['applied'] else None
    values.append(v)
   for slots in [24,48]:
    group=[v for v in values if v['phase']==phase and v['baseline']==base and v['predicted_slots']==slots]
    def stats(field):
     x=np.array([v[field] for v in group]);return dict(mean=float(x.mean()),p50=float(np.percentile(x,50)),p90=float(np.percentile(x,90)),p99=float(np.percentile(x,99)))
    summary=dict(count=len(group),baseline_wait_ms=stats('baseline_wait_ms'),predicted_wait_ms=stats('predicted_wait_ms'),baseline_client_ms=stats('baseline_client_ms'),predicted_client_ms=stats('predicted_client_ms'),
      paired_mean_wait_delta_ms=float(np.mean([v['predicted_wait_ms']-v['baseline_wait_ms'] for v in group])),
      paired_mean_client_delta_ms=float(np.mean([v['predicted_client_ms']-v['baseline_client_ms'] for v in group])))
    summaries[f'{phase}/{base}/slots{slots}']=summary
 policy=[v for v in values if v['baseline']=='policy_static']
 result=dict(status='diagnostic',summaries=summaries,rows=values,
   policy_application_changes=sum(not v['same_policy_application'] for v in policy),
   installed_vector_changes=sum(v['same_installed_vector'] is False for v in policy),
   scope='Matched query IDs within mode/phase via audited FE identity; same planned client/sequence. Slot24/48 groups defined by observed prediction, not favorable latency selection. Group differences are descriptive: arrival times, scheduler weights, resource contention and logging vary; no causal intervention or isolated service-time claim.')
 target=RUN/'native_queue_tail_analysis';target.mkdir(exist_ok=True)
 result['source_sha256']={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),out/'ALLOCATION_AUDIT.json',out/'scored/events.jsonl']}
 (target/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
 lines=['# 原生预算尾延迟：按槽位需求配对分析','',result['scope'],'','| 阶段/基线/预测槽位 | 查询数 | 平均排队变化 ms | 平均请求变化 ms |','|---|---:|---:|---:|']
 for k,v in summaries.items():lines.append(f"| {k} | {v['count']} | {v['paired_mean_wait_delta_ms']:.2f} | {v['paired_mean_client_delta_ms']:.2f} |")
 lines+=['',f"策略应用状态变化 {result['policy_application_changes']} 个配对；两边均应用策略时，安装向量变化 {result['installed_vector_changes']} 个配对。正数表示预测预算更慢。"]
 (target/'REPORT.md').write_text('\n'.join(lines)+'\n')
 print({k:{x:v[x] for x in ['count','paired_mean_wait_delta_ms','paired_mean_client_delta_ms']} for k,v in summaries.items()})
 print('policy changes',result['policy_application_changes'],result['installed_vector_changes'])

if __name__=='__main__':main()
