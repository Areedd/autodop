"""Evaluate frozen development memory model; never fit on report90 outcomes."""
import hashlib,json
from pathlib import Path
from statistics import median
from report90_execute import RUN
from report90_native_predictor import NativePredictor


def main():
    out=RUN/'report90_frozen_budget_evaluation';out.mkdir(exist_ok=True)
    features=RUN/'native_memory_features90_full/RESULT.json'
    identity=RUN/'native_memory_features90_full/IDENTITY_AUDIT.json'
    model_path=RUN/'native_predictor_service17/MODEL.json'
    identity_proof=json.loads(identity.read_text());assert identity_proof['status']=='verified'
    for path,expected in identity_proof['source_sha256'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==expected,path
    feature_rows=json.loads(features.read_text())['records'];assert len(feature_rows)==180
    model=NativePredictor.load(model_path)
    rows=[dict(id=r['id'],pipeline_dop=r['pipeline_dop'],prediction=model.predict_csv(r['csv'])) for r in feature_rows]
    assert len({(r['id'],r['pipeline_dop']) for r in rows})==180
    profiles=RUN/'report90_memory_profiles_full/MEMORY_PROFILE_CHECK.json'
    sources=[Path(__file__),features,identity,model_path]
    result=dict(status='features_replayed',rows=rows,
        scope='Frozen17-development-query model, report90 evaluation only. No test outcome fitting or model selection. Report90 is the previously selected favorable subset, not unbiased arbitrary SQL.')
    if profiles.exists():
        proof=json.loads(profiles.read_text());assert proof['status']=='verified' and len(proof['rows'])==360
        for path,expected in proof['source_sha256'].items():
            assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==expected,path
        events_path=RUN/'report90_memory_profiles_full/scored/events.jsonl'
        events=list(map(json.loads,events_path.read_text().splitlines()))
        assert len(events)==360 and all(e['status']=='verified' for e in events)
        policy_events=[e for e in events if e['mode']=='policy_static'];assert len(policy_events)==180
        result['policy_application']=dict(expected=180,applied=sum(e['dop_validation']['applied'] for e in policy_events),
            fallback_records=[dict(id=e['id'],query_id=e['query_id'],phase=e['phase'],validation=e['dop_validation'])
                              for e in policy_events if not e['dop_validation']['applied']],
            scope='Memory of policy mode includes its actual fallbacks; do not treat every row as installed heterogeneous DOP.')
        sources.append(events_path)
        peaks={}
        for r in proof['rows']:
            key=(r['id'],0 if r['mode']=='native' else 4)
            assert r['mode'] in ['native','policy_static']
            peaks[key]=max(peaks.get(key,0),r['peak_per_node']['upper_bytes'])
        assert len(peaks)==180
        for r in rows:
            observed=peaks[r['id'],r['pipeline_dop']];p=r['prediction']
            r.update(observed_peak_upper_bytes=observed,raw_budget_covers_observed=p['budget_bytes']>=observed,
                     encoded_nominal_covers_observed=p['nominal_bytes_per_worker']>=observed,
                     reservation_ratio=p['nominal_bytes_per_worker']/observed)
        result.update(status='memory_evaluated',raw_budget_underestimates=sum(not r['raw_budget_covers_observed'] for r in rows),
            encoded_nominal_underestimates=sum(not r['encoded_nominal_covers_observed'] for r in rows),
            median_reservation_ratio=median(r['reservation_ratio'] for r in rows),max_reservation_ratio=max(r['reservation_ratio'] for r in rows))
        sources.append(profiles)
    result['source_sha256']={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items() if k not in ['rows','source_sha256']})

if __name__=='__main__':main()
