"""Illustrate a disclosed post-hoc training-query mechanism case; no acceptance claim."""
import json
import os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR','/tmp/autodop-report-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from report90_neighborhood_prepare import RUN,sha

OUT=RUN/'training_contrast_case_study'

def main():
    assert not OUT.exists()
    prior=RUN/'training_contrasts_pilot_v2/SUMMARY.json';conditional=RUN/'training_conditional_contrasts/SUMMARY.json';a=json.loads(prior.read_text());b=json.loads(conditional.read_text())
    assert a['status']==b['status']=='verified_controlled_contrast_summary'
    q='complexdev_train_14_union_b4_m1183';panels=[('Local aggregate; other groups at4',a['queries'][q],['group0_low','group0_high']),('Merge aggregate; local aggregate at1',b['queries'][q],['group1_low','group1_high'])]
    fig,axes=plt.subplots(1,2,figsize=(10,4.3),sharey=True)
    for ax,(title,values,modes) in zip(axes,panels):
        for shift,phase,label,color in [(-.17,'warmup_ms','Warmup (diagnostic)','#a8bed2'),(.17,'formal_ms','Formal (one run)','#315e85')]:
            ys=[values[phase][mode] for mode in modes];ax.bar([shift,1+shift],ys,width=.32,label=label,color=color)
            for x,y in zip([shift,1+shift],ys):ax.text(x,y+15,f'{y:.0f}',ha='center',fontsize=8)
        ax.set_xticks([0,1],['DOP1','DOP16']);ax.set_title(title,fontsize=10);ax.set_ylabel('Query latency (ms)');ax.set_ylim(0,2300);ax.legend(fontsize=8)
    fig.suptitle('Opposite DOP preferences in one training query (selected case)',fontsize=12);fig.tight_layout();OUT.mkdir();fig.savefig(OUT/'opposite_preferences.png',dpi=180);fig.savefig(OUT/'opposite_preferences.pdf');plt.close(fig)
    manifest=RUN/'complex_development24/manifest.json';query=next(x for x in json.loads(manifest.read_text())['queries'] if x['id']==q);assert query['split']=='train'
    result={'status':'verified_descriptive_case','query':q,'query_manifest':query,'local_aggregate_dop1_ms':a['queries'][q]['formal_ms']['group0_low'],'local_aggregate_dop16_ms':a['queries'][q]['formal_ms']['group0_high'],'merge_aggregate_dop1_ms':b['queries'][q]['formal_ms']['group1_low'],'merge_aggregate_dop16_ms':b['queries'][q]['formal_ms']['group1_high'],
        'scope':'Post-hoc illustrative training case selected because it shows opposing observed preferences. The two panels use different controlled contexts and batches; not a complete2x2 factorial, unified-DOP comparison, automatic model performance, independent formal repetitions or significance proof. All4-query outcomes retained in parent reports.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),prior,conditional,manifest]}}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    (OUT/'REPORT.md').write_text('# 同查询相反DOP偏好的描述性案例\n\n'+result['scope']+'\n\n训练查询：'+q+'。局部聚合组DOP1/16对应1224/1924ms；固定该组DOP1后，合并聚合组DOP1/16对应1332/1175ms。两组在各自背景下的预热和正式方向一致，但每配置只有一次正式观测。\n\n![相反偏好](opposite_preferences.png)\n\n该案例用于解释为什么单一查询级DOP可能受限，不能替代90条查询性能测试，也不证明当前模型能正确选择这些配置。\n')
    print(OUT)

if __name__=='__main__':main()
