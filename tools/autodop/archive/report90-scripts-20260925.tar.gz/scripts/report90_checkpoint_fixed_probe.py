"""Require stable admission through a real completed checkpoint after the fix."""
import json,os,time,hashlib
from pathlib import Path
from report90_execute import ROOT,RUN
from report90_queue_extension import connect
OUT=RUN/'checkpoint_fixed_observation'
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
def main():
 OUT.mkdir(exist_ok=False);save('STATUS.json',dict(status='running',pid=os.getpid()))
 save('PROTOCOL.json',dict(max_seconds=95,required_completed_checkpoints=1,stable_samples_after_checkpoint=5,scope='No data queries; native checkpoint remains enabled. Verify global queue true survives actual historical image load/replay/save.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
 log=ROOT.parents[1]/'output/fe/log/fe.log';offset=log.stat().st_size;lines=[];samples=[];stable_after=0;completed=False
 with connect() as c,c.cursor() as q:
  q.execute('SELECT @@global.enable_query_queue_select');original=int(q.fetchone()[0]);save('SETTINGS.json',dict(original=original,restored=False))
  try:
   q.execute('SET GLOBAL enable_query_queue_select=true')
   for i in range(95):
    q.execute('SELECT @@global.enable_query_queue_select');value=int(q.fetchone()[0]);samples.append(dict(at_ms=int(time.time()*1000),value=value));save('SAMPLES.json',samples)
    assert value==1,'Live queue flag changed during fixed checkpoint'
    with log.open() as f:
     f.seek(offset);new=f.readlines();offset=f.tell()
    lines.extend(l.rstrip('\n') for l in new if 'checkpoint' in l.lower() or 'loadImage' in l)
    completed=completed or any('global_state_checkpoint_worker' in l and 'checkpoint finished save image.' in l for l in new)
    save('CHECKPOINT_LOG.json',lines)
    if completed:stable_after+=1
    if stable_after>=5:break
    time.sleep(1)
   assert completed and stable_after>=5,'No completed checkpoint observed within bound'
   save('RESULT.json',dict(status='verified',samples=len(samples),completed_checkpoint=True,stable_samples_after=stable_after,all_queue_samples_enabled=True,scope='Native checkpoint load/replay/save completed while live queue remained true. No checkpoint suppression or recurring reapplication.'))
  finally:
   q.execute('SET GLOBAL enable_query_queue_select=%s',(original,));q.execute('SELECT @@global.enable_query_queue_select');assert int(q.fetchone()[0])==original;save('SETTINGS.json',dict(original=original,restored=True))
 save('STATUS.json',dict(status='verified'))
if __name__=='__main__':
 try:main()
 except BaseException as e:
  if OUT.exists():save('STATUS.json',dict(status='failed',error=repr(e)))
  raise
