"""Extend the frozen readout diagnosis to the remaining two prespecified seeds."""
import json
from pathlib import Path
import runpy
from report90_neighborhood_prepare import RUN,sha
BASE=RUN/'structure_coverage20'


def main():
    first=BASE/'frozen_representation_probe'
    assert json.loads((first/'RESULT.json').read_text())['status']=='verified_frozen_representation_probe'
    assert json.loads((first/'DISAGREEMENT.json').read_text())['status']=='verified_pair_disagreement'
    source=Path(__file__).with_name('report90_frozen_representation_probe.py')
    out=BASE/'frozen_probe_stability';assert not out.exists()
    staged=BASE/'frozen_probe_stability_staged.py';assert not staged.exists()
    text=source.read_text()
    changes={
        "OUT=BASE/'frozen_representation_probe'":"OUT=BASE/'frozen_probe_stability'",
        "checkpoints={'multistage':BASE/'prepared/cost.pt','hard_ema_seed17':BASE/'hard_pair_ema_pilot/pilot/transformer_h0/best.pt'}":"checkpoints={f'hard_ema_seed{seed}':BASE/f'hard_pair_ema_stability/seed{seed}/transformer_h0/best.pt' for seed in [29,43]}",
        "'representations':['multistage64','hard_ema_seed17_64','raw_statistics1088']":"'representations':['hard_ema_seed29_64','hard_ema_seed43_64','raw_statistics1088']",
        "label='multistage64' if name=='multistage' else 'hard_ema_seed17_64'":"label=name+'_64'",
        'sources=[Path(__file__),':"sources=[Path(__file__),Path("+repr(str(source))+"),Path("+repr(str(Path(__file__)))+"),BASE/'frozen_representation_probe/RESULT.json',BASE/'frozen_representation_probe/DISAGREEMENT.json',",
    }
    for old,new in changes.items():assert text.count(old)==1,old;text=text.replace(old,new)
    compile(text,str(staged),'exec');staged.write_text(text)
    runpy.run_path(str(staged),run_name='frozen_probe_stability')['main']()
    a=json.loads((first/'RESULT.json').read_text());b=json.loads((out/'RESULT.json').read_text())
    assert a['models']['raw_statistics1088']==b['models']['raw_statistics1088']
    rows=[]
    for seed,record in [(17,a),(29,b),(43,b)]:
        original=record['original_scalar_models'][f'hard_ema_seed{seed}']['weighted_rank_accuracy']
        linear=record['models'][f'hard_ema_seed{seed}_64']['selected']['validation']['weighted_rank_accuracy']
        rows.append({'seed':seed,'original_macro_accuracy':original,'linear_macro_accuracy':linear})
    summary={'status':'verified_three_seed_frozen_probe','seeds':rows,'original_mean':sum(x['original_macro_accuracy'] for x in rows)/3,'linear_mean':sum(x['linear_macro_accuracy'] for x in rows)/3,'raw_statistics_control_exact_match':True,'scope':'Three predeclared encoder checkpoints frozen; refit only linear pair-gap readout. Same three fixed ridge settings selected on reused validation per representation. Diagnostic only; no90query scoring, SQL, encoder updates, or deployment.','source_sha256':{str(p):sha(p) for p in [Path(__file__),source,staged,first/'RESULT.json',out/'RESULT.json']}}
    (out/'THREE_SEED_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
    lines=['# 三种子冻结图表示诊断','',summary['scope'],'','| 种子 | 原打分头 | 新线性读出 |','|---|---:|---:|']
    for r in rows:lines.append(f"| {r['seed']} | {100*r['original_macro_accuracy']:.3f}% | {100*r['linear_macro_accuracy']:.3f}% |")
    lines+=['',f"原打分头平均{100*summary['original_mean']:.3f}%，线性读出平均{100*summary['linear_mean']:.3f}%。统计特征对照完整结果与第一批逐值一致。"]
    (out/'THREE_SEED_REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps(summary))

if __name__=='__main__':main()
