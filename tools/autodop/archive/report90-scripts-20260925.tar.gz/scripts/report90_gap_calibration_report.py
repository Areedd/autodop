"""Summarize all frozen loss-function seeds only after complete reload verification."""
import json
from pathlib import Path
from statistics import mean
from autodop.training import file_sha256
from report90_coverage_choices import BASE, read


def main():
    out = BASE/'gap_calibration'
    result = read(out/'RESULT.json')
    assert result['status'] == 'verified' and set(result['seeds']) == {'17','29','43'}
    assert read(out/'STATUS.json')['status'] == 'complete'
    assert read(out/'LOSS_CHECK.json')['status'] == 'verified'
    assert not (out/'COMPARISON.json').exists(), 'Preserve prior summary'
    rows = []
    evidence = [Path(__file__),out/'RESULT.json',out/'PROTOCOL.json',out/'LOSS_CHECK.json']
    for seed in ['17','29','43']:
        for phase, folder in [('hinge',BASE/'cosine_decay'/f'seed{seed}'),('gap_calibration',out/f'seed{seed}')]:
            replay = read(folder/'SCORE_REPLAY.json'); trained = read(folder/'RESULT.json')
            assert replay['status']=='verified' and file_sha256(folder/'RESULT.json')==replay['result_sha256']
            evidence += [folder/'RESULT.json',folder/'SCORE_REPLAY.json']
            model = trained['selected']['transformer']
            assert file_sha256(model['model'])==model['model_sha256']
            q = replay['models']['transformer']; assert q==model['selected']['validation']
            expected = result['before_cosine'][seed] if phase=='hinge' else result['seeds'][seed]
            assert replay['models']==expected
            rows.append({'seed':seed,'phase':phase,'epoch':model['selected']['epoch'],
                         'weighted_regret':q['weighted_regret'],
                         'complex_regret':q['cohorts']['complex_new']['mean_regret'],
                         'historical_regret':q['cohorts']['historical']['mean_regret'],
                         'training_seconds':model['seconds']})
        for kind in ['xgboost_points','xgboost_pairs']:
            assert result['before_cosine'][seed][kind]==result['seeds'][seed][kind]
    aggregates = {}
    for phase in ['hinge','gap_calibration']:
        subset = [r for r in rows if r['phase']==phase]
        aggregates[phase] = {key:mean(r[key] for r in subset) for key in ['weighted_regret','complex_regret','historical_regret','training_seconds']}
    improved = all(aggregates['gap_calibration'][key]<aggregates['hinge'][key] for key in ['weighted_regret','complex_regret'])
    comparison = {'status':'verified','rows':rows,'aggregates':aggregates,
                  'mean_weighted_and_complex_improved':improved,
                  'all_xgboost_controls_unchanged':True,
                  'scope':'Repeated development validation; no independent test, report90 scoring, SQL execution or deployment. Report all three seeds.',
                  'source_sha256':{str(p):file_sha256(p) for p in evidence}}
    (out/'COMPARISON.json').write_text(json.dumps(comparison,indent=2)+'\n')
    lines = ['# 延迟比分数间隔训练对照', '',comparison['scope'],'',
             '| 种子 | 训练目标 | 选定轮次 | 综合选择损失 | 复杂选择损失 | 完整训练秒数 |',
             '|---|---|---:|---:|---:|---:|']
    for r in rows:
        lines.append(f"| {r['seed']} | {r['phase']} | {r['epoch']} | {r['weighted_regret']:.2%} | {r['complex_regret']:.2%} | {r['training_seconds']:.2f} |")
    lines += ['', '| 训练目标 | 三种子综合均值 | 三种子复杂均值 |', '|---|---:|---:|']
    for phase,q in aggregates.items():lines.append(f"| {phase} | {q['weighted_regret']:.2%} | {q['complex_regret']:.2%} |")
    lines += ['',f'综合和复杂损失均值同时改善：{improved}。三个种子的XGBoost控制结果与原对照完全一致。', '',
              '总抽样量、模型结构、初始化、均匀抽样、学习率日程与验证选模规则保持不变；仅将单侧动态间隔hinge损失替换为拟合log(慢配置耗时/快配置耗时)的SmoothL1，beta固定为1。历史候选对的原批次标签保留。训练秒数包含100轮及其周期验证，不含更早多阶段预训练、数据准备和最终重载核验。未选择最好种子或触发SQL扩展。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines))


if __name__=='__main__': main()
