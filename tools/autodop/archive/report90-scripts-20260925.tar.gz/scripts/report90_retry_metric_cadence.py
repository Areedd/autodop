"""Quantify archived metric plateaus without treating scrapes as fresh samples."""
import collections
import datetime as dt
import hashlib
import json
import re
from pathlib import Path
from statistics import median


def main():
    root = Path(__file__).resolve().parents[3]
    out = root/'tools/autodop/runs/report90_20260912/development17_retry'
    source = out/'scored/resources.jsonl'
    series = collections.defaultdict(list)
    for r in map(json.loads, source.read_text().splitlines()):
        m = re.search(r'^starrocks_be_process_mem_bytes (\d+)$',
                      r.get('prometheus_raw', ''), re.MULTILINE)
        if m:
            series[r['url']].append((dt.datetime.fromisoformat(r['at']).timestamp(), int(m[1])))
    result = {}
    for url, records in series.items():
        changes = [b[0] for a, b in zip(records, records[1:]) if a[1] != b[1]]
        spans = [b-a for a, b in zip(changes, changes[1:])]
        result[url] = dict(scrapes=len(records), value_changes=len(changes),
                           median_scrape_interval_seconds=median(b[0]-a[0] for a,b in zip(records,records[1:])),
                           median_observed_value_change_interval_seconds=median(spans),
                           changes_separated_by_10_to_20_seconds=sum(10<=s<=20 for s in spans),
                           observed_change_intervals=spans)
    paths = [source, Path(__file__).resolve(), root/'be/src/common/daemon.cpp',
             root/'be/src/util/metrics.h', root/'be/src/util/system_metrics.cpp',
             root/'be/src/agent/task_worker_pool.cpp']
    note = dict(status='verified', endpoints=result,
                interpretation='Archived memory counters often repeat across scrapes. Source has a 15-second metrics daemon when enable_metric_calculator is enabled. This is source/trace consistency, not verification of the historical runtime configuration.',
                limitation='Fresh scrape time is not metric measurement time. Do not infer short-query memory peaks, smoothing causality, or failing-worker memory from fleet metrics. BE-to-FE resource reporting reads the process tracker directly on a separate interval.',
                sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    destination=out/'METRIC_CADENCE_AUDIT.json'; assert not destination.exists()
    destination.write_text(json.dumps(note,indent=2)+'\n')
    text=['# 内存指标刷新频率诊断','',
          '| BE 指标端点 | 抓取次数 | 数值变化次数 | 抓取间隔中位数（秒） | 数值变化间隔中位数（秒） |',
          '|---|---:|---:|---:|---:|']
    for url,r in result.items():
        text.append(f"| {url} | {r['scrapes']} | {r['value_changes']} | {r['median_scrape_interval_seconds']:.2f} | {r['median_observed_value_change_interval_seconds']:.2f} |")
    text+=['',note['interpretation'],'',note['limitation'],'',
           '时间线审计中的“前序采样在3秒内”仅表示抓取时间，不能保证底层内存计数在3秒内更新。',
           '后续小测需同时记录BE直接内存跟踪器、BE向FE上报及请求时平滑值；先验证时间戳和采样成本，再判断控制算法。']
    (out/'METRIC_CADENCE_AUDIT.md').write_text('\n'.join(text)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
