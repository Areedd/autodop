"""Paired complete local search costs including per-search cache setup."""
import json
import os
from pathlib import Path
import random
import statistics
import time
from unittest.mock import patch
import torch
from autodop import graph,mcts
from autodop.model import load_cost_model
from report90_prepared_graph import PreparedGraph
from report90_search_refinement import search
from report90_batched_cost import score_batch
from report90_neighborhood_prepare import RUN,sha


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1)
    out=RUN/'prepared_search_cost';out.mkdir(exist_ok=False)
    proof=json.loads((RUN/'prepared_graph_verification/RESULT.json').read_text());assert proof['status']=='verified_exact_graph_cache'
    protocol_source=RUN/'search_refinement_development/PROTOCOL.json'
    prior=json.loads(protocol_source.read_text());vp=protocol_source.parent/'vectors.json';vectors=json.loads(vp.read_text())
    model,ck=load_cost_model(prior['model']);model.eval();meta=ck['metadata']
    code=RUN/'graph_construction_pilot/competition_staged.py';namespace=dict(vars(graph));exec(compile(code.read_text(),str(code),'exec'),namespace)
    optimized=namespace['_competition'];old_competition=graph._competition;old_build=graph.build_graph;old_mcts=mcts.build_graph
    modes=['refined_uncached','refined_cached','random_uncached','random_cached']
    protocol=dict(queries=prior['queries'],modes=modes,budget=64,seed=17,warmups=1,rounds=4,
                  scope='Same optimized competition calculation in all arms. Cache construction, copying and static tensor clones included in each search timing. Prepared request to final choice only; excludes HTTP, FE, SQL and model load. Round order rotated; identical candidate/score traces required. No production modifications.',
                  source_sha256={str(p):sha(p) for p in [Path(__file__),Path(__file__).with_name('report90_prepared_graph.py'),Path(__file__).with_name('report90_search_refinement.py'),Path(__file__).with_name('report90_batched_cost.py'),Path(graph.__file__),Path(mcts.__file__),code,protocol_source,vp,Path(prior['model']),RUN/'prepared_graph_verification/RESULT.json']})
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    results=[]
    with patch.object(graph,'_competition',optimized),torch.inference_mode():
        for query in prior['queries']:
            sample=graph.sample_from_request(vectors['refined_full'][query]['request']);sample['dop_config']=[1 if f.get('is_gather_root') else 4 for f in sample['fragments']]
            def run(mode):
                start=time.perf_counter_ns()
                cached=mode.endswith('_cached')
                prepared=PreparedGraph(sample,meta,optimized) if cached else None
                def build(s,metadata,unknown_dop=False,device='cpu'):
                    assert metadata is meta and s['fragments'] is sample['fragments'] and s.get('edges') is sample.get('edges')
                    return prepared.build(s.get('dop_config',[0]*len(s['fragments'])),unknown_dop,device) if cached else old_build(s,metadata,unknown_dop,device)
                with patch.object(graph,'build_graph',build),patch.object(mcts,'build_graph',build):
                    if mode.startswith('refined'):
                        r=search(sample,model,meta,budget=64,seed=17)
                        value=dict(config=r['config'],score=r['score'],configs=[v['config'] for v in r['records']],scores=[v['score'] for v in r['records']])
                    else:
                        domains=[graph.supported_dops(f,meta['dop_classes']) for f in sample['fragments']];rng=random.Random(17)
                        configs=[[rng.choice(d) for d in domains] for _ in range(64)];scores=[]
                        for i in range(0,64,16):
                            gs=[build({**sample,'dop_config':c},meta) for c in configs[i:i+16]]
                            scores.extend(score_batch(model,gs).tolist())
                        best=max(range(64),key=lambda i:scores[i]);value=dict(config=configs[best],score=scores[best],configs=configs,scores=scores)
                return value,(time.perf_counter_ns()-start)/1e6
            warm={mode:run(mode)[0] for mode in modes}
            for method in ['refined','random']:assert warm[method+'_cached']==warm[method+'_uncached']
            timings={m:[] for m in modes}
            for round_index in range(4):
                order=modes[round_index:]+modes[:round_index]
                for position,mode in enumerate(order):
                    value,ms=run(mode);assert value==warm[mode]
                    timings[mode].append(dict(round=round_index,position=position,total_ms=ms))
            medians={m:statistics.median(v['total_ms'] for v in rows) for m,rows in timings.items()}
            results.append(dict(query=query,outputs=warm,timings=timings,median_ms=medians))
            print(query,medians,flush=True)
    assert graph._competition is old_competition and graph.build_graph is old_build and mcts.build_graph is old_mcts
    for p,digest in protocol['source_sha256'].items():assert sha(Path(p))==digest
    means={m:statistics.mean(r['median_ms'][m] for r in results) for m in modes}
    result=dict(status='verified_exact_search_cache',queries=results,mean_query_median_ms=means,module_bindings_restored=True,scope=protocol['scope'],protocol_sha256=sha(out/'PROTOCOL.json'))
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 查询静态特征缓存的本地搜索成本','',protocol['scope'],'',
           '| 方法 | 未缓存ms | 缓存ms | 降低 |','|---|---:|---:|---:|']
    for method in ['refined','random']:
        a,b=means[method+'_uncached'],means[method+'_cached']
        lines.append(f'| {method} | {a:.3f} | {b:.3f} | {100*(1-b/a):.2f}% |')
    lines += ['', '4条开发查询、各4轮计时，顺序轮换；每次搜索重新建立缓存，初始化成本计入。两种方法都得到相同缓存优化，所有候选轨迹和评分精确一致。', '',
              '本实验测量本地搜索成本，不含SQL或HTTP；不得将各批次耗时相加后冒充端到端实测。源码仅为实验适配器，生产代码及运行模块绑定未变。', '',
              '逐查询计时：[RESULT.json](RESULT.json)、[协议](PROTOCOL.json)。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(means,indent=2))


if __name__=='__main__':main()
