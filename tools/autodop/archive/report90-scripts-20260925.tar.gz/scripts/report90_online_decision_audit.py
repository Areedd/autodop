"""Audit live load correction and policy service costs on measured windows."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser();parser.add_argument('folder',type=Path);args=parser.parse_args();out=args.folder.resolve()
    audit=json.loads((out/'AUDIT.json').read_text())
    assert audit['status']=='verified_sustained_windows_and_slots'
    for p,digest in audit['source_sha256'].items():assert sha(Path(p))==digest,p
    result=json.loads((out/'RESULT.json').read_text())
    events=[json.loads(line) for line in (out/'events.jsonl').read_text().splitlines()]
    decisions=[json.loads(line) for line in (out/'decisions.jsonl').read_text().splitlines()]
    by={r['query_id']:r for r in decisions};assert len(by)==len(decisions)
    assert all(e['query_id'] in by for e in events if e['mode']!='native')
    summaries=[]
    for cell in result['rounds']:
        if cell['mode']=='native':continue
        measured=[e for e in events if (e['mode'],e['streams'])==(cell['mode'],cell['streams'])
            and cell['window_start']<=e['completion_monotonic']<cell['window_end']]
        timings=[];cpu=[];memory=[];dops=Counter();nodes=0;changed=0
        for event in measured:
            row=by[event['query_id']];assert row['mode']==cell['mode']
            assert row['response']['query_id']==event['query_id']
            timings.append(row['service_ms'])
            for w in row['request']['worker_loads'].values():
                if w.get('fresh'):cpu.append(w['cpu_used']);memory.append(w['mem_used_pct'])
            if not event['dop_validation']['applied']:continue
            fragments={str(f['fragment_id']):f for f in row['request']['fragments']}
            for decision in row['response']['decisions']:
                if fragments[str(decision['fragment_id'])].get('is_gather_root'):continue
                nodes+=1;dops[int(decision['dop'])]+=1
                changed+=':load_corrected' in decision.get('reason','')
        summaries.append(dict(mode=cell['mode'],streams=cell['streams'],measured_decisions=len(measured),
            service_mean_ms=statistics.mean(timings),service_p50_ms=statistics.median(timings),
            fresh_worker_mean_cpu=statistics.mean(cpu) if cpu else None,
            fresh_worker_mean_memory=statistics.mean(memory) if memory else None,
            applied_response_nongather_nodes=nodes,load_corrected_nodes=changed,
            applied_response_dop_histogram=dict(dops),fallbacks=sum(not e['dop_validation']['applied'] for e in measured)))
    sources=[Path(__file__),out/'AUDIT.json',out/'RESULT.json',out/'events.jsonl',out/'decisions.jsonl']
    value=dict(status='verified_live_decision_windows',summaries=summaries,
        scope='Service time includes decision code only, excluding journal append, network and FE. Fresh-worker means are request-weighted. DOP histograms describe accepted service responses, excluding gather roots and confidence fallbacks; physical installation separately verified by the main trace audit.',
        source_sha256={str(p):sha(p) for p in sources})
    (out/'ONLINE_AUDIT.json').write_text(json.dumps(value,indent=2)+'\n');print('Audited',len(summaries),'policy cells')


if __name__=='__main__':main()
