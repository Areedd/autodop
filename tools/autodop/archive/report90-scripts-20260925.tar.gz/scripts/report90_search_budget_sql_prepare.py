"""Freeze all six budget/method cells on four development queries, seed17."""
import json
from pathlib import Path
from autodop.graph import sample_from_request
from collect_paper_evaluations import VectorEngine
from report90_neighborhood_prepare import RUN,sha


def main():
    source=RUN/'search_budget_screen';out=RUN/'search_budget_sql';out.mkdir(exist_ok=False)
    result=json.loads((source/'RESULT.json').read_text());assert result['status']=='verified_prefix_screen'
    protocol=json.loads((source/'PROTOCOL.json').read_text())
    for path,digest in protocol['source_sha256'].items():assert sha(Path(path))==digest
    old=RUN/'search_refinement_development';original=json.loads((old/'vectors.json').read_text())
    manifest=json.loads((old/'manifest.json').read_text())
    assert {q['id'] for q in manifest['queries']}==set(protocol['queries'])
    vectors={}
    for row in result['rows']:
        if row['seed']!=17:continue
        mode=f"{row['method']}_budget{row['budget']}";query=row['query']
        request=original['refined_full'][query]['request'];sample=sample_from_request(request)
        vectors.setdefault(mode,{})[query]=dict(request=request,fragment_dops=dict(zip(sample['fragment_ids'],row['config'])))
    assert len(vectors)==6 and all(len(v)==4 for v in vectors.values())
    for entries in vectors.values():
        engine=VectorEngine(entries)
        for v in entries.values():engine.decide(v['request'])
    for name,value in [('vectors.json',vectors),('manifest.json',manifest)]:
        (out/name).write_text(json.dumps(value,indent=2)+'\n')
    sources=[Path(__file__),source/'RESULT.json',source/'PROTOCOL.json',old/'vectors.json',old/'manifest.json',out/'vectors.json',out/'manifest.json']
    frozen=dict(status='prepared',modes=list(vectors),queries=protocol['queries'],seed=17,
                expected_executions=48,warmups=1,repetitions=1,
                scope='All4development queries, both methods and16/32/64budgets. New fixed-vector SQL replay excludes search time. Different candidate budgets shown explicitly. One measured execution per cell; no significance claim or report90 selection.',
                source_sha256={str(p):sha(p) for p in sources})
    (out/'PROTOCOL.json').write_text(json.dumps(frozen,indent=2)+'\n')
    print(json.dumps({k:v for k,v in frozen.items() if k!='source_sha256'},indent=2))


if __name__=='__main__':main()
