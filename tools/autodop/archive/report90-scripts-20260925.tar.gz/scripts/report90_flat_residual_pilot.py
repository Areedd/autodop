"""Matched pilot of original graph Transformer plus fixed-feature residual head."""
import os
from pathlib import Path
import random
import subprocess
import sys
import torch
from report90_flat_residual_model import load_flat_residual_model as load_cost_model
from autodop.data import load_dataset
from autodop.training import select_partition
from report90_complex_retrain import pair_index, COHORTS, epoch_pairs
import report90_coverage_stability as common
from report90_neighborhood_prepare import RUN, sha

BASE=RUN/'structure_coverage20'
OUT=BASE/'flat_residual_pilot'
SOURCE=BASE/'statistical_readout_pilot/pilot_original_readout_trainer.py'
REFERENCE=BASE/'statistical_readout_pilot/pilot_original_readout'

def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1)
    assert not OUT.exists()
    assert common.read(REFERENCE/'SCORE_REPLAY.json')['status']=='verified'
    for p,digest in common.read(REFERENCE/'EXECUTION_SOURCE_SHA256.json').items(): assert sha(Path(p))==digest
    samples,pairs,meta=load_dataset(BASE/'merged_dataset')
    train,tp=select_partition(samples,pairs,common.read(BASE/'merged_dataset/CONTRACT.json'),'train')
    by=pair_index(train,tp)
    a=epoch_pairs(by,random.Random(17));b=epoch_pairs(by,random.Random(17))
    assert a==b and len(a)==624
    cohorts={plan:cohort for cohort,plans in by.items() for plan in plans}
    assert {c:sum(cohorts[p['plan_key']]==c for p in a) for c in COHORTS}==dict.fromkeys(COHORTS,312)
    assert all(p in by[cohorts[p['plan_key']]][p['plan_key']] for p in a)
    smoke=BASE/'flat_residual_smoke/RESULT.json'
    proof=common.read(smoke);assert proof['status']=='verified' and proof['exact_warmstart_configurations']==1577 and proof['train_only_normalization_samples']==1365
    for path,digest in proof['source_sha256'].items():assert sha(Path(path))==digest
    OUT.mkdir()
    common.save(OUT/'SAMPLING_AUDIT.json',{'status':'verified','seed':17,'sampled_pairs':len(a),
        'cohorts':{c:{'plans':len(plans),'pairs':sum(map(len,plans.values())),
            'min_pairs_per_plan':min(map(len,plans.values())),'max_pairs_per_plan':max(map(len,plans.values()))} for c,plans in by.items()},
        'training_only':True,'reproducible':True})
    common.save(OUT/'PROTOCOL.json',{'seed':17,'smoke_epochs':2,'pilot_epochs':30,
        'hypothesis':'Allow direct DOP-feature interactions and graph statistics to complement graph attention through a zero-output-initialized residual MLP.',
        'design':'Only architecture changes: original multi-stage model+competition plus fixed1088-feature64x64 residual MLP, final layer zero initialized. Same1365train/212valid,624pairs/epoch,original cohort/plan-uniform sampler,batch16,Adam1e-4,cosine100 horizon,calibrated loss/checkpoint selection. Train-only normalization independently recomputed; checkpoint contains normalization buffers. CPU-only prototype, not deployed.',
        'controls':'Retain strongest unchanged XGBoost points/pairs and previous MLP/regression controls; their query-weighted training remains documented. The new hybrid graph+fixed-feature model is reported explicitly, not relabeled as the original architecture. Original attention importance excludes residual branch contribution; search untested.',
        'selection':'Equal-cohort validation pair accuracy, regret then earlier epoch. No report90 scoring or SQL. Reused development validation.',
        'gate':'Must exceed matched reference and both XGBoost controls to expand.',
        'source_sha256':{str(p):sha(p) for p in [Path(__file__),SOURCE,REFERENCE/'RESULT.json',REFERENCE/'SCORE_REPLAY.json',Path(common.__file__),OUT/'SAMPLING_AUDIT.json',smoke,Path(__file__).with_name('report90_flat_residual_model.py')]}})
    for stage in ['smoke','pilot']:
        folder=OUT/stage
        changes={repr(str(REFERENCE)):repr(str(folder)),repr(str(BASE/'statistical_readout_pilot/PROTOCOL.json')):repr(str(OUT/'PROTOCOL.json')),
            'from autodop.model import load_cost_model, save_checkpoint':'from report90_flat_residual_model import load_flat_residual_model as load_cost_model, save_flat_residual_checkpoint as save_checkpoint'}
        if stage=='smoke':changes.update({'range(1,31)':'range(1,3)','epoch%10==0':'epoch%1==0','n_estimators=200':'n_estimators=5'})
        text=SOURCE.read_text(); applied={}
        for old,new in changes.items():
            count=text.count(old);assert count==(2 if old in [repr(str(BASE/'statistical_readout_pilot/PROTOCOL.json')),'epoch%10==0'] else 1),(old,count)
            text=text.replace(old,new);applied[old]={'replacement':new,'occurrences':count}
        script=OUT/f'{stage}_trainer.py';compile(text,str(script),'exec');script.write_text(text)
        common.save(OUT/f'{stage}_TRANSFORM.json',{'original_sha256':sha(SOURCE),'generated_sha256':sha(script),'changes':applied})
        common.save(OUT/'STATUS.json',{'status':'running','stage':stage,'pid':os.getpid()})
        with (OUT/f'{stage}.log').open('w') as stream:subprocess.run([sys.executable,str(script)],stdout=stream,stderr=subprocess.STDOUT,check=True)
        common.load_cost_model=load_cost_model;replay=common.replay(folder)
        print(stage,{k:v['weighted_rank_accuracy'] for k,v in replay.items()},flush=True)
    score=replay['transformer']['weighted_rank_accuracy'];reference=common.read(REFERENCE/'SCORE_REPLAY.json')['models']['transformer']['weighted_rank_accuracy']
    gate=score>reference and all(score>v['weighted_rank_accuracy'] for k,v in replay.items() if k!='transformer')
    common.save(OUT/'RESULT.json',{'status':'verified','models':replay,'reference_macro_accuracy':reference,'expansion_gate_passed':gate,'protocol_sha256':sha(OUT/'PROTOCOL.json')})
    common.save(OUT/'STATUS.json',{'status':'complete','expansion_gate_passed':gate})

if __name__=='__main__':
    try:main()
    except BaseException as error:
        if OUT.exists():common.save(OUT/'STATUS.json',{'status':'failed','error':repr(error)})
        raise
