"""Freeze teacher/student choices with identical requests and local cost scopes."""
import argparse
import json
import os
from pathlib import Path
import statistics
import time
from unittest.mock import patch
import torch
from autodop import graph,mcts
from autodop.model import load_cost_model,load_policy_model
from collect_paper_evaluations import VectorEngine
from report90_prepared_graph import PreparedGraph
from report90_search_refinement import search
from report90_matched_distillation import RUN,sha


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--scope',choices=['development','report90'],required=True);args=parser.parse_args()
    os.sched_setaffinity(0,{35});torch.set_num_threads(1)
    extension=RUN/'distillation_concurrency_extension';training=extension/'matched_distillation_v2'
    ready=json.loads((training/'RESULT.json').read_text());assert ready['status']=='verified_matched_distillation_training'
    parent=RUN/('search_refinement_development' if args.scope=='development' else 'search_refinement_report90')
    manifest=json.loads((parent/'manifest.json').read_text());original=json.loads((parent/'vectors.json').read_text())['refined_full']
    queries=[q['id'] for q in manifest['queries']]
    out=extension/('distillation_'+args.scope);out.mkdir(exist_ok=False)
    teacher_path=RUN/'structure_coverage20/prepared/cost.pt';policy_path=training/'policy.pt'
    teacher,tc=load_cost_model(teacher_path);student,sc=load_policy_model(policy_path)
    teacher.eval();student.eval();assert tc['metadata']==sc['metadata'];meta=tc['metadata']
    assert sc['training']['teacher_sha256']==sha(teacher_path)==ready['teacher_sha256']
    code=RUN/'graph_construction_pilot/competition_staged.py';ns=dict(vars(graph));exec(compile(code.read_text(),str(code),'exec'),ns)
    protocol=dict(status='frozen_before_choices',queries=queries,modes=['matched_teacher','matched_student'],
        seed=17,teacher_budget=64,expected_executions=len(queries)*4,local_warmup=1,local_repeats=2,
        scope='Matched teacher and freshly distilled student. Identical request and graph optimizations. Local time includes per-decision graph cache setup; excludes HTTP/FE/SQL. SQL raw-vector replay will use identical service path; student confidence recorded, no claim of deployment acceptance. No report90model selection.',
        source_sha256={str(p):sha(p) for p in [Path(__file__),teacher_path,policy_path,training/'RESULT.json',parent/'manifest.json',parent/'vectors.json',code]})
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    vectors={m:{} for m in protocol['modes']};rows=[]
    with patch.object(graph,'_competition',ns['_competition']),torch.inference_mode():
        for q in queries:
            request=original[q]['request'];sample=graph.sample_from_request(request)
            sample['dop_config']=[1 if f.get('is_gather_root') else 4 for f in sample['fragments']]
            def run(method):
                start=time.perf_counter_ns();prepared=PreparedGraph(sample,meta,ns['_competition'])
                if method=='matched_teacher':
                    def build(s,metadata,unknown_dop=False,device='cpu'):
                        assert metadata is meta and s['fragments'] is sample['fragments']
                        return prepared.build(s['dop_config'],unknown_dop,device)
                    with patch.object(graph,'build_graph',build),patch.object(mcts,'build_graph',build):
                        result=search(sample,teacher,meta,budget=64,seed=17)
                    config=result['config'];confidence=None
                else:
                    probabilities=student(prepared.build(sample['dop_config'],unknown_dop=True)).softmax(-1)
                    config=[meta['dop_classes'][i] for i in probabilities.argmax(-1).tolist()]
                    confidence=float(probabilities.max(-1).values.min())
                ms=(time.perf_counter_ns()-start)/1e6
                return dict(config=config,confidence=confidence),ms
            outputs={};timings={m:[] for m in vectors}
            for index in range(3):
                order=list(vectors) if index%2==0 else list(reversed(vectors))
                for mode in order:
                    value,ms=run(mode)
                    if mode in outputs:assert value==outputs[mode]
                    outputs[mode]=value
                    if index:timings[mode].append(ms)
            prepared=PreparedGraph(sample,meta,ns['_competition'])
            scores={m:float(teacher(prepared.build(v['config']))) for m,v in outputs.items()}
            for mode,v in outputs.items():vectors[mode][q]=dict(request=request,fragment_dops=dict(zip(sample['fragment_ids'],v['config'])))
            rows.append(dict(query=q,outputs=outputs,timings_ms=timings,teacher_scores=scores,
                equal_nodes=sum(a==b for a,b in zip(outputs['matched_teacher']['config'],outputs['matched_student']['config'])),
                nodes=len(sample['fragments'])))
            if len(rows)%10==0:print('Matched choices',len(rows),flush=True)
    for mode,entries in vectors.items():
        engine=VectorEngine(entries)
        for entry in entries.values():engine.decide(entry['request'])
    for p,d in protocol['source_sha256'].items():assert sha(Path(p))==d,p
    for name,value in [('manifest.json',manifest),('vectors.json',vectors),('CHOICES.json',rows)]:
        (out/name).write_text(json.dumps(value,indent=2)+'\n')
    result=dict(status='verified_matched_choices_and_costs',queries=len(rows),
        median_query_mean_ms={m:statistics.mean(statistics.median(r['timings_ms'][m]) for r in rows) for m in vectors},
        exact_vectors=sum(r['outputs']['matched_teacher']['config']==r['outputs']['matched_student']['config'] for r in rows),
        node_agreement=sum(r['equal_nodes'] for r in rows)/sum(r['nodes'] for r in rows),
        source_sha256={str(p):sha(p) for p in [out/'PROTOCOL.json',out/'vectors.json',out/'CHOICES.json']})
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))


if __name__=='__main__':main()
