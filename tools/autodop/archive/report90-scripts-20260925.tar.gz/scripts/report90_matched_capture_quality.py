"""Report phase variability for all matched queries; never filter by outcomes."""
from collections import defaultdict,Counter
from pathlib import Path
import hashlib,json,statistics

BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/matched_development_duration'


def main():
    proof_path=BASE/'full/INDEPENDENT_AUDIT.json';proof=json.loads(proof_path.read_text());assert proof['status']=='verified'
    for name,h in proof['source_sha256'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h
    source=BASE/'full/RESULT.json';records=json.loads(source.read_text())['executions']
    grouped=defaultdict(dict)
    for row in records:
        assert row['phase'] not in grouped[row['id']]
        grouped[row['id']][row['phase']]=row
    rows=[];counts=Counter()
    for query,phases in sorted(grouped.items()):
        assert set(phases)=={'warmup','measured'}
        a,b=phases['warmup'],phases['measured'];fa,fb=a['feature_record'],b['feature_record']
        assert fa['header']==fb['header']
        differences=[key for key,x,y in zip(fa['header'],fa['values'],fb['values']) if x!=y]
        counts.update(differences)
        rows.append(dict(id=query,split=a['split'],warmup_ms=a['client_latency_ms'],measured_ms=b['client_latency_ms'],
                         phase_ratio=max(a['client_latency_ms'],b['client_latency_ms'])/min(a['client_latency_ms'],b['client_latency_ms']),
                         changed_features=differences,changed_model_features=[k for k in differences if k.startswith(('env_','operators_'))]))
    assert len(rows)==61
    result=dict(status='descriptive_quality_audit',queries=61,phase_ratio_median=statistics.median(r['phase_ratio'] for r in rows),phase_ratio_max=max(r['phase_ratio'] for r in rows),
                queries_with_feature_changes=sum(bool(r['changed_features']) for r in rows),queries_with_model_feature_changes=sum(bool(r['changed_model_features']) for r in rows),
                feature_change_counts=dict(counts),rows=rows,
                scope='All queries and both observations retained, no outlier filtering. Feature equality is not full physical-plan equivalence. Callback service timing excludes network and FE feature construction; it cannot be subtracted to derive uncontaminated BE latency.',
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),proof_path,source]})
    (BASE/'full/QUALITY_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('rows','feature_change_counts','source_sha256')},indent=2))

if __name__=='__main__':main()
