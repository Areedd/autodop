"""Fixed small parity and paired timing pilot for experimental candidate batching."""
import collections
import json
import os
from pathlib import Path
import statistics
import time
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from report90_batched_cost import score_batch
from report90_neighborhood_prepare import RUN,sha
BASE=RUN/'structure_coverage20';OUT=RUN/'batched_cost_pilot'


def main():
    os.sched_setaffinity(0,{34});torch.set_num_threads(1);assert not OUT.exists()
    data=BASE/'merged_dataset';samples,pairs,metadata=load_dataset(data);by=collections.defaultdict(list)
    for s in samples:
        if s['split']=='train':by[s['plan_key']].append(s)
    plans=sorted(by,key=lambda p:(len(by[p][0]['fragments']),p));chosen=[plans[i] for i in [0,len(plans)//3,2*len(plans)//3,len(plans)-1]]
    checkpoint=BASE/'prepared/cost.pt';OUT.mkdir()
    protocol={'plans':chosen,'choice':'Training query plans at four fixed fragment-count quantile positions, no latency or score selection; at most8 lexicographically sorted configurations each.','timing':'Single CPU34, torch1thread, three warmups,10paired timed rounds alternating order; graphs prebuilt, input stacking included, graph construction/HTTP/FE/SQL excluded. Shared host, not exclusive capacity.','tolerance':{'atol':.00001,'rtol':.00001},'scope':'Numerical and local inference-cost pilot only. No ranking improvement, search algorithm speedup, query latency or production deployment claim. Sequentially dependent MCTS decisions cannot automatically be batched without changing search.', 'source_sha256':{str(p):sha(p) for p in [Path(__file__),Path(__file__).with_name('report90_batched_cost.py'),data/'samples.jsonl',data/'metadata.json',checkpoint,Path(__file__).parents[1]/'autodop/model.py']}}
    (OUT/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n');model,_=load_cost_model(checkpoint);model.eval();results=[]
    for plan in chosen:
        selected=sorted(by[plan],key=lambda s:s['config_key'])[:8];graphs=[build_graph(s,metadata) for s in selected]
        with torch.inference_mode():
            def scalar():return torch.stack([model(g) for g in graphs])
            def batch():return score_batch(model,graphs)
            a,b=scalar(),batch();torch.testing.assert_close(a,b,atol=1e-5,rtol=1e-5)
            pair_changes=sum(bool((a[i]>a[j])!=(b[i]>b[j])) for i in range(len(graphs)) for j in range(i+1,len(graphs)))
            for _ in range(3):scalar();batch()
            timings={'scalar':[],'batch':[]}
            for iteration in range(10):
                for name in (['scalar','batch'] if iteration%2==0 else ['batch','scalar']):
                    started=time.perf_counter_ns();result=scalar() if name=='scalar' else batch();elapsed=time.perf_counter_ns()-started;assert torch.isfinite(result).all();timings[name].append(elapsed/1e6)
        results.append({'plan_key':plan,'fragments':len(selected[0]['fragments']),'configs':len(selected),'max_abs_error':float((a-b).abs().max()),'pair_order_changes':pair_changes,'scalar_scores':a.tolist(),'batch_scores':b.tolist(),'timings_ms':timings,'median_scalar_ms':statistics.median(timings['scalar']),'median_batch_ms':statistics.median(timings['batch'])})
    for bad in [[],[graphs[0],build_graph(by[chosen[0]][0],metadata)]]:
        try:score_batch(model,bad)
        except ValueError:pass
        else:raise AssertionError('invalid batch not rejected')
    for p,d in protocol['source_sha256'].items():assert sha(Path(p))==d
    parity=all(r['pair_order_changes']==0 for r in results)
    result={'status':'verified_batch_inference_pilot','queries':results,'pair_order_unchanged':parity,'all_median_costs_lower':all(r['median_batch_ms']<r['median_scalar_ms'] for r in results),'scope':protocol['scope'],'protocol_sha256':sha(OUT/'PROTOCOL.json')}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 候选批量评分小测','',protocol['scope'],'',protocol['timing'],'','| fragment数 | 候选数 | 逐条中位ms | 批量中位ms | 最大分数绝对差 | 排序变化对数 |','|---:|---:|---:|---:|---:|---:|']
    for r in results:lines.append(f"| {r['fragments']} | {r['configs']} | {r['median_scalar_ms']:.3f} | {r['median_batch_ms']:.3f} | {r['max_abs_error']:.3g} | {r['pair_order_changes']} |")
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps(results))

if __name__=='__main__':main()
