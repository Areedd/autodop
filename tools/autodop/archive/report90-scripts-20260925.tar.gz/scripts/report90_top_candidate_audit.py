"""Diagnose top-candidate ranking and train-only sampling exposure; no fitting."""
import collections
import datetime
import json
import os
from pathlib import Path
import numpy as np
import torch
import xgboost as xgb
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model
from autodop.training import file_sha256, select_partition
from report90_models import MLP, flat_features
from report90_complex_retrain import key, pair_index, validation
from report90_coverage_choices import BASE, read


def main():
    out = BASE / 'top_candidate_audit'
    assert not out.exists()
    os.sched_setaffinity(0, {35}); torch.set_num_threads(1)
    out.mkdir()
    dataset = BASE / 'merged_dataset'
    samples, pairs, meta = load_dataset(dataset)
    contract = read(dataset / 'CONTRACT.json')
    train, tp = select_partition(samples, pairs, contract, 'train')
    valid, _ = select_partition(samples, pairs, contract, 'valid')
    assert len(train) == 1365 and len(valid) == 212
    by = pair_index(train, tp)
    train_groups = collections.defaultdict(list)
    for row in train: train_groups[row['plan_key']].append(row)
    exposure = {}
    for cohort, plans in by.items():
        rows = []
        for plan, pp in plans.items():
            ss = train_groups[plan]; best = min(s['latency_ms'] for s in ss)
            top = {s['config_key'] for s in ss if s['latency_ms'] <= 1.03 * best}
            hit = sum(p['fast_config_key'] in top or p['slow_config_key'] in top for p in pp)
            rows.append({'plan_key': plan, 'pairs': len(pp), 'top_pairs': hit,
                         'fraction': hit / len(pp), 'expected_top_draws_per_epoch': 312 / len(plans) * hit / len(pp)})
        exposure[cohort] = {'plans': rows, 'mean_top_pair_fraction': float(np.mean([r['fraction'] for r in rows])),
                            'plans_without_top_pair': sum(r['top_pairs'] == 0 for r in rows)}
    selected = {f'transformer_seed{s}': read(BASE / f'cosine_decay/seed{s}/RESULT.json')['selected']['transformer'] for s in [17,29,43]}
    stability = read(BASE / 'baseline_seed_stability/RESULT.json')
    assert stability['status'] == 'verified'
    for seed, models in stability['selected_models'].items():
        for kind, record in models.items():
            prefix, suffix = kind.split('_', 1)
            selected[f'{prefix}_seed{seed}_{suffix}'] = record
    selected.update({k:v for k,v in read(BASE / 'retrained/RESULT.json')['selected'].items() if k != 'transformer'})
    protocol = {'at': datetime.datetime.now().astimezone().isoformat(),
                'scope': 'Development validation diagnosis only. No report90 labels used; no fitting, model selection, SQL or deployment.',
                'top_definition': 'latency <= 1.03 * minimum candidate latency; pair accuracy ignores gaps below 3%',
                'models': selected, 'source_sha256': {str(p): file_sha256(p) for p in [Path(__file__),
                    dataset/'samples.jsonl', dataset/'pairs.jsonl', dataset/'CONTRACT.json',
                    BASE/'baseline_seed_stability/RESULT.json', BASE/'retrained/FEATURE_NORMALIZATION.npz']}}
    (out/'PROTOCOL.json').write_text(json.dumps(protocol, indent=2)+'\n')
    graphs = [build_graph(s, meta) for s in valid]
    norm = np.load(BASE / 'retrained/FEATURE_NORMALIZATION.npz')
    features = np.stack([(flat_features(g, meta)-norm['mean'])/norm['std'] for g in graphs])
    grouped = collections.defaultdict(list)
    for i,s in enumerate(valid): grouped[s['plan_key']].append(i)
    results = {}; saved_scores = {}
    for kind, record in selected.items():
        assert file_sha256(record['model']) == record['model_sha256']
        if kind.startswith('transformer'):
            model, ck = load_cost_model(record['model']); model.eval(); assert ck['metadata'] == meta
            with torch.no_grad(): scores = [float(model(g)) for g in graphs]
        elif kind.startswith('mlp'):
            ck = torch.load(record['model'], weights_only=False)
            model = MLP(ck['width']); model.load_state_dict(ck['state']); model.eval()
            with torch.no_grad(): scores = model(torch.tensor(features, dtype=torch.float32)).numpy().astype(float)
            if kind.endswith('regression'): scores = -scores
        else:
            model = xgb.XGBRegressor() if kind.endswith('regression') else xgb.XGBRanker()
            model.load_model(record['model']); model.set_params(n_jobs=1); scores = model.predict(features).astype(float)
            if kind.endswith('regression'): scores = -scores
        assert np.isfinite(scores).all()
        q = validation(valid, scores); assert q == record['selected']['validation']
        saved_scores[kind] = [float(x) for x in scores]
        details = []
        for plan, ids in grouped.items():
            fastest = min(valid[i]['latency_ms'] for i in ids)
            chosen = min(ids, key=lambda i: (-scores[i], valid[i]['config_key']))
            counts = {bucket: [0, 0] for bucket in ['top', 'non_top']}
            for offset,a in enumerate(ids):
                for b in ids[offset+1:]:
                    la,lb = valid[a]['latency_ms'],valid[b]['latency_ms']
                    if abs(la-lb)/min(la,lb) < .03: continue
                    bucket = 'top' if min(la,lb) <= 1.03*fastest else 'non_top'
                    counts[bucket][1] += 1
                    counts[bucket][0] += int((scores[a]-scores[b])*(lb-la)>0)
            details.append({'plan_key': plan, 'cohort': valid[chosen]['source_cohort'],
                            'chosen_config': valid[chosen]['config_key'],
                            'regret': valid[chosen]['latency_ms']/fastest-1, 'pairs': counts})
        aggregate = {}
        for cohort in by:
            rr = [r for r in details if r['cohort']==cohort]
            item = {'top3pct_hits':sum(r['regret']<=.03 for r in rr), 'plans':len(rr)}
            for bucket in ['top', 'non_top']:
                correct,total = map(sum,zip(*(r['pairs'][bucket] for r in rr)))
                item[bucket] = {'correct':correct,'pairs':total,'accuracy':correct/total if total else None}
            aggregate[cohort] = item
        results[kind] = {'validation': q, 'aggregate':aggregate, 'queries':details}
    (out/'SCORES.json').write_text(json.dumps(saved_scores)+'\n')
    reloaded = read(out/'SCORES.json')
    assert all(validation(valid, reloaded[k]) == r['validation'] for k,r in results.items())
    result = {'status':'verified', 'training_exposure':exposure, 'models':results,
              'serialized_scores_reverified':True, 'scope':protocol['scope']}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines = ['# 最优候选附近的排序诊断', '', protocol['scope'], '',
             '训练对按队列、计划和候选对依次均匀抽样。以下统计最优3%范围内配置涉及的候选对；历史候选对保留自己的批次标签，最优集合按规范化点标签定义，差异不视为数据错误。', '',
             '| 训练群组 | 涉及最优3%候选的抽样比例 | 无此类候选对的计划数 |','|---|---:|---:|']
    for c,v in exposure.items(): lines.append(f"| {c} | {v['mean_top_pair_fraction']:.2%} | {v['plans_without_top_pair']} |")
    lines += ['', '| 模型 | 验证群组 | 最优3%命中 | 最优附近对准确率 | 其余对准确率 |','|---|---|---:|---:|---:|']
    for k,r in results.items():
        for c,v in r['aggregate'].items():
            lines.append(f"| {k} | {c} | {v['top3pct_hits']}/{v['plans']} | {v['top']['accuracy']:.2%} | {v['non_top']['accuracy']:.2%} |")
    lines += ['', '该诊断只能定位错误与训练暴露，不能单独证明因果或保证改变抽样会改善。若调整抽样，应仅使用训练标签，保持模型结构、初始权重、总抽样预算和验证规则，再以小测检查。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines),flush=True)


if __name__ == '__main__': main()
