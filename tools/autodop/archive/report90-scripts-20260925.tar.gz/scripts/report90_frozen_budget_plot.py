"""Render frozen model memory evaluation; all report configurations retained."""
import json,os
os.environ.setdefault('MPLCONFIGDIR','/tmp/autodop-report-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from report90_execute import RUN

out=RUN/'report90_frozen_budget_evaluation';d=json.loads((out/'RESULT.json').read_text());assert d['status']=='memory_evaluated'
rows=d['rows'];obs=np.array([r['observed_peak_upper_bytes'] for r in rows])/1024**2
pred=np.array([r['prediction']['predicted_peak_bytes'] for r in rows])/1024**2
budget=np.array([r['prediction']['budget_bytes'] for r in rows])/1024**2
nominal=np.array([r['prediction']['nominal_bytes_per_worker'] for r in rows])/1024**2
fig,axes=plt.subplots(1,2,figsize=(10,4.2),layout='constrained')
for vals,label,marker in [(pred,'Predicted peak','o'),(budget,'Budget (+25%)','x'),(nominal,'Encoded nominal capacity','^')]:
 axes[0].scatter(obs,vals,s=14,alpha=.55,label=label,marker=marker)
lo=min(obs.min(),pred.min())*.8;hi=max(obs.max(),nominal.max())*1.2
axes[0].plot([lo,hi],[lo,hi],color='black',linestyle='--',linewidth=1)
axes[0].set(xscale='log',yscale='log',xlabel='Observed per-BE peak upper bound (MiB)',ylabel='Prediction / reservation (MiB)')
axes[0].legend(fontsize=8)
ratios=np.sort(nominal/obs);axes[1].plot(ratios,np.arange(1,len(rows)+1)/len(rows));axes[1].axvline(1,color='black',linestyle='--',linewidth=1)
axes[1].set(xlabel='Encoded nominal capacity / observed peak',ylabel='Empirical CDF',ylim=(0,1))
fig.suptitle('Frozen memory model: 90 queries × 2 modes (180 configurations)')
for ext in ['png','pdf']:fig.savefig(out/f'memory_evaluation.{ext}',dpi=180)
plt.close(fig)
q=np.maximum(pred/obs,obs/pred)
summary=dict(median_prediction_q_error=float(np.median(q)),p90_prediction_q_error=float(np.percentile(q,90)),
 max_prediction_q_error=float(q.max()),saturated=sum(r['prediction']['saturated'] for r in rows))
(out/'PLOT_METRICS.json').write_text(json.dumps(summary,indent=2)+'\n')
lines=['# 冻结内存模型在90条报告查询上的评估','',
 '模型仅使用既有17条开发查询训练，本轮未用报告结果重训或选模。90条是历史优势筛选子集，不能视为任意查询的无偏样本。', '',
 '360次profile采集全部通过；每个查询/模式取两轮观测峰值的较大值并计入显示舍入上界。180个配置中：', '',
 f"- 原始预算低于观测：{d['raw_budget_underestimates']}/180。",
 f"- 槽位编码后名义容量低于观测：{d['encoded_nominal_underestimates']}/180。",
 f"- 名义容量/观测峰值中位数：{d['median_reservation_ratio']:.2f}，最大：{d['max_reservation_ratio']:.2f}。",
 f"- 预测峰值Q-error中位数：{summary['median_prediction_q_error']:.2f}，p90：{summary['p90_prediction_q_error']:.2f}。", '',
 '策略模式180次执行实际应用170次，10次低置信度回退（5条查询各两轮），全部保留。预测预算覆盖与槽位容量覆盖分开报告；编码容量覆盖了这些观测，但保守预留可能限制并发，不能据此宣称模型无低估、未来无OOM或吞吐改善。', '',
 '![内存预测与容量预留](memory_evaluation.png)', '',
 '下一步允许进入预先定义的并发小测门槛：观测名义容量覆盖且无截断。该门槛不是未来内存保证。']
(out/'REPORT.md').write_text('\n'.join(lines)+'\n');print(summary)
