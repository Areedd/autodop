"""Query-grouped, development-only memory prediction screen; no SQL-ID lookup."""
import collections
import hashlib
import json
import math
import os
from pathlib import Path
import pickle
import time
import numpy as np
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'runs/report90_20260912'


def features(request):
    fs=request['fragments'];values={'fragment_count':len(fs),'edge_count':len(request['edges'])}
    for key in ['estimated_cardinality','estimated_avg_row_size','fragment_cost',
                'instance_count','scan_node_count','scan_range_count']:
        a=np.array([max(0,float(f.get(key,0))) for f in fs])
        assert np.isfinite(a).all()
        for label,value in [('sum',a.sum()),('max',a.max()),('mean',a.mean()),('std',a.std())]:
            values[f'{key}_{label}']=float(value)
    row_bytes=[max(0,float(f.get('estimated_cardinality',0)))*max(0,float(f.get('estimated_avg_row_size',0))) for f in fs]
    values['row_bytes_sum']=sum(row_bytes);values['row_bytes_max']=max(row_bytes)
    for kind in ['AGGREGATE','JOIN','SCAN','SORT','ANALYTIC','FILTER','UNION','EXCHANGE','PROJECT']:
        values[f'operators_{kind}']=sum(int(count) for f in fs for op,count in f['operator_counts'].items() if kind in op.upper())
    for key in ['is_gather_root','is_bucket_shuffle','is_colocated','is_replicated']:
        values[key]=sum(bool(f.get(key)) for f in fs)
    for direction in ['source_fragment_id','dest_fragment_id']:
        counts=collections.Counter(e[direction] for e in request['edges'])
        values[f'max_{direction}_degree']=max(counts.values(),default=0)
    names=sorted(values);x=np.log1p([values[k] for k in names]);assert np.isfinite(x).all()
    return names,x


def main():
    out=RUN/'memory_prediction_loo17';out.mkdir(exist_ok=False)
    os.sched_setaffinity(0,{35})
    save=lambda n,d:(out/n).write_text(json.dumps(d,indent=2,default=lambda v:v.item())+'\n')
    save('PROTOCOL.json',dict(scope='Grouped leave-one-query-out on historical development SQL; not independent test, not production prediction. '
         'All memory observations of held query excluded from fitting. Plan features only; no SQL text, IDs, worker load or profile features.',
         targets='Maximum displayed upper-bound per-BE peak over both modes and warm/formal observations.',
         features='Fixed structural/numeric summaries, log1p, first recorded static-policy plan per query.',
         models={'ridge':'StandardScaler(train fold), Ridge(alpha=1), log memory target',
                 'extra_trees':'64 trees, max_depth=4, min_samples_leaf=2, random_state=17, log target',
                 'neighbor_max3':'StandardScaler(train fold); max target among three nearest training queries',
                 'global_max':'maximum training target, conservative non-feature control',
                 'global_median':'median training target, non-feature control'},
         budget='max(64MiB, ceil(1.25 * predicted bytes)); constants unchanged from prior prototype.',
         exploratory_screen='No under-reservation on the 17 held-query observations and median reservation/observed peak <=2. '
                             'A pass permits new-query validation only, not deployment or a claimed guarantee.'))
    profile_path=RUN/'development17_memory_profiles_full/MEMORY_PROFILE_CHECK.json'
    profile=json.loads(profile_path.read_text());assert profile['status']=='verified'
    events_path=RUN/'development17_memory_profiles_full/scored/events.jsonl'
    events={r['query_id']:r for r in map(json.loads,events_path.read_text().splitlines())}
    decision_path=RUN/'development17_memory_profiles_full/scored/decisions.jsonl'
    graphs=collections.defaultdict(list)
    for r in map(json.loads,decision_path.read_text().splitlines()):
        assert r['mode']=='policy_static'
        e=events[r['query_id']];assert e['status']=='verified'
        graphs[e['id']].append(r['request'])
    ids=sorted(graphs);assert len(ids)==17
    X=[];y=[];changes={}
    for key in ids:
        names,x=features(graphs[key][0]);X.append(x)
        changes[key]=sum(not np.array_equal(features(g)[1],x) for g in graphs[key][1:])
        rows=[r for r in profile['rows'] if r['id']==key];assert len(rows)==4
        y.append(max(r['peak_per_node']['upper_bytes'] for r in rows))
    X=np.array(X);y=np.array(y,dtype=float);assert X.shape==(17,len(names))
    save('DATASET.json',dict(ids=ids,feature_names=names,log1p_features=X.tolist(),target_bytes=y.tolist(),
                             subsequent_plan_feature_changes=changes))
    (out/'models').mkdir();scores=[];sources=[profile_path,events_path,decision_path,Path(__file__).resolve()]
    for held,key in enumerate(ids):
        train=np.array([i for i in range(17) if i!=held]);assert held not in train
        scaler=StandardScaler().fit(X[train])
        distances=np.linalg.norm(scaler.transform(X[train])-scaler.transform(X[[held]])[0],axis=1)
        neighbors=train[np.argsort(distances,kind='stable')[:3]]
        assert held not in neighbors
        predictions={'neighbor_max3':float(max(y[neighbors])),
                     'global_max':float(max(y[train])), 'global_median':float(np.median(y[train]))}
        training_seconds={}
        for kind,model in [('ridge',make_pipeline(StandardScaler(),Ridge(alpha=1))),
                            ('extra_trees',ExtraTreesRegressor(n_estimators=64,max_depth=4,
                              min_samples_leaf=2,random_state=17,n_jobs=1))]:
            start=time.monotonic();model.fit(X[train],np.log(y[train]));training_seconds[kind]=time.monotonic()-start
            pred=model.predict(X[[held]])
            path=out/'models'/f'{held:02d}_{kind}.pkl';path.write_bytes(pickle.dumps(model))
            replay=pickle.loads(path.read_bytes()).predict(X[[held]])
            assert np.array_equal(pred,replay)
            assert np.isfinite(pred).all() and -700<float(pred[0])<700
            predictions[kind]=float(np.exp(pred[0]));sources.append(path)
        for kind,pred in predictions.items():
            reservation=max(64*1024**2,math.ceil(1.25*pred))
            scores.append(dict(id=key,model=kind,train_ids=[ids[i] for i in train],
                               neighbors=[ids[i] for i in neighbors] if kind=='neighbor_max3' else None,
                               predicted_bytes=pred,observed_peak_bytes=float(y[held]),reservation_bytes=reservation,
                               under_reserved=reservation<y[held],reservation_ratio=reservation/y[held],
                               q_error=max(pred/y[held],y[held]/pred),training_seconds=training_seconds.get(kind)))
    summaries={}
    for kind in sorted({r['model'] for r in scores}):
        rows=[r for r in scores if r['model']==kind];assert len(rows)==17
        ratios=[r['reservation_ratio'] for r in rows]
        under=sum(r['under_reserved'] for r in rows)
        summaries[kind]=dict(under_reserved_queries=under,median_q_error=float(np.median([r['q_error'] for r in rows])),
                            median_reservation_ratio=float(np.median(ratios)),max_reservation_ratio=max(ratios),
                            exploratory_screen_passed=under==0 and np.median(ratios)<=2)
    result=dict(status='verified',scope='Development LOO screen; no new SQL, full-data fitting, prediction service or deployment.',
                summaries=summaries,rows=scores,all_learned_fold_models_exactly_reloaded=True,
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    save('RESULT.json',result)
    lines=['# 计划特征内存预测：17查询留一验证','',result['scope'],'',
           '| 方法 | 预算低于观测峰值 | 中位Q误差 | 中位预算/峰值 | 最大预算/峰值 | 开发筛查 |',
           '|---|---:|---:|---:|---:|---|']
    for kind,r in summaries.items():
        lines.append(f"| {kind} | {r['under_reserved_queries']}/17 | {r['median_q_error']:.2f} | {r['median_reservation_ratio']:.2f} | {r['max_reservation_ratio']:.2f} | {r['exploratory_screen_passed']} |")
    lines+=['','每折排除整条查询的全部profile标签；特征缩放仅拟合其余16条。单个目标取两模式四次历史观测最大值，显示舍入上界保留。',
            '这仍是共享数据和SQL构造方法的开发验证，不是未见结构独立测试；未低估这些观测不代表未来不会低估。',
            '原生CostPredictor接收物理计划CSV特征，与这里的fragment摘要不同，不能未经特征对齐直接接入。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps(summaries,indent=2,default=lambda v:v.item()))


if __name__=='__main__':main()
