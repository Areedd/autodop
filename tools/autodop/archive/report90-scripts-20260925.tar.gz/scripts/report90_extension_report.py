"""Summarize the matched distillation and sustained-concurrency extension."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics


BASE=Path(__file__).resolve().parents[1]/'runs/report90_20260912/distillation_concurrency_extension'


def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def checked(path):
    value=read(path)
    for p,digest in value.get('source_sha256',{}).items():
        assert sha(Path(p))==digest,p
    return value


def percentile(values,p):
    values=sorted(values);position=(len(values)-1)*p
    low=int(position);high=min(low+1,len(values)-1)
    return values[low]+(values[high]-values[low])*(position-low)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--streams-folder',type=Path);args=parser.parse_args()
    train=checked(BASE/'matched_distillation_v2/RESULT.json')
    protocol=checked(BASE/'matched_distillation_v2/PROTOCOL.json')
    assert sha(BASE/'matched_distillation_v2/PROTOCOL.json')==train['protocol_sha256']
    assert sha(BASE/'matched_distillation_v2/policy.pt')==train['policy_sha256']
    labels=read(BASE/'matched_distillation_v2/LABELS.json')
    assert len(labels)==protocol['train_plans']+protocol['valid_plans']==136
    label_seconds=sum(r['search_seconds'] for r in labels)
    replay_seconds=sum(r['replay_seconds'] for r in labels)
    cost=checked(BASE/'distillation_report90/RESULT.json')
    checked(BASE/'distillation_report90/PROTOCOL.json')
    choices=read(BASE/'distillation_report90/CHOICES.json')
    assert len(choices)==90 and len({r['query'] for r in choices})==90
    timings={m:statistics.mean(statistics.median(r['timings_ms'][m]) for r in choices)
             for m in ('matched_teacher','matched_student')}
    assert timings==cost['median_query_mean_ms']
    confidence=[r['outputs']['matched_student']['confidence'] for r in choices]
    vectors=read(BASE/'distillation_report90/vectors.json');structure={}
    for mode in ('matched_teacher','matched_student'):
        node_counts=Counter();distinct=Counter()
        for row in choices:
            fragments=sorted(vectors[mode][row['query']]['request']['fragments'],key=lambda f:int(f['fragment_index']))
            config=row['outputs'][mode]['config'];assert len(fragments)==len(config)
            dops=[d for f,d in zip(fragments,config) if not f.get('is_gather_root')]
            node_counts.update(dops);distinct[len(set(dops))]+=1
        structure[mode]=dict(nongather_dop_counts=dict(node_counts),distinct_dops_per_query=dict(distinct),
            heterogeneous_queries=sum(n for k,n in distinct.items() if k>1))
    ratio=timings['matched_teacher']/timings['matched_student']
    result=dict(status='in_progress',training=train,decision_mean_ms=timings,decision_speedup=ratio,
                configuration_structure=structure,
                incremental_cost_seconds=dict(teacher_label_search=label_seconds,
                    reused_label_score_verification=replay_seconds,student_training_loop=train['training_loop_seconds']),
                student_confidence=dict(min=min(confidence),median=statistics.median(confidence),
                    max=max(confidence),below_05=sum(c<.5 for c in confidence)),
                exact_vectors=cost['exact_vectors'],node_agreement=cost['node_agreement'])
    sources=[Path(__file__),BASE/'matched_distillation_v2/RESULT.json',BASE/'matched_distillation_v2/PROTOCOL.json',
             BASE/'distillation_report90/RESULT.json',BASE/'distillation_report90/CHOICES.json',BASE/'matched_distillation_v2/LABELS.json']
    lines=['# 策略蒸馏与持续并发补充报告','',
        '本补测沿用从200条查询中事后筛选的90条优势查询，不重新筛选。其结论仅适用于该异构优势子集。', '',
        '## 匹配教师与学生','',
        f"冻结教师 {train['teacher_sha256'][:12]} 以64次候选预算生成114个训练计划和22个验证计划的标签。学生使用教师编码器初始化和随机分类头，训练50轮，按验证交叉熵选中第{train['selected_epoch']}轮；90条报告查询不参与本轮标签、梯度或模型选择。", '',
        '这是新增的直接硬标签蒸馏对照；教师历史训练仍按原报告披露。它不是已部署策略的全部训练阶段消融。', '',
        f"增量离线成本：136个计划的教师标签搜索共 {label_seconds:.2f} 秒，重用标签的逐一评分校验 {replay_seconds:.2f} 秒，50轮学生训练循环 {train['training_loop_seconds']:.2f} 秒。这些计时不含历史成本模型训练、数据采集、进程启动或SQL测试。", '',
        '| 同一请求上的本地决策 | 平均毫秒 |','|---|---:|',
        f"| 教师搜索（64候选预算） | {timings['matched_teacher']:.3f} |",
        f"| 蒸馏学生单次推理 | {timings['matched_student']:.3f} |", '',
        f'学生决策加速 {ratio:.2f} 倍。双方都包含每请求图准备，使用相同图优化；不含HTTP、FE或SQL。每请求预热一次、计时两次，先取请求内中位数再跨90请求取平均。', '',
        f"完整DOP向量一致 {cost['exact_vectors']}/90，节点DOP一致率 {cost['node_agreement']:.2%}。学生最小节点置信度中位数 {statistics.median(confidence):.3f}，{sum(c<.5 for c in confidence)}/90 低于默认0.5门限。SQL回放直接安装双方配置，不能据此声称新学生已通过线上置信度验收；没有替换线上模型。", '']
    lines += [f"排除gather根节点后，学生{structure['matched_student']['heterogeneous_queries']}/90条配置包含不同fragment DOP，教师为{structure['matched_teacher']['heterogeneous_queries']}/90；节点DOP分布保存在结构化结果中。",'']
    completed=[p for p in sorted((BASE/'distillation_report90').glob('collection*/RESULT.json')) if read(p).get('status')=='verified']
    assert len(completed)<=1,'Multiple completed comparisons: define aggregation before reporting'
    if completed:
        p=completed[0];sql=checked(p);sources.append(p)
        assert sql['executions']==360 and sql['restored']
        values=sql['per_query_ms'];assert set(values['matched_teacher'])==set(values['matched_student'])=={r['query'] for r in choices}
        stats={m:dict(mean=statistics.mean(v.values()),p50=percentile(v.values(),.5),
                      p90=percentile(v.values(),.9),p99=percentile(v.values(),.99)) for m,v in values.items()}
        gains={k:1-stats['matched_student'][k]/stats['matched_teacher'][k] for k in stats['matched_teacher']}
        result['sql']=dict(source=str(p),stats_ms=stats,student_reduction=gains,
            student_wins=sum(values['matched_student'][q]<values['matched_teacher'][q] for q in values['matched_teacher']))
        lines+=['| SQL配置来源 | 平均ms | p50 | p90 | p99 |','|---|---:|---:|---:|---:|']
        for m,s in stats.items():lines.append(f"| {m} | {s['mean']:.2f} | {s['p50']:.2f} | {s['p90']:.2f} | {s['p99']:.2f} |")
        lines+=['',f"学生相对教师SQL平均延迟变化：降低 {gains['mean']:.2%}；{result['sql']['student_wins']}/90条更快。每配置预热一次、正式一次，共360次SQL结果与DOP安装独立核验。该小测不证明重复测量显著性。",'']
        lines+=['教师搜索依据冻结模型的预测评分，属于搜索参考，并非实测最优配置的oracle。学生在本轮回放更快不代表超过真实最优解。','']
    else:lines+=['90条实际SQL对照尚未完成。','']
    lines+=['## 持续并发','']
    if args.streams_folder:
        folder=args.streams_folder.resolve();audit=checked(folder/'AUDIT.json');checked(folder/'PROTOCOL.json')
        assert audit['status']=='verified_sustained_windows_and_slots'
        result['concurrency']=audit;sources.append(folder/'AUDIT.json')
        lines+=['原生与已部署AutoDOP策略使用相同FE准入上限4；不是关闭准入的原生默认配置。窗口外稳定期、排空不计入吞吐。所有模式使用相同90条查询循环序列，无人为客户端等待。', '',
            '| 模式 | streams | QPS | 窗口查询种数 | 总查询种数 | 最大运行/等待 |','|---|---:|---:|---:|---:|---|']
        for r in sorted(audit['summaries'],key=lambda r:(r['streams'],r['mode'])):
            lines.append(f"| {r['mode']} | {r['streams']} | {r['qps']:.4f} | {r['window_unique_queries']} | {r['total_unique_queries']} | {r['max_observed_running']}/{r['max_observed_pending']} |")
        for m,s in audit['by_mode'].items():
            lines+=['',f"{m}：各档观测均值严格不下降={s['strictly_nondecreasing_observed']}，最高stream吞吐/观测峰值={s['largest_to_peak_ratio']:.2%}。"]
        policy_curve=audit['by_mode']['policy_load'];native_curve=audit['by_mode']['native']
        result['throughput_checks']=dict(
            observed_policy_monotonic=policy_curve['strictly_nondecreasing_observed'],
            policy_peak_to_queue_controlled_native_peak=policy_curve['peak_qps']/native_curve['peak_qps'],
            formal_stability_acceptance=False,
            scope='Observed points only. No independent repeated windows; no default queue-disabled native comparison.')
        lines+=['',f"AutoDOP观测峰值/相同准入上限原生观测峰值 = {policy_curve['peak_qps']/native_curve['peak_qps']:.3f}。这与关闭准入控制的产品默认峰值不同。"]
        lines+=['', '各格仅一次持续窗口，60秒分段用于检查波动，不作为独立重复。完整原始记录保留所有下降点；不以曲线平滑、挑选重跑结果或减少输入速率来制造单调性。本报告不将未经用户确认的5%容差当作通过标准。', '']
        if completed:result['status']='collected_and_audited; throughput_acceptance_separate'
        online_path=folder/'ONLINE_AUDIT.json'
        if online_path.exists():
            online=checked(online_path);sources.append(online_path);result['online_decisions']=online
            lines+=['## 在线负载修正与服务成本','',
                '| streams | 服务均值ms | 服务p50 ms | 已安装非gather节点修正比例 | 窗口回退数 |',
                '|---|---:|---:|---:|---:|']
            for r in online['summaries']:
                fraction=r['load_corrected_nodes']/r['applied_response_nongather_nodes'] if r['applied_response_nongather_nodes'] else 0
                lines.append(f"| {r['streams']} | {r['service_mean_ms']:.2f} | {r['service_p50_ms']:.2f} | {fraction:.2%} | {r['fallbacks']} |")
            lines+=['', '服务计时不含日志追加、HTTP或FE；修正比例来自已接受响应，gather根及置信度回退排除。物理DOP安装另由主轨迹核验，不把配置声明当作执行证据。', '']
    else:lines+=['正式90查询stream曲线尚未完成；4查询小测已验证263次执行，运行上限4生效，原策略在4/8/16streams下QPS为0.4833/0.5000/0.5167。该小测不替代正式曲线。','']
    lines+=['## 在线改动与边界','',
        '新增可关闭的基础策略LRU缓存，默认关闭，每次仍按最新负载修正。6个单元测试及270个真实请求/负载切换响应一致性检查通过。缓存小测吞吐存在下降，未启用到正式主对照；准入控制沿用FE现有机制。', '',
        '新蒸馏学生与并发使用的已部署策略是不同模型，不能交叉归因。此前90查询报告中的有限批次并发、搜索效率与本次持续窗口分别报告。此补测不能代替合同中的标准TPC-H SF100 streams7–20及TP/AP EXPLAIN开销验收。', '',
        '[结构化数据及来源](EXTENSION_RESULT.json)。失败启动和空闲门禁记录保留在各collection目录。']
    canonical=BASE/'CANONICAL_CACHE_PILOT.json'
    if canonical.exists():
        c=checked(canonical);sources.append(canonical);result['candidate_cache']=c
        lines+=['',f"独立候选试验对worker列表顺序作规范化，{c['requests']}个真实请求响应完全一致，模型调用由{c['model_calls'][0]}次降至{c['model_calls'][1]}次，本地回放服务平均耗时由{c['mean_ms'][0]:.2f}降至{c['mean_ms'][1]:.2f}ms。这是离线结果，未混入上述正式并发曲线，不能作为SQL吞吐收益。"]
    resources=BASE/'RESOURCE_AUDIT.json'
    if resources.exists():
        resource=checked(resources);sources.append(resources);result['resources']=resource
        lines+=['', '## 资源占用证据','',
            '| 模式 | streams | 平均资源组CPU核/BE | 最大跟踪内存GiB/BE | 覆盖 |',
            '|---|---:|---:|---:|---|']
        for cell in resource['cells']:
            bes=list(cell['by_be'].values())
            cores=[b['gauges']['starrocks_be_resource_group_inuse_cpu_cores{name="default_wg"}']['mean'] for b in bes
                   if 'starrocks_be_resource_group_inuse_cpu_cores{name="default_wg"}' in b['gauges']]
            memory=[b['gauges']['starrocks_be_process_mem_bytes']['max']/1024**3 for b in bes if 'starrocks_be_process_mem_bytes' in b['gauges']]
            coverage='完整窗口采样' if len(bes)==3 and all(b['first_offset_seconds']<10 and cell['window_seconds']-b['last_offset_seconds']<10 for b in bes) else '部分/缺失'
            if cores and memory:lines.append(f"| {cell['mode']} | {cell['streams']} | {statistics.mean(cores):.2f} | {max(memory):.2f} | {coverage} |")
        lines+=['', '资源旁路采样于首档开始后启动，首档缺口不补写。CPU列是默认资源组使用核数，内存列是BE跟踪值，不是整库驻内存或进程RSS证明。具体时间覆盖、HTTP失败及逐BE值见 [RESOURCE_AUDIT.json](RESOURCE_AUDIT.json)。']
    environment=BASE/'LIVE_ENVIRONMENT.json'
    if environment.exists():
        sources.append(environment)
        lines+=['', '本轮FE/BE版本、BE上报核数与内存限制见 [运行环境快照](LIVE_ENVIRONMENT.json)。']
    deployment=BASE/'LIVE_DEPLOYMENT.json'
    if deployment.exists():
        sources.append(deployment)
        lines+=['', '本轮三台BE镜像ID与先前验证的CPU容量修正版一致，CPU绑定分别0–7/8–15/16–23，容器内存各16GiB；只读核验见 [部署身份](LIVE_DEPLOYMENT.json)。']
    fe_identity=BASE/'FE_BINARY_IDENTITY.json'
    if fe_identity.exists():
        identity=read(fe_identity);sources.append(fe_identity)
        for row in identity['jars']:
            assert sha(Path(row['path']))==row['sha256']
            lines+=['',f"本轮9030服务FE的核心JAR摘要为 `{row['sha256']}`，与前期checkpoint临时修正版一致={row['matches_prior_checkpoint_fix']}。先前测试结束后恢复了原版FE；本轮两种模式共同使用该运行版本，准入上限由持续槽位采样核验。不能把前期修正FE下的批次结果与本轮曲线当成相同环境直接作差。"]
    profiles={}
    for path in sorted(BASE.glob('guard_pilot*/PROFILE_AUDIT.json')):
        proof=checked(path);assert proof['status']=='verified_profile_pilot'
        name=proof['profile'];assert name not in profiles,'Multiple successful pilot runs need an explicit aggregation rule'
        data=checked(path.parent/'AUDIT.json');profiles[name]=data['summaries'];sources.extend([path,path.parent/'AUDIT.json'])
    if profiles:
        result['admission_profile_pilots']=profiles
        lines+=['', '## 后续准入参数小测','',
            '依据正式曲线的资源占用进行顺序校准，查询固定为4种根结构的4条SQL，每格60秒窗口。与90查询曲线查询组成不同，不直接比较绝对QPS，不替换正式下降点。', '',
            '| 配置 | streams | QPS | 最大运行/等待 |','|---|---:|---:|---|']
        for name,rows in profiles.items():
            for r in rows:lines.append(f"| {name} | {r['streams']} | {r['qps']:.4f} | {r['max_observed_running']}/{r['max_observed_pending']} |")
        if 'cap4' in profiles:
            base={r['streams']:r['qps'] for r in profiles['cap4']};comparison={}
            for name,rows in profiles.items():
                if name=='cap4':continue
                assert {r['streams'] for r in rows}==set(base)
                comparison[name]=dict(all_streams_higher=all(r['qps']>base[r['streams']] for r in rows),
                    relative_qps={r['streams']:r['qps']/base[r['streams']]-1 for r in rows})
            result['admission_pilot_comparison']=comparison
            if {'memory_cap3','memory_cap5'}<=set(comparison) and not any(r['all_streams_higher'] for r in comparison.values()):
                result['admission_selection']='retain_cap4; alternatives_not_consistently_better_in_pilot'
                lines+=['', '上限3在16stream更慢、20stream持平；上限5在两档均更慢。本次小测未确认吞吐改善，保留上限4，不扩大这两项配置。该选择没有消除正式90查询曲线末档的1.41%回落。']
        lines+=['', 'cap4为无额外内存门限的同期控制；memory_cap3/5增加75%原生内存准入门限，CPU准入门限保持关闭，AutoDOP的CPU负载修正保持原设置。小测仅用于决定是否扩大试验，不以数次完成差异声明统计显著性。']
    lines+=['', '[本轮复现命令与核验说明](REPRODUCE.md)。']
    result['source_sha256']={str(p):sha(p) for p in sources}
    (BASE/'EXTENSION_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    (BASE/'REPORT.md').write_text('\n'.join(lines)+'\n');print(result['status'])


if __name__=='__main__':main()
