"""Eight-query diagnostic of native queue continuity; not a performance comparison."""
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,threading,time,uuid,re
from pathlib import Path
from report90_execute import ROOT,RUN,check
from report90_queue_extension import connect,settings_guard
from collect_trusted_dataset import frontend_settings,result_digest
OUT=RUN/'native_queue_repro8'
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
def main():
 OUT.mkdir(exist_ok=False);save('STATUS.json',dict(status='running',pid=os.getpid()));check(OUT/'IDLE.json')
 queries=json.loads((RUN/'DEVELOPMENT17_MANIFEST.json').read_text())['queries'][:2]
 trusted={q['id']:q for q in json.loads((RUN/'DEVELOPMENT17_TRUSTED.json').read_text())['queries']}
 save('PROTOCOL.json',dict(queries=2,clients=4,batches=2,executions=8,scope='Queue continuity diagnosis only; same native DOP0, no cost predictor, no AutoDOP and no performance claim.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
 rows=[]
 with settings_guard(OUT),connect() as control,control.cursor() as ctl:
  ctl.execute("ADMIN SHOW FRONTEND CONFIG LIKE 'enable_query_queue_v2'");assert str(ctl.fetchone()[2]).lower()=='true'
  with frontend_settings(ctl,{'max_query_queue_history_slots_number':'64','query_queue_slots_estimator_strategy':'MBE'},OUT/'frontend_settings.json',restore_connection_factory=connect):
   def flags(q):
    q.execute('SELECT @@global.enable_query_queue_select,@@global.enable_query_queue,@@session.enable_query_queue');return q.fetchone()
   for batch in range(2):
    barrier=threading.Barrier(4)
    def worker(i):
     item=queries[i%2];p=Path(item['sql_file']);assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sql_sha256']
     with connect() as c,c.cursor() as q:
      c._read_timeout=210
      for s in ['enable_pipeline_engine=true','pipeline_dop=0','enable_runtime_adaptive_dop=false','enable_query_cache=false','enable_spill=false','auto_dop_max_dop=16','enable_auto_dop=false','query_timeout=180','enable_profile=false']:q.execute('SET '+s)
      q.execute('USE `'+item['database']+'`');before=flags(q);token='native_queue_repro_'+uuid.uuid4().hex
      sql='/* '+token+' */ '+p.read_text().strip().rstrip(';');barrier.wait(30);q.execute(sql);data=q.fetchall();digest=result_digest(data);assert digest==trusted[item['id']]['native_result_digest']
      q.execute('SELECT /*+ SET_VAR(enable_auto_dop=false) */ last_query_id()');qid=q.fetchone()[0];after=flags(q)
      return dict(batch=batch,client=i,id=item['id'],query_id=qid,before=before,after=after,sql=sql,token=token,result_digest=digest)
    with ThreadPoolExecutor(max_workers=4) as pool:rows.extend(pool.map(worker,range(4)))
    save('ROWS.json',rows)
    ctl.execute('SELECT QUERY_ID,STATE,EST_COSTS_SLOTS,ALLOCATE_SLOTS FROM information_schema.warehouse_queries');cols=[x[0].lower() for x in ctl.description]
    save(f'HISTORY_{batch}.json',[dict(zip(cols,x)) for x in ctl.fetchall()])
    save(f'GLOBAL_{batch}.json',dict(queue_flags=flags(ctl)))
 save('STATUS.json',dict(status='captured',executions=len(rows)))
if __name__=='__main__':
 try:main()
 except BaseException as e:
  if OUT.exists():save('STATUS.json',dict(status='failed',error=repr(e)))
  raise
