"""Frozen development-only pressure screen; retain every attempted query and failure."""
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

from report90_execute import ROOT, RUN, check, accept_concurrent_evidence
import report90_queue_extension as queue
from report90_cpu_observe import observe, workers

OUT = RUN / 'development17_pressure'
MODES = ['native', 'policy_static', 'policy_load']


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    path = OUT / name
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def main():
    OUT.mkdir(exist_ok=False)
    save('STATUS.json', {'status': 'running', 'stage': 'preflight', 'pid': os.getpid()})
    manifest = RUN / 'DEVELOPMENT17_MANIFEST.json'
    trusted = RUN / 'DEVELOPMENT17_TRUSTED.json'
    prior = read(RUN / 'development17_calibration/RESULT.json')
    assert prior['status'] == 'complete' and prior['selected_mode'] is None
    for parent in [RUN/'development17_calibration', RUN/'queue_cpu_corrected_20260913']:
        assert read(parent/'STATUS.json')['status'] == 'complete'
    queries = read(manifest)['queries']
    assert len(queries) == 17 and all(q['split'] == 'train' and q['training_eligible'] for q in queries)
    assert not {q['sql_sha256'] for q in queries} & {q['sql_sha256'] for q in read(RUN/'manifest.json')['queries']}
    model = read(RUN/'PROTOCOL.json')
    assert digest(Path(model['model'])) == model['model_sha256']
    queue.SETTINGS = {**queue.SETTINGS, 'query_queue_concurrency_limit': '16'}
    protocol = {'frozen_at': datetime.datetime.now().astimezone().isoformat(),
                'purpose': 'Test whether default load correction helps under higher common admission capacity, on historical training SQL only.',
                'queries': 17, 'clients': 16, 'minimum_per_client': 2,
                'tasks_per_mode_per_phase': 34, 'expected_slots': 204,
                'warmup': 1, 'repetitions': 1, 'modes': MODES, 'queue_settings': queue.SETTINGS,
                'seed': model['seed'], 'manifest_sha256': digest(manifest),
                'load_parameters': {'cpu_threshold': .4, 'mem_threshold': .65, 'floor': .1},
                'selection_gate': 'All evidence valid; all load queries successful; actual installed correction observed; formal load goodput at least 3% above both native and static. No automatic expansion. All modes and queries retained.',
                'scope': 'Finite-batch development screen, not report90, steady state or significance proof. Same common admission cap for every mode. Native admission is not an AutoDOP contribution.',
                'failure_policy': 'Only independently verified complete attempts with genuine BE process memory-limit failures accepted as overload outcomes; no retry or exclusion. Other failures invalidate screen.'}
    save('PROTOCOL.json', protocol)
    sources = [Path(__file__), ROOT/'collect_paper_evaluations.py', ROOT/'scripts/verify_paper_evaluations.py',
               ROOT/'scripts/report90_execute.py', ROOT/'scripts/report90_queue_extension.py',
               ROOT/'scripts/report90_cpu_observe.py', manifest, trusted, Path(model['model'])]
    save('EXECUTION_SOURCE_SHA256.json', {str(p): digest(p) for p in sources})
    os.sched_setaffinity(0, set(range(27, 35)))
    nodes = workers()
    expected_image = 'sha256:73548ebadb50d11fec58e9937ebd5ee189205fd8f1acf8359fc63923132c476b'
    assert all(n['image_id'] == expected_image for n in nodes)
    save('DEPLOYMENT.json', nodes)
    for attempt in range(20):
        try:
            check(OUT/f'IDLE_{attempt}.json')
            break
        except RuntimeError:
            if attempt == 19:
                raise
            time.sleep(15)
    command = [sys.executable, str(ROOT/'collect_paper_evaluations.py'),
               '--manifest', str(manifest), '--trusted-collection', str(trusted),
               '--output-dir', str(OUT/'scored'), '--policy-model', model['model'],
               '--modes', ','.join(MODES), '--scenario', 'concurrent', '--clients', '16',
               '--minimum-per-client', '2', '--warmup', '1', '--repetitions', '1',
               '--seed', str(model['seed']), '--query-timeout-s', '180', '--auto-dop-max-dop', '16',
               '--torch-threads', '1', '--decision-timeout-ms', '1000', '--metrics-urls',
               'http://127.0.0.1:8040/metrics,http://127.0.0.1:8041/metrics,http://127.0.0.1:8042/metrics,http://127.0.0.1:8030/metrics']
    save('COMMAND.json', command)
    save('STATUS.json', {'status': 'running', 'stage': 'pressure_screen', 'pid': os.getpid()})
    stop = threading.Event()
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
        observation = executor.submit(observe, OUT/'CPU.jsonl', 2400, 3, stop)
        try:
            with queue.settings_guard(OUT):
                subprocess.run(command, check=True)
        finally:
            stop.set()
            observation.result()
    proof_path = OUT/'scored/independent_verification.json'
    subprocess.run([sys.executable, str(ROOT/'scripts/verify_paper_evaluations.py'),
                    '--collection-dir', str(OUT/'scored'), '--output', str(proof_path)], check=True)
    proof = read(proof_path)
    accept_concurrent_evidence(proof_path)
    assert proof['expected_slots'] == 204 and proof['recorded_sql_slots'] == 204
    assert read(OUT/'QUEUE_SETTINGS.json')['restored'] and read(OUT/'scored/frontend_settings.json')['restored']
    for path, expected in proof['source_sha256'].items():
        assert digest(Path(path)) == expected
    events = [json.loads(line) for line in (OUT/'scored/events.jsonl').open()]
    rounds = read(OUT/'scored/collection.json')['rounds']
    # Failed SQL may not return last_query_id; retain failures in mode counts.
    measured = {e['query_id']: e for e in events if e['phase'] == 'measured' and e.get('query_id')}
    metrics = {}
    for mode in MODES:
        selected = [e for e in events if e['mode'] == mode]
        formal = [r for r in rounds if r['mode'] == mode and r['phase'] == 'measured']
        assert len(selected) == 68 and len(formal) == 1
        metrics[mode] = {'attempts_all_phases': len(selected),
                         'failures_all_phases': sum(e['status'] != 'verified' for e in selected),
                         'formal_rounds': formal,
                         'formal_goodput': sum(r['verified'] for r in formal)/sum(r['workload_wall_seconds'] for r in formal),
                         'installed_corrected_formal_queries': 0, 'max_fresh_memory': 0., 'max_fresh_cpu': 0.}
    for line in (OUT/'scored/decisions.jsonl').open():
        decision = json.loads(line)
        event = measured.get(decision['query_id'])
        if event is None:
            continue
        metric = metrics[decision['mode']]
        corrected = any('load_corrected' in d.get('reason', '') for d in decision['response']['decisions'])
        metric['installed_corrected_formal_queries'] += int(corrected and event.get('dop_validation', {}).get('applied', False))
        for load in decision['request'].get('worker_loads', {}).values():
            if load.get('fresh'):
                metric['max_fresh_memory'] = max(metric['max_fresh_memory'], load['mem_used_pct'])
                metric['max_fresh_cpu'] = max(metric['max_fresh_cpu'], load['cpu_used'])
    load = metrics['policy_load']
    passed = (load['failures_all_phases'] == 0 and load['installed_corrected_formal_queries'] > 0
              and all(load['formal_goodput'] >= 1.03*metrics[m]['formal_goodput'] for m in ['native', 'policy_static']))
    save('RESULT.json', {'status': 'complete', 'screen_passed': passed, 'metrics': metrics,
                         'verification_sha256': digest(proof_path), 'scope': protocol['scope']})
    save('STATUS.json', {'status': 'complete', 'screen_passed': passed,
                         'at': datetime.datetime.now().astimezone().isoformat()})


if __name__ == '__main__':
    if OUT.exists():
        raise SystemExit('Existing pressure screen must be preserved')
    try:
        main()
    except BaseException as error:
        if OUT.exists():
            save('STATUS.json', {'status': 'failed', 'error': repr(error), 'pid': os.getpid()})
        raise
