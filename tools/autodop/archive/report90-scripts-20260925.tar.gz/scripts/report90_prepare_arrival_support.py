"""Create a separate collector; preserve earlier benchmark artifacts byte-for-byte."""
from pathlib import Path
import hashlib,json

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'runs/report90_20260912'

def main():
    src=RUN/'native_mixed_budget_pilot_support';out=RUN/'native_arrival_budget_pilot_support'
    out.mkdir(exist_ok=False)
    for p in src.iterdir():
        if p.is_file():(out/p.name).write_bytes(p.read_bytes())
    p=out/'collector.py';s=p.read_text()
    s=s.replace('import time\n','import time\nfrom report90_arrival_schedule import build_schedule, wait_until\n',1)
    anchor='                            measurement = {}'
    assert s.count(anchor)==1
    s=s.replace(anchor,"                            arrival = build_schedule(queues, os.environ['REPORT90_FIRST_QUERY'])\n"+anchor)
    anchor="                                        event = {'scenario': args.scenario"
    assert s.count(anchor)==1
    s=s.replace(anchor,"                                        assert sequence == 0\n                                        planned = measurement['start'] + arrival[client_index]['offset_seconds']\n                                        wait_until(planned)\n"+anchor)
    anchor="                                        try:\n                                            if mode in vectors:"
    assert s.count(anchor)==1
    s=s.replace(anchor,"                                        event.update(arrival_rank=arrival[client_index]['rank'], planned_release_monotonic=planned, release_lateness_ms=(time.monotonic()-planned)*1000)\n"+anchor)
    p.write_text(s);compile(s,str(p),'exec')
    sources=[Path(__file__),ROOT/'scripts/report90_arrival_schedule.py',src/'collector.py']
    (out/'ARRIVAL_PROTOCOL.json').write_text(json.dumps(dict(status='prepared_not_run',interval_seconds=.25,
         orders=['random200_001_m1195','random200_007_m1189'],jobs_per_query=8,clients=16,
         scope='Two mirrored grouped arrival orders, fixed 250 ms release spacing. SQL client latency excludes intentional pre-submit delay; workload wall time includes it. Actual FE require order must be audited. Both orders and all modes retained; instrumented diagnostic only.',
         source_sha256={str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in sources}),indent=2)+'\n')
    print(out)

if __name__=='__main__':main()
