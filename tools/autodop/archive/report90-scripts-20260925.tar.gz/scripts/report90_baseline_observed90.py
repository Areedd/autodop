"""Freeze and replay all baseline seeds on the unchanged measured report90 pool."""
import datetime
import json
import subprocess
import sys
from pathlib import Path

from autodop.training import file_sha256
from report90_coverage_choices import BASE, read


def main():
    source = Path(__file__).with_name('report90_augmented_observed_pool.py')
    stability = BASE / 'baseline_seed_stability/RESULT.json'
    result = read(stability)
    assert result['status'] == 'verified'
    support = BASE / 'observed90_seed_audit_support'
    assert not support.exists(), 'Preserve previous execution'
    support.mkdir()
    replacements = [
        ("OUT = BASE / 'observed90_audit'", "OUT = BASE / 'observed90_seed_audit'"),
        ("    selected.update(extra['selected'])", "    selected.update(extra['selected'])\n"
         "    stability = read(BASE / 'baseline_seed_stability/RESULT.json')\n"
         "    assert stability['status'] == 'verified'\n"
         "    for seed in ['29', '43']:\n"
         "        for kind, record in stability['selected_models'][seed].items():\n"
         "            prefix, suffix = kind.split('_', 1)\n"
         "            selected[f'{prefix}_seed{seed}_{suffix}'] = record\n"
         "    assert len(selected) == 14"),
        ("BASE / 'cosine_decay/RESULT.json', BASE / 'additional_baselines_full/RESULT.json'",
         "BASE / 'cosine_decay/RESULT.json', BASE / 'baseline_seed_stability/RESULT.json', BASE / 'additional_baselines_full/RESULT.json'"),
        ("Path(__file__).with_name('report90_models.py')", repr(str(source.with_name('report90_models.py')))),
        ("All three cosine Transformer seeds and the preselected same-data XGBoost/MLP controls;",
         "All three cosine Transformer seeds and all three preselected seeds of same-data MLP and XGBoost regression, plus XGBoost ranking controls;"),
    ]
    text = source.read_text()
    for old, new in replacements:
        assert text.count(old) == 1, old
        text = text.replace(old, new)
    staged = support / 'score.py'
    staged.write_text(text)
    protocol = {'frozen_at': datetime.datetime.now().astimezone().isoformat(),
                'purpose': 'Report all fixed seeds, never choose the best report90 seed. No fitting or SQL.',
                'source_sha256': {str(p): file_sha256(p) for p in [source, stability, staged, Path(__file__)]},
                'literal_replacements': replacements}
    (support / 'PROTOCOL.json').write_text(json.dumps(protocol, indent=2) + '\n')
    subprocess.run([sys.executable, str(staged)], check=True)
    out = BASE / 'observed90_seed_audit'
    scored = read(out / 'RESULT.json')
    assert scored['status'] == 'complete' and scored['score_serialization_metric_replay_verified']
    groups = {'transformer': [f'transformer_seed{s}' for s in [17, 29, 43]]}
    for kind in ['mlp_rank', 'mlp_regression', 'xgb_regression']:
        prefix, suffix = kind.split('_', 1)
        groups[kind] = [kind] + [f'{prefix}_seed{s}_{suffix}' for s in [29, 43]]
    aggregates = {}
    lines = ['# 全90条已测候选池的三种子比较', '',
             '历史筛选集合上的回顾性评分；复用1091个配置的既有耗时。没有重新执行SQL。全部种子均计入，不择优。', '',
             '| 模型 | 平均选择损失 | 种子最小值 | 种子最大值 | 平均排序准确率 |', '|---|---:|---:|---:|---:|']
    for kind, keys in groups.items():
        qualities = [scored['qualities'][key] for key in keys]
        regrets = [q['mean_regret'] for q in qualities]
        item = {'models': keys, 'mean_regret': sum(regrets) / 3,
                'min_regret': min(regrets), 'max_regret': max(regrets),
                'mean_rank_accuracy': sum(q['rank_accuracy'] for q in qualities) / 3}
        aggregates[kind] = item
        lines.append(f"| {kind} | {item['mean_regret']:.2%} | {item['min_regret']:.2%} | {item['max_regret']:.2%} | {item['mean_rank_accuracy']:.2%} |")
    lines += ['', '排序准确率与配置选择损失衡量不同目标，不能互相替代。种子范围不是置信区间；该集合已参与开发分析，不能作为独立泛化或当前BE端到端结果。历史预训练预算不同，本比较也不是等预算纯结构因果消融。']
    (out / 'SEED_SUMMARY.json').write_text(json.dumps(aggregates, indent=2) + '\n')
    (out / 'SEED_SUMMARY.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps(aggregates, indent=2), flush=True)


if __name__ == '__main__':
    main()
