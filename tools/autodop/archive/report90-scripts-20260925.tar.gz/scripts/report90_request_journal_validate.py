"""Offline replay/integrity gate before using journal logging in SQL trials."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import tempfile
import time

from report90_request_journal import RequestJournal
from report90_native_predictor_fixed4 import NativePredictor

RUN = Path(__file__).resolve().parents[1]/'runs/report90_20260912'


def main():
    out = RUN/'request_journal_validation'
    out.mkdir(exist_ok=False)
    source = RUN/'report90_native_budget_cap4_full/PREDICTOR_REQUESTS.json'
    archived = json.loads(source.read_text())
    model_path = RUN/'native_predictor_service17/MODEL.json'
    predictor = NativePredictor.load(model_path)
    journal = RequestJournal(out/'replay.jsonl')
    elapsed = []
    for row in archived['records']:
        predicted = predictor.predict_csv(row['csv'], row['prediction']['mode'])
        assert predicted == row['prediction'], 'Frozen prediction changed'
        start = time.perf_counter_ns()
        journal.append('record', row)
        elapsed.append(time.perf_counter_ns()-start)
    for error in archived['errors']:
        journal.append('error', error)
    journal.close()
    assert journal.export(out/'replay.json') == archived
    checks = ['all archived predictions replay exactly', 'complete export matches archived records and errors']
    with tempfile.TemporaryDirectory() as directory:
        d = Path(directory)
        j = RequestJournal(d/'concurrent.jsonl')
        def append(i):
            j.append('record', {'id': i, 'csv': 'a,b\n1,2\n', 'unicode': '查询'})
        with ThreadPoolExecutor(max_workers=16) as executor:
            list(executor.map(append, range(1024)))
        j.append('error', 'simulated request failure')
        j.close()
        result = j.export(d/'export.json')
        assert sorted(r['id'] for r in result['records']) == list(range(1024))
        assert result['errors'] == ['simulated request failure']
        checks.append('16 concurrent writers: 1024 records, unique contiguous sequence, multiline/unicode and errors preserved')
        try:
            RequestJournal(d/'concurrent.jsonl')
        except FileExistsError:
            checks.append('existing evidence cannot be overwritten')
        else:
            raise AssertionError('existing journal accepted')
        raw = (d/'concurrent.jsonl').read_text()
        for corrupt in [raw[:-1], raw.replace('"sequence":0', '"sequence":7', 1)]:
            (d/'concurrent.jsonl').write_text(corrupt)
            try:
                j.export(d/'bad.json')
            except ValueError:
                pass
            else:
                raise AssertionError('corrupt journal accepted')
        checks.append('truncation and sequence corruption rejected')
    elapsed.sort()
    result = dict(status='verified', replayed_records=len(archived['records']), checks=checks,
                  append_median_ms=elapsed[len(elapsed)//2]/1e6,
                  append_p99_ms=elapsed[int((len(elapsed)-1)*.99)]/1e6,
                  scope='Offline serialization plus append and flush timing; not HTTP or SQL latency, not power-loss durability. No old latency correction.',
                  source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source,model_path,Path(__file__),Path(__file__).with_name('report90_request_journal.py')]})
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
