"""Audit final-stage policy inputs and freeze controlled retraining arms, without SQL."""
from pathlib import Path
import hashlib
import json
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_policy_model
from autodop.training import select_partition

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'runs/report90_20260912'
HISTORY = ROOT / 'runs/structural_scale_development01_20260911/policy_preservation02'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    out = RUN / 'policy_final_stage_ablation'
    out.mkdir(exist_ok=False)
    old = json.loads((HISTORY / 'PROTOCOL.json').read_text())
    changed, missing = [], []
    for name, digest in old['source_sha256'].items():
        if not Path(name).exists(): missing.append(name)
        elif sha(name) != digest: changed.append(name)
    assert not missing
    assert set(changed) <= {str(ROOT/'autodop/model.py'),str(ROOT/'autodop/graph.py')}
    torch.set_num_threads(1)
    initial, saved = load_policy_model(old['initial_policy']); initial.eval()
    final, final_saved = load_policy_model(HISTORY/'model/policy.pt'); final.eval()
    assert saved['metadata'] == final_saved['metadata'] and saved['model_config'] == final_saved['model_config']
    samples, pairs, _ = load_dataset(old['dataset'])
    contract = json.loads(Path(old['training_contract']).read_text())
    train, _ = select_partition(samples,pairs,contract,'train')
    valid, _ = select_partition(samples,pairs,contract,'valid')
    by = {s['plan_key']:s for s in samples}
    train_keys = {s['plan_key'] for s in train}
    valid_keys = {s['plan_key'] for s in valid}
    assert len(train_keys)==130 and len(valid_keys)==14 and not train_keys & valid_keys
    manifest = json.loads((RUN/'manifest.json').read_text())
    report_sha = {q['sql_sha256'] for q in manifest['queries']}
    assert not report_sha & {s['sql_sha256'] for s in samples}
    targets = json.loads(Path(old['targets']).read_text())['plans']
    assert {r['plan_key'] for r in targets} == train_keys
    historical_final = {r['plan_key']:r for r in json.loads((HISTORY/'RESULT.json').read_text())['plans']}
    records=[]
    with torch.no_grad():
        for record in targets:
            key=record['plan_key'];graph=build_graph(by[key],saved['metadata'],unknown_dop=True)
            before=initial(graph).softmax(-1);after=final(graph).softmax(-1)
            config=lambda probs:[saved['metadata']['dop_classes'][i] for i in probs.argmax(-1).tolist()]
            before_config=config(before);after_config=config(after)
            assert before_config == record['target_dops']
            assert after_config == historical_final[key]['predicted_dops']
            records.append(dict(plan_key=key,initial_confidence_difference=float(before.max(-1).values.min())-record['reference_confidence'],
                                final_confidence_difference=float(after.max(-1).values.min())-historical_final[key]['confidence']))
    audit=dict(status='verified_inputs_current_code',historical_sources=len(old['source_sha256']),changed_code=changed,
               train_plans=130,valid_plans=14,report_sql_overlap=0,target_configs_replayed=130,
               historical_final_configs_replayed=130,
               max_initial_confidence_abs_difference=max(abs(r['initial_confidence_difference']) for r in records),
               max_final_confidence_abs_difference=max(abs(r['final_confidence_difference']) for r in records),records=records,
               scope='Replay agreement does not prove identical gradients or all historical behavior. All new arms use current frozen code; old final checkpoint is not substituted for a retrained full arm.')
    (out/'INPUT_AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
    source_paths=[Path(__file__),HISTORY/'PROTOCOL.json',HISTORY/'RESULT.json',Path(old['initial_policy']),
                  Path(old['targets']),Path(old['training_contract']),Path(old['dataset'])/'samples.jsonl',
                  Path(old['dataset'])/'pairs.jsonl',ROOT/'autodop/model.py',ROOT/'autodop/graph.py',ROOT/'autodop/data.py']
    protocol=dict(status='frozen_before_training',initial_policy=old['initial_policy'],dataset=old['dataset'],
                  training_contract=old['training_contract'],targets=old['targets'],
                  seed=old['seed'],epochs=old['epochs'],batch_size=old['batch_size'],encoder_lr=old['encoder_lr'],
                  classifier_lr=old['classifier_lr'],margin_probability=old['margin_probability'],
                  arms={'full':dict(kl_weight=10,max_kl_weight=10,margin_weight=1),
                        'no_margin':dict(kl_weight=10,max_kl_weight=10,margin_weight=0),
                        'no_preservation':dict(kl_weight=0,max_kl_weight=0,margin_weight=1),
                        'no_max_node_kl':dict(kl_weight=10,max_kl_weight=0,margin_weight=1)},
                  selection='Fixed final epoch for every arm, same seed/order/initial weights and architecture; no report90 evaluation for model selection.',
                  first_step='One complete training epoch per arm in separate smoke outputs; finite gradients and exact reload checks before full training.',
                  scope='Controlled ablation of final confidence-margin and preservation training stage only. Does not remove all policy distillation or reconstruct missing early cost-model pretraining.',
                  source_sha256={str(p):sha(p) for p in source_paths})
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    print(json.dumps({k:v for k,v in audit.items() if k!='records'},indent=2))


if __name__=='__main__': main()
