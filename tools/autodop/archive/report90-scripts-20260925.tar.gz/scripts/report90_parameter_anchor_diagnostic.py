"""Measure parameter drift; distinguish descriptive changes from causal claims."""
import json
from pathlib import Path
import torch
from autodop.model import load_cost_model
from report90_neighborhood_prepare import RUN, sha
BASE=RUN/'structure_coverage20'
OUT=BASE/'parameter_anchor_pilot'


def main():
    torch.set_num_threads(1)
    assert json.loads((OUT/'RESULT.json').read_text())['status']=='verified'
    warm=BASE/'prepared/cost.pt'
    original,_=load_cost_model(warm)
    origin=dict(original.named_parameters())
    rows={};sources=[Path(__file__),warm,OUT/'RESULT.json']
    for name,folder in [('reference',BASE/'hard_pair_ema_pilot/pilot/transformer_h0'),('anchored',OUT/'pilot/transformer_h0')]:
        outcome=json.loads((folder/'RESULT.json').read_text());sources.append(folder/'RESULT.json')
        states={}
        for checkpoint in ['best.pt','raw_final.pt']:
            path=folder/checkpoint;model,_=load_cost_model(path);sources.append(path)
            groups={}
            for key,p in model.named_parameters():
                group='encoder' if key.startswith('encoder.') else 'readout_and_scorer'
                v=groups.setdefault(group,{'parameters':0,'squared_distance':0.,'origin_squared_norm':0.})
                v['parameters']+=p.numel();v['squared_distance']+=float((p-origin[key]).detach().double().square().sum());v['origin_squared_norm']+=float(origin[key].detach().double().square().sum())
            for v in groups.values():v['relative_l2_distance']=(v['squared_distance']/v['origin_squared_norm'])**.5
            states[checkpoint]=groups
        rows[name]={'selected_epoch':outcome['selected']['epoch'],'macro_accuracy':outcome['selected']['validation']['weighted_rank_accuracy'],'checkpoints':states}
    result={'status':'verified_parameter_distance_diagnostic','models':rows,
        'scope':'Same seed17 and30epoch schedule; reference uses hard-pair EMA, treatment adds0.001 parameter penalty. Selected EMA checkpoints may come from different epochs; compare raw_final for equal final update count. Distance alone cannot explain generalization. Inherited raw_final checkpoint metadata purpose is descriptive, not proof of unchanged trajectory.',
        'source_sha256':{str(p):sha(p) for p in sources}}
    p=OUT/'PARAMETER_DISTANCE.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(rows,indent=2))

if __name__=='__main__':main()
