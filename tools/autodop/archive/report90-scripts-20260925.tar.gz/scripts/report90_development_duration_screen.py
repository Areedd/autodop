"""Development-only duration feasibility screen; no policy deployment or report-label fit."""
from collections import defaultdict
from pathlib import Path
import hashlib,json
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler

ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'runs/report90_20260912'


def main():
    out=RUN/'development17_duration_screen';out.mkdir(exist_ok=False)
    protocol=dict(models=['training_median','nearest3_geometric_mean','ridge_log_alpha1'],
                  split='Leave one SQL out; scaling fitted on 16 training queries only',
                  target='Median native warmup/formal client latency, two serial observations per SQL',
                  gate=dict(median_qerror_max=1.5,p90_qerror_max=2.5,pair_accuracy_min=.75,beat_median_baseline=True),
                  scope='Feasibility only, no hyperparameter search. Seventeen previously used development SQLs, no report latency labels. Native DOP0 only; not heterogeneous runtime or concurrency prediction. Features and timings captured in separate runs; exact native physical-plan identity is unverified. No deployment even if statistical screen passes.')
    (out/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    feature_path=RUN/'native_memory_features17_full/RESULT.json'
    event_path=RUN/'development17_memory_profiles_full/scored/events.jsonl'
    proof_path=RUN/'development17_memory_profiles_full/MEMORY_PROFILE_CHECK.json'
    proof=json.loads(proof_path.read_text());assert proof['status']=='verified'
    events=[json.loads(s) for s in event_path.read_text().splitlines()]
    profile_ids={r['query_id'] for r in proof['rows']}
    pairs=defaultdict(list)
    for e in events:
        assert e['status']=='verified' and e['query_id'] in profile_ids
        if e['mode']=='native':pairs[e['id']].append(e)
    features=json.loads(feature_path.read_text());assert not features['errors']
    report_manifest=RUN/'manifest.json';report=json.loads(report_manifest.read_text())
    report_hashes={q['sql_sha256'] for q in report['queries']}
    records=[]
    assert len(features['records'])==34 and {r['pipeline_dop'] for r in features['records']}=={0,4}
    for r in features['records']:
        if r['pipeline_dop']!=0:continue
        assert r['pipeline_dop']==0 and r['sql_sha256'] not in report_hashes
        obs=pairs[r['id']];assert len(obs)==2 and {e['phase'] for e in obs}=={'warmup','measured'}
        assert all(e['sql_sha256']==r['sql_sha256'] for e in obs)
        indexes=[i for i,n in enumerate(r['header']) if n.startswith(('env_','operators_'))]
        records.append(dict(id=r['id'],sql_sha256=r['sql_sha256'],features=[r['values'][i] for i in indexes],
                            latency_ms=float(np.median([e['client_latency_ms'] for e in obs])),
                            observation_ratio=max(e['client_latency_ms'] for e in obs)/min(e['client_latency_ms'] for e in obs),
                            query_ids=[e['query_id'] for e in obs]))
    assert len(records)==17 and len({r['id'] for r in records})==17
    x=np.array([r['features'] for r in records],dtype=float);y=np.array([r['latency_ms'] for r in records])
    assert np.isfinite(x).all() and np.all(y>0)
    predictions={name:[] for name in protocol['models']}
    for i in range(17):
        mask=np.arange(17)!=i;scaler=StandardScaler().fit(x[mask]);train=scaler.transform(x[mask]);test=scaler.transform(x[i:i+1])
        nearest=np.argsort(np.linalg.norm(train-test,axis=1),kind='stable')[:3]
        predictions['training_median'].append(float(np.median(y[mask])))
        predictions['nearest3_geometric_mean'].append(float(np.exp(np.log(y[mask][nearest]).mean())))
        model=Ridge(alpha=1.0).fit(train,np.log(y[mask]))
        predictions['ridge_log_alpha1'].append(float(np.exp(np.clip(model.predict(test)[0],-30,30))))
    summary={}
    for name,pred in predictions.items():
        z=np.array(pred);q=np.maximum(z/y,y/z)
        pairs=[(i,j) for i in range(17) for j in range(i+1,17) if y[i]!=y[j]]
        accuracy=sum(.5 if z[i]==z[j] else float((z[i]-z[j])*(y[i]-y[j])>0) for i,j in pairs)/len(pairs)
        summary[name]=dict(median_qerror=float(np.median(q)),p90_qerror=float(np.quantile(q,.9)),max_qerror=float(max(q)),pair_accuracy=accuracy,pairs=len(pairs))
    for name,s in summary.items():
        s['screen_passed']=name!='training_median' and s['median_qerror']<=1.5 and s['p90_qerror']<=2.5 and s['pair_accuracy']>=.75 and s['median_qerror']<summary['training_median']['median_qerror']
    sources=[Path(__file__),feature_path,event_path,proof_path,report_manifest]
    result=dict(status='development_oof_diagnostic',queries=17,features=x.shape[1],summary=summary,predictions=predictions,records=records,
                deployment_ready=False,scope=protocol['scope'],source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 开发侧执行时长预测可行性检查','',protocol['scope'],'',
           '| 模型 | 中位Q-error | p90 Q-error | 最大Q-error | 跨查询排序准确率 | 筛查通过 |','|---|---:|---:|---:|---:|---|']
    for name,s in summary.items():lines.append(f"| {name} | {s['median_qerror']:.3f} | {s['p90_qerror']:.3f} | {s['max_qerror']:.3f} | {100*s['pair_accuracy']:.2f}% | {s['screen_passed']} |")
    lines+=['','留一折之间训练数据重叠，136个查询对不是136个独立样本。该排序指标是不同查询执行时长排序，不是同一查询不同DOP候选的排序准确率。未部署、未改动内存预测器或在线DOP权重。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))

if __name__=='__main__':main()
