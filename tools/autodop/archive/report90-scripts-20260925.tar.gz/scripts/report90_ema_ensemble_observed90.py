"""Apply the already fixed score-mean rule to all90 historical measured candidates."""
import json
from pathlib import Path
import numpy as np
from report90_models import metrics
from report90_interaction_pair_audit import BASE,sha

OUT=BASE/'hard_pair_ema_ensemble_observed90'

def main():
    assert not OUT.exists()
    raw=BASE/'hard_pair_ema_observed90';summary=json.loads((raw/'RESULT.json').read_text());assert summary['status']=='complete' and summary['queries']==90
    protocol=BASE/'hard_pair_ema_ensemble/PROTOCOL.json';declared=json.loads(protocol.read_text());assert declared['seeds']==[17,29,43]
    for path,digest in declared['source_sha256'].items():assert sha(Path(path))==digest
    for path,digest in summary['source_sha256'].items():assert sha(Path(path))==digest
    score_path=raw/'SCORES.json';scores=json.loads(score_path.read_text())
    label_path=BASE.parent/'original_teacher_audit/POOL_SCORES.json';rows=json.loads(label_path.read_text());assert len(rows)==1091
    labels=[{'plan_key':r['id'],'config_key':str(tuple(r['dops'])),'latency_ms':float(np.mean(r['mode_mean_latencies_ms']))} for r in rows]
    assert len({r['plan_key'] for r in labels})==90
    families=sorted({k.rsplit('_seed',1)[0] for k in scores});results={};averages={}
    for family in families:
        matrix=np.array([scores[f'{family}_seed{s}'] for s in [17,29,43]],dtype=np.float64)
        assert matrix.shape==(3,1091) and np.isfinite(matrix).all()
        for index,seed in enumerate([17,29,43]):assert metrics(labels,matrix[index])==summary['qualities'][f'{family}_seed{seed}']
        averaged=matrix.mean(axis=0);averages[family]=averaged.tolist();results[family]=metrics(labels,averaged)
    OUT.mkdir();(OUT/'SCORES.json').write_text(json.dumps(averages)+'\n')
    reread=json.loads((OUT/'SCORES.json').read_text());assert all(metrics(labels,reread[k])==v for k,v in results.items())
    sources=[Path(__file__),protocol,raw/'RESULT.json',score_path,label_path,OUT/'SCORES.json']
    gate=all(results['transformer']['rank_accuracy']>v['rank_accuracy'] for k,v in results.items() if k!='transformer')
    result={'status':'verified_fixed_ensemble_observed90','queries':90,'observed_configurations':1091,'models':results,'transformer_accuracy_beats_all_ensemble_controls':gate,
        'scope':'Same fixed unweighted three-seed score mean for every family; no fitting or selection from report90. Historical positive query subset and mode-selected candidate pool, not blind evaluation or newSQL. Three-checkpoint ensemble, not single-model result; runtime overhead not measured here.',
        'source_sha256':{str(p):sha(p) for p in sources}}
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# 三检查点平均模型的报告查询排序复核','',result['scope'],'', '| 模型（三检查点平均） | 排序准确率 | 平均候选选择损失 |','|---|---:|---:|']
    for kind,v in results.items():lines.append(f"| {kind} | {100*v['rank_accuracy']:.3f}% | {100*v['mean_regret']:.3f}% |")
    lines += ['',f'是否排序准确率超过全部同样聚合的对照：{gate}。全部90条与1091个候选均保留，未执行新SQL。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');print({k:v['rank_accuracy'] for k,v in results.items()})

if __name__=='__main__':main()
