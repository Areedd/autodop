"""Observe one queue flag through a checkpoint; no data-query executions."""
import json,time,os,hashlib
from pathlib import Path
from report90_execute import RUN,ROOT
from report90_queue_extension import connect
OUT=RUN/'native_queue_write_observation'
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
def main():
 OUT.mkdir(exist_ok=False);save('STATUS.json',dict(status='running',pid=os.getpid()))
 save('PROTOCOL.json',dict(max_observation_seconds=95,sampling_seconds=1,minimum_false_samples=3,scope='Temporarily set global select admission true and observe write provenance; no data-query or performance experiment.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
 rows=[];start_ms=int(time.time()*1000)
 with connect() as c,c.cursor() as q:
  q.execute('SELECT @@global.enable_query_queue_select');original=int(q.fetchone()[0]);save('SETTINGS.json',dict(original=original,restored=False))
  try:
   q.execute('SET GLOBAL enable_query_queue_select=true');q.execute('SELECT @@global.enable_query_queue_select');assert int(q.fetchone()[0])==1
   false_count=0
   for i in range(95):
    q.execute('SELECT @@global.enable_query_queue_select');v=int(q.fetchone()[0]);rows.append(dict(at_ms=int(time.time()*1000),value=v));save('SAMPLES.json',rows)
    false_count=false_count+1 if v==0 else 0
    if false_count>=3:break
    time.sleep(1)
   lines=[l.rstrip('\n') for l in (ROOT.parents[1]/'output/fe/log/fe.out').read_text(errors='replace').splitlines() if l.startswith('NATIVE_QUEUE_WRITE|')]
   parsed=[dict(part.split('=',1) for part in l.split('|')[1:]) for l in lines]
   transitions=[r for r in parsed if int(r['at'])>=start_ms and r['old']=='true' and r['requested'].lower() in ('false','0','off')]
   save('WRITES.json',dict(lines=lines,transitions=transitions))
   assert false_count>=3 and any(r['thread']=='global_state_checkpoint_worker' and ('VariableMgr.lambda$load' in r['stack'] or 'VariableMgr.replayGlobalVariableV2' in r['stack']) for r in transitions),'No checkpoint write provenance observed'
   save('RESULT.json',dict(status='verified',samples=len(rows),transitions=transitions,scope='Checkpoint thread wrote the live global select queue flag false while observation held true; polling observed persistent false. No data-query execution.'))
  finally:
   q.execute('SET GLOBAL enable_query_queue_select=%s',(original,));q.execute('SELECT @@global.enable_query_queue_select');assert int(q.fetchone()[0])==original
   save('SETTINGS.json',dict(original=original,restored=True))
 save('STATUS.json',dict(status='verified'))
if __name__=='__main__':
 try:main()
 except BaseException as e:
  if OUT.exists():save('STATUS.json',dict(status='failed',error=repr(e)))
  raise
