import json
from pathlib import Path
from collections import Counter
import numpy as np
from collect_paper_evaluations import VectorEngine,validate_execution_trace,verify_offline_intervention
R=Path(__file__).resolve().parents[1]/'runs/report90_20260912';O=R/'model_comparison_audit';s=json.loads((R/'SUMMARY.json').read_text());means=s['serial']['per_query_mean_ms'];repair=set(s['serial_repair']['replaced_queries']);rows={};vectors={f:json.loads((R/f/'vectors.json').read_text()) for f in ['choices','choices_attempt1']}
for fn in vectors:
 for a in json.loads((R/fn/'ROWS.json').read_text()):
  if a['type']=='cost_model' and a['mode'] in ['transformer_rank_s17','xgb_rank_s17'] and not(fn=='choices' and a['id'] in repair):rows[(a['id'],a['mode'])]=a
out={'uniform_test_ranking':{},'candidate_sources':{}}
for kind in ['transformer_rank_s17','xgb_rank_s17']:
 good=total=0;reg=[]
 for (qid,k),row in rows.items():
  if k!=kind:continue
  scores=row['uniform_scores'];lat=[means['uniform'+str(d)][qid] for d in [1,2,4,8,16]];reg.append(lat[int(np.argmax(scores))]/min(lat)-1)
  for i in range(5):
   for j in range(i+1,5):
    if abs(lat[i]-lat[j])/min(lat[i],lat[j])<.03:continue
    total+=1;good+=int((scores[i]-scores[j])*(lat[j]-lat[i])>0)
 out['uniform_test_ranking'][kind]={'correct':good,'pairs':total,'accuracy':good/total,'selection_mean_regret':float(np.mean(reg))}
ident=[q for q in means['native'] if rows[(q,'transformer_rank_s17')]['selected_dops']==rows[(q,'xgb_rank_s17')]['selected_dops']]
out['identical_choices']={'queries':len(ident),'mean_ms':{k:float(np.mean([means[k][q] for q in ident])) for k in ['cost_transformer_rank','cost_xgb_rank']}}
for kind in ['transformer_rank','xgb_rank']:
 counts=Counter()
 for q in means['native']:
  v=vectors['choices_attempt1' if q in repair else 'choices'];chosen=v['cost_'+kind][q]['fragment_dops'];matches=[m for m in ['policy_vector','teacher_mcts','search_random','search_no_attention','search_no_equivalence'] if v[m][q]['fragment_dops']==chosen];counts.update(matches or ['other_pool_candidate'])
 out['candidate_sources'][kind]=dict(counts)
# Revalidate actual DOP against the frozen per-query vectors, including exact plan variants.
merged=json.loads((R/'repair_vectors.json').read_text());engines={}
count=0
for stage in ['serial','serial_repair']:
 for line in (R/stage/'scored/events.jsonl').open():
  e=json.loads(line)
  if e['phase']=='warmup' or e['mode'] not in ['cost_transformer_rank','cost_xgb_rank'] or(stage=='serial' and e['id'] in repair):continue
  key=(e['mode'],e['id'])
  if key not in engines:engines[key]=VectorEngine({e['id']:merged[e['mode']][e['id']]})
  v=validate_execution_trace(e['trace'],e['query_id']);verify_offline_intervention(e['trace'],v,e['mode'],engines[key]);count+=1
out['actual_dop_reverified_observations']=count;assert count==540
(O/'DIAGNOSTICS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
