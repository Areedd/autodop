"""Collect frozen configuration labels for all24 semantically verified development SQL."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from report90_execute import ROOT,RUN,check
from report90_cpu_observe import workers

BASE=RUN/'complex_development24'
OUT=BASE/'labels'


def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
    p=OUT/name;tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(p)


def main():
    OUT.mkdir(exist_ok=False)
    save('STATUS.json',{'status':'running','stage':'preflight','pid':os.getpid()})
    assert read(BASE/'prepass/AUDITED_RESULT.json')['verified_executions']==96
    assert read(BASE/'prepass/scored/frontend_settings.json')['restored']
    separation=read(BASE/'prepass/PLAN_SEPARATION.json')
    assert not separation['new_train_valid_raw_plan_overlap'] and not separation['new_valid_previous_cost_raw_plan_overlap']
    proof=read(BASE/'prepass/scored/independent_verification.json')
    assert proof['all_expected_executions_verified']
    for name,expected in proof['source_sha256'].items():assert sha(Path(name))==expected
    manifest=BASE/'manifest.json'
    audit=ROOT/'runs/paper_campaign_20260905/environment/audit_tpcds_sf100.json'
    protocol={'frozen_at':datetime.datetime.now().astimezone().isoformat(),'queries':24,'train_queries':16,'valid_queries':8,
        'configs':8,'config_design':'balanced','dops':[1,2,4,8,16],'seed':2026091311,
        'warmup':1,'formal_repetitions':3,'expected_config_executions':768,'expected_formal_executions':576,
        'expected_additional_native_and_probe_executions':48,
        'design':'Existing deterministic collector design: five uniform candidates and three random heterogeneous configurations for these multi-fragment graphs; freeze per native-discovered plan before timing configurations. No model scores or composite performance used to choose configurations.',
        'purpose':'Add large-graph training and separate large-graph development-validation cost labels. Validation labels never used in gradient updates; no report90 SQL labels added.',
        'gate':'All24 accepted, all8 configurations each with3 verified formal executions, independent dataset reconciliation, native digest match to semantic assembly, no train/valid raw plan overlap. Preserve failures, no silent query replacement.',
        'scope':'This is development data acquisition after correctness small pass, not a report90 benchmark rerun. Historical data-scale audit reused; current BE image and query-slice semantics checked separately.',
        'manifest_sha256':sha(manifest),'historical_audit_sha256':sha(audit)}
    save('PROTOCOL.json',protocol)
    sources=[Path(__file__),ROOT/'collect_trusted_dataset.py',ROOT/'scripts/build_trusted_dataset.py',ROOT/'scripts/verify_paper_dataset.py',
             ROOT/'autodop/data.py',manifest,audit,BASE/'prepass/AUDITED_RESULT.json',BASE/'SEMANTIC_AUDIT.json']
    save('EXECUTION_SOURCE_SHA256.json',{str(p):sha(p) for p in sources})
    os.sched_setaffinity(0,set(range(27,35)))
    nodes=workers();assert all(n['image_id']=='sha256:73548ebadb50d11fec58e9937ebd5ee189205fd8f1acf8359fc63923132c476b' for n in nodes)
    save('DEPLOYMENT.json',nodes)
    for attempt in range(20):
        try:check(OUT/f'IDLE_{attempt}.json');break
        except RuntimeError:
            if attempt==19:raise
            time.sleep(15)
    command=[sys.executable,str(ROOT/'collect_trusted_dataset.py'),'--manifest',str(manifest),
        '--output-dir',str(OUT/'collection'),'--configs','8','--config-design','balanced','--dops','1,2,4,8,16',
        '--audit',str(audit),'--probe-timeout-s','180','--query-timeout-s','180','--repetitions','3','--warmup','1',
        '--seed',str(protocol['seed'])]
    save('COMMAND.json',command);save('STATUS.json',{'status':'running','stage':'configuration_labels','pid':os.getpid()})
    subprocess.run(command,check=True)
    collection=read(OUT/'collection/collection.json')
    assert collection['status']=='finished' and len(collection['queries'])==24
    assert all(q['status']=='accepted' and len(q['configs'])==8 for q in collection['queries'])
    semantic={q['id']:q['native_result_digest'] for q in read(BASE/'SEMANTIC_AUDIT.json')['queries']}
    assert all(q['native_result_digest']==semantic[q['id']] for q in collection['queries'])
    train={q['plan_key'] for q in collection['queries'] if q['split']=='train'}
    valid={q['plan_key'] for q in collection['queries'] if q['split']=='valid'}
    assert not train&valid, 'Native-discovered graphs overlap across train and validation'
    subprocess.run([sys.executable,str(ROOT/'scripts/build_trusted_dataset.py'),'--input',str(OUT/'collection/measured/accepted.jsonl'),
        '--manifest',str(manifest),'--collection',str(OUT/'collection/collection.json'),'--output',str(OUT/'dataset')],check=True)
    subprocess.run([sys.executable,str(ROOT/'scripts/verify_paper_dataset.py'),'--collection-dir',str(OUT/'collection'),
        '--dataset-dir',str(OUT/'dataset'),'--output',str(OUT/'dataset/verification.json')],check=True)
    samples=[json.loads(l) for l in (OUT/'dataset/all/samples.jsonl').open()]
    assert len(samples)==192 and sum(s['split']=='train' for s in samples)==128 and sum(s['split']=='valid' for s in samples)==64
    assert read(OUT/'collection/frontend_settings.json')['restored']
    save('RESULT.json',{'status':'complete','queries':24,'samples':192,'train_samples':128,'valid_samples':64,
        'formal_executions':576,'native_digest_semantics_verified':True,'train_valid_raw_plan_overlap':0,
        'verification':read(OUT/'dataset/verification.json')})
    save('STATUS.json',{'status':'complete','at':datetime.datetime.now().astimezone().isoformat()})


if __name__=='__main__':
    if OUT.exists():raise SystemExit('Preserve existing label collection')
    try:main()
    except BaseException as e:
        if OUT.exists():save('STATUS.json',{'status':'failed','error':repr(e),'pid':os.getpid()})
        raise
