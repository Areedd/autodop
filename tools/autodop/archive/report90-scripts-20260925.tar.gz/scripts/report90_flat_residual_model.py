"""Experimental graph Transformer with a zero-initialized fixed-feature residual head."""
from pathlib import Path
import numpy as np
import torch
from torch import nn
from autodop.model import CostModel,MODEL_FORMAT_VERSION,save_checkpoint
from report90_models import flat_features

NORMALIZATION=Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20/retrained/FEATURE_NORMALIZATION.npz'

class FlatResidualCostModel(CostModel):
    def __init__(self,metadata,mean,std,model_config=None):
        super().__init__(metadata,model_config)
        self.feature_metadata=metadata
        self.register_buffer('flat_mean',torch.as_tensor(mean,dtype=torch.float32).clone())
        self.register_buffer('flat_std',torch.as_tensor(std,dtype=torch.float32).clone())
        assert self.flat_mean.ndim==1 and self.flat_mean.shape==self.flat_std.shape
        assert torch.isfinite(self.flat_mean).all() and torch.isfinite(self.flat_std).all() and (self.flat_std>0).all()
        self.flat_scorer=nn.Sequential(nn.Linear(len(self.flat_mean),64),nn.GELU(),nn.Linear(64,64),nn.GELU(),nn.Linear(64,1))
        nn.init.zeros_(self.flat_scorer[-1].weight);nn.init.zeros_(self.flat_scorer[-1].bias)

    def forward(self,graph):
        score=super().forward(graph)
        raw=torch.as_tensor(flat_features(graph,self.feature_metadata),device=self.flat_mean.device)
        features=(raw-self.flat_mean)/self.flat_std
        return score+self.flat_scorer(features).squeeze(-1)

def load_flat_residual_model(path,device='cpu'):
    if str(device)!='cpu':raise ValueError('Experimental fixed-feature extractor is CPU-only')
    checkpoint=torch.load(path,map_location=device,weights_only=False)
    if checkpoint.get('format_version')!=MODEL_FORMAT_VERSION or checkpoint.get('kind') not in ['cost','cost_flat_residual']:
        raise ValueError('Unsupported flat-residual checkpoint')
    if checkpoint['kind']=='cost':
        with np.load(NORMALIZATION) as norm:mean,std=norm['mean'],norm['std']
    else:mean,std=checkpoint['model_state']['flat_mean'],checkpoint['model_state']['flat_std']
    model=FlatResidualCostModel(checkpoint['metadata'],mean,std,checkpoint['model_config'])
    if checkpoint['kind']=='cost':
        missing,unexpected=model.load_state_dict(checkpoint['model_state'],strict=False)
        expected={'flat_mean','flat_std'}|{f'flat_scorer.{i}.{name}' for i in [0,2,4] for name in ['weight','bias']}
        if set(missing)!=expected or unexpected:raise ValueError('Warm-start mismatch beyond new residual head')
    else:model.load_state_dict(checkpoint['model_state'],strict=True)
    return model,checkpoint

def save_flat_residual_checkpoint(path,kind,model,metadata,training=None):
    if kind!='cost' or not isinstance(model,FlatResidualCostModel):raise ValueError('Expected flat residual model')
    save_checkpoint(path,'cost_flat_residual',model,metadata,training)
