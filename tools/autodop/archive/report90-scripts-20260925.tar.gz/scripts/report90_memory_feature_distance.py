"""Frozen feature-space distance diagnostic, not a calibrated OOD detector."""
import hashlib,json,csv,io,os
from pathlib import Path
import numpy as np
from report90_execute import RUN
from report90_native_predictor import NativePredictor


def main():
    os.sched_setaffinity(0,{35})
    model_file=RUN/'native_predictor_service17/MODEL.json'
    features=RUN/'native_memory_features90_full/RESULT.json'
    model=NativePredictor.load(model_file)
    train=model.training
    distances=np.linalg.norm(train[:,None,:]-train[None,:,:],axis=2)
    np.fill_diagonal(distances,np.inf)
    reference=distances.min(axis=1)
    threshold=float(np.percentile(reference,95))
    rows=[]
    for r in json.loads(features.read_text())['records']:
        model.predict_csv(r['csv']) # Require original schema and environment checks.
        values=np.array(list(csv.reader(io.StringIO(r['csv'])))[1],dtype=float)
        x=(values[model.indices]-model.mean)/model.scale
        ds=np.linalg.norm(train-x,axis=1)
        rows.append(dict(id=r['id'],pipeline_dop=r['pipeline_dop'],nearest_distance=float(ds.min()),
            neighbor_indices=np.argsort(ds,kind='stable')[:3].tolist(),above_training_loo_p95=bool(ds.min()>threshold)))
    assert len(rows)==180
    result=dict(status='diagnostic',training_loo_nearest_distances=reference.tolist(),training_loo_p95=threshold,
        report_median_distance=float(np.median([r['nearest_distance'] for r in rows])),
        report_max_distance=max(r['nearest_distance'] for r in rows),
        report_above_training_loo_p95=sum(r['above_training_loo_p95'] for r in rows),rows=rows,
        scope='Uses frozen training normalization,17 training rows and180 report configurations. Distance reference is training-only; diagnostic has no calibrated coverage or error probability, no new acceptance gate and no model tuning.',
        source_sha256={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),model_file,features]})
    out=RUN/'report90_frozen_budget_evaluation';out.mkdir(exist_ok=True)
    (out/'FEATURE_DISTANCE.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items() if k not in ['rows','source_sha256','training_loo_nearest_distances']})

if __name__=='__main__':main()
