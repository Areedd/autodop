"""One fixed equal-parameter average of all three completed development seeds."""
import datetime
import json
import os
from pathlib import Path
import torch
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model, save_checkpoint
from autodop.training import file_sha256, select_partition
from report90_complex_retrain import validation
from report90_coverage_choices import BASE, read


def main():
    out = BASE / 'parameter_average3'; assert not out.exists()
    stability = read(BASE / 'seed_stability/RESULT.json'); assert stability['status'] == 'verified'
    folders = [BASE / 'retrained', BASE / 'seed_stability/seed29', BASE / 'seed_stability/seed43']
    selected = [read(p / 'RESULT.json')['selected']['transformer'] for p in folders]
    for s in selected: assert file_sha256(s['model']) == s['model_sha256']
    out.mkdir(); os.sched_setaffinity(0, {35}); torch.set_num_threads(1)
    protocol = {'frozen_at': datetime.datetime.now().astimezone().isoformat(), 'seeds': [17, 29, 43],
                'weights': [1/3, 1/3, 1/3], 'models': selected,
                'rule': 'One arithmetic mean of all floating state tensors, accumulated in float64 and cast back; nonfloating states must match. No coefficient search, seed subset, gradient fit, or model architecture change.',
                'scope': 'Post-stability development experiment on reused validation. Parent checkpoints were validation-selected. Not independent testing or a three-seed repeat of the averaged model.',
                'gate': 'Averaged model must have equal-cohort and complex-validation regret no greater than every available selected XGBoost/MLP control. No automatic SQL expansion or deployment.',
                'source_sha256': {str(p): file_sha256(p) for p in [Path(__file__), BASE / 'seed_stability/RESULT.json', BASE / 'retrained/SCORE_REPLAY.json', BASE / 'additional_baselines_full/RESULT.json', BASE / 'merged_dataset/samples.jsonl', BASE / 'retrained/CONTRACT.json']}}
    (out / 'PROTOCOL.json').write_text(json.dumps(protocol, indent=2) + '\n')
    models = [load_cost_model(s['model']) for s in selected]
    reference = models[0][1]
    assert all(ck['metadata'] == reference['metadata'] and ck['model_config'] == reference['model_config'] for _, ck in models)
    states = [model.state_dict() for model, _ in models]; averaged = {}
    assert all(s.keys() == states[0].keys() for s in states)
    for key in states[0]:
        values = [s[key] for s in states]
        assert all(v.shape == values[0].shape and v.dtype == values[0].dtype for v in values)
        if values[0].is_floating_point():
            averaged[key] = torch.stack([v.to(torch.float64) for v in values]).mean(0).to(values[0].dtype)
            assert torch.isfinite(averaged[key]).all()
        else:
            assert all(torch.equal(values[0], v) for v in values)
            averaged[key] = values[0].clone()
    model = models[0][0]; model.load_state_dict(averaged); model.eval()
    samples, pairs, metadata = load_dataset(BASE / 'merged_dataset'); assert metadata == reference['metadata']
    valid, _ = select_partition(samples, pairs, read(BASE / 'retrained/CONTRACT.json'), 'valid'); assert len(valid) == 212
    graphs = [build_graph(s, metadata) for s in valid]
    with torch.no_grad(): scores = [float(model(g)) for g in graphs]
    quality = validation(valid, scores)
    path = out / 'cost.pt'; save_checkpoint(path, 'cost', model, metadata, {'protocol': str(out / 'PROTOCOL.json'), 'parent_sha256': [s['model_sha256'] for s in selected]})
    loaded, checkpoint = load_cost_model(path); loaded.eval()
    assert checkpoint['model_config'] == reference['model_config']
    with torch.no_grad(): replay_scores = [float(loaded(g)) for g in graphs]
    assert scores == replay_scores and validation(valid, replay_scores) == quality
    controls = {k: q for k, q in read(BASE / 'retrained/SCORE_REPLAY.json')['after'].items() if k != 'transformer'}
    controls.update({k: s['selected']['validation'] for k, s in read(BASE / 'additional_baselines_full/RESULT.json')['selected'].items()})
    passed = all(quality['weighted_regret'] <= q['weighted_regret'] and quality['cohorts']['complex_new']['mean_regret'] <= q['cohorts']['complex_new']['mean_regret'] for q in controls.values())
    result = {'status': 'verified', 'quality': quality, 'controls': controls, 'development_gate_passed': passed,
              'model': str(path), 'model_sha256': file_sha256(path), 'prediction_reload_exact': True,
              'model_structure_unchanged': True, 'scope': protocol['scope'], 'protocol_sha256': file_sha256(out / 'PROTOCOL.json')}
    (out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    h, c = quality['cohorts']['historical'], quality['cohorts']['complex_new']
    lines = ['# 三种子参数等权平均的开发检查', '', protocol['scope'], '',
             '固定使用17、29、43三个验证选定检查点，全部参数等权平均；未挑种子、搜索权重或增加模型层。浮点参数以float64累加后恢复原精度。保存模型后重新加载，全部212个验证配置的预测严格一致。', '',
             f"综合选择损失：{100*quality['weighted_regret']:.2f}%；历史选择损失：{100*h['mean_regret']:.2f}%；复杂选择损失：{100*c['mean_regret']:.2f}%。", '',
             f"不差于全部已有XGBoost/MLP对照的综合与复杂损失门槛：{'通过' if passed else '未通过'}。未自动部署或执行SQL。", '',
             '该检查使用已有三个完整训练模型；不是单次训练成本，也不代表平均模型已通过跨数据或SQL执行复现。']
    (out / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({'status': result['status'], 'weighted_regret': quality['weighted_regret'], 'complex_regret': c['mean_regret'], 'gate': passed}))


if __name__ == '__main__': main()
