"""Predeclared development screen: defer CPU correction, preserve memory correction."""
import concurrent.futures
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

from report90_execute import ROOT, RUN, check, accept_concurrent_evidence
from report90_cpu_observe import observe, workers
import report90_queue_extension as queue

OUT = RUN/'development17_cpu_threshold'
SUPPORT = RUN/'development17_calibration'
MODE = 'policy_cpu_deferred'
MODES = ['native', 'policy_static', 'policy_load', MODE]
PARAMETERS = {'cpu_threshold': .999, 'mem_threshold': .65, 'floor': .1}


def read(p):
    return json.loads(p.read_text())


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def save(name, value):
    p = OUT/name
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2)+'\n')
    tmp.replace(p)


def summarize():
    scored = OUT/'scored'
    proof_path = scored/'independent_verification.json'
    proof = read(proof_path)
    accept_concurrent_evidence(proof_path)
    assert proof['expected_slots'] == proof['recorded_sql_slots'] == 272
    for name, expected in proof['source_sha256'].items():
        assert sha(Path(name)) == expected
    assert read(OUT/'QUEUE_SETTINGS.json')['restored'] and read(scored/'frontend_settings.json')['restored']
    events = [json.loads(l) for l in (scored/'events.jsonl').open()]
    rounds = read(scored/'collection.json')['rounds']
    assert len(events) == 272 and len(rounds) == 8
    by_qid = {e['query_id']: e for e in events if e.get('query_id')}
    assert len(by_qid) == sum(bool(e.get('query_id')) for e in events)
    metrics = {}
    for mode in MODES:
        selected = [e for e in events if e['mode'] == mode]
        formal = [r for r in rounds if r['mode'] == mode and r['phase'] == 'measured']
        assert len(selected) == 68 and len(formal) == 1 and formal[0]['expected'] == 34
        metrics[mode] = {'all_phase_failures': sum(e['status'] != 'verified' for e in selected),
                         'formal_verified': formal[0]['verified'], 'formal_attempts': 34,
                         'formal_goodput': formal[0]['verified']/formal[0]['workload_wall_seconds'],
                         'installed_corrected_successful_formal_queries': 0,
                         'max_fresh_cpu': None if mode == 'native' else 0.,
                         'max_fresh_memory': None if mode == 'native' else 0.,
                         'unlinked_decisions_all_phases': 0}
    for line in (scored/'decisions.jsonl').open():
        d = json.loads(line); m = metrics[d['mode']]; e = by_qid.get(d['query_id'])
        if e is None:
            m['unlinked_decisions_all_phases'] += 1
        elif e['phase'] == 'measured' and e['status'] == 'verified':
            assert e['mode'] == d['mode']
            corrected = any('load_corrected' in f.get('reason', '') for f in d['response']['decisions'])
            m['installed_corrected_successful_formal_queries'] += int(corrected and e['dop_validation']['applied'])
        for load in d['request'].get('worker_loads', {}).values():
            if load.get('fresh'):
                m['max_fresh_cpu'] = max(m['max_fresh_cpu'], load['cpu_used'])
                m['max_fresh_memory'] = max(m['max_fresh_memory'], load['mem_used_pct'])
    pending=[]
    for line in (scored/'resources.jsonl').open():
        row=json.loads(line)
        if row.get('url') == 'http://127.0.0.1:8030/metrics':
            pending += [float(x.split()[-1]) for x in row.get('prometheus_raw','').splitlines() if x.startswith('starrocks_fe_query_queue_pending ')]
    assert max(pending, default=0)>0, 'Shared admission queue activation not observed'
    candidate=metrics[MODE]
    passed=(candidate['all_phase_failures']==0 and candidate['installed_corrected_successful_formal_queries']>0
            and all(candidate['formal_goodput']>=1.03*metrics[m]['formal_goodput'] for m in ['native','policy_static']))
    result={'status':'complete_with_observed_memory_failures' if proof['failed_slots'] else 'complete',
            'screen_passed':passed,'metrics':metrics,'failed_slots':proof['failed_slots'],
            'queue_activity':{'max_pending':max(pending),'samples':len(pending)},
            'verification_sha256':sha(proof_path),'scope':'Historical training SQL finite-batch screen only. No automatic report90 expansion or deployment change.'}
    save('RESULT.json',result)
    lines=['# 推迟 CPU 修正触发的开发小测','','共同准入上限12、16客户端；17条历史训练SQL每模式每轮各执行两次，四种模式各1轮预热及1轮正式测量，共272次尝试。新参数只将CPU阈值从0.4改为0.999，内存阈值0.65及floor=0.1不变。', '',
           '| 模式 | 正式成功/尝试 | 有效吞吐 查询/秒 | 全阶段失败 | 实际安装修正的正式成功查询 |','|---|---:|---:|---:|---:|']
    for mode,m in metrics.items():
        lines.append(f"| {mode} | {m['formal_verified']}/34 | {m['formal_goodput']:.4f} | {m['all_phase_failures']} | {m['installed_corrected_successful_formal_queries']} |")
    lines += ['',f"预先规定的门槛（候选零失败、实际修正、有效吞吐比原生和静态各高至少3%）：{'通过' if passed else '未通过'}。",'',
              '所有模式均使用同一个准入上限；准入来自StarRocks，不归因于AutoDOP。保留全部失败，吞吐计算包含失败所占时间。未取得query_id的失败不强行关联安装证据。', '',
              'SQL与报告90条无精确哈希重合，但共享历史训练分布。本次为开发筛选，不代表稳态、统计显著性、合同达标或默认配置结果。CPU阈值0.999不是严格禁用CPU修正，实际触发按请求日志分析。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
    return result


def main():
    OUT.mkdir(exist_ok=False)
    save('STATUS.json',{'status':'running','stage':'offline_validation','pid':os.getpid()})
    assert read(RUN/'development17_pressure/AUDITED_RESULT.json')['screen_passed'] is False
    assert read(RUN/'development17_pressure/QUEUE_SETTINGS.json')['restored']
    assert read(RUN/'development17_pressure/scored/frontend_settings.json')['restored']
    manifest=RUN/'DEVELOPMENT17_MANIFEST.json';trusted=RUN/'DEVELOPMENT17_TRUSTED.json'
    queries=read(manifest)['queries'];model=read(RUN/'PROTOCOL.json')
    assert len(queries)==17 and all(q['split']=='train' and q['training_eligible'] for q in queries)
    assert not {q['sql_sha256'] for q in queries}&{q['sql_sha256'] for q in read(RUN/'manifest.json')['queries']}
    assert sha(Path(model['model']))==model['model_sha256']
    prep=read(SUPPORT/'PREPARATION.json')
    for name,key in [('collector_candidate.py','candidate_sha256'),('verifier_candidate.py','verifier_candidate_sha256')]:
        assert sha(SUPPORT/name)==prep[key]
    save('variants.json',{MODE:{'checkpoint':model['model'],'load_correction':True,'load_parameters':PARAMETERS}})
    queue.SETTINGS={**queue.SETTINGS,'query_queue_concurrency_limit':'12'}
    save('PROTOCOL.json',{'frozen_at':datetime.datetime.now().astimezone().isoformat(),'modes':MODES,
        'parameters':PARAMETERS,'queries':17,'clients':16,'minimum_per_client':2,'expected_slots':272,
        'warmup':1,'repetitions':1,'seed':model['seed'],'queue_settings':queue.SETTINGS,
        'rationale':'CPU saturation alone is not evidence that parallelism should collapse. Compare deferred CPU threshold within a shared admission cap midway between observed safe8 and overloaded16. SQL, model and memory parameters fixed.',
        'gate':'Candidate zero failures in both phases, actual installed correction, formal goodput >=1.03 times both static and native; otherwise no report90 expansion. Preserve all outcomes.',
        'manifest_sha256':sha(manifest),'decision_timeout_ms':1000,'query_timeout_s':180})
    sources=[Path(__file__),SUPPORT/'collector_candidate.py',SUPPORT/'verifier_candidate.py',
             ROOT/'scripts/report90_execute.py',ROOT/'scripts/report90_queue_extension.py',ROOT/'scripts/report90_cpu_observe.py',
             ROOT/'autodop/engine.py',ROOT/'autodop/load_correction.py',manifest,trusted,Path(model['model']),OUT/'variants.json',OUT/'PROTOCOL.json']
    save('EXECUTION_SOURCE_SHA256.json',{str(p):sha(p) for p in sources})
    spec=importlib.util.spec_from_file_location('threshold_collector',SUPPORT/'collector_candidate.py')
    collector=importlib.util.module_from_spec(spec);spec.loader.exec_module(collector)
    variant=collector.load_policy_variants(OUT/'variants.json')[MODE]
    engine=collector.policy_variant_engine(variant)
    from autodop.engine import PolicyEngine
    baseline=PolicyEngine(model['model'])
    request=read_request=json.loads(next((RUN/'development17_pressure/scored/decisions.jsonl').open()))['request']
    import copy
    low=copy.deepcopy(request); high=copy.deepcopy(request)
    for req,mem in [(low,.5),(high,.9)]:
        for worker in req['worker_loads']:
            req['worker_loads'][worker]={'cpu_used':.98,'mem_used_pct':mem,'fresh':True}
    base=baseline.decide(low);idle=engine.decide(low);pressure=engine.decide(high)
    assert base==idle, 'CPU98% with memory headroom should preserve complete response'
    assert any(a['dop']>b['dop'] for a,b in zip(base['decisions'],pressure['decisions']))
    assert all(a['dop']>=b['dop'] for a,b in zip(base['decisions'],pressure['decisions']))
    save('OFFLINE_CHECK.json',{'status':'passed','cpu98_memory50_exact_static_response':True,
        'cpu98_memory90_reduces_DOP_without_raising':True,'parameters_forwarded':engine.load_correction})
    os.sched_setaffinity(0,set(range(27,35)))
    nodes=workers();assert all(n['image_id']=='sha256:73548ebadb50d11fec58e9937ebd5ee189205fd8f1acf8359fc63923132c476b' for n in nodes)
    save('DEPLOYMENT.json',nodes)
    for attempt in range(20):
        try:check(OUT/f'IDLE_{attempt}.json');break
        except RuntimeError:
            if attempt==19:raise
            time.sleep(15)
    command=[sys.executable,str(SUPPORT/'collector_candidate.py'),'--manifest',str(manifest),'--trusted-collection',str(trusted),
        '--output-dir',str(OUT/'scored'),'--policy-model',model['model'],'--policy-variants',str(OUT/'variants.json'),
        '--modes',','.join(MODES),'--scenario','concurrent','--clients','16','--minimum-per-client','2','--warmup','1','--repetitions','1',
        '--seed',str(model['seed']),'--query-timeout-s','180','--auto-dop-max-dop','16','--torch-threads','1','--decision-timeout-ms','1000',
        '--metrics-urls','http://127.0.0.1:8040/metrics,http://127.0.0.1:8041/metrics,http://127.0.0.1:8042/metrics,http://127.0.0.1:8030/metrics']
    save('COMMAND.json',command);save('STATUS.json',{'status':'running','stage':'small_batch','pid':os.getpid()})
    stop=threading.Event()
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        observation=pool.submit(observe,OUT/'CPU.jsonl',2400,3,stop)
        try:
            with queue.settings_guard(OUT):subprocess.run(command,check=True)
        finally:stop.set();observation.result()
    subprocess.run([sys.executable,str(SUPPORT/'verifier_candidate.py'),'--collection-dir',str(OUT/'scored'),
                    '--output',str(OUT/'scored/independent_verification.json')],check=True)
    result=summarize()
    save('STATUS.json',{'status':'complete','screen_passed':result['screen_passed'],'at':datetime.datetime.now().astimezone().isoformat()})


if __name__=='__main__':
    if OUT.exists():raise SystemExit('Preserve existing screen directory')
    try:main()
    except BaseException as e:
        if OUT.exists():save('STATUS.json',{'status':'failed','error':repr(e),'pid':os.getpid()})
        raise
