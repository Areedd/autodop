"""Training-only error mining with fixed cohort and query sampling weights."""
import torch

def mine_pairs(model, train, graphs, by):
    assert train and all(s['split']=='train' for s in train)
    training_keys={(s['plan_key'],s['config_key']) for s in train}
    model.eval()
    with torch.no_grad():
        scores={k:float(model(graphs[k])) for k in sorted(training_keys)}
    assert all(torch.isfinite(torch.tensor(v)) for v in scores.values())
    hard={};counts={}
    for cohort,plans in by.items():
        hard[cohort]={};counts[cohort]={'pairs':0,'wrong_or_tied':0,'plans':len(plans),'plans_with_errors':0}
        for plan,pairs in plans.items():
            wrong=[]
            for p in pairs:
                fast=(plan,p['fast_config_key']);slow=(plan,p['slow_config_key'])
                assert fast in training_keys and slow in training_keys
                if scores[fast]<=scores[slow]:wrong.append(p)
            hard[cohort][plan]=wrong
            counts[cohort]['pairs']+=len(pairs);counts[cohort]['wrong_or_tied']+=len(wrong)
            counts[cohort]['plans_with_errors']+=bool(wrong)
    return hard,counts

def epoch_pairs(by,rng,hard):
    jobs=[]
    for cohort in ['historical','complex_new']:
        plans=sorted(by[cohort])
        for _ in range(312):
            plan=rng.choice(plans)
            pool=hard[cohort][plan] if rng.random()<.5 and hard[cohort][plan] else by[cohort][plan]
            jobs.append(rng.choice(pool))
    rng.shuffle(jobs)
    return jobs
