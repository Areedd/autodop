"""Query-grouped, development-only memory prediction screen; no SQL-ID lookup."""
import collections
import hashlib
import json
import math
import os
from pathlib import Path
import pickle
import time
import numpy as np
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'runs/report90_20260912'


def main():
    out=RUN/'native_memory_prediction_loo17';out.mkdir(exist_ok=False)
    os.sched_setaffinity(0,{35})
    save=lambda n,d:(out/n).write_text(json.dumps(d,indent=2,default=lambda v:v.item())+'\n')
    save('PROTOCOL.json',dict(scope='Grouped leave-one-query-out on historical development SQL; not independent test, not production prediction. '
         'All memory observations of held query excluded from fitting. Native physical-plan operator/environment features only; omit SQL/table IDs, DOP and runtime load.',
         targets='Maximum displayed upper-bound per-BE peak over both modes and warm/formal observations.',
         features='Real pre-admission CSV; select env/operations, exclude table IDs and var_0. Target covers both DOP modes.',
         models={'ridge':'StandardScaler(train fold), Ridge(alpha=1), log memory target',
                 'extra_trees':'64 trees, max_depth=4, min_samples_leaf=2, random_state=17, log target',
                 'neighbor_max3':'StandardScaler(train fold); max target among three nearest training queries',
                 'global_max':'maximum training target, conservative non-feature control',
                 'global_median':'median training target, non-feature control'},
         budget='max(64MiB, ceil(1.25 * predicted bytes)); constants unchanged from prior prototype.',
         exploratory_screen='No under-reservation on the 17 held-query observations and median reservation/observed peak <=2. '
                             'A pass permits new-query validation only, not deployment or a claimed guarantee.'))
    profile_path=RUN/'development17_memory_profiles_full/MEMORY_PROFILE_CHECK.json'
    profile=json.loads(profile_path.read_text());assert profile['status']=='verified'
    native_path=RUN/'native_memory_features17_full/RESULT.json'
    identity_path=RUN/'native_memory_features17_full/IDENTITY_AUDIT.json'
    native=json.loads(native_path.read_text());identity=json.loads(identity_path.read_text())
    assert identity['status']=='verified' and identity['records']==34
    assert all(v==['var_0'] for v in identity['dop0_vs4_different_columns'].values())
    names=[n for n in native['header'] if n.startswith('env_') or n.startswith('operators_')]
    selected=[native['header'].index(n) for n in names]
    records={r['id']:r for r in native['records'] if r['pipeline_dop']==4}
    ids=sorted(records);assert len(ids)==17
    X=np.array([[records[k]['values'][i] for i in selected] for k in ids],dtype=float)
    assert np.isfinite(X).all() and X.shape==(17,len(names))
    y=[]
    for key in ids:
        rows=[r for r in profile['rows'] if r['id']==key];assert len(rows)==4
        y.append(max(r['peak_per_node']['upper_bytes'] for r in rows))
    y=np.array(y,dtype=float)
    save('DATASET.json',dict(ids=ids,feature_names=names,features=X.tolist(),target_bytes=y.tolist(),
                             omitted_fields=['tables_0','tables_1','tables_2','var_0']))
    (out/'models').mkdir();scores=[];sources=[profile_path,native_path,identity_path,Path(__file__).resolve()]
    for held,key in enumerate(ids):
        train=np.array([i for i in range(17) if i!=held]);assert held not in train
        scaler=StandardScaler().fit(X[train])
        distances=np.linalg.norm(scaler.transform(X[train])-scaler.transform(X[[held]])[0],axis=1)
        neighbors=train[np.argsort(distances,kind='stable')[:3]]
        assert held not in neighbors
        predictions={'neighbor_max3':float(max(y[neighbors])),
                     'global_max':float(max(y[train])), 'global_median':float(np.median(y[train]))}
        training_seconds={}
        for kind,model in [('ridge',make_pipeline(StandardScaler(),Ridge(alpha=1))),
                            ('extra_trees',ExtraTreesRegressor(n_estimators=64,max_depth=4,
                              min_samples_leaf=2,random_state=17,n_jobs=1))]:
            start=time.monotonic();model.fit(X[train],np.log(y[train]));training_seconds[kind]=time.monotonic()-start
            pred=model.predict(X[[held]])
            path=out/'models'/f'{held:02d}_{kind}.pkl';path.write_bytes(pickle.dumps(model))
            replay=pickle.loads(path.read_bytes()).predict(X[[held]])
            assert np.array_equal(pred,replay)
            assert np.isfinite(pred).all() and -700<float(pred[0])<700
            predictions[kind]=float(np.exp(pred[0]));sources.append(path)
        for kind,pred in predictions.items():
            reservation=max(64*1024**2,math.ceil(1.25*pred))
            scores.append(dict(id=key,model=kind,train_ids=[ids[i] for i in train],
                               neighbors=[ids[i] for i in neighbors] if kind=='neighbor_max3' else None,
                               predicted_bytes=pred,observed_peak_bytes=float(y[held]),reservation_bytes=reservation,
                               under_reserved=reservation<y[held],reservation_ratio=reservation/y[held],
                               q_error=max(pred/y[held],y[held]/pred),training_seconds=training_seconds.get(kind)))
    summaries={}
    for kind in sorted({r['model'] for r in scores}):
        rows=[r for r in scores if r['model']==kind];assert len(rows)==17
        ratios=[r['reservation_ratio'] for r in rows]
        under=sum(r['under_reserved'] for r in rows)
        summaries[kind]=dict(under_reserved_queries=under,median_q_error=float(np.median([r['q_error'] for r in rows])),
                            median_reservation_ratio=float(np.median(ratios)),max_reservation_ratio=max(ratios),
                            exploratory_screen_passed=under==0 and np.median(ratios)<=2)
    result=dict(status='verified',scope='Development LOO screen; no new SQL, full-data fitting, prediction service or deployment.',
                summaries=summaries,rows=scores,all_learned_fold_models_exactly_reloaded=True,
                source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    save('RESULT.json',result)
    lines=['# 原生物理计划特征内存预测：17查询留一验证','',result['scope'],'',
           '| 方法 | 预算低于观测峰值 | 中位Q误差 | 中位预算/峰值 | 最大预算/峰值 | 开发筛查 |',
           '|---|---:|---:|---:|---:|---|']
    for kind,r in summaries.items():
        lines.append(f"| {kind} | {r['under_reserved_queries']}/17 | {r['median_q_error']:.2f} | {r['median_reservation_ratio']:.2f} | {r['max_reservation_ratio']:.2f} | {r['exploratory_screen_passed']} |")
    lines+=['','每折排除整条查询的全部profile标签；特征缩放仅拟合其余16条。单个目标取两模式四次历史观测最大值，显示舍入上界保留。',
            '这仍是共享数据和SQL构造方法的开发验证，不是未见结构独立测试；未低估这些观测不代表未来不会低估。',
            '此处使用原生CostPredictor实际发出的CSV，模型只读取env/operations字段；尚未部署或进行新查询验证。']
    (out/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps(summaries,indent=2,default=lambda v:v.item()))


if __name__=='__main__':main()
