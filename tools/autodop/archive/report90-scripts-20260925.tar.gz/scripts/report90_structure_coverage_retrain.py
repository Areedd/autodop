"""Train the frozen data-coverage comparison only after complete verified collection."""
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import time
import numpy as np
import torch
from report90_execute import ROOT,RUN
from report90_complex_retrain import read,save,key,validation,order,pair_index,epoch_pairs,xgb_rows,COHORTS
from report90_models import flat_features
from autodop.data import load_dataset
from autodop.graph import build_graph
from autodop.model import load_cost_model,save_checkpoint,dynamic_margin_ranking_loss
from autodop.training import select_partition,file_sha256

BASE=RUN/'structure_coverage20';OUT=BASE/'retrained'

def main():
    protocol=read(BASE/'RETRAIN_PROTOCOL.json')
    for p,expected in protocol['source_sha256'].items():assert file_sha256(p)==expected
    assert protocol['transformer']['learning_rate']==1e-4 and protocol['transformer']['preservation_weight']==0.0
    assert protocol['transformer']['epochs']==100 and protocol['transformer']['seed']==17
    OUT.mkdir(exist_ok=False);os.sched_setaffinity(0,{35});torch.set_num_threads(1)
    save(OUT/'STATUS.json',{'status':'running','stage':'waiting_verified_labels','pid':os.getpid()})
    while True:
        state=read(BASE/'labels_recovery/STATUS.json')
        if state['status']=='complete':break
        assert state['status']=='running',state
        pid=state['pid'];os.kill(pid,0)
        assert b'report90_structure_coverage_recover.py' in Path(f'/proc/{pid}/cmdline').read_bytes()
        time.sleep(15)
    save(OUT/'STATUS.json',{'status':'running','stage':'prepare_augmented_data','pid':os.getpid()})
    subprocess.run([sys.executable,str(ROOT/'scripts/report90_structure_coverage_prepare.py')],check=True)
    prepared=read(BASE/'prepared/RESULT.json');assert prepared['status']=='complete' and prepared['train_samples']==1365
    for p,expected in prepared['source_sha256'].items():assert file_sha256(p)==expected
    dataset=BASE/'merged_dataset';warm=BASE/'prepared/cost.pt'
    assert file_sha256(warm)==prepared['model_sha256']
    samples,pairs,meta=load_dataset(dataset);contract=read(dataset/'CONTRACT.json')
    train,tp=select_partition(samples,pairs,contract,'train');valid,_=select_partition(samples,pairs,contract,'valid')
    assert len(train)==1365 and len(valid)==212 and all(s['split']=='train' for s in train)
    by=pair_index(train,tp);historical=[s for s in train if s['source_cohort']=='historical']
    sources=[Path(__file__),ROOT/'scripts/report90_complex_merge.py',ROOT/'scripts/report90_models.py',
             BASE/'RETRAIN_PROTOCOL.json',BASE/'prepared/RESULT.json',warm,
             ROOT/'scripts/report90_complex_retrain.py',ROOT/'scripts/report90_structure_coverage_prepare.py',
             dataset/'samples.jsonl',dataset/'pairs.jsonl',dataset/'CONTRACT.json',dataset/'metadata.json']
    save(OUT/'EXECUTION_SOURCE_SHA256.json',{str(p):file_sha256(p) for p in sources})
    save(OUT/'CONTRACT.json',contract);save(OUT/'METADATA.json',meta)
    begin=time.perf_counter();graphs={key(s):build_graph(s,meta) for s in samples}
    teacher,ck=load_cost_model(warm);teacher.eval();assert ck['metadata']==meta
    with torch.no_grad():anchors={key(s):teacher(graphs[key(s)]).detach() for s in historical}
    raw={k:flat_features(g,meta) for k,g in graphs.items()}
    X=np.stack([raw[key(s)] for s in train]);mean=X.mean(0);std=X.std(0);std[std<1e-6]=1
    flat={k:(v-mean)/std for k,v in raw.items()};np.savez(OUT/'FEATURE_NORMALIZATION.npz',mean=mean,std=std)
    save(OUT/'PREPARATION.json',{'seconds':time.perf_counter()-begin,'train_samples':len(train),'valid_samples':len(valid),
        'pair_eligible_plans':{c:len(by[c]) for c in COHORTS},
        'plans_without_stable_pairs':sorted({s['plan_key'] for s in train}-{k for c in COHORTS for k in by[c]}),
        'historical_training_anchors':len(anchors),'flat_width':len(mean),'feature_normalization_fit_on_train_only':True})
    candidates=[]
    for index,lr in enumerate([1e-4]):
        folder=OUT/f'transformer_h{index}';folder.mkdir();torch.manual_seed(17);rng=random.Random(17)
        model,_=load_cost_model(warm);optimizer=torch.optim.Adam(model.parameters(),lr=lr)
        history=[];best=None;started=time.perf_counter()
        save(OUT/'STATUS.json',{'status':'running','stage':folder.name,'pid':os.getpid()})
        for epoch in range(1,101):
            model.train();jobs=epoch_pairs(by,rng);losses=[]
            for offset in range(0,len(jobs),16):
                optimizer.zero_grad();ranking=[]
                for pair in jobs[offset:offset+16]:
                    plan=pair['plan_key'];a=model(graphs[(plan,pair['fast_config_key'])]);b=model(graphs[(plan,pair['slow_config_key'])])
                    ranking.append(dynamic_margin_ranking_loss(a,b,pair['fast_latency_ms'],pair['slow_latency_ms']))
                chosen=[rng.choice(historical) for _ in range(16)]
                preservation=torch.stack([(model(graphs[key(s)])-anchors[key(s)]).square() for s in chosen]).mean()
                loss=torch.stack(ranking).mean()+0.0*preservation
                assert torch.isfinite(loss);loss.backward();optimizer.step();losses.append(float(loss.detach()))
            entry={'epoch':epoch,'loss':float(np.mean(losses))}
            if epoch%10==0:
                model.eval()
                with torch.no_grad():scores=[float(model(graphs[key(s)])) for s in valid]
                q=validation(valid,scores);entry['validation']=q
                if best is None or (*order(q),epoch)<best[0]:
                    best=((*order(q),epoch),{'epoch':epoch,'validation':q})
                    save_checkpoint(folder/'best.pt','cost',model,meta,{'contract':contract,'parent_sha256':file_sha256(warm),'protocol':str(BASE/'RETRAIN_PROTOCOL.json')})
            history.append(entry);save(folder/'PROGRESS.json',{'status':'running','history':history})
            if epoch%10==0:print(folder.name,epoch,entry['validation']['weighted_regret'],flush=True)
        result={'kind':'transformer','setting':index,'learning_rate':lr,'seconds':time.perf_counter()-started,
                'selected':best[1],'model':str(folder/'best.pt'),'model_sha256':file_sha256(folder/'best.pt'),'history':history}
        save(folder/'RESULT.json',result);candidates.append(result)
    import xgboost as xgb
    for paired in [False,True]:
        kind='xgboost_pairs' if paired else 'xgboost_points'
        xx,yy,groups,weights=xgb_rows(train,tp,flat,paired)
        for index,depth in enumerate([3,6]):
            folder=OUT/f'{kind}_h{index}';folder.mkdir();started=time.perf_counter()
            save(OUT/'STATUS.json',{'status':'running','stage':folder.name,'pid':os.getpid()})
            model=xgb.XGBRanker(objective='rank:pairwise',n_estimators=200,max_depth=depth,learning_rate=.05,
                n_jobs=1,random_state=17,tree_method='hist',subsample=1.,colsample_bytree=1.)
            model.fit(xx,yy,group=groups,sample_weight=weights)
            q=validation(valid,model.predict(np.stack([flat[key(s)] for s in valid])))
            model.save_model(folder/'model.ubj')
            result={'kind':kind,'setting':index,'seconds':time.perf_counter()-started,'training_rows':len(yy),
                'training_groups':len(groups),'group_weight_sum':float(weights.sum()),'selected':{'epoch':None,'validation':q},
                'model':str(folder/'model.ubj'),'model_sha256':file_sha256(folder/'model.ubj')}
            save(folder/'RESULT.json',result);candidates.append(result)
    selected={kind:min([c for c in candidates if c['kind']==kind],key=lambda c:(*order(c['selected']['validation']),c['setting']))
              for kind in ['transformer','xgboost_points','xgboost_pairs']}
    t=selected['transformer']['selected']['validation']
    gate=all(t['weighted_regret']<=c['selected']['validation']['weighted_regret'] and
             t['cohorts']['complex_new']['mean_regret']<=c['selected']['validation']['cohorts']['complex_new']['mean_regret']
             for kind,c in selected.items() if kind!='transformer')
    save(OUT/'RESULT.json',{'status':'complete','candidates':candidates,'selected':selected,'development_gate_passed':gate,
        'xgboost_version':xgb.__version__,'scope':'Validation selection only. No automatic SQL expansion or online model replacement.'})
    save(OUT/'STATUS.json',{'status':'complete','development_gate_passed':gate})


if __name__=='__main__':
    if OUT.exists():raise SystemExit('Preserve existing coverage retraining')
    try:main()
    except BaseException as error:
        if OUT.exists():save(OUT/'STATUS.json',{'status':'failed','error':repr(error),'pid':os.getpid()})
        raise
