"""Independently recount the frozen development pairs for the hard-pair pilot."""
import json
from pathlib import Path
import runpy
from report90_interaction_pair_audit import BASE, sha


def main():
    root = BASE/'hard_pair_pilot'
    assert json.loads((root/'RESULT.json').read_text())['status']=='verified'
    protocol = json.loads((root/'PROTOCOL.json').read_text())
    for path, digest in protocol['source_sha256'].items():
        assert sha(Path(path)) == digest
    boundary = json.loads((root/'SAMPLER_BOUNDARY_TEST.json').read_text())
    assert boundary['status'] == 'verified'
    assert boundary['sampler_sha256'] == sha(Path(__file__).with_name('report90_hard_pair_sampler.py'))
    original = Path(__file__).with_name('report90_interaction_pair_audit.py')
    changes = {
        "BASE = Path(__file__).resolve().parents[1]/'runs/report90_20260912/structure_coverage20'": 'BASE = Path('+repr(str(BASE))+')',
        "BASE/f'interaction_ranking/seed{seed}'": 'Path('+repr(str(root/'pilot'))+')',
        "BASE/f'interaction_pair_audit_seed{seed}'": 'Path('+repr(str(root/'pair_audit'))+')',
        'from report90_interaction_model import load_interaction_model as load_cost_model': 'from autodop.model import load_cost_model',
        "Path(__file__).with_name('report90_interaction_model.py')": 'Path('+repr(str(Path(__file__).resolve().parents[1]/'autodop/model.py'))+')',
        'sources = [Path(__file__),': 'sources = [Path(__file__), Path('+repr(str(original))+'), Path('+repr(str(Path(__file__)))+'),',
        'Interaction-augmented Transformer; unchanged flat controls.': 'Train-only50% hard-pair mining, seed17 30-epoch pilot; unchanged flat controls.',
    }
    text=original.read_text()
    for old,new in changes.items():
        assert text.count(old)==1,old
        text=text.replace(old,new)
    generated=root/'pair_audit_staged.py'; assert not generated.exists()
    compile(text,str(generated),'exec'); generated.write_text(text)
    (root/'AUDIT_TRANSFORM.json').write_text(json.dumps({'source_sha256':sha(original),'generated_sha256':sha(generated),'wrapper_sha256':sha(Path(__file__)),'changes':changes},indent=2)+'\n')
    runpy.run_path(str(generated),run_name='hard_pair_audit')['main'](17)
    result=json.loads((root/'pair_audit/RESULT.json').read_text())
    lines=['# 训练错对强化小测','', '原多阶段Transformer与竞争边整体保留，仅增加训练错对采样，保留查询与数据组的权重。固定seed17，30轮；原始1365训练样本、212验证样本和920有效查询对不变。未新增SQL，未使用报告查询选模。', '', '| 模型 | 两类等权准确率 | 汇总准确率 |','|---|---:|---:|']
    for kind,record in result['models'].items():
        lines.append(f"| {kind} | {100*record['macro_accuracy']:.3f}% | {100*record['pooled_accuracy']:.3f}% |")
    decision=json.loads((root/'RESULT.json').read_text())
    lines += ['',f"匹配的原采样对照两类等权准确率为{100*decision['reference_macro_accuracy']:.3f}%。扩大实验门槛通过：{decision['expansion_gate_passed']}。",'', '门槛要求同时超过原采样对照和XGBoost排序对照。此为反复使用的开发验证集小测，不构成三种子稳定领先或盲测结论。']
    (root/'REPORT.md').write_text('\n'.join(lines)+'\n')

if __name__=='__main__': main()
