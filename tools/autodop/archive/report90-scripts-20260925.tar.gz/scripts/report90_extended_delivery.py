"""Create an integrated extended report without overwriting the prior delivery."""
import hashlib
import json
from pathlib import Path
import re


RUN=Path(__file__).resolve().parents[1]/'runs/report90_20260912'
EXT=RUN/'distillation_concurrency_extension'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def checked(path):
    value=json.loads(path.read_text())
    for p,d in value.get('source_sha256',{}).items():assert sha(Path(p))==d,p
    return value


def main():
    checked(RUN/'FINAL_REPORT_AUDIT.json')
    result=checked(EXT/'EXTENSION_RESULT.json')
    assert 'sql' in result and 'concurrency' in result
    assert result['status']=='collected_and_audited; throughput_acceptance_separate'
    checked(EXT/'RESOURCE_AUDIT.json')
    figure_sources=json.loads((EXT/'figures/SOURCES.json').read_text())
    for p,d in figure_sources.items():assert sha(Path(p))==d,p
    original=(RUN/'FINAL_REPORT.md').read_text()
    original=original.replace('# AutoDOP 异构查询实验测试报告','# AutoDOP 异构查询实验测试报告（蒸馏与持续并发补充版）',1)
    intro='前九节保留前期实验范围；第十节补充匹配教师—学生与持续stream实验。采集完成、配置可部署和吞吐稳定验收分别判断。'
    original=original.replace('对应实验已完成；',intro+' ',1)
    original=original.replace('当前90查询报告范围的实验已完成，未新增生产代码或替换线上模型。',
        '前期90查询报告范围的实验已完成，前期未新增生产代码或替换线上模型；本轮缓存候选及新增测量见第十节。')
    original=original.replace('报告由 scripts/report90_final_delivery.py 从已完成产物生成，不执行SQL。',
        '前期报告由 scripts/report90_final_delivery.py 生成；本补充版由 scripts/report90_extended_delivery.py 整合，二者都不执行SQL。')
    extension=(EXT/'REPORT.md').read_text().split('\n',1)[1]
    extension=re.sub(r'^(#+) ',r'#\1 ',extension,flags=re.MULTILINE)
    def relocate(match):
        label,target=match.groups()
        if not target.startswith(('http:','https:','/','#')):target='distillation_concurrency_extension/'+target
        return f'[{label}]({target})'
    extension=re.sub(r'\[([^\]]*)\]\(([^)]+)\)',relocate,extension)
    checks=result['throughput_checks']
    acceptance=('本轮各档AutoDOP观测吞吐严格不下降；这是一轮持续窗口的观察，不是重复稳定性保证。'
        if checks['observed_policy_monotonic'] else
        '本轮存在AutoDOP吞吐下降点，尚未达到“各档观测平均吞吐严格不下降”；下降点完整保留。')
    headline=(f"本轮补充实验已收集并核验：学生本地决策加速{result['decision_speedup']:.2f}倍，固定配置SQL回放平均延迟降低{result['sql']['student_reduction']['mean']:.2%}。"
              +acceptance)
    original=original.replace('\n\n','\n\n'+headline+'\n\n',1)
    text=original+'\n## 10. 匹配蒸馏与持续并发补充\n\n'+acceptance+'\n'+extension
    text+='\n![匹配蒸馏的决策与SQL分布](distillation_concurrency_extension/figures/matched_distillation.png)\n'
    text+='\n![固定时间窗口吞吐与排队](distillation_concurrency_extension/figures/sustained_streams.png)\n'
    text+='\nBE资源旁路采样在首档开始后启动，首档覆盖不完整，后续按每档时间窗口对齐；缺失范围及原始指标见 [资源核验](distillation_concurrency_extension/RESOURCE_AUDIT.json)。\n'
    path=RUN/'FINAL_REPORT_EXTENDED.md';path.write_text(text)
    links=[]
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
        if target.startswith(('http:','https:','#')):continue
        target=target.split('#',1)[0].strip('<>');resolved=(RUN/target).resolve()
        assert resolved.exists(),target;links.append(str(resolved))
    sources=[Path(__file__),RUN/'FINAL_REPORT.md',RUN/'FINAL_REPORT_AUDIT.json',EXT/'REPORT.md',
             EXT/'EXTENSION_RESULT.json',EXT/'RESOURCE_AUDIT.json',EXT/'figures/SOURCES.json',path]
    audit=dict(status='verified_integrated_extension_report',local_links_checked=len(links),
        throughput_checks=checks,scope='Prior delivery preserved. Collection status does not imply deployment or throughput acceptance.',
        source_sha256={str(p):sha(p) for p in sources})
    (RUN/'EXTENDED_REPORT_AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n');print(path)


if __name__=='__main__':main()
